from pathlib import Path
import json
r=Path(__file__).resolve().parent
b=r/'browser-final'
report=json.loads((b/'browser-report.json').read_text())
assert len(report['cases'])==4 and all(c['pass'] for c in report['cases']) and report['failures']==[]
assert len(report['geometry'])==20
pairs=[]
for before in sorted(b.glob('*-rank*-before-*.json')):
 prefix=before.name.rsplit('-before-',1)[0]
 after=list(b.glob(prefix+'-after-*.json'));assert len(after)==1
 a=json.loads(before.read_text());z=json.loads(after[0].read_text())
 assert a['version']==z['version']==22
 for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==z[domain],(prefix,domain)
 rank=19 if '-rank19' in prefix else 20
 assert z['player']['skillLevels']=={'druid.oak_sage':1,'druid.heart_of_wolverine':1,'druid.spirit_of_barbs':rank}
 assert z['player']['skillPoints']==(1 if rank==19 else 0)
 assert z['player']['comboOrder']==[]
 for field in ['spiritOfBarbs','barbsSpiritId','vigorLife']:assert field not in json.dumps(z)
 pairs.append({'label':prefix,'before':before.name,'after':after[0].name,'fiveDomainsExact':True,'rank':rank})
assert len(pairs)==8
out={'pass':True,'browserCases':4,'geometrySamples':20,'pairs':pairs,'pairCount':8,
 'scope':'Constructed L30 public imported saves only; no earned progression or independent QA acceptance.'}
(r/'browser-attachment-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':True,'browserCases':4,'geometrySamples':20,'exactFiveDomainPairs':8}))
