# Root self-review: Druid fire / BUG190

Scope: D04-druid-fire-dot-v1; five explicit JSON potencies and shared truthful Burn presentation. This is root self-review, not independent design or QA acceptance.

- Correctness: reviewed the 15 original missing-HP failures and 10 passing resource/miss controls; actual registry spells now use existing canonical status integration. Literal independent seed-7 hits at ranks 1/2/20, exact HP and 4700ms expiry, floor, resistance/increase composition, weapon Attack independence, Molten Boulder first-two versus all-enemy targets, cooldown fallback/boundary, old-rate retention and rate-less promotion are covered. Native current-class/full-chain/rank/MAX-alias checks exercise actual casts.
- Readability: the production change is five explicit JSON fields, one schema guard and one pure display resolver plus localized rendering. No copied combat loops, new runtime abstractions or dependencies.
- Architecture: existing metadata adapter/status pipeline retained, engine pure, save22 and persistence representation unchanged. Shared renderer also clarifies already-authored Fire Bolt/Meteor Burn without new skill credit.
- Security: no secrets, network/permissions/CI/dependencies/publication changes. Strict positive finite data and native ownership remain.
- Performance: no new combat scheduling or RNG; one small display computation per selected rank. Full test-duration budgets, chunk/PWA warnings and real-device performance remain open.

Corrections before final verification: strictRequired schema damage reference; test fixture Fire flat mitigation must use Defense; fixed synthetic hero identity for alias comparisons; authored priority arrays versus canonical cast IDs; exact optional-property representation and exclusive status unions; standard lint hygiene. Original logs retained. Fire Bolt hit prose remains independently readable, with new Burn prose in a separate paragraph; the old exact-description assertions remain unchanged. The former Firestorm no-rate test was intentionally replaced by an explicitly rate-less registered copy, retaining no-global-fallback verification under the new explicit contract.

Remaining: provisional 10% tuning needs earned class/build balance; independent review/QA, actual campaign/Baal, C2-C4 and full G0-G7 remain open. Existing small-screen header/nav occlusion, nested below-fold panels, icon/font fallbacks, generic shared DoT visual FX and full a11y/PWA/performance are not accepted by this patch. No genuine save promotion or campaign action.
