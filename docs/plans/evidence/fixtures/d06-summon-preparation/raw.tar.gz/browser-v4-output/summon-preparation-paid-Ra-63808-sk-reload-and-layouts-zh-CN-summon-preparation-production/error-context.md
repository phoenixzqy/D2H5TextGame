# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: summon-preparation.spec.ts >> paid Raven native allocation, startup, disk reload and layouts zh-CN
- Location: tests/pwa/summon-preparation.spec.ts:66:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  80  |         rarity: 'rare',level: 1,identified: true,equipped: true,equipSlot: 'head',
  81  |         affixes: [{ affixId: 'fixture-imported-survival-mana',values: new Map([
  82  |           ['statMods.life',999810],['statMods.mana',900],['statMods.defense',99958]
  83  |         ]) }] };
  84  |       // Explicitly imported eligibility/survival scaffold; no earned progression or balance claim.
  85  |       const eligible: SaveCurrent = { ...fresh,player: { ...fresh.player,level: 6,skillPoints: 2,
  86  |         skillLevels: {},comboOrder: [],derivedStats: { ...fresh.player.derivedStats,
  87  |           life: 900000,lifeMax: 1000000,mana: 300,manaMax: 1000,attack: 30,defense: 100000,attackSpeed: 120 } },
  88  |         inventory: { ...fresh.inventory,equipped: { ...fresh.inventory.equipped,head: cap } } };
  89  |       const importLabel = english ? 'Import Save' : '导入存档';
  90  |       await page.getByRole('button',{ name: importLabel,exact: true }).click();
  91  |       const dialog = page.getByRole('dialog');
  92  |       await dialog.getByRole('textbox').fill(JSON.stringify(eligible, (_key,value: unknown) => value instanceof Map ? [...value] : value));
  93  |       await dialog.getByRole('button',{ name: importLabel,exact: true }).click(); await expect(dialog).toHaveCount(0);
  94  |       const prepared = await backup(page); expect(prepared.player).toEqual(eligible.player);
  95  |       await attach(info,'01-imported-eligibility-and-gear',{ fresh,prepared });
  96  |       await navTo(page,'map');
  97  |       await page.getByTestId('sub-area-row-a1-blood-moor').getByRole('button',{ name: english ? 'Enter' : '进入',exact: true }).click();
  98  |       await expect(page.getByTestId('combat-screen')).toBeVisible(); await pause(page,english);
  99  |       const before = await combatSnapshot(page); expect(before.cards.length).toBeGreaterThan(1);
  100 |       expect(await page.locator('[data-kind="summon"]').count()).toBe(0);
  101 |       await attach(info,'02-paused-wave-before-allocation',before);
  102 |       for (const rank of [1,2]) {
  103 |         const panel = await detail(page), allocate = panel.getByRole('button',{ name: text.allocate,exact: true });
  104 |         await allocate.focus(); await expect(allocate).toBeFocused(); await page.keyboard.press('Enter');
  105 |         const current = section(panel,page,text.current), next = section(panel,page,text.next);
  106 |         await expect(current.getByText(text.cap,{ exact: true }).locator('+ dd')).toHaveText(String(rank));
  107 |         await expect(current.getByText(text.mana,{ exact: true }).locator('+ dd')).toHaveText('6');
  108 |         await expect(next.getByText(text.cap,{ exact: true }).locator('+ dd')).toHaveText(`${String(rank+1)}(+1)`);
  109 |         await expect(next.getByText(text.mana,{ exact: true }).locator('+ dd')).toHaveText('6');
  110 |         if (rank === 2) await expect(panel).toContainText(text.description);
  111 |         const allocated = await backup(page);
  112 |         expect(allocated.player).toEqual({ ...prepared.player,skillPoints: 2-rank,skillLevels: { [SKILL]: rank } });
  113 |         await navTo(page,'combat');
  114 |         await expect(page.getByRole('button',{ name: english ? 'Resume' : '继续',exact: true })).toHaveAttribute('aria-pressed','true');
  115 |         const after = await combatSnapshot(page); expect(after).toEqual(before);
  116 |         await attach(info,`03-native-allocation-${String(rank)}`,{ allocated,after });
  117 |       }
  118 |       await navTo(page,'skills'); await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  119 |       const slot = page.getByRole('combobox',{ name: english ? 'Slot 1' : '槽位 1',exact: true });
  120 |       await expect(slot).toHaveValue(''); await expect(slot.locator(`option[value="${NODE}"]`)).toHaveCount(1);
  121 |       await slot.selectOption(NODE); await expect(slot).toHaveValue(NODE); // Explicit native combo replay.
  122 |       const observer = await page.evaluateHandle(mpLabel => {
  123 |         const frames: Frame[] = []; let previous = '', overflow = false;
  124 |         const sample = (): void => {
  125 |           const root = document.querySelector('[data-testid="combat-screen"]'); if (!root) return;
  126 |           const bar = root.querySelector(`[role="group"][aria-label="${mpLabel}"] [role="progressbar"]`);
  127 |           const frame: Frame = { mp: Number(bar?.getAttribute('aria-valuenow')),max: Number(bar?.getAttribute('aria-valuemax')),
  128 |             ravens: Array.from(root.querySelectorAll<HTMLElement>('[data-testid^="unit-card-"][data-testid*="-summon-raven-"]'),node => ({
  129 |               id: node.dataset.testid ?? '',lifeWidth: node.querySelector<HTMLElement>('.bg-red-600')?.style.width ?? '' })),
  130 |             logs: Array.from(root.querySelectorAll('[data-testid="combat-log"] > div > span:last-child'),node => node.textContent ?? '').slice(-8) };
  131 |           const serialized = JSON.stringify(frame); if (serialized === previous) return; previous = serialized;
  132 |           if (frames.length === 128) { overflow = true; return; } frames.push(frame);
  133 |         };
  134 |         const changes = new MutationObserver(sample);
  135 |         changes.observe(document.body,{ childList: true,subtree: true,attributes: true,characterData: true });
  136 |         return { read: () => ({ frames,overflow }),disconnect: () => changes.disconnect() };
  137 |       },text.mp);
  138 |       try {
  139 |         await navTo(page,'combat');
  140 |         const ravens = page.locator('[data-testid^="unit-card-"][data-testid*="-summon-raven-"]');
  141 |         await expect(ravens).toHaveCount(2,{ timeout: 1500 }); await pause(page,english);
  142 |         const observation = await observer.evaluate(handle => handle.read());
  143 |         await attach(info,'04-ordinary-DOM-paid-two-raven-startup',observation);
  144 |         expect(observation.overflow).toBe(false);
  145 |         expect(observation.frames.some(frame => frame.mp === 300 && frame.max === 1000 && frame.ravens.length === 0)).toBe(true);
  146 |         const batch = observation.frames.find(frame => frame.ravens.length === 2);
  147 |         expect(batch).toBeDefined(); expect(batch).toMatchObject({ mp: 294,max: 1000 });
  148 |         expect(new Set(batch?.ravens.map(raven => raven.id)).size).toBe(2);
  149 |         expect(batch?.ravens.map(raven => raven.lifeWidth)).toEqual(['100%','100%']);
  150 |         const cast = english ? `${NAME} casts Raven.` : `${NAME} 施放了 乌鸦。`;
  151 |         const summon = english ? `${NAME} summons Raven.` : `${NAME} 召唤了 乌鸦。`;
  152 |         expect(batch?.logs.filter(line => line === cast)).toHaveLength(1);
  153 |         expect(batch?.logs.filter(line => line === summon)).toHaveLength(2);
  154 |         expect(batch?.logs[0]).toBe(english ? 'Turn 1 begins' : '第 1 回合开始');
  155 |         await production(page);
  156 |       } finally { await observer.evaluate(handle => handle.disconnect()); await observer.dispose(); }
  157 |       await page.getByRole('button',{ name: english ? 'Flee' : '逃跑',exact: true }).click();
  158 |       const panel = await detail(page), metrics = [];
  159 |       await expect(panel).toContainText(text.description);
  160 |       for (const [width,height] of sizes) {
  161 |         await page.setViewportSize({ width,height }); const controls = [];
  162 |         for (const target of [page.getByTestId(`skill-node-${NODE}`),panel.getByRole('button')]) {
  163 |           await target.scrollIntoViewIfNeeded(); const bounds = await target.boundingBox(); expect(bounds).not.toBeNull();
  164 |           expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  165 |           controls.push({ bounds,hits: await hitGrid(target) });
  166 |         }
  167 |         const description = panel.getByText(text.description,{ exact: true });
  168 |         await description.scrollIntoViewIfNeeded(); await expect(description).toBeVisible();
  169 |         const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  170 |         expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14); await production(page);
  171 |         const headingHits = await hitGrid(panel.getByRole('heading',{ name: text.name,exact: true }));
  172 |         if (!english && width === 360) {
  173 |           const cdp = await context.newCDPSession(page);
  174 |           try {
  175 |             await cdp.send('DOM.enable'); await cdp.send('CSS.enable'); const doc = await cdp.send('DOM.getDocument');
  176 |             const node = await cdp.send('DOM.querySelector',{ nodeId: doc.root.nodeId,
  177 |               selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  178 |             const fonts = await cdp.send('CSS.getPlatformFontsForNode',{ nodeId: node.nodeId });
  179 |             await attach(info,'05-actual-Chinese-fonts',fonts);
> 180 |             expect(fonts.fonts.some(f => f.familyName === 'Noto Sans CJK SC' && f.glyphCount > 0)).toBe(true);
      |                                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  181 |           } finally { await cdp.detach(); }
  182 |         }
  183 |         if (width === 360 || width === 1280) await info.attach(`detail-${String(width)}x${String(height)}`,{ body: await page.screenshot(),contentType: 'image/png' });
  184 |         metrics.push({ width,height,font,controls,headingHits });
  185 |       }
  186 |       await attach(info,'05-finite-layout-metrics',metrics); await page.setViewportSize({ width: 1280,height: 800 });
  187 |       const saved = await backup(page);
  188 |       expect(saved.player).toEqual({ ...prepared.player,skillPoints: 0,skillLevels: { [SKILL]: 2 },comboOrder: [NODE] });
  189 |       await page.getByRole('button',{ name: english ? 'Save' : '保存',exact: true }).click();
  190 |       await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  191 |       await page.close(); page = await context.newPage(); watch(page); await page.clock.setFixedTime(fixedTime);
  192 |       await page.goto('/'); await page.getByTestId('home-continue').click(); await expect(page.getByTestId('town-screen')).toBeVisible();
  193 |       const loaded = await backup(page); expect(loaded).toEqual(saved);
  194 |       await attach(info,'06-explicit-save-close-newpage-continue',{ saved,loaded });
  195 |       await expect(await detail(page)).toContainText(text.description);
  196 |       await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  197 |       await expect(page.getByRole('combobox',{ name: english ? 'Slot 1' : '槽位 1',exact: true })).toHaveValue(NODE);
  198 |       await attach(info,'07-console-errors',errors); expect(errors).toEqual([]); await production(page);
  199 |     } finally { await page.close(); }
  200 |   });
  201 | }
  202 | 
```