from pathlib import Path
import datetime,gzip,hashlib,io,json,stat,subprocess,tarfile
w=Path.cwd();raw=Path(__file__).resolve().parent
assert w==Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert subprocess.check_output(['git','status','--porcelain'],text=True)==' M docs/design/skills-spec.md\n'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
freeze=json.loads((raw/'browser-execution-freeze-v6.json').read_text())
closure=json.loads((raw/'closure-v2-freeze.json').read_text())
reconciliation=json.loads((raw/'archive-reconciliation-freeze.json').read_text())
sourceNames=sorted(set(freeze['files'])|set(closure['files'])|{'docs/plans/execution-ledger.md'})
sources={}
for name in sourceNames:
 q=w/name;assert not q.is_symlink() and q.is_file();b=q.read_bytes();sources[name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
# Closure legitimately replaces only its four existing documents and adds evidence.
for name,v in freeze['files'].items():
 if name not in closure['files'] and name not in reconciliation['files']:assert sources[name]==v,name
for name,v in closure['files'].items():assert sources[name]==v,name
for name,v in reconciliation['files'].items():assert sources[name]==v,name
births=set();commandRecords=[]
for q in sorted(raw.glob('*.meta.json')):commandRecords.append({'path':q.name,**json.loads(q.read_text())})
for q in raw.glob('*.processes.json'):
 for row in json.loads(q.read_text())['observations']:births.add((row['pid'],row['startTicks']))
for pid,ticks in births:
 try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=ticks,(pid,ticks,fields[0])
inv=json.loads((raw/'names-output-inventory.json').read_text());outputs=[v['path'] for v in inv['files']]+[n for n in inv['directories'] if Path(n).is_relative_to(w/'dist')]
for name in outputs:
 q=Path(name);assert not q.exists() and not q.is_symlink(),name
assert subprocess.check_output(['git','status','--porcelain'],cwd='/home/felixzhao/workspace/D2H5TextGame',text=True)==''
files=[];dirs=[]
for q in sorted(raw.rglob('*')):
 mode=q.lstat().st_mode;assert not stat.S_ISLNK(mode),q
 if stat.S_ISREG(mode):
  b=q.read_bytes();files.append({'path':str(q.relative_to(raw)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 elif stat.S_ISDIR(mode):dirs.append(str(q.relative_to(raw)))
 else:raise RuntimeError('Unexpected raw type: '+str(q))
fixture=w/'docs/plans/evidence/fixtures/d06-summon-preparation';assert not fixture.exists();fixture.mkdir()
archive=fixture/'raw.tar.gz'
with archive.open('xb') as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for v in files:
    b=(raw/v['path']).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
    info=tarfile.TarInfo(v['path']);info.size=len(b);info.mode=0o600;info.mtime=0;tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(files) and {m.name for m in members}=={v['path'] for v in files}
 expected={v['path']:v for v in files}
 for m in members:
  assert m.isfile();b=tf.extractfile(m).read();v=expected[m.name];assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'];assert b==(raw/m.name).read_bytes()
b=archive.read_bytes()
packet={'task':'D06 v1b paid external-input-free summon preparation + BUG071','sourceHead':head,'sourceCommits':['5dbe443','52d8cf8','51a82f9','3538184','b8fa9e9','0e7a8ed'],'browserCommit':'bff2a70551e404c277b322f40a70afa1fab3cabe','rawRoot':str(raw),'owner':'root','archive':{'path':'raw.tar.gz','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'files':len(files),'originalBytes':sum(v['bytes'] for v in files),'roundtripVerified':True},'rawManifest':files,'rawDirectories':dirs,'finalClosureVerification':{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'closureCommit':head,'files':sources},'processAudit':{'commandRecords':len(commandRecords),'uniqueBirths':len(births),'remainingIncludingZ':[],'historicalSignals':'Two exact-owned-PID SIGTERM entries in unit-b2-v2 metadata for reviewed abort after 0.201356s lint/unit overlap; no aborted-run pass or report claimed','records':commandRecords},'disposableOutputsAbsent':outputs,'validation':{'unitPassed':5805,'unitFiles':207,'browserPassed':2,'finalScreenshotsViewedByQA':4,'finiteLayoutsPerLocale':9,'locales':['en','zh-CN'],'fullUnitsSeconds':98.268,'unitBoundSeconds':120,'ordinaryUnitTargetSeconds':15,'browserRunnerSeconds':24.377,'engineCoverage':'94.63% lines/statements,93.85% functions,91.29% branches; thresholds unchanged'},'preserved':'All actual RED/failed/aborted/successful attempts, unexecuted drafts and corrections, source/evidence reviews, coverage, original browser base64 attachments and extracted copies, font-environment diagnostics and task-only cache, freezes, process observations and cleanup receipts','scope':'Thirteen-skill paid preparation plus supported-name fix, imported-scaffold native browser/save/finite Chromium layouts; fullD06/P09,corpse3,selected-itemIron,earnedcampaign,balance,fulla11y,offline,performance,private-v1/C0-C4/G0-G7 open','rawCleanup':{'status':'pending','owner':'root','requires':'Independent durable review and committed archive, exact manifest/live bytes/final source/output/process/original checks; remove only exact manifest files and empty childdirs, retain empty RAWroot/sharedparents/source/history/fonts/tools'},'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independentDurableReview':{'verdict':'pending'}}
(fixture/'packet.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':packet['archive'],'sourceFiles':len(sources),'commands':len(commandRecords),'births':len(births),'rawDirectories':len(dirs)}))
