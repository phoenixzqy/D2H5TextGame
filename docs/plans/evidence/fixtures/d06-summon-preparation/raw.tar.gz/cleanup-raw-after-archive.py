from pathlib import Path
import datetime,hashlib,json,stat,subprocess,tarfile
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd()==w
packetPath=w/'docs/plans/evidence/fixtures/d06-summon-preparation/packet.json'
p=json.loads(packetPath.read_text());raw=Path(p['rawRoot'])
assert raw==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-summon-preparation-cijxqtry') and raw.is_dir() and not raw.is_symlink()
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive=packetPath.parent/p['archive']['path'];blob=subprocess.check_output(['git','show',head+':'+str(archive.relative_to(w))])
assert blob==archive.read_bytes() and len(blob)==p['archive']['bytes'] and hashlib.sha256(blob).hexdigest()==p['archive']['sha256']
assert p['rawCleanup']['status']=='pending' and p['independentDurableReview']['verdict']=='APPROVE'
for name,v in p['finalClosureVerification']['files'].items():
 q=w/name;assert not q.is_symlink() and q.is_file();b=q.read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'],name
births=set()
for record in raw.glob('*.processes.json'):
 for row in json.loads(record.read_text())['observations']:births.add((row['pid'],row['startTicks']))
assert len(births)==p['processAudit']['uniqueBirths']
for pid,ticks in births:
 try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=ticks,(pid,ticks,fields[0])
for name in p['disposableOutputsAbsent']:
 q=Path(name);assert not q.exists() and not q.is_symlink(),name
assert subprocess.check_output(['git','status','--porcelain'],cwd='/home/felixzhao/workspace/D2H5TextGame',text=True)==''
expected={v['path']:v for v in p['rawManifest']};actual={};dirs=[]
for q in raw.rglob('*'):
 mode=q.lstat().st_mode;assert not stat.S_ISLNK(mode),q
 if stat.S_ISREG(mode):actual[str(q.relative_to(raw))]=q
 elif stat.S_ISDIR(mode):dirs.append(str(q.relative_to(raw)))
 else:raise RuntimeError('Unexpected raw member: '+str(q))
assert set(actual)==set(expected) and set(dirs)==set(p['rawDirectories'])
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(expected) and len({m.name for m in members})==len(members)
 for m in members:
  assert m.isfile() and m.name in expected and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,m.name
  b=tf.extractfile(m).read();v=expected[m.name];assert m.size==len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'];assert actual[m.name].read_bytes()==b,m.name
# All guards complete before mutation. Exact manifest files and derived empty child directories only.
for name in sorted(actual):actual[name].unlink()
for name in sorted(dirs,key=lambda n:len(Path(n).parts),reverse=True):(raw/name).rmdir()
assert raw.is_dir() and list(raw.iterdir())==[]
p['rawCleanup']={'status':'complete','owner':'root','archiveCommit':head,'verifiedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freshChecks':'committedarchive/allmembers/exactliveRAWset/finalsources/processbirthsincludingZ/outputabsence/originalcheckout/readersreleased','removedFiles':len(actual),'removedBytes':sum(v['bytes'] for v in expected.values()),'removedEmptyChildDirectories':len(dirs),'remainingFiles':0,'retainedEmptyRoot':str(raw),'failures':[]}
packetPath.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(p['rawCleanup']))
