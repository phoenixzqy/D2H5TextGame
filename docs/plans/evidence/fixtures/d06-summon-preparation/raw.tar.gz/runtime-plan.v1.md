# D06 v1b implementation plan draft

Root sole writer/executor; no source/runtime edits yet. Three-doc approved policy
must be committed before source changes. Existing identity/D04/D05 contracts remain.
Security check: pass for local deterministic skill policy; no network, credentials,
dependencies, permissions, CI or save schema change. Policy metadata is not tuning.

Representation proposal: one small pure TS module engine/skills/summon-preparation.ts
exports immutable exact 13 canonical IDs and isPreparationSummonSkill(skill), matching
resolved canonical skill.id. No new schema field, RegisteredSkill flag, generic summon
framework or unit/save metadata. A synthetic differently named skill sharing an authored
template does not opt in. Existing registry alias resolution precedes this predicate.
Runtime State owns Map<ownerId,Set<templateId>> for authoritative enabled pairs, populated
from valid eligible scoped startup sources before affordability/full-cap decisions; no
module-global mutable state. Only that pair suppresses refunds (preloaded included).
Invalid/unslotted scoped sources cannot establish a pair; ordinary scoped recasts are
always skipped. A production adapter filters only those 13 entries from comboOrder when
not in the character class data, not learned at positive finite integer rank, below
required level, or missing positive finite prerequisites. Preserve all other entries and
original ordering/aliases; engine's generic rank1 fallback is retained for standalone
snapshots without player eligibility data. Allocated aliases use existing helpers.

Increment A (3paths): new policy module, stores/combatHelpers.ts, new focused adapter
test. Actual RED against unchanged adapter can use canonical literal scope in tests;
install helper+adapter only after frozen independent test review. Tests exercise all13
resolved canonical/authored aliases, learned/slotted/rank source, unlearned/belowlevel/
prereq/foreignclass/unslotted exclusions and unrelated/excluded/synthetic preservation.
No engine runtime changes in A, no full summon-preparation acceptance. Run focused,
types/lint/fullunits/cleanproductionbridgebuild; engine tier after helper addition per
repo rule. Exact tier bounds need review before execution (prior engine suites exceed3s).

Increment B (2paths): engine/combat/combat.ts and new summon-preparation.test.ts. Use
shared exact-ID predicate. Extend canUseSkillForState with explicit startup scope or
separate common eligibility path; skip scoped skills in ordinary choice unconditionally,
ignore only their carried own cooldown during startup. Preserve excluded/synthetic path.
At startup dedup canonical scoped aliases in owner/skill insertion order; dead owners and
initially terminal battles skip preparation only. Require exactly one valid summon effect
for these 13 authored sources; unknown/malformed source is an atomic no-op. Compute current
living owner/template count and authored cap/rank. Zero missing leaves all state/events/CD
unchanged. Validate/build every missing template before payment, then commit one normal
cast/mana event and ordinary cooldown once, and register all prepared units/time0 events.
Extract only the existing summon placement/registration/scheduling code to a local helper
so ordinary single spawns and prepared batches share collision-safe identity/grid/D05
empowerment. Do not repeatedly invoke castSkill (would repeatedly charge). No new stats,
RNG consumption, scheduler turns, resets/refills or template-family cap. Existing death
handler gets one pair check around the legacy refund/CD-clear block; all other death,
orb/status/orphan ordering untouched. Validate source/template before setting pair; set
even when full/insufficient to stop free refunds for matching preloaded summons.

Independent literal B proofs before production edits: 13skills, singleton/multicap ranks
1/2/3/6/20→1/2/3/4/8 at time0, actual rounded ranked mana once, CD once, stable owner/skill
order+alias dedup; damaged/statused/id-positioned living preloads unchanged, dead IDs
reserved, partial and zero-missing; no debit/spawn/retry after insufficiency/invalid
source (including future regen/orbs); only own staleCD ignored; next active/basic ordinary
fallback; scoped new/preloaded deaths no refund/replacement while same-template synthetic
negative control and excluded Skeleton replacement retain prior behavior; dead/terminal
scoped no-op with excluded/synthetic startup controls; exact input immutability, recorded
vs plain/A-A/A-B-A replay equivalence. No weakening existing resummon tests. Production
integration proves adapter+runtime, next-wave actual mana carry/new preparation/no refill.
Review exact concrete tests/source before installation; actual RED then green, focused,
engine,types,lint,full,cleanbuild+requiredcoverage under explicit bounded budgets, serial,
no source edits during gates. No broader simulation/farming/search.

Increment C later: bilingual player-visible start-only paid-batch detail and a focused
production browser contract (native learning/combos/actual startup resources, explicit
save/reload, mobile/desktop/CJK) after runtime review. Imported eligibility stays labeled
scaffolding. No cast/campaign/balance/fullD06 claim before observed evidence. Evidence/
control/ledger/bug reporting in separate≤5path committed increments. Lossless RAW archive
and exact task-owned output/RAW cleanup after independent review. No remote action.
