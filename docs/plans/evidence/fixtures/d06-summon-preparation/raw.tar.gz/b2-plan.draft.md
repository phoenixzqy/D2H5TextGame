# D06 B2 proposed integration slice

Root sole writer/executor in claimed worktree; at most new
src/stores/summon-preparation-native.test.ts. No production changes unless an
observed integration defect is separately diagnosed/reviewed. Follow committed
D06 policy and runtime-plan.v2.md. Existing thirteen-ID adapter/runtime complete.

Use real stores, playerToCombatUnit, startSubAreaRun, recorded playback/drain,
advanceWaveOrFinish, actual allocation and combo setters/refresh. Only save disk
I/O may be mocked. Reset persistence/run/pity/all stores/registry and fixed Date.now
between tests. Imported class level, ranks/points, equipped high-life/mana/defense
gear and synthetic deterministic finisher are labeled scaffolding, never earned
campaign/balance acceptance. Actual map/enemy/wave/reward and summon paths remain.

Proposed four concepts:
1. Unlearned slotted Raven is filtered; native authored learn then canonical
upgrade preserve frozen recording/event-array identity and every captured state
with default no-replay refresh. Next waves use rank1/count1 then rank2/count2,
one literal 6MP time-zero payment per batch, fresh summons and carried resources.
2. Imported Raven20 yields eight units and literal4MP once each wave. Every new
wave input has no summons and exact prior terminal hero life/mana/all three carry
fields, with below-cap mana rather than a refill. Cooldown from prior outcome is
carried and own stale cooldown does not prevent fresh preparation.
3. Low initial mana causes no startup payment/summon, no late retry after actual
regen/orbs; later wave pays once from actual now-affordable carried mana.
4. Native combo changes with explicit replay rebuild event-array identity and
change preparation; removing/readding slots replays from original prepayment
baseline, deterministic A-B-A and no duplicate rewards. Default refresh remains
no replay. Do not claim explicit combo replay preserves the recording.

Concrete draft tests require serial independent QA/design review before install.
These are post-runtime integration acceptance tests; do not claim they produced
runtime RED. Existing runtime frozen V5 RED provenance remains unchanged. Focused
30s; types/lint90s; full120s; build210s if required by review. No new engine edits,
no broad balance/farming/browser matrix in B2. Preserve exact command reports and
process/output inventories; guarded cleanup only after readers release. Commit
before C bilingual/browser work. Full D06/P09 and external-input summons stay open.
