# D06 v1b implementation plan V2 draft

Root sole writer/executor; no source/runtime edits yet. Three-doc approved policy
is committed at5dbe443 before source changes. Existing identity/D04/D05 contracts remain.
Security check: pass for local deterministic skill policy; no network, credentials,
dependencies, permissions, CI or save schema change. Policy metadata is not tuning.

Representation proposal: one small pure TS module engine/skills/summon-preparation.ts
exports an immutable exact thirteen-entry canonical ID→expected-template mapping
and isPreparationSummonSkill(skill), matching resolved canonical skill.id. The three
existing multi-cap skills are explicitly identified; all other scoped caps remain1. No new schema field, RegisteredSkill flag, generic summon
framework or unit/save metadata. A synthetic differently named skill sharing an authored
template does not opt in. Existing registry alias resolution precedes this predicate.
Runtime State owns Map<ownerId,Set<templateId>> for authoritative enabled pairs, populated
from valid eligible scoped startup sources before affordability/full-cap decisions; no
module-global mutable state. Only that pair suppresses refunds (preloaded included).
Invalid/unslotted scoped sources cannot establish a pair; ordinary scoped recasts are
always skipped. A production adapter filters only those 13 entries from comboOrder when
not in character class data, unlearned, below required level, or missing prerequisites.
Player level must be a positive finite integer. Resolve each allocated canonical/authored
alias independently: only finite integers1..that authored skill.maxLevel count; ignore
invalid aliases, choose the maximum valid alias, exclude when none valid. Do not clamp
invalid/out-of-cap allocations into a learned skill. Resolve prerequisites against same-
class authored templates with the same validation; unknown/malformed/missing/zero-only
prerequisites fail. Retain original order/slot aliases, but normalize each retained scoped
skill's COPIED skillLevels: remove its canonical+authored aliases and write exactly one
validated canonical rank. Player and all unrelated ranks remain untouched. Conflicting
canonical1/authored20 becomes copiedcanonical20; invalidNaN/1.5/>20 alias with valid2
uses2; invalid-only excludes. Generic standalone engine rank1 fallback remains compatibility
only; it is not production eligibility. Zero/negative/fractional/nonfinite levels exclude
scoped production skills, without changing unrelated skill behavior.

Increment A (3paths): new policy module, stores/combatHelpers.ts, new focused adapter
test. Actual RED against unchanged adapter can use canonical literal scope in tests;
install helper+adapter only after frozen independent test review. Tests exercise all13
resolved canonical/authored aliases, learned/slotted/rank source, unlearned/belowlevel/
prereq/foreignclass/unslotted exclusions; conflicting aliases, invalid alongside valid,
fractional/out-of-cap ranks, nonfinite/fractional player level and malformed prerequisites;
exact copied canonical rank, original Player immutability, unrelated/excluded preservation.
No engine runtime changes in A, no full summon-preparation acceptance. Run focused,
types/lint/fullunits/cleanproductionbridgebuild; engine tier after helper addition per
repo rule. Exact tier bounds need review before execution (prior engine suites exceed3s).

Increment B (2paths): engine/combat/combat.ts and new summon-preparation.test.ts. Use
shared exact-ID predicate. Extend canUseSkillForState with explicit startup scope or
separate common eligibility path; skip scoped skills in ordinary choice unconditionally,
ignore only their carried own cooldown during startup. Preserve excluded/synthetic path.
At startup dedup canonical scoped aliases in owner/skill insertion order; dead owners and
initially terminal battles skip preparation only. Require active trigger/summon target/summonOnStart, exactly one total effect of kind
summon with that canonical skill's expected template. Reject a different known template,
extra effects or invalid numbers. Validate finite nonnegative manaCost/cooldown, finite
optional rank deltas/statScaling coefficients, positive integer minLevel/maxCount, and
recognized currently authored cap shape: the three multi-cap sources use first-three-
then-every-three, other ten use maxCount1/no scaling. Resolved rank/cap/cost/cooldown
must be finite and valid before any State change. No numeric tuning is introduced;
these shape checks preserve authored curves. Unknown/malformed source is an atomic no-op. Compute current
living owner/template count and authored cap/rank. Zero missing leaves all state/events/CD
unchanged. Validate/build every missing template before touching battle state. A later candidate
can fail even after earlier candidates were built: require finite valid derived stats
(lifeMax>0, finite nonnegative numeric capacities/combat fields and finite resistances),
then reject the entire batch without cast/mana/summon events, cooldowns, allocated IDs,
registration, scheduling or RNG changes. Factories' temporary candidate construction
is not State registration. Only valid fully built sources establish authority; a valid
but full or unaffordable source also establishes it without casting. Freeze a temporary
existing-template factory override whose first build is valid and second has nonfinite
stats; restore original factory in finally. Prove failure against no-preparation control,
including subsequent valid spawn's first collision-safe ID and scheduler/recording state.
Then commit one normal
cast/mana event and ordinary cooldown once, and register all prepared units/time0 events.
Extract only the existing summon placement/registration/scheduling code to a local helper
so ordinary single spawns and prepared batches share collision-safe identity/grid/D05
empowerment. Do not repeatedly invoke castSkill (would repeatedly charge). No new stats,
RNG consumption, scheduler turns, resets/refills or template-family cap. Existing death
handler gets one pair check around the legacy refund/CD-clear block; all other death,
orb/status/orphan ordering untouched. Validate source/template before setting pair; set
even when full/insufficient to stop free refunds for matching preloaded summons.

Independent literal B proofs before production edits: 13skills, singleton/multicap ranks
1/2/3/6/20→1/2/3/4/8 at time0, actual rounded ranked mana once, CD once, stable owner/skill
order+alias dedup; damaged/statused/id-positioned living preloads unchanged, dead IDs
reserved, partial and zero-missing; no debit/spawn/retry after insufficiency/invalid
source (including future regen/orbs); only own staleCD ignored; next active/basic ordinary
fallback; scoped new/preloaded deaths no refund/replacement while same-template synthetic
negative control and excluded Skeleton replacement retain prior behavior; dead/terminal
scoped no-op with excluded/synthetic startup controls; exact input immutability, recorded
vs plain/A-A/A-B-A replay equivalence. No weakening existing resummon tests. No pure engine test imports stores. A named later Increment B2 changes only a new
store integration test and, if required by observed production behavior, its owning
adapter. It exercises actual playerToCombatUnit→recorded production wave→next-wave
transition with carried mana, fresh missing-count preparation and no refill; authoritative
rank/payment/cap are observed together. Compare explicitly unchanged current recording
(including original event-array identity) before/after player learning/upgrade/combo
operations as scoped by existing replay policy; ordinary combo edits intentionally
rebuild the current wave and must not be misreported as preservation.
Review exact concrete tests/source before installation; actual RED then green, focused,
engine,types,lint,full,cleanbuild under explicit bounded budgets, serial,
then separate coverage for Increment B: npm run test:engine -- --coverage
--coverage.reportsDirectory=<RAW>/coverage-b --coverage.reporter=json
--coverage.reporter=text --reporter=json --outputFile=<RAW>/coverage-b-report.json.
Selection is all engine tests; preserve configured src/engine/**/*.ts collection,
test-file exclusions and existing80% lines/functions/branches/statements thresholds.
Changed-source list for explicit report inspection: src/engine/skills/summon-preparation.ts
and src/engine/combat/combat.ts. Coverage timeout180s; reports task-local in RAW, individual
32MiB/combined64MiB cap still applies. Report any global/changed-source threshold miss
and resolve evidence gaps without automatic collection broadening or threshold changes.
Other command bounds: focused30s, engine120s, full120s, types90s, lint90s, build210s,
browser240s, cleanup2s; ordinary3sengine/15sunit misses remain reported. All gates serial,
no source edits during gates. No broader simulation/farming/search.

Increment C later: bilingual player-visible start-only paid-batch detail and a focused
production browser contract (native learning/combos/actual startup resources, explicit
save/reload, mobile/desktop/CJK) after runtime review. Imported eligibility stays labeled
scaffolding. No cast/campaign/balance/fullD06 claim before observed evidence. Evidence/
control/ledger/bug reporting in separate≤5path committed increments. Lossless RAW archive
and exact task-owned output/RAW cleanup after independent review. No remote action.
