# D06 C draft: truthful startup detail and native production browser

After B2 commit/cleanup, root owns ≤4 source paths: SkillsScreen.tsx, both locale
skills.json files and a new focused SkillsScreen.summon-preparation.test.tsx.
Use committed exact13 canonical membership helper after authored→canonical
resolution. No new runtime/formula/schema/eligibility policy. Preserve numeric
current/next MP/CD/cap/summon stats and excluded/synthetic generic description.
Render paid preparation description only for those13 skill identities when
summonCap exists, using already resolved display cap and mana cost. No business
math in React. Proposed player text must cover learned/unlocked/slotted, time0
once per wave, fill missing living count up to cap, one displayed ranked MP
payment per batch, no payment when already full, all-or-nothing insufficient
mana with no later retry, no ordinary action/replacement or death mana refund,
fresh summons and payment from carried mana on later waves. Bilingual concise
prose, understandable to player; avoid implementation IDs/protocol details.

Freeze concrete literal UI tests and source drafts with serial QA/GD/TD review,
actual unchanged-source RED then GREEN, focused/types/lint/full/clean production
bridge-build within existing bounds. Verify all13 membership, rank1/2/20+aliases,
singleton/multicap current/next numeric rows, 4excluded negative controls,
unlearned preview, normal native learning/combo and frozen recording behavior.
This is UI contract coverage, no earned/campaign/balance claim. File any confirmed
old display defect through bug-report before patching; do not mislabel incomplete
new feature prose as a historical runtime bug.

Later separate ≤2path production browser spec/config, no debug bridge. Native
creation and explicit imported eligible stats/gear/points scaffold; native Raven
learn0→1→2, combo selection, real wave startup batch/resource observation, explicit
save/close/reopen fullSaveCurrent equality, both locales and bounded mobile/
desktop finite layouts with actual CJK font/clear console. Hidden recording/event
identity remains store-test proof. Real seeded production runtime, no finisher or
fixture API exposed in production. Concrete browser fixture/design review before
install/execution. Existing shared browser/font installs preserved.

Separate evidence/control/ledger updates then reviewed durable lossless RAW
archive and exact task-owned cleanup; fullD06/P09/corpse3/Iron/campaign/balance/
performance/privatev1 gates remain open until their own acceptance.
