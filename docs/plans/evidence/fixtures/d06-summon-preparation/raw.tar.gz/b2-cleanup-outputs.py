from pathlib import Path
import json, hashlib, stat, subprocess, datetime
raw = Path(__file__).resolve().parent
worktree = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd() == worktree
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
summary = json.loads((raw / 'b2-final-gate-summary.json').read_text())
for relative, record in summary['files'].items():
    assert hashlib.sha256((worktree / relative).read_bytes()).hexdigest() == record['sha256']
owned = set()
for name in summary['commands']:
    report = json.loads((raw / (name + '.processes.json')).read_text())
    assert report['remainingNonZombie'] == []
    for identity in report['observations']:
        owned.add((identity['pid'], identity['startTicks']))
for pid, birth in owned:
    try:
        fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        continue
    assert int(fields[19]) != birth, (pid, birth, fields[0])
inventory = json.loads((raw / 'b2-output-inventory.json').read_text())
baseline = json.loads((raw / 'b2-baseline.json').read_text())
assert baseline['distExisted'] is False and baseline['vitestResultsExisted'] is False
assert not (worktree / 'dist').exists()
cache = worktree / 'node_modules/.vite/vitest/results.json'
assert inventory['count'] == 1 and len(inventory['files']) == 1
record = inventory['files'][0]
assert Path(record['path']) == cache and cache.resolve() == cache
assert stat.S_ISREG(cache.lstat().st_mode)
assert cache.stat().st_size == record['bytes'] == inventory['bytes']
assert hashlib.sha256(cache.read_bytes()).hexdigest() == record['sha256']
receipt_path = raw / 'b2-commit-cleanup-receipt.json'
assert not receipt_path.exists()
cache.unlink()
assert not cache.exists() and cache.parent.is_dir()
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
    'removedFiles': 1, 'removedBytes': inventory['bytes'],
    'auditedAbsentProcessBirths': len(owned), 'remainingDisposableOutputs': [],
    'retained': [str(raw), str(cache.parent)],
    'reason': 'RAW retained by root for later D06 evidence archive; shared cache parent preserved',
    'sourceBytesUnchanged': True}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
