from pathlib import Path
import datetime, hashlib, json, stat, subprocess
raw = Path(__file__).resolve().parent
worktree = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd() == worktree
receipt = raw / 'names-old-dist-cleanup-receipt.json'
assert not receipt.exists()
freeze = json.loads((raw / 'names-build-freeze.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == freeze['head']
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == freeze['status']
for name, row in freeze['files'].items():
    p = worktree / name
    assert not p.is_symlink() and p.is_file()
    data = p.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], name
births = set()
for p in raw.glob('*.processes.json'):
    for row in json.loads(p.read_text())['observations']:
        births.add((row['pid'], row['startTicks']))
for p in raw.glob('*.process.json'):
    data = json.loads(p.read_text())
    # Root identities also occur among observations; absence of that record is an error.
    assert any(pid == data['pid'] for pid, ticks in births), str(p)
for pid, ticks in births:
    try:
        fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        continue
    assert int(fields[19]) != ticks, (pid, ticks, fields[0])
root = worktree / 'dist'
assert root.is_dir() and not root.is_symlink()
old = json.loads((raw / 'c-output-inventory.json').read_text())
files = [row for row in old['files'] if Path(row['path']).is_relative_to(root)]
directories = [Path(name) for name in old['directories'] if Path(name) == root or Path(name).is_relative_to(root)]
assert len(files) == 760 and len(directories) == 10
actual_files, actual_dirs = [], [root]
for p in root.rglob('*'):
    mode = p.lstat().st_mode
    assert not stat.S_ISLNK(mode), str(p)
    if stat.S_ISREG(mode): actual_files.append(p)
    elif stat.S_ISDIR(mode): actual_dirs.append(p)
    else: raise RuntimeError('Unexpected output type: ' + str(p))
assert set(actual_files) == {Path(row['path']) for row in files}
assert set(actual_dirs) == set(directories)
for row in files:
    p = Path(row['path']); data = p.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], str(p)
for row in files:
    Path(row['path']).unlink()
for p in sorted(directories, key=lambda p: len(p.parts), reverse=True):
    p.rmdir()
assert not root.exists()
result = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': freeze['head'],
    'filesRemoved': len(files), 'bytesRemoved': sum(row['bytes'] for row in files),
    'directoriesRemoved': len(directories), 'allTaskBirthsAuditedAbsentIncludingZ': len(births),
    'failed': [], 'distAbsent': True, 'retained': ['RAW', 'shared parents/cache/fonts/tools/dependencies',
    'new task Vitest cache pending postcommit cleanup'], 'reason': 'Retired exact old C build before BUG071 locale rebuild; all readers released'}
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
