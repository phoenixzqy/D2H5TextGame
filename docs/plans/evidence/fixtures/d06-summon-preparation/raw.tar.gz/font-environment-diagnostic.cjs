const { chromium } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/playwright');
const fs = require('node:fs');
const path = require('node:path');
const raw = __dirname;
(async () => {
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage({ viewport: { width: 640, height: 360 } });
    await page.setContent('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><body><p id="generic" style="font:24px sans-serif">乌鸦：已学习，法力消耗 6。</p><p id="explicit" style="font:24px &quot;Noto Sans CJK SC&quot;">乌鸦：已学习，法力消耗 6。</p></body></html>');
    const cdp = await page.context().newCDPSession(page);
    await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
    const doc = await cdp.send('DOM.getDocument');
    const result = { version: browser.version(), executable: chromium.executablePath(), fonts: {}, processEnv: [] };
    for (const id of ['generic', 'explicit']) {
      const node = await cdp.send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#' + id });
      result.fonts[id] = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
    }
    for (const entry of fs.readdirSync('/proc')) {
      if (!/^\d+$/.test(entry)) continue;
      try {
        const cmd = fs.readFileSync('/proc/' + entry + '/cmdline', 'utf8');
        if (!cmd.startsWith(chromium.executablePath() + '\0')) continue;
        const env = fs.readFileSync('/proc/' + entry + '/environ', 'utf8').split('\0');
        result.processEnv.push({ pid: Number(entry), variables: env.filter(v => /^(HOME|FONTCONFIG_FILE|FONTCONFIG_PATH|XDG_CACHE_HOME|XDG_DATA_HOME|XDG_CONFIG_HOME|LANG|LC_ALL)=/.test(v)) });
      } catch (error) { if (!['ENOENT', 'ESRCH'].includes(error.code)) throw error; }
    }
    await page.screenshot({ path: path.join(raw, 'font-environment-diagnostic.png') });
    fs.writeFileSync(path.join(raw, 'font-environment-diagnostic.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
    console.log(JSON.stringify(result));
    await cdp.detach(); await page.close();
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
