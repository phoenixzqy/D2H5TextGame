from pathlib import Path
import json, hashlib, stat, subprocess, datetime
raw = Path(__file__).resolve().parent
worktree = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd() == worktree
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
summary = json.loads((raw / 'b-final-gate-summary.json').read_text())
for relative, record in summary['files'].items():
    assert hashlib.sha256((worktree / relative).read_bytes()).hexdigest() == record['sha256']
owned = set()
for name in summary['commands']:
    report = json.loads((raw / (name + '.processes.json')).read_text())
    assert report['remainingNonZombie'] == []
    for identity in report['observations']:
        owned.add((identity['pid'], identity['startTicks']))
for pid, birth in owned:
    try:
        fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        continue
    assert int(fields[19]) != birth, (pid, birth, fields[0])
inventory = json.loads((raw / 'b-output-inventory.json').read_text())
dist = worktree / 'dist'
cache = worktree / 'node_modules/.vite/vitest/results.json'
expected = {Path(record['path']) for record in inventory['files']}
actual = {path for path in dist.rglob('*') if path.is_file()}
assert actual | {cache} == expected
for record in inventory['files']:
    path = Path(record['path'])
    assert path == cache or path.is_relative_to(dist)
    assert path.resolve() == path
    assert stat.S_ISREG(path.lstat().st_mode)
    assert path.stat().st_size == record['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
for directory in inventory['emptyDirectoriesAfterFiles']:
    path = Path(directory)
    assert path == dist or path.is_relative_to(dist)
    assert path.resolve() == path and stat.S_ISDIR(path.lstat().st_mode)
for record in inventory['files']:
    Path(record['path']).unlink()
for directory in inventory['emptyDirectoriesAfterFiles']:
    Path(directory).rmdir()
assert not dist.exists() and not cache.exists()
assert (worktree / 'node_modules/.vite/vitest').is_dir()
receipt = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
    'removedFiles': inventory['count'], 'removedBytes': inventory['bytes'],
    'removedEmptyDistDirectories': len(inventory['emptyDirectoriesAfterFiles']),
    'auditedAbsentProcessBirths': len(owned), 'remainingDisposableOutputs': [],
    'retained': [str(raw), str(worktree / 'node_modules/.vite/vitest')],
    'reason': 'RAW retained by root for later D06 evidence archive; shared cache parent preserved',
    'sourceBytesUnchanged': True}
(raw / 'b-commit-cleanup-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
