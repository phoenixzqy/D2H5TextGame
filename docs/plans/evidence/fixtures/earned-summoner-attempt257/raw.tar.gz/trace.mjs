import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync,gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const save=JSON.parse(gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz')));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const rows=[];
 for(const area of ['areas/act2-arcane-sanctuary','areas/act2-tomb-of-tal-rasha']){
  restoreEarnedSave(save,0);const handle=startEarnedRun({act:2,subAreaId:area,mode:'manual',runSeed:1});
  assert.equal(handle.challengeOrdinal,257);const target=playEarnedTarget(handle),waves=[];
  for(const w of target.waves){
   const hero=w.opening.playerTeam.find(x=>x.kind==='hero'),events=w.opening.recordedEvents,damage=events.filter(e=>e.kind==='damage'&&e.target===hero.id),sources=[...new Set(damage.map(e=>e.source))];
   waves.push({wave:w.index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,heroEntryHP:hero.life,heroMaxHP:hero.stats.lifeMax,
    finalHero:w.played.outcome.finalPlayerTeam.find(x=>x.id===hero.id),enemies:w.opening.enemyTeam,
    damageBySource:sources.map(id=>({id,total:damage.filter(e=>e.source===id).reduce((n,e)=>n+e.amount,0),hits:damage.filter(e=>e.source===id).length,
     actions:events.filter(e=>e.kind==='action'&&e.actor===id).map(e=>({skill:e.skillId,ms:e.simClockMs})),
     hitsDetail:damage.filter(e=>e.source===id)})),
    healing:events.filter(e=>e.kind==='heal'&&e.target===hero.id),events});
  }
  rows.push({area,terminal:target.terminalAdvance,waves});useCombatStore.getState().endCombat();
 }
 await writeFile(root+'/trace.json.gz',gzipSync(JSON.stringify(rows)));
 process.stdout.write(JSON.stringify(rows.map(x=>({area:x.area,waves:x.waves.map(w=>({wave:w.wave,winner:w.winner,ms:w.ms,heroEntryHP:w.heroEntryHP,heroMaxHP:w.heroMaxHP,finalHP:w.finalHero.life,
  damage:w.damageBySource.map(s=>({id:s.id,total:s.total,hits:s.hits,actions:s.actions.slice(0,4)})),healing:w.healing}))})),null,2)+'\n');
}finally{await server.close();}
