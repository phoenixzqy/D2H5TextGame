import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const phase=process.argv[2];assert(['before','after'].includes(phase));
const raw=gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz'));
const inputHash=createHash('sha256').update(raw).digest('hex');
assert.equal(inputHash,'a22721de7f38951892de573d7994ccab3d4ddfa44b62148a28a5afff426012ee');
const save=JSON.parse(raw),gear=JSON.parse(await readFile(root+'/defensive-loadout.json','utf8'));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {playerToCombatUnit}=await load('/src/stores/combatHelpers.ts');
 const {mercToCombatUnit}=await load('/src/stores/mercToCombatUnit.ts');
 const {resolveChallengeWavePlan}=await load('/src/engine/combat/sub-area-run.ts');
 const {resolveSubArea}=await load('/src/stores/subAreaResolver.ts');
 const {buildMonsterUnit}=await load('/src/engine/combat/monster-factory.ts');
 const {runBattleRecorded}=await load('/src/engine/combat/combat.ts');
 const {createRng}=await load('/src/engine/rng.ts');
 const {monsters}=await load('/src/data/index.ts');
 restoreEarnedSave(save,0);
 for(const [who,config,old] of [['hero',gear.hero,save.inventory.equipped],['merc',gear.merc,save.mercs.mercEquipment[save.mercs.fieldedMercId]]])for(const slot of Object.keys(config)){
  const id=config[slot];if(!id||old[slot]?.id===id)continue;
  const item=useInventoryStore.getState().backpack.find(x=>x.id===id);assert(item);
  assert.deepEqual(who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(save.mercs.fieldedMercId,slot,item),{ok:true});
 }
 for(const [expected,actual] of [[gear.hero,useInventoryStore.getState().equipped],[gear.merc,useMercStore.getState().mercEquipment[save.mercs.fieldedMercId]]])
  for(const slot of Object.keys(expected))assert.equal(actual[slot]?.id??null,expected[slot]);
 const {observeEarnedState}=await load('/tests/sim/production/earned-state.ts');
 usePlayerStore.getState().setComboOrder(['skills-sorceress-frost-nova','skills-sorceress-ice-blast','skills-sorceress-glacial-spike']);
 await writeFile(root+'/expected-prepared.json.gz',(await import('node:zlib')).gzipSync(JSON.stringify(observeEarnedState())),{flag:'wx'});
 console.log('Prepared exact public-action reference; no combat entry or point allocation');
}finally{await server.close();}
