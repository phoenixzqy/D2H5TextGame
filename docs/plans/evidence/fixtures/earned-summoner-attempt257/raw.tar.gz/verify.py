import subprocess,time,json,os
from pathlib import Path
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz')
repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2'
commands=[('typecheck',['npm','run','typecheck']),('lint',['npm','run','lint']),('engine',['npm','run','test:engine']),('full',['npm','test']),('build',['npm','run','build','--','--outDir',str(root/'dist'),'--emptyOutDir'])]
rows=[]
env=os.environ.copy();env.pop('VITE_E2E',None)
for name,command in commands:
 print('START',name,flush=True);start=time.monotonic()
 with open(root/(name+'.log'),'x') as out:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=command,exit=r.returncode,seconds=time.monotonic()-start))
 (root/'verify.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('DONE',name,rows[-1],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
