import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const phase=process.argv[2];assert(['before','after'].includes(phase));
const raw=gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz'));
const inputHash=createHash('sha256').update(raw).digest('hex');
assert.equal(inputHash,'a22721de7f38951892de573d7994ccab3d4ddfa44b62148a28a5afff426012ee');
const save=JSON.parse(raw),gear=JSON.parse(await readFile(root+'/defensive-loadout.json','utf8'));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {playerToCombatUnit}=await load('/src/stores/combatHelpers.ts');
 const {mercToCombatUnit}=await load('/src/stores/mercToCombatUnit.ts');
 const {resolveChallengeWavePlan}=await load('/src/engine/combat/sub-area-run.ts');
 const {resolveSubArea}=await load('/src/stores/subAreaResolver.ts');
 const {buildMonsterUnit}=await load('/src/engine/combat/monster-factory.ts');
 const {runBattleRecorded}=await load('/src/engine/combat/combat.ts');
 const {createRng}=await load('/src/engine/rng.ts');
 const {monsters}=await load('/src/data/index.ts');
 restoreEarnedSave(save,0);
 for(const [who,config,old] of [['hero',gear.hero,save.inventory.equipped],['merc',gear.merc,save.mercs.mercEquipment[save.mercs.fieldedMercId]]])for(const slot of Object.keys(config)){
  const id=config[slot];if(!id||old[slot]?.id===id)continue;
  const item=useInventoryStore.getState().backpack.find(x=>x.id===id);assert(item);
  assert.deepEqual(who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(save.mercs.fieldedMercId,slot,item),{ok:true});
 }
 for(const [expected,actual] of [[gear.hero,useInventoryStore.getState().equipped],[gear.merc,useMercStore.getState().mercEquipment[save.mercs.fieldedMercId]]])
  for(const slot of Object.keys(expected))assert.equal(actual[slot]?.id??null,expected[slot]);
 const hero=playerToCombatUnit(usePlayerStore.getState().player);hero.life=hero.stats.lifeMax;hero.mana=hero.stats.manaMax;
 const ms=useMercStore.getState(),merc=ms.ownedMercs.find(x=>x.id===ms.fieldedMercId);assert(merc);
 const rogue=mercToCombatUnit(merc,save.formation.mercPosition,ms.mercEquipment[merc.id]);rogue.life=rogue.stats.lifeMax;rogue.mana=rogue.stats.manaMax;
 const area=resolveSubArea(2,'areas/act2-arcane-sanctuary');assert(area);
 const defs=new Map(monsters.map(x=>[x.id,x])),definition=defs.get('monsters/act2.the-summoner');assert(definition);
 const rows=[];
 for(let seed=1;seed<=1000;seed++){
  const plan=resolveChallengeWavePlan({subArea:area,fallbackArchetypeId:'monsters/act2.sand-raider',fallbackLevel:23,seed,challengeOrdinal:257,mode:'manual'});
  const wi=plan.waves.length-1,waveSeed=(seed^((wi+1)*0x9e3779b1))>>>0,rng=createRng(waveSeed);
  const enemies=plan.waves[wi].spawns.map(s=>buildMonsterUnit({def:defs.get(s.archetypeId),level:s.level,tier:s.tier,index:s.index,rng}));
  const boss=enemies.find(x=>x.monsterArchetypeId===definition.id);assert(boss);assert.equal(boss.level,28);
  const battle=runBattleRecorded({seed:waveSeed,act:2,playerTeam:[hero,rogue],enemyTeam:enemies});
  rows.push({seed,winner:battle.result.winner,ms:battle.events.at(-1).simClockMs,bossLife:boss.life,
   remaining:battle.result.enemyTeam.find(x=>x.id===boss.id).life,heroAlive:battle.result.playerTeam.find(x=>x.kind==='hero').life>0});
  if(seed%250===0)process.stdout.write(`${phase} isolated ${seed}/1000\n`);
 }
 const q=(a,p)=>a.sort((a,b)=>a-b)[Math.floor((a.length-1)*p)]??null,wins=rows.filter(x=>x.winner==='player');
 const summary={n:rows.length,wins:wins.length,deaths:rows.filter(x=>!x.heroAlive).length,bossLife:[Math.min(...rows.map(x=>x.bossLife)),Math.max(...rows.map(x=>x.bossLife))],victoryTTK:{p50:q(wins.map(x=>x.ms),.5),p95:q(wins.map(x=>x.ms),.95)}};
 await writeFile(root+'/'+phase+'-isolated.json',JSON.stringify({inputHash,kind:'optimistic isolated full-resource L24 boss-wave scenario, not native carry or campaign proof',definition,summary,rows},null,2)+'\n',{flag:'wx'});
 process.stdout.write(JSON.stringify(summary)+'\n');
}finally{await server.close();}
