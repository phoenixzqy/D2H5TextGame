import { chromium, expect } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { gzipSync, gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz/browser257-resume';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const base='http://127.0.0.1:4411';
const bytes=await readFile(root+'/input.json.gz'), raw=gunzipSync(bytes).toString('utf8'), input=JSON.parse(raw);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
assert.equal(hash(Buffer.from(raw)),'a22721de7f38951892de573d7994ccab3d4ddfa44b62148a28a5afff426012ee');
assert.equal(input.version,20);assert.equal(input.map.challengeOrdinals.normal,257);
const gear=JSON.parse(await readFile(root+'/defensive-loadout.json','utf8'));
const expectedPrepared=JSON.parse(gunzipSync(await readFile(root+'/expected-prepared.json.gz')));
const bases=new Map(JSON.parse(await readFile(repo+'/src/data/items/bases.json','utf8')).map(x=>[x.id,x]));
const slots=JSON.parse(await readFile(repo+'/src/i18n/locales/en/inventory.json','utf8')).slots;
const freeze=JSON.parse(await readFile(root+'/freeze.json','utf8'));
async function rehash(){
  for(const [kind,base] of [['source',repo],['build',freeze.buildRoot],['input',root]]){
    for(const [path,expected] of Object.entries(freeze[kind]))assert.equal(hash(await readFile(base+'/'+path)),expected,`${kind}/${path} drift`);
  }
}
await rehash();
const report={kind:'earned historical ActII continuation; exploratory, independent acceptance pending',runtime:freeze.head,retries:0,setupAttempt:2,navigation:[],launches:0,ordinalBefore:257,errors:[],console:[],waves:[],preplayPriorityRefreshes:0,states:[],diagnosticErrors:[]};
const record=async(label,value)=>{await writeFile(`${root}/${label}.json.gz`,gzipSync(JSON.stringify(value)),{flag:'wx'});report.states.push(label);};
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:360,height:640},acceptDownloads:true});
context.on('page',page=>{
  page.on('pageerror',e=>report.errors.push(e.message));
  page.on('console',m=>{if(['error','warning'].includes(m.type()))report.console.push({type:m.type(),text:m.text()});});
});
const clean=()=>{assert.deepEqual(report.errors,[]);assert.deepEqual(report.console,[]);};
let page, latest, baseline;
async function open(){const p=await context.newPage();await p.clock.setFixedTime(new Date(input.timestamp));await p.goto(base);await p.waitForLoadState('networkidle');return p;}
async function nav(route){const started=performance.now();await page.locator(`a[href="/${route}"]`).first().click();await expect(page.getByTestId(`${route}-screen`)).toBeVisible({timeout:route==='inventory'?30000:5000});report.navigation.push({route,ms:performance.now()-started});}
async function exported(label,check=true){
  await nav('settings');const pending=page.waitForEvent('download',{timeout:30000});await page.getByTestId('export-save-button').click();const file=await pending;
  let save;try{save=JSON.parse(await readFile(await file.path(),'utf8'));}finally{await file.delete();}
  if(label)await record(label,save);if(check)clean();return save;
}
function conserved(actual,expected){
  const now=actual.meta.idleState;
  assert.deepEqual(actual,{...expected,timestamp:actual.timestamp,meta:{...expected.meta,idleState:{...expected.meta.idleState,
    lastOnline:now.lastOnline,offlineTime:now.offlineTime,activeMultiplier:now.activeMultiplier,multiplierSecondsRemaining:now.multiplierSecondsRemaining}}});
  assert.equal(now.idleTarget,undefined);assert.equal(now.activeMultiplier,1);assert.equal(now.multiplierSecondsRemaining,0);
}
async function durable(label,expected){
  await nav('settings');await page.getByRole('button',{name:'Save',exact:true}).click();await expect(page.getByRole('status')).toHaveText('Saved');
  const saved=await exported(label+'-saved');conserved(saved,expected);await page.close();page=await open();
  await page.getByTestId('home-continue').click();await expect(page.getByTestId('town-screen')).toBeVisible();
  const restored=await exported(label+'-continued');conserved(restored,saved);return restored;
}
function owned(s){
  const items=[...s.inventory.backpack,...s.inventory.stash,...Object.values(s.inventory.equipped),...Object.values(s.mercs.mercEquipment).flatMap(Object.values)].filter(Boolean);
  const all=new Map(items.map(x=>[x.id,x]));assert.equal(all.size,items.length);return all;
}
const xp=s=>{let total=s.player.experience;for(let l=1;l<s.player.level;l++)total+=Math.floor(100*Math.pow(l,2.5));return total;};
function delta(s,old){
  const prior=owned(old),next=owned(s);for(const [id,item] of prior)assert.deepEqual(next.get(id),item,`lost/changed ${id}`);
  const newIds=[...next.keys()].filter(id=>!prior.has(id));
  const difference=(a,b)=>Object.fromEntries([...new Set([...Object.keys(a),...Object.keys(b)])].map(id=>[id,(a[id]??0)-(b[id]??0)]));
  const materials=difference(s.inventory.materials,old.inventory.materials),currencies=difference(s.inventory.currencies,old.inventory.currencies),heroXP=xp(s)-xp(old);
  for(const n of [...Object.values(materials),...Object.values(currencies),heroXP])assert.ok(n>=0);
  assert.deepEqual(s.inventory.equipped,old.inventory.equipped);assert.deepEqual(s.player.equipment,old.player.equipment);
  assert.deepEqual(s.player.skillLevels,old.player.skillLevels);assert.deepEqual(s.player.comboOrder,old.player.comboOrder);
  assert.deepEqual(s.inventory.latestMaterialAction,old.inventory.latestMaterialAction);assert.equal(s.inventory.materialActionOrdinal,1);
  assert.deepEqual(s.map.challengeOrdinals,{normal:258,nightmare:0});assert.deepEqual(s.endgame,{attemptOrdinal:0,clearCounts:{ashen:0,glacial:0},achievementRewardClaimed:false});
  assert.equal(s.meta.idleState.idleTarget,undefined);assert.equal(s.meta.idleState.activeMultiplier,1);assert.equal(s.meta.idleState.multiplierSecondsRemaining,0);
  return {newIds,materials,currencies,heroXP};
}
async function view(){return page.evaluate(()=>({
  wave:document.querySelector('[data-testid="wave-counter"]')?.textContent??'',
  area:document.querySelector('[data-testid="combat-sub-area-name"]')?.textContent??'',
  skipDisabled:document.querySelector('[data-testid="skip-button"]')?.disabled,
  log:[...document.querySelectorAll('[data-testid="combat-log"] > div > span:last-child')].map(n=>n.textContent),
  cards:[...document.querySelectorAll('[data-testid^="unit-card-"]')].map(n=>({id:n.getAttribute('data-testid'),dead:n.getAttribute('data-dead'),text:n.textContent})),
  enemyIds:[...document.querySelectorAll('[data-testid="enemies-grid"] [data-testid^="unit-card-"]')].map(n=>n.getAttribute('data-testid')),
  liveEnemies:document.querySelectorAll('[data-testid="enemies-grid"] [data-testid^="unit-card-"]:not([data-dead="true"])').length,
  defeat:document.querySelector('[data-testid="defeat-panel"]')?.textContent??null
}));}
const waveOf=v=>Number(/^\D*(\d+)/.exec(v.wave)?.[1]);
const watchdog=setTimeout(()=>{report.watchdog=true;void browser.close();},15*60000);
try{
  page=await open();await page.getByTestId('home-new-game').click();await page.getByTestId('class-sorceress').click();
  await page.getByTestId('character-name-input').fill('Import access only');await page.getByTestId('character-start-btn').click();await expect(page.getByTestId('town-screen')).toBeVisible();
  await nav('settings');await page.getByRole('button',{name:'English',exact:true}).click();
  await page.getByRole('button',{name:'Import Save',exact:true}).click();const dialog=page.getByRole('dialog'),textbox=dialog.getByRole('textbox');
  await context.grantPermissions(['clipboard-read','clipboard-write'],{origin:base});await page.evaluate(value=>navigator.clipboard.writeText(value),raw);
  await textbox.click();await textbox.press('ControlOrMeta+V');await expect(textbox).toHaveValue(raw);
  await dialog.getByRole('button',{name:'Import Save',exact:true}).click();await expect(dialog).toHaveCount(0);
  baseline=await exported('migrated');latest=baseline;
  conserved(baseline,input);assert.equal(owned(baseline).size,6124);assert.equal(baseline.player.level,24);
  assert.equal(baseline.player.derivedStats.life,120);assert.equal(baseline.player.derivedStats.mana,102);
  for(const slot of ['head','chest','gloves','boots','belt','offhand']){
    const target=gear.hero[slot];if(target===input.inventory.equipped[slot]?.id)continue;
    await nav('inventory');await page.locator('#tab-equipment').click();
    await page.getByTestId(`equip-slot-${slot}`).getByText(slots[slot],{exact:true}).click();
    const row=page.getByTestId(`equip-picker-row-${target}`);await expect(row).toHaveAttribute('aria-disabled','false');await row.click();
    await expect(page.getByTestId('equip-picker-confirm')).toBeEnabled();await page.getByTestId('equip-picker-confirm').click();await expect(page.getByTestId('equip-picker')).toHaveCount(0);
    latest=await exported(`hero-${slot}`);assert.equal(latest.inventory.equipped[slot].id,target);assert.equal(owned(latest).size,6124);
  }
  for(const slot of ['head','chest','gloves','boots','belt','offhand']){
    const target=gear.merc[slot];if(target===input.mercs.mercEquipment[input.mercs.fieldedMercId][slot]?.id)continue;
    const candidates=latest.inventory.backpack.filter(x=>bases.get(x.baseId)?.slot===slot),index=candidates.findIndex(x=>x.id===target);assert.ok(index>=0);
    await nav('mercs');await page.getByTestId(`merc-equipment-${input.mercs.fieldedMercId}`).click();await expect(page.getByRole('dialog')).toBeVisible();
    await page.getByTestId(`merc-equip-slot-${slot}`).getByText(slots[slot],{exact:true}).click();
    const buttons=page.getByRole('dialog').getByRole('button',{name:'Equip',exact:true});await expect(buttons).toHaveCount(candidates.length);
    await buttons.nth(index).click();await expect(buttons).toHaveCount(0);await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);
    latest=await exported(`merc-${slot}`);assert.equal(latest.mercs.mercEquipment[input.mercs.fieldedMercId][slot].id,target);assert.equal(owned(latest).size,6124);
  }
  await nav('skills');await page.locator('#tab-active').click();
  const priorityRows=page.getByTestId('skills-active-panel').locator('ol > li');await expect(priorityRows).toHaveCount(9);
  await priorityRows.nth(1).getByRole('button',{name:'Move up',exact:true}).click();
  latest=await exported('prepared');
  conserved(latest,{...input,player:expectedPrepared.player.player,inventory:expectedPrepared.inventory,mercs:expectedPrepared.merc});
  assert.equal(latest.player.skillPoints,1);assert.deepEqual(latest.player.comboOrder,['skills-sorceress-frost-nova','skills-sorceress-ice-blast','skills-sorceress-glacial-spike']);
  baseline=await durable('precombat',latest);latest=baseline;
  assert.equal(baseline.map.challengeOrdinals.normal,257);
  assert.equal(await page.evaluate(()=>'__GAME__' in window),false);await nav('map');
  const act=page.getByRole('button',{name:/^Act 2 ·/});if(await act.getAttribute('aria-expanded')!=='true')await act.click();
  const enter=page.getByTestId('sub-area-row-a2-arcane-sanctuary').getByRole('button',{name:'Enter',exact:true});await expect(enter).toBeEnabled();clean();
  await writeFile(root+'/launch.json',JSON.stringify({ordinal:257,area:'a2-arcane-sanctuary',runtime:freeze.head,inputRawHash:hash(Buffer.from(raw)),at:new Date().toISOString()}),{flag:'wx'});
  report.launches=1;await enter.click();await expect(page.getByTestId('combat-screen')).toBeVisible();
  for(let wave=1;wave<=6;wave++){
    if(wave===6){
      const original=await view();assert.equal(waveOf(original),6);assert.equal(original.log.length,0);
      await record('boss-before-priority',original);
      await nav('skills');await page.locator('#tab-active').click();
      const priorityRows=page.getByTestId('skills-active-panel').locator('ol > li');await expect(priorityRows).toHaveCount(9);
      report.preplayPriorityRefreshes++;await priorityRows.nth(1).getByRole('button',{name:'Move up',exact:true}).click();
      const configured=await exported('boss-priority-prepared');
      conserved(configured,{...latest,player:{...latest.player,comboOrder:input.player.comboOrder}});latest=configured;
      await nav('combat');const pause=page.getByRole('button',{name:'Pause',exact:true});if(await pause.isVisible())await pause.click();
      await expect(page.getByRole('button',{name:'Resume',exact:true})).toHaveAttribute('aria-pressed','true');
    }
    const start=await view();assert.equal(waveOf(start),wave);assert.ok(start.area.includes('Arcane Sanctuary'));assert.ok(start.wave.includes('/6')||start.wave.includes('/ 6'));
    await record(`wave-${wave}-initial`,start);clean();
    if(wave>1)await page.getByRole('button',{name:'Resume',exact:true}).click();
    let terminal=start;
    await expect.poll(async()=>{clean();terminal=await view();assert.equal(waveOf(terminal),wave);assert.equal(terminal.area,start.area);return terminal.skipDisabled===true;},{timeout:90000,intervals:[50]}).toBe(true);
    await record(`wave-${wave}-terminal`,terminal);
    const won=terminal.log.at(-1)==='Victory! All enemies are defeated.'&&terminal.liveEnemies===0&&terminal.cards.find(c=>c.id===`unit-card-${input.player.id}`)?.dead===null;
    assert.ok(start.enemyIds.length>0);for(const id of start.enemyIds)assert.ok(terminal.enemyIds.includes(id));
    if(!won){
      await expect(page.getByTestId('defeat-panel')).toBeVisible();await page.screenshot({path:root+'/nonwin.png'});
      await page.getByTestId('return-to-town').click();await expect(page.getByTestId('town-screen')).toBeVisible();
      const stopped=await exported('nonwin-settled'),d=delta(stopped,latest);
      assert.equal(d.heroXP,0);assert.deepEqual(d.newIds,[]);assert.deepEqual(stopped.inventory,latest.inventory);assert.deepEqual(stopped.mercs,latest.mercs);
      report.waves.push({wave,outcome:'nonwin',delta:d});report.outcome='nonwin';report.failedWave=wave;latest=await durable('nonwin',stopped);break;
    }
    if(wave<6){
      await expect.poll(async()=>{const n=waveOf(await view());assert.ok(n===wave||n===wave+1);return n;},{timeout:5000,intervals:[50]}).toBe(wave+1);
      await page.getByRole('button',{name:'Pause',exact:true}).click();await expect(page.getByRole('button',{name:'Resume',exact:true})).toHaveAttribute('aria-pressed','true');
    }else{
      await expect(page.getByTestId('victory-panel')).toBeVisible();await record('victory-summary',{text:await page.getByTestId('loot-summary').innerText()});
      await page.screenshot({path:root+'/victory.png'});await page.getByTestId('return-to-town').click();await expect(page.getByTestId('town-screen')).toBeVisible();
    }
    const settled=await exported(`wave-${wave}-settled`),d=delta(settled,latest);assert.ok(d.heroXP>0);assert.ok(d.newIds.length>0);
    await record(`wave-${wave}-delta`,d);latest=settled;report.waves.push({wave,outcome:'victory',delta:d});
    process.stdout.write(`wave${wave}: victory, +${d.heroXP}XP, +${d.newIds.length}items\n`);
    if(wave<6){await nav('combat');assert.equal(waveOf(await view()),wave+1);await expect(page.getByRole('button',{name:'Resume',exact:true})).toHaveAttribute('aria-pressed','true');}
    else{
      assert.ok(settled.map.clearedSubAreas.includes('areas/act2-arcane-sanctuary'));
      const q='quests/act2-arcane-sanctuary';
      assert.equal(settled.map.questProgress[q].status,'inProgress');
      assert.deepEqual(settled.map.questProgress[q].objectives,{'obj-find-summoner':true,'obj-read-journal':false});assert.notEqual(settled.map.questProgress[q].rewardClaimed,true);
      latest=await durable('victory-journal-unread',settled);report.outcome='victory-journal-unread';
      const openObjects=async()=>{
        await nav('map');const act=page.getByRole('button',{name:/^Act 2 ·/});if(await act.getAttribute('aria-expanded')!=='true')await act.click();
        await page.getByTestId('area-objects-a2-arcane-sanctuary').click();await expect(page.getByTestId('area-object-panel')).toBeVisible();
      };
      await openObjects();await expect(page.getByTestId('quest-object-objects/horazon_journal')).toBeEnabled();
      const inspected=await exported('journal-inspected');assert.deepEqual(inspected.map.questProgress[q],latest.map.questProgress[q]);
      await openObjects();await page.getByTestId('quest-object-objects/horazon_journal').click();
      await expect(page.getByTestId('area-object-excerpt')).toBeVisible();await page.screenshot({path:root+'/journal-read.png'});
      const read=await exported('journal-read');assert.equal(read.map.questProgress[q].status,'completed');assert.equal(read.map.questProgress[q].objectives['obj-read-journal'],true);
      assert.equal(xp(read),xp(latest));assert.equal(read.player.skillPoints,latest.player.skillPoints);latest=await durable('journal-read-unclaimed',read);
      const unclaimed=latest;await nav('quests');await page.getByTestId('quest-claim-'+q).click();
      const claimed=await exported('claimed');assert.equal(xp(claimed)-xp(unclaimed),7000);assert.equal(claimed.player.skillPoints,unclaimed.player.skillPoints+1);
      assert.equal(claimed.map.questProgress[q].rewardClaimed,true);assert.deepEqual(claimed.inventory,unclaimed.inventory);
      latest=await durable('claimed',claimed);report.outcome='victory-journal-read-claimed';report.questXP=7000;report.questSP=1;
    }
  }
  clean();report.totalDelta=delta(latest,{...baseline,player:{...baseline.player,comboOrder:latest.player.comboOrder}});report.ordinalAfter=latest.map.challengeOrdinals.normal;
  report.status='observed';await record('final',latest);
}catch(error){
  report.status='tooling-failure';report.failure=String(error.stack??error);
  if(page&&!page.isClosed()){
    for(const [label,operation] of [
      ['pause',async()=>{const p=page.getByRole('button',{name:'Pause',exact:true});if(await p.isVisible()&&await p.isEnabled())await p.click({timeout:1000});}],
      ['view',async()=>record('stopped-terminal',await view())],
      ['screenshot',async()=>page.screenshot({path:root+'/failure.png'})],
      ['export',async()=>record('stopped-export',await exported(undefined,false))]
    ]){try{await operation();}catch(e){report.diagnosticErrors.push({label,error:String(e)});}}
  }
  process.exitCode=1;
}finally{
  clearTimeout(watchdog);await context.close();await browser.close();
  try{await rehash();report.freezeDrift=[];}catch(e){report.freezeFailure=String(e);process.exitCode=1;}
  await writeFile(root+'/report.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  process.stdout.write(`${report.status}: ${report.outcome??report.failure}\n`);
}
