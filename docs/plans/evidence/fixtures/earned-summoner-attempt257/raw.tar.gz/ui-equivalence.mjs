import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const save=JSON.parse(gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz')));
const gear=JSON.parse(await readFile(root+'/defensive-loadout.json','utf8'));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
const phase='ui-equivalence';
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave,observeEarnedState}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {refreshActivePlayerCombatConfig}=await load('/src/stores/combatHelpers.ts');
 const {createHash}=await import('node:crypto');
 const rows=[];
 const cases=['native-prepare','ui-refresh'];
 for(const name of cases)for(const seed of [1,2,31]){
  restoreEarnedSave(save,0);
  for(const [who,config,old] of [['hero',gear.hero,save.inventory.equipped],['merc',gear.merc,save.mercs.mercEquipment[save.mercs.fieldedMercId]]])for(const slot of Object.keys(config)){
   const id=config[slot];if(!id||old[slot]?.id===id)continue;
   const item=useInventoryStore.getState().backpack.find(x=>x.id===id);assert(item);
   assert.deepEqual(who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(save.mercs.fieldedMercId,slot,item),{ok:true});
  }
  for(const [expected,actual] of [[gear.hero,useInventoryStore.getState().equipped],[gear.merc,useMercStore.getState().mercEquipment[save.mercs.fieldedMercId]]])
   for(const slot of Object.keys(expected))assert.equal(actual[slot]?.id??null,expected[slot]);
  const freezeOrder=['skills-sorceress-frost-nova','skills-sorceress-ice-blast','skills-sorceress-glacial-spike'];
  usePlayerStore.getState().setComboOrder(freezeOrder);
  const handle=startEarnedRun({act:2,subAreaId:'areas/act2-arcane-sanctuary',mode:'manual',runSeed:seed});assert.equal(handle.challengeOrdinal,257);
  const waves=[];
  for(let index=0;index<handle.totalWaves;index++){
   // Wave5 is already recorded; changing here preserves it and prepares IceBlast for wave6.
   if(name==='native-prepare'&&index===handle.totalWaves-2)usePlayerStore.getState().setComboOrder(save.player.comboOrder);
   if(name==='ui-refresh'&&index===handle.totalWaves-1){usePlayerStore.getState().setComboOrder(save.player.comboOrder);refreshActivePlayerCombatConfig({replayCurrentWave:true});}
   const w=playEarnedWave(handle,index),boss=w.opening.enemyTeam.find(x=>x.monsterArchetypeId==='monsters/act2.the-summoner');
   if(w.played.outcome.winner!=='player'){assert.equal(w.actualDelta.xp,0);assert.deepEqual(w.actualDelta.addedItems,[]);}
   waves.push({recordingHash:createHash('sha256').update(JSON.stringify([w.opening.playerTeam,w.opening.enemyTeam,w.opening.recordedEvents,w.opening.outcome])).digest('hex'),index,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,heroAlive:w.played.outcome.finalPlayerTeam.find(x=>x.kind==='hero').life>0,
    order:w.opening.playerTeam.find(x=>x.kind==='hero').skillOrder,
    ...(boss?{bossHP:boss.life,remaining:w.played.outcome.finalEnemyTeam.find(x=>x.id===boss.id).life}:{} )});
   if(w.advanceResult!=='next-wave')break;
  }
  assert.equal(observeEarnedState().map.challengeOrdinals.normal,258);
  rows.push({name,seed,win:waves.length===handle.totalWaves&&waves.at(-1).winner==='player',waves});
  useCombatStore.getState().endCombat();
  if(seed%16===0)process.stdout.write(`${phase} ${name} ${seed}/64\n`);
 }
 for(const seed of [1,2,31])assert.deepEqual(rows.find(x=>x.seed===seed&&x.name==='native-prepare').waves,rows.find(x=>x.seed===seed&&x.name==='ui-refresh').waves);
 await writeFile(root+'/ui-equivalence.json',JSON.stringify({kind:'UI refresh before sixth-wave playback versus prior next-wave preparation, three paired seeds',drift:[],rows},null,2)+'\n',{flag:'wx'});
 console.log('3/3 complete six-wave recording hashes identical');
}finally{await server.close();}
