import { readFile, writeFile, readdir } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz/browser257-prepared';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try{
 const {validateSave}=await server.ssrLoadModule('/src/engine/save/validate.ts');
 const all=[];
 for(const file of (await readdir(root)).filter(x=>x.endsWith('.json.gz')&&!x.startsWith('expected-'))){
  const s=JSON.parse(gunzipSync(await readFile(root+'/'+file)));
  if(s.version===20&&s.player){validateSave(s);all.push(file);}
 }
 const read=async n=>JSON.parse(gunzipSync(await readFile(root+'/'+n+'.json.gz')));
 const imported=await read('input'),final=await read('final');
 const input=JSON.parse(gunzipSync(await readFile(root+'/../browser257/input.json.gz')));
 assert.equal(imported.map.challengeOrdinals.normal,257);
 const success=JSON.parse(await readFile(root+'/report.json','utf8')).outcome==='victory-journal-read-claimed';
 assert.equal(input.map.challengeOrdinals.normal,257);
 assert.equal(final.map.challengeOrdinals.normal,258);
 const owned=s=>{
  const items=[...s.inventory.backpack,...s.inventory.stash,...Object.values(s.inventory.equipped),...Object.values(s.mercs.mercEquipment).flatMap(Object.values)].filter(Boolean);
  const map=new Map(items.map(x=>[x.id,x]));assert.equal(map.size,items.length);return map;
 };
 const prepared=await read('precombat-continued');
 const old=owned(input),reference=owned(prepared),now=owned(final);
 assert.equal(old.size,reference.size);assert.equal(old.size,6124);
 const transferred=[];
 for(const [id,item] of old){
  const moved=reference.get(id);assert(moved);
  const {equipped:oldEquipped,equipSlot:oldSlot,...oldPayload}=item;
  const {equipped:newEquipped,equipSlot:newSlot,...newPayload}=moved;
  assert.deepEqual(newPayload,oldPayload,id+' original immutable payload');
  if(oldEquipped!==newEquipped||oldSlot!==newSlot)transferred.push(id);
 }
 for(const [id,item] of reference)assert.deepEqual(now.get(id),item,id+' prepared payload');
 assert.deepEqual(final.player.skillLevels,input.player.skillLevels);
 if(success)assert.deepEqual(final.player.comboOrder,input.player.comboOrder);
 const q='quests/act2-arcane-sanctuary';
 if(success){assert.equal(final.map.questProgress[q].rewardClaimed,true);
 assert.deepEqual(final.map.questProgress[q].objectives,{'obj-find-summoner':true,'obj-read-journal':true});}
 assert.equal(final.player.skillPoints,input.player.skillPoints+(success?1:0));
 const xp=s=>{let n=s.player.experience;for(let l=1;l<s.player.level;l++)n+=Math.floor(100*Math.pow(l,2.5));return n;};
 const reportBefore=JSON.parse(await readFile(root+'/report.json','utf8'));
 assert.equal(xp(final)-xp(input),reportBefore.waves.reduce((n,x)=>n+x.delta.heroXP,0)+(success?7000:0));
 assert.equal(now.size-old.size,reportBefore.waves.reduce((n,x)=>n+x.delta.newIds.length,0));
 
 const pairs=[];
 for(const file of all.filter(x=>x.endsWith('-saved.json.gz'))){
  const prefix=file.slice(0,-'-saved.json.gz'.length),a=await read(prefix+'-saved'),b=await read(prefix+'-continued');
  const idle=b.meta.idleState;
  assert.deepEqual(b,{...a,timestamp:b.timestamp,meta:{...a.meta,idleState:{...a.meta.idleState,
   lastOnline:idle.lastOnline,offlineTime:idle.offlineTime,activeMultiplier:idle.activeMultiplier,multiplierSecondsRemaining:idle.multiplierSecondsRemaining}}});
  pairs.push(prefix);
 }
 const report=JSON.parse(await readFile(root+'/report.json','utf8'));
 assert.equal(report.status,'observed');assert.equal(report.launches,1);assert.equal(report.retries,0);
 assert.equal(report.setupAttempt,3);if(success)assert.equal(report.preplayPriorityRefreshes,1);
 assert.deepEqual(report.errors,[]);assert.deepEqual(report.console,[]);assert.deepEqual(report.freezeDrift,[]);
 const audit={kind:'root self-audit, not independent acceptance',nativeSaves:all,durablePairs:pairs,
  transferredPayloadFlags:transferred,ancestralItems:old.size,finalItems:now.size,newItems:now.size-old.size,outcome:report.outcome,
  nextOrdinal:258,retainedFinal:'final.json.gz'};
 const packets=[];
 for(const dir of ['browser257','browser257-resume','browser257-prepared']){
  const report=JSON.parse(await readFile(root+'/../'+dir+'/report.json','utf8'));
  assert.equal(report.launches,dir==='browser257-prepared'?1:0);
  for(const file of (await readdir(root+'/../'+dir)).filter(x=>x.endsWith('.json.gz')&&!x.startsWith('expected-'))){
   const s=JSON.parse(gunzipSync(await readFile(root+'/../'+dir+'/'+file)));
   if(s.version===20&&s.player){validateSave(s);packets.push(dir+'/'+file);}
  }
 }
 validateSave(await read('expected-native-prepared'));
 audit.validatedNativePackets=packets;audit.validatedReference='expected-native-prepared.json.gz (diagnostic only)';
 const {createHash}=await import('node:crypto');
 const hash=b=>createHash('sha256').update(b).digest('hex');
 const drift=[];
 for(const dir of ['browser257','browser257-resume','browser257-prepared']){
  const freeze=JSON.parse(await readFile(root+'/../'+dir+'/freeze.json','utf8'));
  for(const [kind,base] of [['source',repo],['build',freeze.buildRoot],['input',root+'/../'+dir]])
   for(const [file,want] of Object.entries(freeze[kind]))assert.equal(hash(await readFile(base+'/'+file)),want,kind+'/'+file);
 }
 audit.allFreezeDrift=drift;
 await writeFile(root+'/audit-v2.json',JSON.stringify(audit,null,2)+'\n');process.stdout.write(JSON.stringify(audit)+'\n');
}finally{await server.close();}
