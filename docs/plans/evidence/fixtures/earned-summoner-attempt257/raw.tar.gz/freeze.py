from pathlib import Path
import hashlib,json,subprocess,re
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz');b=p/'browser257';dist=p/'dist'
hashfile=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
source=json.loads((p/'source-before-validation.json').read_text())
for name,value in source.items():assert hashfile(repo/name)==value,name
build={str(f.relative_to(dist)):hashfile(f) for f in sorted(dist.rglob('*')) if f.is_file()}
js=[f for f in sorted(dist.rglob('*.js')) if f.is_file()]
for f in js:
 s=f.read_text()
 for pattern in [r'__GAME__',r'\bseedItem\b',r'\bseedMerc\b',r'\binstallTestBridge\b',r'[,{]flushSave:']:assert not re.search(pattern,s),(str(f),pattern)
inputs={n:hashfile(b/n) for n in ['browser.mjs','input.json.gz','defensive-loadout.json','expected-prepared.json.gz']}
freeze=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source=source,build=build,buildRoot=str(dist),input=inputs)
with (b/'freeze.json').open('x') as f:json.dump(freeze,f,indent=2);f.write('\n')
print(json.dumps(dict(source=len(source),build=len(build),input=len(inputs),bridgeFreeJS=len(js),head=freeze['head'])))
