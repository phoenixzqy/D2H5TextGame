import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const save=JSON.parse(gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz')));
const gear=JSON.parse(await readFile(root+'/defensive-loadout.json','utf8'));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
const phase=process.argv[2]??'before';assert(['before','after'].includes(phase));
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave,observeEarnedState}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const rows=[];
 const cases=phase==='before'?['freeze-first','freeze-trash-ice-boss']:['freeze-trash-ice-boss'];
 for(const name of cases)for(let seed=1;seed<=64;seed++){
  restoreEarnedSave(save,0);
  for(const [who,config,old] of [['hero',gear.hero,save.inventory.equipped],['merc',gear.merc,save.mercs.mercEquipment[save.mercs.fieldedMercId]]])for(const slot of Object.keys(config)){
   const id=config[slot];if(!id||old[slot]?.id===id)continue;
   const item=useInventoryStore.getState().backpack.find(x=>x.id===id);assert(item);
   assert.deepEqual(who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(save.mercs.fieldedMercId,slot,item),{ok:true});
  }
  for(const [expected,actual] of [[gear.hero,useInventoryStore.getState().equipped],[gear.merc,useMercStore.getState().mercEquipment[save.mercs.fieldedMercId]]])
   for(const slot of Object.keys(expected))assert.equal(actual[slot]?.id??null,expected[slot]);
  const freezeOrder=['skills-sorceress-frost-nova','skills-sorceress-ice-blast','skills-sorceress-glacial-spike'];
  usePlayerStore.getState().setComboOrder(freezeOrder);
  const handle=startEarnedRun({act:2,subAreaId:'areas/act2-arcane-sanctuary',mode:'manual',runSeed:seed});assert.equal(handle.challengeOrdinal,257);
  const waves=[];
  for(let index=0;index<handle.totalWaves;index++){
   // Wave5 is already recorded; changing here preserves it and prepares IceBlast for wave6.
   if(name==='freeze-trash-ice-boss'&&index===handle.totalWaves-2)usePlayerStore.getState().setComboOrder(save.player.comboOrder);
   const w=playEarnedWave(handle,index),boss=w.opening.enemyTeam.find(x=>x.monsterArchetypeId==='monsters/act2.the-summoner');
   if(w.played.outcome.winner!=='player'){assert.equal(w.actualDelta.xp,0);assert.deepEqual(w.actualDelta.addedItems,[]);}
   waves.push({index,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,heroAlive:w.played.outcome.finalPlayerTeam.find(x=>x.kind==='hero').life>0,
    order:w.opening.playerTeam.find(x=>x.kind==='hero').skillOrder,
    ...(boss?{bossHP:boss.life,remaining:w.played.outcome.finalEnemyTeam.find(x=>x.id===boss.id).life}:{} )});
   if(w.advanceResult!=='next-wave')break;
  }
  assert.equal(observeEarnedState().map.challengeOrdinals.normal,258);
  rows.push({name,seed,win:waves.length===handle.totalWaves&&waves.at(-1).winner==='player',waves});
  useCombatStore.getState().endCombat();
  if(seed%16===0)process.stdout.write(`${phase} ${name} ${seed}/64\n`);
 }
 const quantile=(a,p)=>[...a].sort((x,y)=>x-y)[Math.floor((a.length-1)*p)]??null;
 const summary=cases.flatMap(name=>['screen','holdout'].map(group=>{
  const r=rows.filter(x=>x.name===name&&(group==='screen'?x.seed<=32:x.seed>32)),wins=r.filter(x=>x.win),bosses=r.filter(x=>x.waves.at(-1).bossHP);
  return {name,group,n:r.length,wins:wins.length,deaths:r.filter(x=>!x.waves.at(-1).heroAlive).length,reachedBoss:bosses.length,
   bossTTK:{p50:quantile(wins.map(x=>x.waves.at(-1).ms),.5),p95:quantile(wins.map(x=>x.waves.at(-1).ms),.95)},
   meanDamage:bosses.reduce((n,x)=>n+x.waves.at(-1).bossHP-x.waves.at(-1).remaining,0)/bosses.length};
 }));
 await writeFile(root+'/'+phase+'-control.json',JSON.stringify({kind:'fixed legal crowd-control policy projections, no campaign state promoted',ordinal:257,summary,rows},null,2)+'\n');
 process.stdout.write(JSON.stringify(summary)+'\n');
}finally{await server.close();}
