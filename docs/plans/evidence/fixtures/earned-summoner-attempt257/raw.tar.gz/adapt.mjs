import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-act2-progression-jbutorzz';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const raw=gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt256/retained-final.json.gz'));
const hash=createHash('sha256').update(raw).digest('hex');
assert.equal(hash,'a22721de7f38951892de573d7994ccab3d4ddfa44b62148a28a5afff426012ee');
const save=JSON.parse(raw),server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
const quantile=(a,p)=>[...a].sort((x,y)=>x-y)[Math.floor((a.length-1)*p)]??null;
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave,observeEarnedState}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {buildEnemiesForWave}=await load('/src/stores/combatHelpers.ts');
 const {resolveChallengeWavePlan}=await load('/src/engine/combat/sub-area-run.ts');
 const {resolveSubArea}=await load('/src/stores/subAreaResolver.ts');
 const {prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts');
 const {deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts');
 const {loadItemBases}=await load('/src/data/loaders/loot.ts');
 const {checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts');
 const {planEquipMutex}=await load('/src/engine/inventory/equipValidator.ts');
 const {actionPeriodMs}=await load('/src/engine/combat/combat.ts');
 const {mitigateDamage}=await load('/src/engine/combat/damage.ts');
 const {getSkill}=await load('/src/engine/skills/registry.ts');
 const {MERC_INNER_SIGHT_DEFINITION}=await load('/src/engine/skills/inner-sight.ts');
 const merc=save.mercs.ownedMercs.find(x=>x.id===save.mercs.fieldedMercId);assert(merc);
 restoreEarnedSave(save,0);
 const bases=loadItemBases(),items=save.inventory.backpack,byId=new Map(items.map(x=>[x.id,x]));
 const slots=['head','chest','gloves','boots','belt','offhand'],originalHero=save.inventory.equipped,originalMerc=save.mercs.mercEquipment[merc.id];
 const arcane=resolveSubArea(2,'areas/act2-arcane-sanctuary');assert(arcane);
 const plan=resolveChallengeWavePlan({subArea:arcane,seed:1,challengeOrdinal:257,mode:'manual',idleEliteMisses:0,fallbackArchetypeId:'monsters/act2.horror-mage',fallbackLevel:23});
 const wi=plan.waves.length-1,enemies=buildEnemiesForWave(plan.waves[wi],(1^((wi+1)*0x9e3779b1))>>>0);
 const boss=enemies.find(x=>x.monsterArchetypeId==='monsters/act2.the-summoner');assert(boss);
 const ice=getSkill('skills-sorceress-ice-blast').effects.find(e=>e.kind==='damage');assert(ice);
 const arrow=getSkill('mskill-basic-arrow').effects.find(e=>e.kind==='damage');assert(arrow);
 const rank=save.player.skillLevels['sorceress.ice_blast'];assert.equal(rank,20);
 const compose=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
 const score=(who,gear)=>{
  const stats=who==='hero'?compose(gear):deriveEquippedMercStats(merc,gear);
  const baseline=who==='hero'?compose(originalHero):deriveEquippedMercStats(merc,originalMerc);
  if(stats.attack<baseline.attack||stats.attackSpeed<baseline.attackSpeed||stats.critChance+1e-10<baseline.critChance||stats.critDamage+1e-10<baseline.critDamage||stats.defense<100)return -Infinity;
  const input={defenderResistances:stats.resistances,defenderMagicResist:stats.magicResist,defenderArmor:stats.defense};
  const lightning=mitigateDamage(55,{...input,type:'lightning'}).final;
  const cold=mitigateDamage(35,{...input,type:'cold'}).final;
  return stats.lifeMax/(((lightning+cold)/2)*Math.max(.1,1-stats.magicDodge));
 };
 const candidates=new Map();
 for(const [who,actor] of [['hero',save.player],['merc',merc]])for(const slot of slots){
  candidates.set(who+slot,items.filter(x=>slotMatches(bases.get(x.baseId)?.slot,slot)&&checkEligibility(x,actor,bases).eligible));
 }
 const optimize=first=>{
  let hg={...originalHero},mg={...originalMerc};
  for(let pass=0;pass<2;pass++)for(const who of [first,first==='hero'?'merc':'hero'])for(const slot of slots){
   const gear=who==='hero'?hg:mg,other=who==='hero'?mg:hg;
   const occupied=new Set([...Object.values(other),...Object.entries(gear).filter(([k])=>k!==slot).map(([,x])=>x)].filter(Boolean).map(x=>x.id));
   let best=gear,bestScore=score(who,gear);
   for(const item of candidates.get(who+slot)){
    if(occupied.has(item.id))continue;
    const next={...gear,[slot]:item},mutex=planEquipMutex(slot,bases.get(item.baseId),gear,bases);
    for(const clear of mutex.clear)next[clear]=null;
    const value=score(who,next);
    if(value>bestScore+1e-12){best=next;bestScore=value;}
   }
   if(who==='hero')hg=best;else mg=best;
  }
  return {first,hero:hg,merc:mg,score:score('hero',hg)+score('merc',mg)};
 };
 const optimized=[optimize('hero'),optimize('merc')].sort((a,b)=>b.score-a.score)[0];
 const config={hero:Object.fromEntries(Object.entries(optimized.hero).map(([k,x])=>[k,x?.id??null])),merc:Object.fromEntries(Object.entries(optimized.merc).map(([k,x])=>[k,x?.id??null])),
  heroStats:compose(optimized.hero),mercStats:deriveEquippedMercStats(merc,optimized.merc),
  originalScore:score('hero',originalHero)+score('merc',originalMerc),score:optimized.score,
  heuristic:'two fixed coordinate-descent orderings, two passes, all slots, only originally owned backpack candidates; magic EHP estimate vs equally weighted55lightning/35cold, offense floors and armor>=100; no battle outcomes used to select gear'};
 await writeFile(root+'/defensive-loadout.json',JSON.stringify(config,null,2)+'\n');
 process.stdout.write(JSON.stringify({score:config.score,originalScore:config.originalScore,hero:config.heroStats,merc:config.mercStats})+'\n');
 const scenarios=[['blizzard-arcane','areas/act2-arcane-sanctuary',false,true],['defensive-arcane','areas/act2-arcane-sanctuary',true,false],['defensive-blizzard-arcane','areas/act2-arcane-sanctuary',true,true],['defensive-blizzard-tomb','areas/act2-tomb-of-tal-rasha',true,true]];
 const rows=[];
 for(const [name,area,opt,blizzard] of scenarios)for(let seed=1;seed<=32;seed++){
  restoreEarnedSave(save,0);
  if(opt){
   for(const [who,gear,old] of [['hero',config.hero,originalHero],['merc',config.merc,originalMerc]])for(const slot of slots){
    const id=gear[slot];if(!id||id===old[slot]?.id)continue;
    const item=useInventoryStore.getState().backpack.find(x=>x.id===id);assert(item,who+'/'+slot+'/'+id);
    if(who==='hero')assert.deepEqual(useInventoryStore.getState().equipItem(item),{ok:true});
    else assert.deepEqual(useMercStore.getState().equipOnMerc(merc.id,slot,item),{ok:true});
   }
  }
  if(blizzard){assert.equal(usePlayerStore.getState().allocateSkillPoint('skills-sorceress-blizzard'),'ok');usePlayerStore.getState().setComboOrder(['skills-sorceress-blizzard',...save.player.comboOrder]);}
  if(opt){for(const [who,expected,actual] of [['hero',config.hero,useInventoryStore.getState().equipped],['merc',config.merc,useMercStore.getState().mercEquipment[merc.id]]])for(const slot of Object.keys(expected))assert.equal(actual[slot]?.id??null,expected[slot],who+'/'+slot);}
  const before=observeEarnedState();assert.equal(before.map.challengeOrdinals.normal,257);
  const handle=startEarnedRun({act:2,subAreaId:area,mode:'manual',runSeed:seed});assert.equal(handle.challengeOrdinal,257);
  const target=playEarnedTarget(handle),after=observeEarnedState();assert.equal(after.map.challengeOrdinals.normal,258);
  const waves=target.waves.map(w=>{
   const boss=w.opening.enemyTeam.find(x=>x.monsterArchetypeId==='monsters/act2.the-summoner'||x.monsterArchetypeId==='monsters/act2.duriel');
   const damage=w.opening.recordedEvents.filter(x=>x.kind==='damage'&&x.target===boss?.id);
   if(w.played.outcome.winner!=='player'){assert.equal(w.actualDelta.xp,0);assert.deepEqual(w.actualDelta.addedItems,[]);}
   return {wave:w.index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,xp:w.actualDelta.xp,items:w.actualDelta.addedItems.length,
    heroAlive:w.played.outcome.finalPlayerTeam.find(x=>x.kind==='hero').life>0,
    ...(boss?{boss:{id:boss.monsterArchetypeId,level:boss.level,hp:boss.life,stats:boss.stats,remaining:w.played.outcome.finalEnemyTeam.find(x=>x.id===boss.id).life},
     damageBySource:Object.fromEntries([...new Set(damage.map(e=>e.source))].map(id=>[id,damage.filter(x=>x.source===id).reduce((n,x)=>n+x.amount,0)]))}:{} )};
  });
  rows.push({name,seed,terminal:target.terminalAdvance,waves});useCombatStore.getState().endCombat();
  if(seed%8===0)process.stdout.write(`${name} ${seed}/32\n`);
 }
 const summary=scenarios.map(([name])=>{
  const r=rows.filter(x=>x.name===name),wins=r.filter(x=>x.terminal==='victory'),bosses=r.map(x=>x.waves.at(-1)).filter(x=>x.boss);
  return {name,n:r.length,wins:wins.length,deaths:r.filter(x=>!x.waves.at(-1).heroAlive).length,
   failWaves:r.filter(x=>x.terminal!=='victory').reduce((a,x)=>{const w=x.waves.at(-1).wave;a[w]=(a[w]??0)+1;return a;},{}),
   victoryBossTTK:{p50:quantile(wins.map(x=>x.waves.at(-1).ms),.5),p95:quantile(wins.map(x=>x.waves.at(-1).ms),.95)},
   meanBossHP:bosses.reduce((n,x)=>n+x.boss.hp,0)/bosses.length,
   meanBossDamage:bosses.reduce((n,x)=>n+x.boss.hp-x.boss.remaining,0)/bosses.length};
 });
 await writeFile(root+'/adaptations.json',JSON.stringify({inputHash:hash,ordinal:257,kind:'isolated native full-area projections; no campaign state promoted',config,summary,rows},null,2)+'\n');
 process.stdout.write(JSON.stringify(summary)+'\n');
}finally{await server.close();}
