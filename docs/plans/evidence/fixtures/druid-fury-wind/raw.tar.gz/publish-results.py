from pathlib import Path
import csv,io,json,collections,re,hashlib,subprocess
p=Path(__file__).parent;repo=Path.cwd()
full=json.loads((p/'full.json').read_text());assert full['exit']==0
assert json.loads((p/'frozen-before.json').read_text())==json.loads((p/'frozen-after.json').read_text())
log=(p/'full.log').read_text();assert re.search(r'Test Files\s+596 passed',log) and re.search(r'Tests\s+13607 passed \| 2 skipped',log)
source=json.loads((p/'committed-source-proof.json').read_text());assert source['actualCommittedBlobs'] and source['sourceCount']==1321
runtime=source['runtime'];presentation=source['head'];seconds=full['seconds']
audit=json.loads((p/'browser-attachment-audit.json').read_text());assert len(audit['cases'])==4 and len(audit['pairs'])==8
for label in ['engine-with-shield','types-with-shield','lint-corrected','lint-with-shield','build-corrected','attachment-audit-command']:assert json.loads((p/(label+'.json')).read_text())['exit']==0
packet='docs/plans/evidence/d04-druid-fury-wind.md'
text=f"""# D04 — Fury repeats real attacks; Druid wind/control verification

Runtime `{runtime[:7]}` repairs BUG194; presentation `{presentation[:7]}` adds
truthful bilingual per-strike/count/grid/control details. Exactly Fury, Arctic
Blast, Tornado, Hurricane, Twister and Shock Wave receive bounded local functional
credit. Five wind/control attacks retain their existing runtime data. Independent
design/QA and earned class/build balance remain open.

## Behavior and contract

[Contract](../decisions/D04-druid-fury-wind-v1.md) adds explicit provisional
JSON `hitSequence.strikes=5`, integer technical bound2–8. This is new v1 tuning,
not canonical D2 or earned balance. Existing Fury95–135/+8rank,11MP,1s cooldown,
unlock30/cap20 and full Rabies prerequisites stay unchanged. One cast pays and
starts cooldown once; each attempt uses a fresh ordinary roll and the existing
damage/status/absorption/death/orb/reflection settlement. All share the scheduled
simulation timestamp. No new enemy turn, RNG algorithm or save field is added.

Select the existing first-two pool once; rotate among living original members,
skip dead targets, allow the survivor to take the remaining attempts, and stop
when the actor or pool dies. A miss spends an attempt. Never acquire a third
target or attack a corpse. No-sequence damage remains unchanged. Fury works in
human, paid wolf or paid bear form after the learned prerequisites; it neither
transforms nor requires a separately paid transformation. The strict schema
limits metadata to exact Fury and forbids contradictory shape/status overrides.

Arctic Blast remains best-cross Cold/Chill; Tornado best horizontal line3
Physical/no control; Hurricane one all-enemy Cold/Chill pulse; Twister first-two
Physical/Stun; Shock Wave all-enemy Physical/Stun in any existing paid form.
Copy now reflects these actual rules. Twister no longer promises knockback;
Hurricane does not promise a sustained aura. Shared Chill2s/Stun1s/bossStun0.5s
are displayed from authoritative defaults. All five retain authored damage,
growth, cost, cooldown, unlocks, rank caps and prerequisites.

## Causal evidence and corrections

Original native rank1/20 RED at seed7 legally pays11MP for one action but resolves
one hit, removing97/249HP. Original script/results/log/terminal1 receipt remain.
The same assertions pass via a green-output variant that preserves the RED result.
Five new test files add88 cases:19combat,19schema,4display,38native causal and8UI.
Literal five-strike damage at rank1 is97,116,104,105,116 (538HP); rank2 totals578,
rank20 totals1298. Mitigated strikes38,48,42,42,48 remove218HP. Tests assert
actual HP/payment/action/cooldown, original-pool order/stops, missed attempts,
reflection death, unchanged no-sequence controls and immutable exact replay.
A finite240-point shield absorbs successive reflections97,116,27 before later
reflections remove77,105,116HP; no pool reset or stale actor write occurs.

Native rank1/2/20 cases cover actual hit HP, all six target sets, exact class/
unlock/prerequisite/cap/MAX-alias authority, real Stun interruption and boss
expiry, actual paired Chill delay, and paid wolf/bear preservation. Pure display
and bilingual Skills checks cover current/next/MAX/unlearned bounds and count.

Original failures/sources are retained. A schema editor's unanchored substring
assertion failed before writes. Initial native form fixtures omitted selecting
the paid form; corrected fixtures preserve the actual runtime. Control fixtures
assumed2500ms although the ordinary scheduler caps the period at2000ms. Seed7
then missed after an earlier enemy consumed RNG; disclosed seed1 plus an actual
landed-hit assertion provides the paired Chill check. Initial display/UI,
pre-metadata, type and lint failures remain; explicit typed status extraction
retains all original status identity/source/clock assertions without suppression.
A pre-browser scratch inspection misread regex escaping and failed before any
driver edit; the prepared driver was already correct. Root source/test/visual
review is author self-review, not independent acceptance.

## Production browser evidence and limits

Four terminal0 cases use one explicit-false production build, en/zh-CN ×
1280×800/360×640. Public controls create/export/import, Save-close-new-page-
Continue, allocate all six rank1→2, select each attack, enter real Catacombs,
Pause/Flee and Continue again. Separate attachment auditing confirms24 actual
attack entries, first Fury sequences2–5 resolved attempts, actual damaged living
enemies, eight exact player/inventory/map/mercs/formation Continue pairs, six
spent points per case and final selected Shock Wave. No page errors or test bridge.
Twenty geometry samples cover360×640,412×915,640×360,1280×800,1920×1080 with no
horizontal overflow and allocation targets at least44×44. Forty-eight screenshots
remain; eight selected captures were individually inspected.

Fixtures are synthetic L30/full learned prerequisites/50000-life-and-mana gear,
defense100/attackSpeed−80, with no extra critical gear. They establish actual
public allocation/combat/persistence, not earned campaign or balance. Existing
mobile nested scrolling/fixed header/nav occlusion and icon/font fallback remain;
mobile combat enemies can lie below the captured fold. Complete mobile/a11y/PWA
acceptance is open. Existing bundle/precache/Browserslist and test/runtime budget
issues remain. Exact owned preview PID423178 is absent and port4480 is closed.

## Final validation and scope

Final standard full: **13607 tests /596 files**, **two existing skips**,
{seconds}s wrapper wall. Engine: **7069/249**,80.664s. Focused:104/6,9.095s
(88new plus16existing sustain UI cases). Typecheck47.311s, full lint109.673s
plus changed-test lint9.983s, production build11.942s pass. Four JS chunks contain
no forbidden test-bridge tokens; all756 precache references exist. Original
warnings remain. No new skips, threshold/timeout relaxations or dependencies.

All1321 source/test/config hashes,760 build hashes, HEAD/Git status and genuine
save digest stay exact through the final full run. Actual committed HEAD blobs
are compared against every tested source hash and disk after both local commits.
No source changes follow. Retained build hashes represent disposable output.

Exactly six rows gain credit; all213 IDs/order remain: **129unverified /
82bounded-functional /one engine-only /one review-needed**. These differing proof
scopes are not an overall completion percentage. Genuine Ancients401 retains
SHA256 `c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`:
L33/XP149261/23682gear/nextNormal402/Nightmare0, Ancients/Rite claimed,
**Baal uncleared**. No genuine campaign or remote action. C0/C1 retain narrow
historical acceptance; C2-C4/fullG0-G7, earned all-class builds/pacing/economy/
endgame and independent acceptance remain open. Root is sole writer; umbrella
goal/branch/worktree remain active.

## Retention and cleanup

[Manifest](fixtures/druid-fury-wind/manifest.json),
[raw packet](fixtures/druid-fury-wind/raw.tar.gz),
[retention audit](fixtures/druid-fury-wind/retention-audit.json) and
[cleanup receipt](fixtures/druid-fury-wind/cleanup.json) preserve original RED/
failures, source variants, scripts/logs/terminal receipts, browser exports/
screenshots, build/freeze maps, source blob audit and author reviews. Every raw
member is byte-compared against its original before exact task-owned disposal.
Shared caches, umbrella worktree and older required campaign evidence stay under
their existing ownership. Final cleanup counts are appended after verification.
"""
assert not (repo/packet).exists();(repo/packet).write_text(text)
inventory=repo/'docs/plans/skill-inventory.csv';old=inventory.read_text();(p/'inventory-before.csv').write_text(old)
rows=list(csv.DictReader(io.StringIO(old)));fields=list(rows[0]);ids=[r['data_id'] for r in rows]
changed=['skills-druid-'+s for s in ['arctic-blast','tornado','hurricane','twister','shock-wave','fury']]
for row in rows:
 if row['data_id'] not in changed:continue
 assert row['behavior_verification']=='unverified'
 row['behavior_verification']='bounded-functional;independent-acceptance-open';row['contract_evidence']=packet
 row['risk_flags']='earned-balance-open'
 if row['data_id']=='skills-druid-fury':
  row['risk_flags']='provisional-five-strike-tuning|earned-balance-open';row['adapter_route']='damage+bounded-independent-hit-sequence'
out=io.StringIO();writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows)
inventory.write_text(out.getvalue());after=list(csv.DictReader(io.StringIO(inventory.read_text())))
assert len(rows)==len(after)==213 and [r['data_id'] for r in after]==ids
before=list(csv.DictReader(io.StringIO(old)));actual=[a['data_id'] for a,b in zip(before,after) if a!=b];assert actual==changed,(actual,changed)
counts=dict(collections.Counter(r['behavior_verification'] for r in after));assert counts=={'unverified':129,'bounded-functional;independent-acceptance-open':79,'bounded-engine-functional;independent-acceptance-open':1,'bounded-functional;earned-balance-open':3,'review-needed':1},counts
(p/'inventory-publication-proof.json').write_text(json.dumps(dict(total=213,idsAndOrderPreserved=True,changedIds=actual,beforeSha256=hashlib.sha256(old.encode()).hexdigest(),afterSha256=hashlib.sha256(inventory.read_bytes()).hexdigest(),counts=counts,scope='Six bounded local skill credits only; independent and earned acceptance open.'),indent=2)+'\n')
bug=repo/'production/bugs/BUG-194-druid-fury-single-hit.md';s=bug.read_text().replace('Status: Reproduced; local contract recorded, repair pending.','Status: Locally repaired and verified; independent design/QA and earned balance remain open.')
s=s.replace('The original reproduction script/result/log/terminal receipt are task-owned at\n`/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-fury-295j1qf_/`\nuntil the repair\'s evidence publication; root will archive them and remove the\nexact scratch after all consumers finish.', 'The original reproduction script/result/log/terminal receipt are retained in\n[the repair evidence packet](../../docs/plans/evidence/d04-druid-fury-wind.md).\nThe same assertions pass with a separate output path, preserving the RED result.')
s+=f'\nLocal repair `{runtime[:7]}` and presentation `{presentation[:7]}` follow the linked\nprovisional five-strike contract. Full13607/596/two existing skips, engine7069/249,\ntypes/lint/build/bridge and four production browser cases pass. No genuine\ncampaign or remote action; independent/earned acceptance remains open.\n';bug.write_text(s)
ledger=repo/'docs/plans/execution-ledger.md';s=ledger.read_text()
card=f'| D04 Fury/wind/control / BUG194 | locally fixed/verified; independent and earned acceptance open | Runtime `{runtime[:7]}`, presentation `{presentation[:7]}`; explicit provisional five independent Fury attempts in original first-two pool, one payment/action/CD and per-strike settlement/stops. Five wind/control attacks retain existing data with truthful bilingual grid/status/pulse/form copy. Full13607/596/two existing skips ({seconds}s), engine7069/249, focused104/6, types/lint/build/four-chunk bridge/precache PASS. Production4/4,24 actual attacks/eight exact five-domain Continue pairs/20geometry/48screenshots/eight inspected. [Evidence](evidence/d04-druid-fury-wind.md);1321source/760build/Git/genuine hashes exact, committed source blobs checked. Exactly six credits:213 IDs/order,129unverified/82bounded-functional/one engine-only/one review-needed. Synthetic proof only; genuineL33/next402 unchanged/Baal uncleared. Independent/earned balance, C2-C4/fullG0-G7/privatev1 remain open; root sole writer, local only, umbrella goal/worktree active. |\n'
needle='| --- | --- | --- |\n';assert needle in s;s=s.replace(needle,needle+card,1)
s+=f'\n\n## D04 — Fury repeated attacks and five wind/control skills / BUG194\n\nRuntime `{runtime[:7]}` introduces the missing JSON-owned bounded independent\nsequence; presentation `{presentation[:7]}` explains actual per-strike/grid/control\nrules. Five wind/control attacks retain authored runtime data. Original native\none-hit RED and all fixture/type/lint failures remain in the byte-verified\n[packet](evidence/d04-druid-fury-wind.md). Final full13607/596/two existing skips\n({seconds}s), engine7069/249, types/lint/build/bridge/precache PASS. Production4/4,\n24attack entries, eight exact five-domain Continue pairs,20geometry samples,\n48screenshots/eight inspected. Synthetic fixtures and provisional five-strike\ntuning do not establish earned balance. All1321source/760build hashes, HEAD/Git\nand genuine digest stay exact; actual committed source blobs match.\n\nExactly six credits:213 IDs/order preserved,129unverified/82bounded-functional/\none engine-only/one review-needed. Genuine Ancients/Rite remainsL33/XP149261/\n23682gear/nextNormal402/Nightmare0/Baal uncleared. C0/C1 retain narrow acceptance;\nC2-C4/fullG0-G7/all-class earned builds/pacing/economy/endgame/independent QA and\nexisting mobile/a11y/PWA/performance issues remain open. No campaign/remote\naction. Root sole writer; umbrella goal/branch/worktree remain active.\n'
ledger.write_text(s)
print(json.dumps(dict(evidence=packet,runtime=runtime,presentation=presentation,fullSeconds=seconds,counts=counts,changedIds=actual)))
