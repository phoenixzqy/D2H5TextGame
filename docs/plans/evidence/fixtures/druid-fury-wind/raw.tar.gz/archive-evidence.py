from pathlib import Path
import hashlib, json, tarfile, shutil

p=Path(__file__).parent
repo=Path.cwd()
target=repo/'docs/plans/evidence/fixtures/druid-fury-wind'
target.mkdir(exist_ok=False)
digest=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted(f for f in p.rglob('*') if f.is_file())
assert all(not f.is_symlink() for f in p.rglob('*'))
inventory={str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=digest(f.read_bytes())) for f in paths}
raw={n:v for n,v in inventory.items() if Path(n).parts[0]!='production'}
build={n.removeprefix('production/'):v['sha256'] for n,v in inventory.items() if n.startswith('production/')}
frozen=json.loads((p/'frozen-after.json').read_text())
assert build==frozen['build'] and len(build)==760
large=[n for n in raw if raw[n]['bytes']>32*1024*1024]
assert all(n.endswith('-failed-trace.zip') for n in large)
with tarfile.open(target/'raw.tar.gz','w:gz',compresslevel=6) as archive:
    for n,v in raw.items():
        if n in large:
            attachment='traces/'+n.replace('/','--')
            (target/attachment).parent.mkdir(exist_ok=True)
            shutil.copyfile(p/n,target/attachment)
            v['storage']=dict(attachment=attachment)
        else:
            archive.add(p/n,arcname=n,recursive=False)
            v['storage']=dict(archive='raw.tar.gz',member=n)
verified=[]
with tarfile.open(target/'raw.tar.gz','r:gz') as archive:
    members={m.name:m for m in archive.getmembers()}
    assert set(members)==set(raw)-set(large)
    for n,v in raw.items():
        if n in large:
            data=(target/v['storage']['attachment']).read_bytes()
        else:
            assert members[n].isfile()
            data=archive.extractfile(members[n]).read()
        assert len(data)==v['bytes'] and digest(data)==v['sha256'] and data==(p/n).read_bytes(),n
        verified.append(n)
receipts={}
for n in raw:
    if not n.endswith('.json'): continue
    try: data=json.loads((p/n).read_text())
    except (ValueError,UnicodeError): continue
    if isinstance(data,dict) and 'argv' in data and 'exit' in data:
        receipts[n]={k:data[k] for k in ('argv','exit','seconds','finished') if k in data}
publication=json.loads((p/'inventory-publication-proof.json').read_text())
source=json.loads((p/'committed-source-proof.json').read_text())
manifest=dict(scope='Fury repeated-attack repair and five unchanged wind/control attacks; synthetic local proof only. Independent QA and earned balance remain open.',
    owner='root',session='01a1577a-5af4-70e3-8699-50a906877d8f',worktree=str(repo),base=frozen['head'],
    runtime=source['runtime'],presentation=source['head'],rawFiles=len(raw),files=raw,
    archiveSha256=digest((target/'raw.tar.gz').read_bytes()),archiveBytes=(target/'raw.tar.gz').stat().st_size,
    largeTraceAttachments=large,terminalReceipts=receipts,sourceCount=source['sourceCount'],buildCount=len(build),
    genuine=frozen['genuine'],inventory=publication,independentAcceptance=False,earnedCampaignActions=False)
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(target/'cleanup-inventory.json').write_text(json.dumps(dict(root=str(p),files=inventory),indent=2)+'\n')
proof=dict(originalFilesVerified=len(verified),archiveFiles=len(raw)-len(large),traceAttachments=len(large),
    terminalReceipts=len(receipts),productionFilesExcluded=len(build),archiveSha256=manifest['archiveSha256'],
    allBytesExact=True)
(target/'retention-audit.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
