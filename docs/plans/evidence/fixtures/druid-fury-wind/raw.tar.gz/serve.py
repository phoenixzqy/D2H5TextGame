import pathlib, subprocess, json
p=pathlib.Path(__file__).parent
repo=pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
argv=['node',str(repo/'node_modules/vite/bin/vite.js'),'preview','--outDir',str(p/'production'),'--host','127.0.0.1','--port','4480','--strictPort']
with (p/'server.log').open('w') as out:
 child=subprocess.Popen(argv,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
 (p/'server-owner.json').write_text(json.dumps({'pid':child.pid,'argv':argv,'ownedBy':'BUG194 root'},indent=2)+'\n')
 print('Owned preview PID',child.pid,flush=True)
 status=child.wait()
 (p/'server-terminal.json').write_text(json.dumps({'pid':child.pid,'exit':status})+'\n')
