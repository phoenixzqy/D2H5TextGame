from pathlib import Path
import subprocess, hashlib, gzip, json, io

p = Path(__file__).parent
repo = Path.cwd()
before = json.loads((p / 'frozen-before.json').read_text())
assert before == json.loads((p / 'frozen-after.json').read_text())
assert json.loads((p / 'full.json').read_text())['exit'] == 0
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
names = list(before['source'])
result = subprocess.run(['git', 'cat-file', '--batch'], input=''.join(head + ':' + n + '\n' for n in names).encode(), stdout=subprocess.PIPE, check=True)
stream = io.BytesIO(result.stdout)
verified = {}
for name in names:
    header = stream.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob', (name, header)
    size = int(header[2])
    content = stream.read(size)
    assert stream.read(1) == b'\n'
    digest = hashlib.sha256(content).hexdigest()
    assert digest == before['source'][name] == hashlib.sha256((repo / name).read_bytes()).hexdigest(), name
    verified[name] = dict(blob=header[0], sha256=digest, bytes=size)
assert stream.read() == b''
genuine = hashlib.sha256(gzip.decompress((repo / 'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
assert genuine == before['genuine']
report = dict(head=head, runtime=json.loads((p/'local-commits.json').read_text())['runtime'], sourceCount=len(verified), verified=verified, genuine=genuine, actualCommittedBlobs=True)
(p / 'committed-source-proof.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k != 'verified'}))
