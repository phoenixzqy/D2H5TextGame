from pathlib import Path
import json,re
p=Path(__file__).parent
spells=['fury','arctic-blast','tornado','hurricane','twister','shock-wave']
cases=[];pairs=[];geometry=[];screenshots=[]
for locale in ['en','zh-CN']:
 for width in [1280,360]:
  label=f'{locale}-{width}';d=p/f'browser-verified-{label}'
  receipt=json.loads((p/f'browser-{label}.json').read_text());assert receipt['exit']==0
  report=json.loads((d/'browser-report.json').read_text());assert not report['failures']
  assert len(report['cases'])==1
  c=report['cases'][0];assert c['pass'] and not c['errors'] and c['pairs']==['rank1','rank2']
  assert [x['slug'] for x in c['combat']]==spells
  for attack in spells:
   combat=json.loads((d/f'{label}-{attack}-combat.json').read_text())
   assert combat['damagedLivingEnemy'] and any(0<float(x['life'].rstrip('%'))<100 for x in combat['hp'] if x['life'])
   sequence=combat['firstSequence']
   pattern=r'FuryCheck (?:attacks|hits) .+ for \d+ |dodges FuryCheck' if locale=='en' else r'FuryCheck (?:普攻|对) .+造成 \d+ 点|闪避了 FuryCheck 的攻击'
   actual=[line for line in sequence if re.search(pattern,line)]
   assert len(actual)==combat['resolvedAttempts'] and actual,(label,attack)
   if attack=='fury':assert 2<=len(actual)<=5,(label,actual)
   for suffix in ['details','combat']:
    screenshot=d/f'{label}-{attack}-{suffix}.png';assert screenshot.is_file();screenshots.append(str(screenshot.relative_to(p)))
  for rank in [1,2]:
   before=list(d.glob(f'{label}-rank{rank}-before-*.json'));after=list(d.glob(f'{label}-rank{rank}-after-*.json'));assert len(before)==len(after)==1
   a=json.loads(before[0].read_text());b=json.loads(after[0].read_text());assert a['version']==b['version']==22
   for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==b[domain],(label,rank,domain)
   for slug in spells:assert b['player']['skillLevels']['druid.'+slug.replace('-','_')]==rank
   assert b['player']['skillPoints']==(6 if rank==1 else 0)
   if rank==2:assert b['player']['comboOrder']==['skills-druid-shock-wave']
   assert not re.search(r'hitSequence|expiresAtMs',json.dumps(b))
   pairs.append(dict(label=label,rank=rank,before=str(before[0].relative_to(p)),after=str(after[0].relative_to(p)),exactDomains=['player','inventory','map','mercs','formation']))
  assert len(report['geometry'])==5
  for g in report['geometry']:assert g['overflow']==0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
  geometry.extend(report['geometry']);cases.append(c)
assert len(pairs)==8 and len(geometry)==20 and len(screenshots)==48
out=dict(cases=cases,pairs=pairs,geometry=geometry,screenshots=screenshots,syntheticScope='Imported L30/learned prerequisites/50000-life-and-mana gear/defense100/attackSpeed-80; no extra critical gear. Actual public allocation/config, native combat and Continue; no earned campaign proof.',limitations=['Existing mobile nested scrolling/header/nav occlusion','Existing font/icon fallback','No independent design or QA acceptance','No earned balance/pacing/endgame/PWA/performance/a11y acceptance'])
(p/'browser-attachment-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS: 4 terminal browser cases, 24 actual attack entries, 8 exact five-domain Continue pairs, 20 geometry samples, 48 screenshots.')
