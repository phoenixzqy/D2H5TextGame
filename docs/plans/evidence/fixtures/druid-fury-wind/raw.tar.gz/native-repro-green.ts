import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
import { writeFileSync } from 'node:fs';

const hold=(at=0):ActiveStatus=>({id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:at});
const results=[];
for(const rank of [1,20]){
  const player={...createMockPlayer('Synthetic Fury reproduction','druid'),level:30,
    skillLevels:{'druid.werewolf':1,'druid.feral_rage':1,'druid.rabies':1,'druid.fury':rank},
    comboOrder:['skills-druid-fury']};
  const native=playerToCombatUnit(player);
  const hero:CombatUnit={...native,life:10000,mana:11,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
    manaRegenCarry:0,manaRegenCompensation:0,manaRegenExactCarry:'0',statuses:[hold(1701)],
    stats:{...native.stats,lifeMax:10000,manaMax:100,attack:1,attackSpeed:100,critChance:0}};
  const enemy:CombatUnit={...hero,id:'held-enemy',kind:'monster',side:'enemy',life:10000,mana:0,
    statuses:[hold()],skillOrder:[],skillLevels:{},increasedDamagePct:{},
    stats:{...hero.stats,defense:0,magicResist:0,physDodge:0,magicDodge:0,
      resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}}};
  const input={seed:7,playerTeam:[hero],enemyTeam:[enemy]};
  const before=JSON.stringify(input);
  const actual=runBattleRecorded(input);
  const actions=actual.events.filter(e=>e.kind==='action');
  const hits=actual.events.filter(e=>e.kind==='damage'&&e.source===hero.id);
  const removed=10000-(actual.result.enemyTeam[0]?.life??10000);
  const checks={nativeConfigured:native.skillOrder.length===1&&native.skillOrder[0]==='skills-druid-fury',
    onePaidCast:actions.length===1&&actions[0]?.kind==='action'&&actions[0].skillId==='druid.fury',
    paid11:actual.result.playerTeam[0]?.mana===0,actualHpMatchesDamage:removed===hits.reduce((n,e)=>n+e.amount,0),
    inputUnchanged:JSON.stringify(input)===before,
    repeatedAttacks:hits.length>=2};
  results.push({rank,checks,hitCount:hits.length,removed,actions,hits,finalPlayer:actual.result.playerTeam[0]});
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-fury-295j1qf_/native-green-result.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
if(results.some(r=>Object.values(r.checks).some(v=>!v)))process.exitCode=1;
