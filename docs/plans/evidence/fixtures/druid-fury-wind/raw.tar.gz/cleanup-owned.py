from pathlib import Path
import json,hashlib,socket,sys
p=Path(__file__).resolve().parent
expected=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-fury-295j1qf_')
assert p==expected and not p.is_symlink()
target=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/druid-fury-wind')
manifest=json.loads((target/'cleanup-inventory.json').read_text());assert manifest['root']==str(p)
assert json.loads((target/'retention-audit.json').read_text())['allBytesExact']
owner=json.loads((p/'server-owner.json').read_text());assert not Path(f"/proc/{owner['pid']}").exists()
s=socket.socket();closed=s.connect_ex(('127.0.0.1',4480))!=0;s.close();assert closed
files=manifest['files'];actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}
assert actual==set(files),(actual-set(files),set(files)-actual)
assert all(not f.is_symlink() for f in p.rglob('*'))
for name,v in files.items():
 f=p/name;assert f.resolve().is_relative_to(p) and f.stat().st_size==v['bytes']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==v['sha256'],name
removed=[];failures=[]
for name in files:
 try:(p/name).unlink();removed.append(name)
 except OSError as e:failures.append(dict(path=name,error=str(e)))
for d in sorted((d for d in p.rglob('*') if d.is_dir()),key=lambda d:len(d.parts),reverse=True):
 try:d.rmdir()
 except OSError as e:failures.append(dict(path=str(d),error=str(e)))
try:p.rmdir()
except OSError as e:failures.append(dict(path=str(p),error=str(e)))
remaining=[str(f) for f in p.rglob('*')] if p.exists() else []
report=dict(root=str(p),removedFiles=len(removed),scratchAbsent=not p.exists(),ownedPid=owner['pid'],pidAbsent=not Path(f"/proc/{owner['pid']}").exists(),port=4480,portClosed=closed,remaining=remaining,failures=failures)
(target/'cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));assert not remaining and not failures and report['scratchAbsent']
