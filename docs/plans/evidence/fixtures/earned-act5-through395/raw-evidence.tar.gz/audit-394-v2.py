from pathlib import Path
import gzip,json,hashlib
r=Path(__file__).resolve().parent
j=lambda p:json.loads(Path(p).read_text())
z=lambda p:json.load(gzip.open(p))
def own(s):
 a=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[v for eq in s['mercs']['mercEquipment'].values() for v in eq.values()];a=[i for i in a if i is not None];m={i['id']:i for i in a};assert len(m)==len(a);return m
def xp(s):return s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))
policy=j(r/'policy.json');initial=z(policy['input']);report=j(r/'earned-arreat394/report.json');final=z(r/'earned-arreat394/final.json.gz');assert report['status']=='observed' and report['prisonPrepared'] and not report['errors'] and not report['console'];assert report['launches']==[{'ordinal':394,'alias':'arreat-plateau'}];assert report['questActions']==['Start Prison','Inspect Anya','Receive Malah potion','Thaw Anya'];screen=j(r/'screen-v2.json');assert screen['qualified'] and screen['wins']==32 and screen['secondHalfWins']==16;assert len(j(r/'screen-failure.json')['rows'])==0
ancestors=own(initial);current=own(final)
for id,item in ancestors.items():assert current[id]==item,id
assert len(current)-len(ancestors)==152 and xp(final)-xp(initial)==48820
for key in ['coreStats','skillLevels','comboOrder','skillPoints','statPoints','respecsRemaining']:assert final['player'][key]==initial['player'][key]
for key in ['equipped','questServices','materialActionOrdinal']:assert final['inventory'][key]==initial['inventory'][key]
won_label=next(label for label in report['states'] if label.endswith('394-won-continued'));won=z(r/'earned-arreat394'/(won_label+'.json.gz'))
for key in ['materials','currencies']:assert final['inventory'][key]==won['inventory'][key]
assert final['player']==won['player'] and final['mercs']==won['mercs'] and own(final)==own(won)
assert final['player']['derivedStats']==initial['player']['derivedStats'];assert final['map']['challengeOrdinals']=={'normal':395,'nightmare':0};assert final['map']['questProgress']['quests/act5-rescue-on-mount-arreat']==initial['map']['questProgress']['quests/act5-rescue-on-mount-arreat']
qid='quests/act5-prison-of-ice';assert final['map']['questProgress'][qid]['objectives']=={'obj-find-anya':True,'obj-thaw':True,'obj-kill-nihlathak':False};assert final['map']['questProgress'][qid]['status']=='inProgress';assert not final['map']['questProgress'][qid].get('rewardClaimed');assert final['inventory']['questItems']=={**initial['inventory']['questItems'],qid+'#action:receive-potion':{'itemId':'quest/malahs_potion','state':'consumed'}}
for source in ['inspect-anya','receive-potion','thaw-anya']:assert final['map']['questReceipts'][qid+'#action:'+source] is True
for source in ['nihlathak-victory','read-resistance-scroll']:assert qid+'#action:'+source not in final['map']['questReceipts']
for n in range(1,7):
 before=z(r/f'earned-arreat394/394-w{n}-initial.json.gz');after=z(r/f'earned-arreat394/394-w{n}-terminal.json.gz');assert after['skipDisabled'] and after['liveEnemies']==0 and after['defeat'] is None and after['log'][-1]=='Victory! All enemies are defeated.';assert next(c for c in after['cards'] if c['id']=='unit-card-'+initial['player']['id'])['dead'] is None;assert set(before['enemyIds'])<=set(after['enemyIds'])
pairs=[];snapshots=0
for i,label in enumerate(report['states']):
 value=z(r/'earned-arreat394'/(label+'.json.gz'))
 if 'player' in value:snapshots+=1;assert set(ancestors)<=set(own(value))
 if label.endswith('-saved'):
  nextlabel=report['states'][i+1];assert nextlabel.endswith('-continued') and value==z(r/'earned-arreat394'/(nextlabel+'.json.gz'));pairs.append([label,nextlabel])
out={'status':'pass','inputRawSHA256':policy['inputRawSHA256'],'finalRawSHA256':hashlib.sha256(gzip.decompress((r/'earned-arreat394/final.json.gz').read_bytes())).hexdigest(),'diagnosticWins':32,'diagnosticN':32,'diagnosticSecondHalfWins':16,'nativeChallenge394':'six original victories','nativeQuestActions':report['questActions'],'nativeSavedSnapshots':snapshots,'saveContinuePairs':pairs,'ownedBefore':len(ancestors),'ownedAfter':len(current),'newItems':152,'heroXP':48820,'finalLevel':final['player']['level'],'finalXP':final['player']['experience'],'nextNormal':395,'PrisonPreparedNoKillProof':True,'skillPoints':final['player']['skillPoints'],'statPoints':final['player']['statPoints'],'sourceUnchanged':j(r/'validation.json')['status']=='pass'}
(r/'audit394.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='saveContinuePairs'}))
