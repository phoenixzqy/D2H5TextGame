from pathlib import Path
import gzip,json,hashlib
r=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
j=lambda p:json.loads(Path(p).read_text())
z=lambda p:json.load(gzip.open(p))
def own(s):
 a=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[v for eq in s['mercs']['mercEquipment'].values() for v in eq.values()];a=[i for i in a if i is not None];m={i['id']:i for i in a};assert len(m)==len(a);return m
def xp(s):return s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))

audit394=j(r/'audit394.json');assert audit394['status']=='pass'
policy=j(r/'passage-policy.json');initial=z(policy['input']);report=j(r/'earned-passage395/report.json');final=z(r/'earned-passage395/final.json.gz');assert report['status']=='observed' and not report['errors'] and not report['console'] and not report.get('cleanupErrors');assert report['launches']==[{'ordinal':395,'alias':'crystalline-passage'}];screen=j(r/'passage-screen.json');assert screen['status']=='complete' and screen['qualified'] and len(screen['rows'])==32 and screen['wins']==26 and screen['secondHalfWins']==13
assert hashlib.sha256(gzip.decompress(Path(policy['input']).read_bytes())).hexdigest()==policy['inputRawSHA256']==audit394['finalRawSHA256']
ancestors=own(initial);current=own(final)
for id,item in ancestors.items():assert current[id]==item,id
for key in ['coreStats','skillLevels','comboOrder','skillPoints','statPoints','respecsRemaining']:assert final['player'][key]==initial['player'][key]
for key in ['equipped','materialActionOrdinal']:assert final['inventory'][key]==initial['inventory'][key]
assert final['map']['challengeOrdinals']=={'normal':396,'nightmare':0};assert final['player']['derivedStats']['magicResist']==40
for merc in initial['mercs']['ownedMercs']:
 if merc['id']!=initial['mercs']['fieldedMercId']:assert next(m for m in final['mercs']['ownedMercs'] if m['id']==merc['id'])==merc
qid='quests/act5-prison-of-ice';scroll=qid+'#reward:questItem';won=report['outcome']=='earned-act5-area-victory';assert won or report['outcome']=='nonwin';waves=report['areas'][0]['waves'];assert waves
for w in waves:
 n=w['wave'];before=z(r/f'earned-passage395/395-w{n}-initial.json.gz');after=z(r/f'earned-passage395/395-w{n}-terminal.json.gz');assert set(before['enemyIds'])<=set(after['enemyIds']);assert after['skipDisabled']
 if w['outcome']=='victory':assert after['liveEnemies']==0 and after['defeat'] is None and after['log'][-1]=='Victory! All enemies are defeated.' and next(c for c in after['cards'] if c['id']=='unit-card-'+initial['player']['id'])['dead'] is None
 else:assert not won and w is waves[-1] and w['delta']['xp']==0 and w['delta']['newItems']==[]
pairs=[];snapshots=0;states={}
for i,label in enumerate(report['states']):
 value=z(r/'earned-passage395'/(label+'.json.gz'));states[label]=value
 if 'player' in value:snapshots+=1;assert set(ancestors)<=set(own(value))
 if label.endswith('-saved'):
  nextlabel=report['states'][i+1];assert nextlabel.endswith('-continued') and value==z(r/'earned-passage395'/(nextlabel+'.json.gz'));pairs.append([label,nextlabel])
claimXP=0
if won:
 assert len(waves)==6 and all(w['outcome']=='victory' for w in waves);assert report['prisonClaimedAndRead'] and report['questActions']==['Claim Prison','Read actual resistance scroll'];assert final['map']['questProgress'][qid]['rewardClaimed'];assert all(final['map']['questProgress'][qid]['objectives'].values())
 for source in ['inspect-anya','receive-potion','thaw-anya','nihlathak-victory','read-resistance-scroll']:assert final['map']['questReceipts'][qid+'#action:'+source] is True
 assert final['inventory']['questItems'][scroll]=={'itemId':'items/scroll_of_resist','state':'consumed'};assert final['inventory']['questServices'][qid+'#reward:service']=={'serviceId':'personalize_item','state':'available'}
 before=next(value for label,value in states.items() if label.endswith('prison-unclaimed-continued'));unread=next(value for label,value in states.items() if label.endswith('prison-claimed-unread-continued'));read=next(value for label,value in states.items() if label.endswith('scroll-read-continued'))
 assert xp(unread)-xp(before)==12000 and xp(read)==xp(unread);assert unread['player']['derivedStats']['resistances']==before['player']['derivedStats']['resistances'];assert unread['inventory']['questItems'][scroll]['state']=='owned';assert own(before)==own(unread)==own(read)
 for key in ['currencies','materials','equipped','materialActionOrdinal']:assert before['inventory'][key]==unread['inventory'][key]==read['inventory'][key]
 for key,value in unread['player']['derivedStats']['resistances'].items():assert read['player']['derivedStats']['resistances'][key]==final['player']['derivedStats']['resistances'][key]==value+10
 claimXP=12000
else:
 assert not report.get('prisonClaimedAndRead') and not report.get('questActions');assert final['map']['questProgress'][qid]==initial['map']['questProgress'][qid];assert final['inventory']['questItems']==initial['inventory']['questItems'];assert final['inventory']['questServices']==initial['inventory']['questServices']
freeze=j(r/'source-freeze.json');drift=[p for p,h in freeze.items() if not(repo/p).is_file() or hashlib.sha256((repo/p).read_bytes()).hexdigest()!=h];assert not drift
summary={'status':'pass','kind':'earned Arreat394/Anya prep and one Passage395 with actual terminal retained','sourceFiles':len(freeze),'sourceDrift':drift,'arreatDiagnostic':{'n':32,'wins':32,'secondHalfWins':16},'passageDiagnostic':{'n':32,'wins':26,'secondHalfWins':13,'draws':6},'genuineLaunches':[{'ordinal':394,'area':'arreat-plateau'},{'ordinal':395,'area':'crystalline-passage'}],'genuine395Outcome':report['outcome'],'PrisonClaimedAndRead':won,'nativeSavedSnapshots':audit394['nativeSavedSnapshots']+snapshots,'saveContinuePairs394':audit394['saveContinuePairs'],'saveContinuePairs395':pairs,'ownedBefore':audit394['ownedBefore'],'ownedFinal':len(current),'newItems':len(current)-audit394['ownedBefore'],'allAncestorFullPayloadsExact':True,'heroXP394':48820,'heroXP395':xp(final)-xp(initial),'PrisonClaimXP':claimXP,'totalHeroXP':48820+xp(final)-xp(initial),'finalLevel':final['player']['level'],'finalXP':final['player']['experience'],'finalStatPoints':final['player']['statPoints'],'finalSkillPoints':final['player']['skillPoints'],'finalMagicResist':40,'finalNextNormal':396,'finalRawSHA256':hashlib.sha256(gzip.decompress((r/'earned-passage395/final.json.gz').read_bytes())).hexdigest(),'limitations':'one English360x640 earned pilot; no C2/full-v1/pacing/class-matrix acceptance; source unchanged; no diagnostic promotion'}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if not k.startswith('saveContinuePairs')},indent=2))
