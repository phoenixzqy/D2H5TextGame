from pathlib import Path
import hashlib,json,tarfile
p=Path(__file__).parent.resolve()
assert p==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-conversion-xzvjsj_z')
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
packet=wd/'docs/plans/evidence/fixtures/conversion'
assert json.loads((p/'owned-paths.json').read_text())['root']==str(p)
assert not any(f.is_symlink() for f in p.rglob('*'))
items={}
for f in sorted(p.rglob('*')):
 if f.is_file() and 'production-dist' not in f.relative_to(p).parts: items['scratch/'+str(f.relative_to(p))]=f
for f in sorted(packet.iterdir()):
 if f.is_file() and f.suffix in ['.json','.log'] and f.name not in ['packet.json','cleanup.json']: items['commands/'+f.name]=f
archive=packet/'raw.tar.gz';assert not archive.exists()
manifest={name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for name,f in items.items()}
with tarfile.open(archive,'w:gz') as tar:
 for name,f in items.items():tar.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member in members:
  stream=tar.extractfile(member);assert stream is not None
  data=stream.read();assert manifest[member.name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
receipts=0
for name,f in items.items():
 if f.suffix=='.json':
  data=json.loads(f.read_text())
  if isinstance(data,dict) and ('exit_code' in data or 'exit' in data):receipts+=1
result={'archive':'raw.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'raw_files':len(manifest),'members':manifest,'terminal_command_receipts':receipts,'synthetic_browser_and_combat_fixtures':True,'independent_earned_acceptance':False,'superseded':['scratch/frozen-inputs.json initial build','scratch/frozen-inputs-final.json before strict test fixture correction','commands/full.json intentionally interrupted first run','commands/full-final.json before strict test fixture correction','scratch/browser-en-* and browser-zh-* initial production build'], 'final_verification':'commands/full-strict.json; scratch/frozen-inputs-strict.json; scratch/post-full-freeze-audit-strict.json; final browser runs use unchanged production runtime bytes'}
(packet/'packet.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'raw_files':len(manifest),'terminal_receipts':receipts,'archive_bytes':archive.stat().st_size,'all_members_verified':True}))
