from pathlib import Path
import json,hashlib
p=Path(__file__).parent
names=['browser-final-en-desktop','browser-final-zh-desktop','browser-final-en-mobile','browser-final-zh-mobile','browser-final-visual-en-mobile','browser-final-visual-zh-mobile']
pairs=[];geometries=0;screens=[]
for name in names:
 d=p/name;report=json.loads((d/'browser-report.json').read_text())
 assert len(report['cases'])==1 and not report['failures']
 case=report['cases'][0];assert case['pass'] and not case['errors']
 assert case['combat'][0]['localizedConversionChip'] and case['combat'][0]['actualConversionLog']
 for stage,rank in [('rank1',1),('rank2',2)]:
  before=list(d.glob('*-'+stage+'-before-*.json'));after=list(d.glob('*-'+stage+'-after-*.json'))
  assert len(before)==len(after)==1
  b=json.loads(before[0].read_text());a=json.loads(after[0].read_text())
  assert b['version']==a['version']==22
  for domain in ['player','inventory','map','mercs','formation']: assert b[domain]==a[domain],(name,stage,domain)
  assert a['player']['skillLevels']['paladin.conversion']==rank
  assert a['player']['skillPoints']==2-rank
  assert a['player']['comboOrder']==['skills-paladin-conversion']
  assert 'conversionRank' not in json.dumps(a)
  pairs.append({'case':name,'stage':stage,'exact_domains':['player','inventory','map','mercs','formation'],'before_sha256':hashlib.sha256(before[0].read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(after[0].read_bytes()).hexdigest()})
 assert len(report['geometry'])==5
 for g in report['geometry']: assert g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
 geometries+=len(report['geometry']);screens.extend(str(x.relative_to(p)) for x in sorted(d.glob('*.png')))
out={'primary_cases':4,'supplemental_mobile_cases':2,'pairs':pairs,'geometry_samples':geometries,'screenshots':screens,'synthetic_imports':True,'actual_browser_monster_to_monster_hp_claim':False,'native_engine_tests_prove_allegiance':True,'all_exact':True}
f=p/'browser-audit.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'cases':6,'exact_five_domain_pairs':len(pairs),'geometry_samples':geometries,'screenshots':len(screens),'pass':True}))
