import subprocess,time,json,sys,os,pathlib
wd=pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=pathlib.Path(__file__).parent
packet=wd/'docs/plans/evidence/fixtures/conversion'
name=sys.argv[1]
env=os.environ.copy()
if name.startswith('browser-final-'):
 locale,width=sys.argv[2:4]
 env.update(BROWSER_RUN=name,BROWSER_LOCALE=locale,BROWSER_WIDTH=width)
 command=['node',str(root/'browser.cjs')]
elif name=='focused-strict':
 command=['npx','vitest','run','src/engine/skills/conversion.test.ts','src/engine/combat/conversion.test.ts','src/stores/conversion.causal.test.ts','src/features/skills/SkillsScreen.conversion.test.tsx','src/stores/eventToLogI18n.conversion.test.ts']
else:
 command=['npm','run',sys.argv[2]]
for suffix in ['.log','.json']:
 assert not (packet/(name+suffix)).exists()
start=time.monotonic()
p=subprocess.Popen(command,cwd=wd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
owner=packet/(name+'-owner.json')
assert not owner.exists()
owner.write_text(json.dumps({'pid':p.pid,'wrapper_pid':os.getpid(),'command':command,'cwd':str(wd)},indent=2)+'\n')
output=p.communicate()[0]
(packet/(name+'.log')).write_bytes(output)
receipt={'command':command,'exit_code':p.returncode,'seconds':time.monotonic()-start,'pid':p.pid}
if name.startswith('browser-final-'): receipt.update(locale=locale,width=int(width),build='production-dist final frozen bytes')
(packet/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(output.decode(errors='replace')[-3000:])
print(json.dumps(receipt))
sys.exit(p.returncode)
