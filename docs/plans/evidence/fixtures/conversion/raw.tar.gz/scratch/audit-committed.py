from pathlib import Path
import subprocess,hashlib,json,gzip,sys
p=Path(__file__).parent;wd=Path.cwd()
assert wd==Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
frozen=json.loads((p/'frozen-inputs-strict.json').read_text())
names=sorted(frozen['source'])
proc=subprocess.run(['git','cat-file','--batch'],input=('\n'.join('HEAD:'+n for n in names)+'\n').encode(),stdout=subprocess.PIPE,check=True)
raw=proc.stdout;offset=0
for name in names:
 end=raw.index(b'\n',offset);header=raw[offset:end].split();assert len(header)==3 and header[1]==b'blob',(name,header)
 size=int(header[2]);data=raw[end+1:end+1+size];assert len(data)==size and raw[end+1+size:end+2+size]==b'\n'
 assert hashlib.sha256(data).hexdigest()==frozen['source'][name],name
 assert hashlib.sha256((wd/name).read_bytes()).hexdigest()==frozen['source'][name],name
 offset=end+2+size
assert offset==len(raw)
for name,digest in frozen['build'].items():assert hashlib.sha256((p/'production-dist'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()==frozen['genuine']
next_proof=json.loads((p/'freezing-arrow-source-audit.json').read_text())
assert all(frozen['source'][name]==digest for name,digest in next_proof['source_hashes'].items())
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'implementation_commits':sys.argv[1:],'actual_committed_source_blobs':len(names),'source_disk_exact':True,'source_commit_exact':True,'build_files_exact':len(frozen['build']),'genuine':frozen['genuine'],'next_freezing_arrow_reproduction_source_exact':True,'all_exact':True}
f=wd/'docs/plans/evidence/fixtures/conversion/committed-source-audit.json';assert not f.exists();f.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
