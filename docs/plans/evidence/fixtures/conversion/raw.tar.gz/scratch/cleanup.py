from pathlib import Path
import hashlib,json,os,socket
p=Path(__file__).parent
expected=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-conversion-xzvjsj_z')
assert p==p.resolve()==expected and not p.is_symlink()
assert json.loads((p/'owned-paths.json').read_text())['root']==str(p)
packet=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/conversion')
manifest=json.loads((packet/'packet.json').read_text())
assert hashlib.sha256((packet/'raw.tar.gz').read_bytes()).hexdigest()==manifest['sha256']
owner=json.loads((p/'browser-server-server-owner.json').read_text());assert owner['port']==4486
assert not (Path('/proc')/str(owner['pid'])).exists()
with socket.socket() as sock:assert sock.connect_ex(('127.0.0.1',4486))!=0
for pid in [675243,675254,675255,675281]:assert not (Path('/proc')/str(pid)).exists()
for f in packet.glob('*-owner.json'):
 for key,value in json.loads(f.read_text()).items():
  if key in ['pid','wrapper_pid']:assert not (Path('/proc')/str(value)).exists(),(f.name,key,value)
all_paths=list(p.rglob('*'));assert not any(f.is_symlink() for f in all_paths)
files=[f for f in all_paths if f.is_file()];records=[]
for f in files:
 data=f.read_bytes();records.append({'path':str(f),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
failures=[]
for record in records:
 f=Path(record['path']);assert f.resolve().is_relative_to(p)
 try:
  assert hashlib.sha256(f.read_bytes()).hexdigest()==record['sha256']
  f.unlink()
 except Exception as e:failures.append({'path':str(f),'error':str(e)})
for d in sorted([f for f in all_paths if f.is_dir()],key=lambda x:len(x.parts),reverse=True):
 try:d.rmdir()
 except Exception as e:failures.append({'path':str(d),'error':str(e)})
try:p.rmdir()
except Exception as e:failures.append({'path':str(p),'error':str(e)})
removed_command_files=[]
keep={'packet.json','cleanup.json','inventory-reconciliation.json','committed-source-audit.json'}
for name,record in manifest['members'].items():
 if not name.startswith('commands/'):continue
 f=packet/name.removeprefix('commands/')
 if f.name in keep:continue
 try:
  assert f.is_file() and not f.is_symlink() and f.resolve().parent==packet.resolve()
  assert hashlib.sha256(f.read_bytes()).hexdigest()==record['sha256']
  f.unlink();removed_command_files.append(str(f))
 except Exception as e:failures.append({'path':str(f),'error':str(e)})
remaining=[str(f) for f in p.rglob('*')] if p.exists() else []
result={'task_root':str(p),'scratch_files_removed':len(records),'scratch_file_inventory':records,'archived_command_files_removed':removed_command_files,'scratch_absent':not p.exists(),'preview_pid':owner['pid'],'preview_pid_absent':not (Path('/proc')/str(owner['pid'])).exists(),'port4486_closed':True,'initial_interrupted_descendants_absent':True,'remaining':remaining,'failures':failures,'older_task_roots_preserved':True,'worktree_and_shared_caches_preserved':True}
(packet/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['scratch_file_inventory','archived_command_files_removed']}))
assert not failures and not remaining and not p.exists()
