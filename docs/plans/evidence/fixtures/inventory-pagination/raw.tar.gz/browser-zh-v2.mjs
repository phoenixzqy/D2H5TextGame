import {chromium,expect} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {gunzipSync,gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/inventory-pagination';
const inputPath='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/earned-act3-through362/retained-final.json.gz';
const raw=gunzipSync(await readFile(inputPath)),input=JSON.parse(raw),base='http://127.0.0.1:4433';
const browser=await chromium.launch({headless:true});
const report={kind:'read-only UI diagnostics on copies of genuine earned save; zero gameplay entries or projected state promotion',inputPath,browser:browser.version(),cases:[],errors:[],console:[]};
const sizes=[[360,640],[412,915],[640,360],[1280,800],[1920,1080]];
try {
 for(const locale of ['zh-CN'])for(const [width,height] of sizes){
  const dir=root+'/browser-zh-v2/'+locale+'-'+width+'x'+height;await mkdir(dir,{recursive:true});
  const context=await browser.newContext({viewport:{width,height},acceptDownloads:true});
  const en=locale==='en',row={locale,width,height};const expected=structuredClone(input);expected.meta.settings.locale=locale;report.cases.push(row);
  context.on('page',p=>{p.on('pageerror',e=>report.errors.push(e.message));p.on('console',m=>{if(['error','warning'].includes(m.type()))report.console.push(m.text());});});
  let page;
  async function open(){const p=await context.newPage();p.setDefaultTimeout(60000);await p.clock.install({time:new Date(input.timestamp)});await p.clock.setFixedTime(new Date(input.timestamp));await p.goto(base);await p.waitForLoadState('networkidle');return p;}
  async function nav(route){await page.locator(`a[href="/${route}"]`).first().click();await expect(page.getByTestId(route+'-screen')).toBeVisible({timeout:60000});}
  async function exported(label){await nav('settings');const waiting=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const d=await waiting;let s;try{s=JSON.parse(await readFile(await d.path(),'utf8'));}finally{await d.delete();}await writeFile(dir+'/'+label+'.json.gz',gzipSync(JSON.stringify(s)),{flag:'wx'});return s;}
  try {
   page=await open();await page.getByTestId('home-new-game').click();await page.getByTestId('class-sorceress').click();await page.getByTestId('character-name-input').fill('Import access only');await page.getByTestId('character-start-btn').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav('settings');await page.getByRole('button',{name:'English',exact:true}).click();await context.grantPermissions(['clipboard-read','clipboard-write'],{origin:base});await page.getByRole('button',{name:'Import Save',exact:true}).click();const dialog=page.getByRole('dialog');await page.evaluate(s=>navigator.clipboard.writeText(s),raw.toString('utf8'));await dialog.getByRole('textbox').click();await dialog.getByRole('textbox').press('ControlOrMeta+V');await dialog.getByRole('button',{name:'Import Save',exact:true}).click();await expect(dialog).toHaveCount(0);assert.deepEqual(await exported('imported'),input);assert.equal(await page.evaluate(()=>'__GAME__'in window),false);
   if(!en)await page.getByRole('button',{name:'简体中文',exact:true}).click();
   const started=performance.now();await page.locator('a[href="/inventory"]').first().click();const clicked=performance.now();await expect(page.getByTestId('inventory-screen')).toBeVisible({timeout:60000});row.inventoryTotalMs=performance.now()-started;row.inventoryPostClickMs=performance.now()-clicked;
   const count=async()=>page.locator('[data-testid="backpack-grid"] [data-testid^="inv-item-"]').count();assert.equal(await count(),100);
   const pager=page.getByRole('navigation',{name:en?'Inventory pages':'物品分页'});await expect(pager).toBeVisible();
   const controls=await pager.locator('button,input').evaluateAll(nodes=>nodes.map(n=>({width:n.getBoundingClientRect().width,height:n.getBoundingClientRect().height})));for(const c of controls){assert(c.width>=44&&c.height>=44);}row.touchControls=controls.length;
   const next=page.getByRole('button',{name:en?'Next page':'下一页',exact:true});await next.focus();await next.press('Enter');await expect(page.getByTestId('inv-item-'+input.inventory.backpack[100].id)).toBeVisible();assert.equal(await count(),100);
   await page.getByRole('button',{name:en?'Last page':'末页',exact:true}).click();const last=input.inventory.backpack.at(-1);await expect(page.getByTestId('inv-item-'+last.id)).toBeVisible();assert.equal(await count(),input.inventory.backpack.length%100||100);row.lastItem=last.id;await page.screenshot({path:dir+'/last-page.png'});
   await page.getByTestId('inv-item-'+last.id).click();await expect(page.getByTestId('inv-primary-action')).toBeVisible();await page.keyboard.press('Escape');
   const number=page.getByRole('spinbutton',{name:en?'Page':'页码',exact:true});await number.fill('45');await expect(page.getByTestId('inv-item-'+input.inventory.backpack[4400].id)).toBeVisible();assert.equal(await count(),100);
   const overflow=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth}));assert(overflow.scrollWidth<=overflow.width+1);row.overflow=overflow;await pager.scrollIntoViewIfNeeded();await page.mouse.move(width-1,0);await page.clock.runFor(300);await page.screenshot({path:dir+'/middle-page.png'});
   assert.deepEqual(await exported('after-navigation'),expected);
   await page.getByRole('button',{name:en?'Save':'保存',exact:true}).click();await expect(page.getByRole('status')).toHaveText(en?'Saved':'已保存');const saved=await exported('saved');assert.deepEqual(saved,expected);await page.close();page=await open();await page.getByTestId('home-continue').click();await expect(page.getByTestId('town-screen')).toBeVisible();assert.deepEqual(await exported('continued'),saved);row.exactSaveCloseContinue=true;row.status='pass';
   assert.deepEqual(report.errors,[]);assert.deepEqual(report.console,[]);process.stdout.write(JSON.stringify(row)+'\n');
  }catch(error){row.status='failure';row.failure=String(error.stack??error);if(page&&!page.isClosed()){try{await page.screenshot({path:dir+'/failure.png'});await writeFile(dir+'/failure.txt',await page.locator('body').innerText());await exported('stopped-diagnostic');}catch(e){row.captureFailure=String(e);}}throw error;}
  finally{await writeFile(root+'/browser-zh-v2/report.json',JSON.stringify(report,null,2));await context.close();}
 }
 report.status='pass';
}catch(error){report.status='failure';report.failure=String(error.stack??error);process.exitCode=1;}
finally{await writeFile(root+'/browser-zh-v2/report.json',JSON.stringify(report,null,2));await browser.close();}
