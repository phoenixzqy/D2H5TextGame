import gzip, hashlib, json, sys, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=lambda raw: hashlib.sha256(raw).hexdigest()
freeze=json.loads((ROOT/'freeze.json').read_text())
checks={}
for label,base in [('source',REPO),('dist',ROOT/'dist')]:
    drift=[name for name,digest in freeze[label].items() if not (base/name).is_file() or sha((base/name).read_bytes())!=digest]
    assert not drift, (label,drift)
    checks[label]={'files':len(freeze[label]),'drift':drift}
if '--served' in sys.argv:
    served={}
    for name,digest in freeze['dist'].items():
        if name.endswith('.js') and name.startswith('assets/'):
            raw=urllib.request.urlopen('http://127.0.0.1:4433/'+name).read()
            assert sha(raw)==digest,name
            for marker in [b'__GAME__',b'seedItem',b'attachTestBridge']:
                assert marker not in raw, (name,marker)
            served[name]=digest
    assert len(served)==4,len(served)
    checks['served']=served
path=REPO/'docs/plans/evidence/fixtures/earned-act3-through362/retained-final.json.gz'
raw=gzip.decompress(path.read_bytes())
assert sha(raw)=='6c094440dedbe276f9280815c26a90d4926034b834c725d151151b67456d408c'
original=json.loads(raw)
checks['authoritativeSaveRawSHA256']=sha(raw)
rows=[]
for report_dir,locale in [('browser','en'),('browser-zh-v2','zh-CN')]:
    report=json.loads((ROOT/report_dir/'report.json').read_text())
    assert report['errors']==[] and report['console']==[]
    cases=[r for r in report['cases'] if r['locale']==locale]
    assert len(cases)==5 and all(r['status']=='pass' for r in cases)
    for row in cases:
        base=ROOT/report_dir/f"{locale}-{row['width']}x{row['height']}"
        expected=json.loads(raw)
        expected['meta']['settings']['locale']=locale
        for name in ['imported','after-navigation','saved','continued']:
            value=json.loads(gzip.decompress((base/(name+'.json.gz')).read_bytes()))
            assert value==(original if name=='imported' else expected),(base,name)
        assert row['exactSaveCloseContinue'] and row['touchControls']==5
        assert row['overflow']['scrollWidth']<=row['overflow']['width']+1
        rows.append(row)
checks['validBrowserCases']=rows
checks['exactDurablePairs']=len(rows)
checks['postClickMs']={'min':min(r['inventoryPostClickMs'] for r in rows),'max':max(r['inventoryPostClickMs'] for r in rows)}
checks['scope']='UI diagnostics on copies; zero genuine campaign changes; independent acceptance pending'
(ROOT/'audit.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k not in ['validBrowserCases','served']},indent=2))
