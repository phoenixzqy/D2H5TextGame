from pathlib import Path
import json,hashlib,tarfile,gzip
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
OUT=REPO/'docs/plans/evidence/fixtures/earned-tyrael-and-river-through379'
OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted(p for p in ROOT.rglob('*')if p.is_file())
assert not any(p.is_symlink()for p in paths)
manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in paths}
with tarfile.open(OUT/'evidence.tar.gz','w:gz')as t:
 for p in paths:t.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(OUT/'evidence.tar.gz')as t:
 assert len(t.getmembers())==len(paths)
 for m in t.getmembers():
  data=t.extractfile(m).read();r=manifest[m.name];assert len(data)==r['bytes']and sha(data)==r['sha256']
raw=(ROOT/'river-farm376/final.json.gz').read_bytes();summary=(ROOT/'audit-final.json').read_bytes()
(OUT/'retained-final.json.gz').write_bytes(raw)
(OUT/'summary.json').write_bytes(summary)
(OUT/'catalog-audit.json').write_bytes((ROOT/'catalog-audit.json').read_bytes())
(OUT/'manifest.json').write_text(json.dumps({'sourceCommit':'59f2590','runtimeHead':'22bc93c','archive':'evidence.tar.gz','archiveBytes':(OUT/'evidence.tar.gz').stat().st_size,'archiveSHA256':sha((OUT/'evidence.tar.gz').read_bytes()),'entries':manifest,'coverage':'Every retained file in this exact task raw directory, including all native exports, original failures, scripts, reports, screenshots, policies, source/build hashes and cleanup. No build output or task Python cache remains.','retainedFinalSHA256':sha(raw),'finalRawSHA256':sha(gzip.decompress(raw)),'summarySHA256':sha(summary),'retainedRoot':str(ROOT),'owner':'root','retention':'Raw evidence through campaign/full-v1 consumers; root removes exact raw directory afterward.'},indent=2)+'\n')
print(json.dumps({'entries':len(paths),'archiveBytes':(OUT/'evidence.tar.gz').stat().st_size,'archiveSHA256':sha((OUT/'evidence.tar.gz').read_bytes()),'finalRawSHA256':sha(gzip.decompress(raw))}))
