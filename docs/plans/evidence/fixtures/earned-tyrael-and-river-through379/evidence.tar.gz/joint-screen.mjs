import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';import {gunzipSync} from 'node:zlib';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/diablo-preparation376';
const input=root+'/tyrael-blessing/final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw)),earlier=JSON.parse(await readFile(root+'/screen.json','utf8'));
assert.equal(save.map.challengeOrdinals.normal,376);assert.equal(save.player.skillPoints,3);assert.equal(save.player.statPoints,5);
const policy={kind:'bounded joint owned-gear damage/survival preparation',owner:'root',security:'pass: existing public local-copy equip/allocation/respec/combat APIs; no source tuning, networking, dependency or genuine state mutation',planReview:'ready: three fixed policies before32 new independent paired seeds, first16/last16. Chaos first, River regression after qualification; first>=26/32 and>=12/16 both qualifies. Max128 projections, stop first nonwin; no actual supplied seed or promoted diagnostic save.',builds:[{id:'joint-ehp150',floor:1.5},{id:'joint-ehp200',floor:2},{id:'joint-ehp150-dex180',floor:1.5,respec:true}],heuristic:'two fixed coordinate passes; start prior four defensive swaps, original Rogue; maximize expected Orb/physical damage after observed Diablo50cold/460armor/180MR, preserving hero1.5or2x original physicalEHP, merc1x; heroLife>=500,mana>=85%original,AS>=original,fire>=40,cold>=60,lightning>=50; mercLife>=330,mana>=85%original,AS>=original,fire>=25,cold>=45,lightning>=35. Three earned skills toColdMastery14;5statsDex, or one free reset all155refunded pointsDex180. No paid skill reset.'};
await writeFile(root+'/joint-policy.json',JSON.stringify(policy,null,2)+'\n',{flag:'wx'});
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p),{restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts'),{useInventoryStore}=await load('/src/stores/inventoryStore.ts'),{usePlayerStore}=await load('/src/stores/playerStore.ts'),{useMercStore}=await load('/src/stores/mercStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{prepareTownRespec,executeTownRespec}=await load('/src/stores/respecActions.ts'),{prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts'),{deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts'),{loadItemBases}=await load('/src/data/loaders/loot.ts'),{checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts'),{isTwoHanded}=await load('/src/engine/inventory/equipValidator.ts'),{mitigateDamage}=await load('/src/engine/combat/damage.ts'),{actionPeriodMs}=await load('/src/engine/combat/combat.ts'),{hashSeed}=await load('/src/engine/rng.ts');
 const merc=save.mercs.ownedMercs.find(m=>m.id===save.mercs.fieldedMercId),bases=loadItemBases(),slots=['head','chest','gloves','boots','belt','offhand','weapon','amulet','ring-left','ring-right'];
 const beforeHero=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts)(save.inventory.equipped),beforeMerc=deriveEquippedMercStats(merc,save.mercs.mercEquipment[merc.id]);
 const hit=(raw,s,type='physical',resistances=s.resistances)=>mitigateDamage(raw,{type,defenderResistances:resistances,defenderArmor:s.defense,defenderMagicResist:s.magicResist}).final;
 const ehp=s=>s.lifeMax/((.75*hit(600,s)+.25*hit(1200,s))*Math.max(.05,.85-s.physDodge));
 const boss={defense:460,magicResist:180,resistances:{physical:0,fire:75,cold:-17,lightning:75,poison:50,arcane:50}};
 function points(b){
  if(b.respec){const q=prepareTownRespec('npc/ormus','stat');assert.equal(q.kind,'ok');assert.equal(q.cost,0);assert.equal(executeTownRespec(q.request),'ok');assert.equal(usePlayerStore.getState().player.statPoints,155);assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:155,vitality:0,energy:0},usePlayerStore.getState().player),'ok');}
  else assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:5,vitality:0,energy:0},usePlayerStore.getState().player),'ok');
  for(let i=0;i<3;i++)assert.equal(usePlayerStore.getState().allocateSkillPoint('skills-sorceress-cold-mastery'),'ok');
 }
 const report={policy,inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),seeds:Array.from({length:32},(_,i)=>hashSeed('joint-diablo376-v1:'+i)),proposals:[],rows:[],summary:[],selected:null};
 for(const b of policy.builds){
  restoreEarnedSave(save,0);points(b);const person=structuredClone(usePlayerStore.getState().player),heroDerive=prepareEquippedPlayerStats(person,person.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
  const derive=(who,g)=>who==='hero'?heroDerive(g):deriveEquippedMercStats(merc,g),initial={hero:beforeHero,merc:beforeMerc};
  const gear={hero:{...save.inventory.equipped},merc:{...save.mercs.mercEquipment[merc.id]}};
  for(const c of earlier.changes)gear.hero[c.slot]=save.inventory.backpack.find(i=>i.id===c.to);
  function score(who,g){const s=derive(who,g),base=initial[who];
   if(s.lifeMax<(who==='hero'?500:330)||s.manaMax<base.manaMax*.85||s.attackSpeed<base.attackSpeed||ehp(s)<ehp(base)*(who==='hero'?b.floor:1))return -Infinity;
   if(s.resistances.fire<(who==='hero'?40:25)||s.resistances.cold<(who==='hero'?60:45)||s.resistances.lightning<(who==='hero'?50:35))return -Infinity;
   const physical=(1-s.critChance)*hit(s.attack,boss)+s.critChance*hit(s.attack*s.critDamage,boss),rate=1000/actionPeriodMs(s.attackSpeed);
   if(who==='merc')return physical*rate;
   const orb=(1-s.critChance)*hit(189,boss,'cold')+s.critChance*hit(189*s.critDamage,boss,'cold');
   return orb/2+physical*Math.max(0,rate-1);
  }
  for(let pass=0;pass<2;pass++)for(const who of ['hero','merc'])for(const slot of slots){
   const occupied=new Set([...Object.entries(gear[who]).filter(([k])=>k!==slot).map(([,i])=>i?.id),...Object.values(gear[who==='hero'?'merc':'hero']).map(i=>i?.id)]);
   let best=gear[who],value=score(who,best);
   for(const item of save.inventory.backpack){const base=bases.get(item.baseId);if(occupied.has(item.id)||isTwoHanded(base)||!slotMatches(base?.slot,slot)||!checkEligibility(item,who==='hero'?person:merc,bases).eligible)continue;const next={...gear[who],[slot]:item},n=score(who,next);if(n>value+1e-12){best=next;value=n;}}
   gear[who]=best;
  }
  const changes=[];for(const who of ['hero','merc'])for(const slot of slots){const old=(who==='hero'?save.inventory.equipped:save.mercs.mercEquipment[merc.id])[slot],item=gear[who][slot];if(item?.id!==old?.id)changes.push({who,slot,from:old?.id??null,to:item.id});}
  const proposal={...b,changes,hero:derive('hero',gear.hero),merc:derive('merc',gear.merc),heroScore:score('hero',gear.hero),mercScore:score('merc',gear.merc),heroEHPFactor:ehp(derive('hero',gear.hero))/ehp(beforeHero),mercEHPFactor:ehp(derive('merc',gear.merc))/ehp(beforeMerc)};assert(Number.isFinite(proposal.heroScore)&&Number.isFinite(proposal.mercScore));report.proposals.push(proposal);
 }
 await writeFile(root+'/joint-proposals.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({proposals:report.proposals})+'\n');
 function prepare(p){restoreEarnedSave(save,0);points(p);for(const c of p.changes){const i=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(i);assert.deepEqual(c.who==='hero'?useInventoryStore.getState().equipItem(i,c.slot):useMercStore.getState().equipOnMerc(merc.id,c.slot,i),{ok:true});}const hero=usePlayerStore.getState().player;assert.deepEqual(hero.derivedStats,p.hero);assert.deepEqual(deriveEquippedMercStats(merc,useMercStore.getState().mercEquipment[merc.id]),p.merc);assert.equal(hero.skillLevels['sorceress.cold_mastery'],14);assert.equal(hero.skillPoints,0);assert.equal(hero.statPoints,0);assert.equal(hero.derivedStats.life,save.player.derivedStats.life);assert.equal(hero.derivedStats.mana,save.player.derivedStats.mana);return {coreStats:hero.coreStats,derivedStats:hero.derivedStats,skillLevels:hero.skillLevels,statPoints:hero.statPoints,skillPoints:hero.skillPoints,respecsRemaining:hero.respecsRemaining};}
 for(const p of report.proposals){let qualified=true;for(const area of ['chaos-sanctuary','river-of-flame']){const preparation=prepare(p);for(const [index,seed]of report.seeds.entries()){
   prepare(p);const h=startEarnedRun({act:4,subAreaId:'areas/act4-'+area,mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,376);const waves=[];
   for(let i=0;i<h.totalWaves;i++){const w=playEarnedWave(h,i);waves.push({wave:i+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana})),remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life}))});if(w.advanceResult!=='next-wave')break;}
   report.rows.push({build:p.id,area,seed,group:index<16?'screen':'second-half',won:waves.length===h.totalWaves&&waves.every(w=>w.winner==='player'),waves});useCombatStore.getState().endCombat();
  }
  const rows=report.rows.filter(r=>r.build===p.id&&r.area===area),wins=rows.filter(r=>r.won).length,second=rows.filter(r=>r.group==='second-half'&&r.won).length;report.summary.push({build:p.id,area,n:32,wins,secondHalfWins:second,preparation});process.stdout.write(JSON.stringify({build:p.id,area,wins,secondHalfWins:second})+'\n');await writeFile(root+'/joint-partial.json',JSON.stringify(report,null,2)+'\n');if(wins<26||second<12){qualified=false;break;}}
  if(qualified){report.selected=p;break;}
 }
 assert(report.rows.length<=128);assert.deepEqual(await readFile(input),raw);await writeFile(root+'/joint-screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({selected:report.selected?.id??null,summary:report.summary.map(({preparation,...r})=>r)})+'\n');
}finally{await server.close();}
