import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/diablo-preparation376';
const input=repo+'/docs/plans/evidence/fixtures/earned-mephisto-and-act4-through375/retained-final.json.gz';
const raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,376);assert.equal(save.player.statPoints,5);assert.equal(save.player.skillPoints,1);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {loadItemBases}=await load('/src/data/loaders/loot.ts');
 const {checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts');
 const {isTwoHanded}=await load('/src/engine/inventory/equipValidator.ts');
 const {prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts');
 const {mitigateDamage}=await load('/src/engine/combat/damage.ts');
 const {hashSeed}=await load('/src/engine/rng.ts');
 const derive=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
 const initial=derive(save.inventory.equipped),bases=loadItemBases();assert.deepEqual(initial,save.player.derivedStats);
 const crit=s=>1+s.critChance*(s.critDamage-1),baseCrit=crit(initial);
 const score=gear=>{
  const s=derive(gear);
  if(s.lifeMax<initial.lifeMax||s.manaMax<initial.manaMax||s.attack<initial.attack||s.attackSpeed<initial.attackSpeed||crit(s)+1e-12<baseCrit)return -Infinity;
  if(['fire','cold','lightning'].some(k=>s.resistances[k]<60))return -Infinity;
  const hit=damage=>mitigateDamage(damage,{type:'physical',defenderResistances:s.resistances,defenderArmor:s.defense,defenderMagicResist:s.magicResist}).final;
  return s.lifeMax/((.75*hit(600)+.25*hit(1200))*Math.max(.05,.85-s.physDodge));
 };
 const policy=JSON.parse(await readFile(root+'/policy.json','utf8'));let equipment={...save.inventory.equipped};
 const reserved=new Set(Object.values(save.mercs.mercEquipment).flatMap(Object.values).filter(Boolean).map(i=>i.id));
 for(let pass=0;pass<2;pass++)for(const slot of policy.heuristic.slots){
  const occupied=new Set([...reserved,...Object.entries(equipment).filter(([s])=>s!==slot).map(([,i])=>i?.id)]);
  let best=equipment,value=score(equipment);
  for(const item of save.inventory.backpack){
   const base=bases.get(item.baseId);
   if(occupied.has(item.id)||isTwoHanded(base)||!slotMatches(base?.slot,slot)||!checkEligibility(item,save.player,bases).eligible)continue;
   const next={...equipment,[slot]:item},n=score(next);
   if(n>value+1e-12){best=next;value=n;}
  }
  equipment=best;
 }
 const changes=policy.heuristic.slots.filter(slot=>equipment[slot]?.id!==save.inventory.equipped[slot]?.id).map(slot=>({slot,from:save.inventory.equipped[slot]?.id??null,to:equipment[slot].id}));
 const builds=[{id:'baseline',baseline:true},{id:'points',points:true},{id:'gear',gear:true},{id:'gear-points',gear:true,points:true}];
 function prepare(b){
  restoreEarnedSave(save,0);
  if(b.gear)for(const c of changes){const item=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(item);assert.deepEqual(useInventoryStore.getState().equipItem(item,c.slot),{ok:true});}
  if(b.gear)for(const [slot,item]of Object.entries(equipment))assert.equal(useInventoryStore.getState().equipped[slot]?.id,item?.id);
  if(b.points){assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:0,vitality:5,energy:0},usePlayerStore.getState().player),'ok');assert.equal(usePlayerStore.getState().allocateSkillPoint('skills-sorceress-cold-mastery'),'ok');}
  const p=usePlayerStore.getState().player;
  assert.equal(p.derivedStats.life,save.player.derivedStats.life);assert.equal(p.derivedStats.mana,save.player.derivedStats.mana);
  assert.deepEqual(p.comboOrder,save.player.comboOrder);assert.deepEqual(p.respecsRemaining,save.player.respecsRemaining);
  assert.deepEqual(useMercStore.getState().mercEquipment,save.mercs.mercEquipment);
  return {coreStats:p.coreStats,derivedStats:p.derivedStats,skillLevels:p.skillLevels,statPoints:p.statPoints,skillPoints:p.skillPoints};
 }
 const report={kind:'bounded diagnostic owned-mitigation screening; no genuine action or promoted save',policy,inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),initial,proposed:derive(equipment),changes,seeds:Array.from({length:32},(_,i)=>hashSeed('diablo376-owned-mitigation-v1:'+i)),rows:[],summary:[],selected:null};
 assert.equal(new Set(report.seeds).size,32);report.preflight=prepare({gear:true});assert.deepEqual(report.preflight.derivedStats,report.proposed);
 await writeFile(root+'/gear-preflight.json',JSON.stringify({initial,proposed:report.proposed,changes,baselineScore:score(save.inventory.equipped),proposedScore:score(equipment)},null,2)+'\n',{flag:'wx'});
 for(const b of builds){let qualified=true;for(const area of (b.baseline?['chaos-sanctuary']:['chaos-sanctuary','river-of-flame'])){
  const preparation=prepare(b);
  for(const [index,seed]of report.seeds.entries()){
   prepare(b);const h=startEarnedRun({act:4,subAreaId:'areas/act4-'+area,mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,376);const waves=[];
   for(let i=0;i<h.totalWaves;i++){const w=playEarnedWave(h,i);waves.push({wave:i+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana})),remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life}))});if(w.advanceResult!=='next-wave')break;}
   const won=waves.length===h.totalWaves&&waves.every(w=>w.winner==='player');report.rows.push({build:b.id,area,seed,group:index<16?'screen':'second-half',won,waves});useCombatStore.getState().endCombat();
  }
  const rows=report.rows.filter(r=>r.build===b.id&&r.area===area),wins=rows.filter(r=>r.won).length,second=rows.filter(r=>r.group==='second-half'&&r.won).length;
  const result={build:b.id,area,n:32,wins,secondHalfWins:second,preparation};report.summary.push(result);process.stdout.write(JSON.stringify({...result,preparation:undefined})+'\n');
  await writeFile(root+'/partial.json',JSON.stringify(report,null,2)+'\n');
  if(wins<26||second<12){qualified=false;break;}
 }
 if(qualified&&!b.baseline){report.selected=b;break;}}
 assert(report.rows.length<=160);assert.deepEqual(await readFile(input),raw);
 await writeFile(root+'/screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({selected:report.selected,changes,proposed:report.proposed})+'\n');
}finally{await server.close();}
