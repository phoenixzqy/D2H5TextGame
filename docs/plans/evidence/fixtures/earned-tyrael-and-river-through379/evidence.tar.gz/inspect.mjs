import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';import {gunzipSync} from 'node:zlib';import assert from 'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/diablo-preparation376';
const save=JSON.parse(gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-mephisto-and-act4-through375/retained-final.json.gz'))),screen=JSON.parse(await readFile(root+'/screen.json','utf8'));
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p),{restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts'),{useInventoryStore}=await load('/src/stores/inventoryStore.ts'),{useMercStore}=await load('/src/stores/mercStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts');
 restoreEarnedSave(save,0);for(const c of screen.changes){const i=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert.deepEqual(useInventoryStore.getState().equipItem(i,c.slot),{ok:true});}
 const h=startEarnedRun({act:4,subAreaId:'areas/act4-chaos-sanctuary',mode:'manual',runSeed:screen.seeds[0]});
 for(let i=0;i<6;i++)assert.equal(playEarnedWave(h,i).advanceResult,'next-wave');
 const store=useCombatStore.getState(),merc=save.mercs.ownedMercs.find(m=>m.id===save.mercs.fieldedMercId);
 const result={kind:'diagnostic trace of full original Chaos progression on private copy',seed:screen.seeds[0],playerTeam:store.playerTeam,enemyTeam:store.enemyTeam,events:store.recordedEvents,outcome:store.outcome,merc,mercEquipment:save.mercs.mercEquipment[merc.id],mercDerived:deriveEquippedMercStats(merc,save.mercs.mercEquipment[merc.id])};
 await writeFile(root+'/inspection.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 const compact=u=>({id:u.id,life:u.life,mana:u.mana,stats:u.stats,coldMastery:u.coldMastery,keys:Object.keys(u),skills:u.skills});
 process.stdout.write(JSON.stringify({players:store.playerTeam.map(compact),enemies:store.enemyTeam.map(compact),merc:result.mercDerived})+'\n');useCombatStore.getState().endCombat();
}finally{await server.close();}
