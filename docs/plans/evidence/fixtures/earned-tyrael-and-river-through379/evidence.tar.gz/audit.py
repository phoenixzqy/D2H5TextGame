import copy,gzip,hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
sha=lambda b:hashlib.sha256(b).hexdigest()
original=load(REPO/'docs/plans/evidence/fixtures/earned-mephisto-and-act4-through375/retained-final.json.gz')
assert sha(gzip.decompress((REPO/'docs/plans/evidence/fixtures/earned-mephisto-and-act4-through375/retained-final.json.gz').read_bytes()))=='f16814259c3ac7bf7ba70752521cc792212ddf97ab9447dcbc233fa2cd57639c'
freeze=json.loads((ROOT/'freeze.json').read_text())
assert all(sha((REPO/k).read_bytes())==v for k,v in freeze['source'].items())
assert all(sha((Path(freeze['distRoot'])/k).read_bytes())==v for k,v in freeze['dist'].items())
for k,v in json.loads((ROOT/'served.json').read_text()).items():
 b=urllib.request.urlopen('http://127.0.0.1:4438/'+k).read();assert sha(b)==v
 assert not any(t in b for t in [b'__GAME__',b'seedItem',b'attachTestBridge'])
for name,n,builds in [('screen.json',128,4),('joint-screen-v3.json',96,3)]:
 s=json.loads((ROOT/name).read_text());assert s['selected'] is None and len(s['rows'])==n and len(s['summary'])==builds
 assert len(set(s['seeds']))==32
 assert all(r['area']=='chaos-sanctuary' and not r['won'] and r['waves'][-1]['winner']!='player' for r in s['rows'])
 assert all(r['wins']==r['secondHalfWins']==0 for r in s['summary'])
def owned(s):
 rows=[*s['inventory']['backpack'],*s['inventory']['stash'],*s['inventory']['equipped'].values(),*(i for g in s['mercs']['mercEquipment'].values() for i in g.values())]
 rows=[i for i in rows if i];d={i['id']:i for i in rows};assert len(d)==len(rows);return d
def xp(s):return s['player']['experience']+sum(int(100*l**2.5)for l in range(1,s['player']['level']))
quest='quests/side-act4-tyraels-blessing'
blessing=ROOT/'tyrael-blessing';report=json.loads((blessing/'report.json').read_text())
assert report['status']=='observed' and report['errors']==report['console']==[] and not report.get('cleanupErrors')
expected=copy.deepcopy(original)
assert load(blessing/'imported.json.gz')==expected
expected['map']['questProgress'][quest]={'id':quest,'status':'inProgress','objectives':{'obj-talk':False}}
assert load(blessing/'started.json.gz')==expected
expected['map']['questProgress'][quest].update(status='completed',objectives={'obj-talk':True})
assert load(blessing/'talked.json.gz')==expected
expected['map']['questProgress'][quest]['rewardClaimed']=True;expected['player']['skillPoints']+=2
for name in ['claimed','saved','continued','final']:assert load(blessing/(name+'.json.gz'))==expected
assert load(blessing/'saved.json.gz')==load(blessing/'continued.json.gz')
ancestral=owned(expected);assert len(ancestral)==19893
farm=ROOT/'river-farm376';r=json.loads((farm/'report.json').read_text());assert r['status']=='observed',r.get('failure')
assert r['errors']==r['console']==[] and not r.get('cleanupErrors') and r['retries']==0
launches=r['launches'];assert 1<=len(launches)<=4
assert [x['ordinal']for x in launches]==list(range(376,376+len(launches)))
assert all(x['alias']=='river-of-flame'for x in launches)
exports=[];pairs=[['tyrael-blessing/saved.json.gz','tyrael-blessing/continued.json.gz']]
for directory in [blessing,farm]:
 for p in sorted(directory.glob('*.json.gz')):
  s=load(p)
  if 'player' not in s:continue
  exports.append(str(p.relative_to(ROOT)));now=owned(s)
  for ident,item in ancestral.items():assert now.get(ident)==item,(p,ident)
  assert s['player']['coreStats']==original['player']['coreStats']
  assert s['player']['skillLevels']==original['player']['skillLevels']
  assert s['player']['comboOrder']==original['player']['comboOrder']
  assert s['player']['respecsRemaining']==original['player']['respecsRemaining']=={'stat':2,'skill':0}
  assert s['inventory']['equipped']==original['inventory']['equipped']
  assert s['mercs']['mercEquipment']==original['mercs']['mercEquipment']
  assert s['mercs']['fieldedMercId']==original['mercs']['fieldedMercId']
  assert s['map']['challengeOrdinals']['nightmare']==0 and s['endgame']==original['endgame']
  assert s['map']['questProgress']['quests/act4-terrors-end']==original['map']['questProgress']['quests/act4-terrors-end']
  assert s['map']['questReceipts']==original['map']['questReceipts']
  assert s['inventory']['questItems']==original['inventory']['questItems']
  if directory==farm:
   assert s['player']['statPoints']==5+5*(s['player']['level']-31)
   assert s['player']['skillPoints']==3+(s['player']['level']-31)
 for p in directory.glob('*-saved.json.gz'):
  other=p.with_name(p.name.replace('-saved','-continued'));assert other.exists() and load(p)==load(other);pairs.append([str(p.relative_to(ROOT)),str(other.relative_to(ROOT))])
winning=failed=income=gear=0
for area in r['areas']:
 ordinal=area['ordinal'];previous=load(farm/('prelaunch-'+str(ordinal)+'.json.gz'))
 for row in area['waves']:
  wave=row['wave'];initial=load(farm/(f'{ordinal}-w{wave}-initial.json.gz'));terminal=load(farm/(f'{ordinal}-w{wave}-terminal.json.gz'))
  assert initial['enemyIds'] and set(initial['enemyIds'])<=set(terminal['enemyIds'])
  assert terminal['skipDisabled'] is True
  if row['outcome']=='victory':
   winning+=1;assert terminal['liveEnemies']==0 and terminal['log'][-1]=='Victory! All enemies are defeated.'
   assert next(c for c in terminal['cards']if c['id']=='unit-card-'+original['player']['id'])['dead'] is None
   matches=list(farm.glob(f'*-{ordinal}-w{wave}-settled.json.gz'));assert len(matches)==1;current=load(matches[0])
   delta=xp(current)-xp(previous);new=set(owned(current))-set(owned(previous));assert delta==row['delta']['xp']>0 and sorted(new)==sorted(row['delta']['newItems'])
   income+=delta;gear+=len(new);previous=current
  else:
   failed+=1;assert row['delta']=={'xp':0,'newItems':[]};assert row is area['waves'][-1]
   assert area is r['areas'][-1]
final=load(farm/'final.json.gz');assert xp(final)-xp(expected)==income==r['totalXP']
assert len(owned(final))-len(ancestral)==gear
assert final['map']['challengeOrdinals']['normal']==376+len(launches)
summary={'sourceCommit':'59f2590','runtimeHead':'22bc93c','sourceFiles':len(freeze['source']),'buildFiles':len(freeze['dist']),'builtBridgeFreeJS':len(freeze['allJSTokenScan']),'servedChunks':4,'exportsAudited':len(exports),'ancestralFullPayloads':len(ancestral),'exactDurablePairs':len(pairs),'pairs':pairs,'diagnosticProjections':224,'selected':None,'tyraelSkillPointsEarned':2,'launches':launches,'winningWaves':winning,'failedWaves':failed,'heroXPEarned':income,'newGear':gear,'finalLevel':final['player']['level'],'finalXP':final['player']['experience'],'nextNormal':final['map']['challengeOrdinals']['normal'],'finalOwnedGear':len(owned(final)),'statPoints':final['player']['statPoints'],'skillPoints':final['player']['skillPoints'],'finalRawSHA256':sha(gzip.decompress((farm/'final.json.gz').read_bytes())),'scope':'earned Tyrael blessing and new River farming; originalDiablo375 loss retained, no actual reset/equip/point spending or newDiablo attempt; C2-C4/fullG0-G7 incomplete'}
(ROOT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
