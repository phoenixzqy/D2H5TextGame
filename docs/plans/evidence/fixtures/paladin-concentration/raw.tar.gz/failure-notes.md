# Original failures and correction boundaries

Initial core RED14failed/2passed included four table-fixture TypeErrors: Vitest spreads row arrays as parameters. Corrected before production edits to object rows, yielding causal10failed/6controls. Both raw outputs retained.

First core GREEN13passed/3failed and corresponding engine6266passed/3failed reflect two fixture assumptions: normal direct damage has85% hit chance even when dodge is0; carried cooldown values are absolute remaining milliseconds, so30 expired before1700. Assertions now distinguish seeded miss events from exact103/170 landed damage while keeping all35scheduled actions, and the blocked skill fixture uses30000ms. No damage, RNG, readiness, timeout or gate logic changed for these corrections.

Native/UI first run96passed/4failed: two stale20-versus21radio counts and two obsolete descriptions. Native controlled Stun, core and definitions already passed. Final focused121/6 and standalone engine6269/222 pass.

No new skips, suppressions, timeout/worker/discovery changes, production historical-fixture changes, genuine replay or remote publication. Preview exit-15 is the deliberate exact-PID SIGTERM after all browser consumers finished, recorded in preview-stop.json; it is not a validation failure. Full standard npm test completed normally with12451passed/2existing skips/533files in513.228s.
