import json,pathlib
root=pathlib.Path(__file__).resolve().parent
report=json.loads((root/'browser-report.json').read_text())
assert len(report['cases'])==4 and all(c['pass'] for c in report['cases']) and report['failures']==[]
assert len(report['geometry'])==20
pairs=0
for label in ['en-1280','en-360','zh-CN-1280','zh-CN-360']:
 prepared=json.loads(next(root.glob(label+'-prepared-*.json')).read_text())
 assert prepared['player']['level']==18 and prepared['player']['skillPoints']==3
 for mode in ['concentration','none']:
  before=json.loads(next(root.glob(label+'-'+mode+'-before-*.json')).read_text())
  after=json.loads(next(root.glob(label+'-'+mode+'-after-*.json')).read_text())
  for key in ['player','inventory','map','mercs','formation']: assert before[key]==after[key],(label,mode,key)
  for key in ['inventory','map','mercs','formation']: assert before[key]==prepared[key],(label,mode,key,'unexpected change')
  expected={**prepared['player'],'skillPoints':0,'skillLevels':{**prepared['player']['skillLevels'],'paladin.might':1,'paladin.blessed_aim':1,'paladin.concentration':1}}
  if mode=='concentration': expected['selectedAuraId']='paladin.concentration'
  assert before['player']==expected,(label,mode,'allocation changed other player data')
  assert before['version']==22
  assert 'concentration' not in before['player'] and 'preventStunInterruption' not in before['player'] and 'vigorLife' not in before['player'] and 'statAura' not in before['player'] and 'corpses' not in before['player']
  pairs+=1
for sample in report['geometry']:
 assert sample['overflow']<=0 and len(sample['sizes'])==21
 assert all(s['width']>=44 and s['height']>=44 for s in sample['sizes'])
print(json.dumps({'cases':4,'exactFiveDomainContinuePairs':pairs,'geometrySamples':20,'radioLabels':21,'syntheticLevel':18,'noCampaignActions':True}))
