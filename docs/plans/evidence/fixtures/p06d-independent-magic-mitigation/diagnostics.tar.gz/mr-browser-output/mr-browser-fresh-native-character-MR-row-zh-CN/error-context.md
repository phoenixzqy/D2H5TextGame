# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mr-browser.spec.cjs >> fresh native character MR row zh-CN
- Location: ../../zai-temp/d2h5-root-den-calibration-lknpvtpc/mr-browser.spec.cjs:3:3

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: locator.click: Test timeout of 45000ms exceeded.
Call log:
  - waiting for locator('a[href="/character"]').first()

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "主导航" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "营地" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: 营地
        - listitem [ref=e10]:
          - link "地图" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: 地图
        - listitem [ref=e14]:
          - link "战斗" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: 战斗
        - listitem [ref=e18]:
          - link "背包" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: 背包
        - listitem [ref=e22]:
          - link "技能" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: 技能
        - listitem [ref=e26]:
          - link "佣兵" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: 佣兵
        - listitem [ref=e30]:
          - link "任务" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: 任务
        - listitem [ref=e34]:
          - link "设置" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: 设置
        - listitem [ref=e38]:
          - link "Dev Tool" [ref=e39] [cursor=pointer]:
            - /url: /dev
            - generic [ref=e40]: 🛠️
            - generic [ref=e41]: Dev Tool
    - generic [ref=e42]:
      - banner [ref=e43]:
        - generic [ref=e44]: 设置
      - main [ref=e45]:
        - generic [ref=e46]:
          - generic [ref=e47]:
            - heading "语言" [level=2] [ref=e48]
            - generic [ref=e49]:
              - button "简体中文" [pressed] [ref=e50] [cursor=pointer]
              - button "English" [ref=e51] [cursor=pointer]
          - generic [ref=e52]:
            - generic [ref=e53] [cursor=pointer]:
              - generic [ref=e54]:
                - generic [ref=e55]: 摸鱼模式
                - generic [ref=e56]: 隐藏图标和颜色，便于上班时游玩
              - checkbox "摸鱼模式" [ref=e57]
            - generic [ref=e59] [cursor=pointer]:
              - generic [ref=e61]: 音效
              - checkbox "音效" [checked] [ref=e62]
            - generic [ref=e64] [cursor=pointer]:
              - generic [ref=e66]: 音乐
              - checkbox "音乐" [checked] [ref=e67]
          - generic [ref=e68]:
            - heading "存档管理" [level=2] [ref=e69]
            - generic [ref=e70]:
              - button "保存" [ref=e71] [cursor=pointer]
              - button "导出存档" [ref=e72] [cursor=pointer]
              - button "导入存档" [ref=e73] [cursor=pointer]
              - button "删除存档" [ref=e74] [cursor=pointer]
          - generic [ref=e75]:
            - link "☕ 给我买杯咖啡" [ref=e76] [cursor=pointer]:
              - /url: https://www.buymeacoffee.com/
            - generic [ref=e77]: "版本: 0.1.0"
  - button "MR Browser · 等级 1。点击查看角色面板。" [ref=e78] [cursor=pointer]:
    - generic [ref=e80]: "1"
    - generic [ref=e81]:
      - generic [ref=e82]:
        - generic [ref=e83]: MR Browser
        - generic [ref=e84]: 等级 1
      - generic [ref=e85]:
        - generic [ref=e86]: HP
        - progressbar "HP" [ref=e87]
      - generic [ref=e89]:
        - generic [ref=e90]: MP
        - progressbar "MP" [ref=e91]
      - generic [ref=e93]:
        - generic [ref=e94]: XP
        - progressbar "XP" [ref=e95]
```

# Test source

```ts
  1  | const { test, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
  2  | for (const locale of ['zh-CN', 'en']) {
  3  |   test(`fresh native character MR row ${locale}`, async ({ page }) => {
  4  |     const errors=[];page.on('pageerror',e=>errors.push(e.message));
  5  |     await page.setViewportSize({width:360,height:640});
  6  |     await page.goto('/');await page.waitForLoadState('networkidle');
  7  |     await page.getByTestId('home-new-game').click();
  8  |     await page.getByTestId('class-sorceress').click();
  9  |     await page.getByTestId('character-name-input').fill('MR Browser');
  10 |     await page.getByTestId('character-start-btn').click();
  11 |     await expect(page.getByTestId('town-screen')).toBeVisible();
  12 |     await page.locator('a[href="/settings"]').first().click();
  13 |     await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
> 14 |     await page.locator('a[href="/character"]').first().click();
     |                                                        ^ Error: locator.click: Test timeout of 45000ms exceeded.
  15 |     await expect(page.getByTestId('character-screen')).toBeVisible();
  16 |     const row=page.getByText(locale==='en'?'Magic Resist':'魔法防御',{exact:true}).locator('..');
  17 |     await expect(row).toHaveText(locale==='en'?'Magic Resist0':'魔法防御0');
  18 |     for(const width of [320,360,768,1024,1280,1440]) {
  19 |       await page.setViewportSize({width,height:width<768?640:800});
  20 |       await expect(row).toBeVisible();
  21 |       expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
  22 |     }
  23 |     await page.setViewportSize({width:360,height:640});
  24 |     await page.screenshot({path:__dirname+`/mr-character-${locale}-360.png`,fullPage:true});
  25 |     expect(errors).toEqual([]);
  26 |   });
  27 | }
  28 | 
```