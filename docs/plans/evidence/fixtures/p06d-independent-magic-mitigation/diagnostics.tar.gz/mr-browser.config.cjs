const { defineConfig } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
module.exports = defineConfig({
  testDir: __dirname, testMatch: 'mr-browser.spec.cjs', workers: 1, retries: 0, timeout: 45000,
  outputDir: __dirname + '/mr-browser-output-3', reporter: [['line'], ['json', {outputFile: __dirname + '/mr-browser-3.json'}]],
  use: { baseURL: 'http://127.0.0.1:4387', headless: true, screenshot: 'only-on-failure', trace: 'off' },
  webServer: {
    command: 'node_modules/.bin/vite dev --port 4387 --host 127.0.0.1 --strictPort',
    cwd: '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',
    url: 'http://127.0.0.1:4387', reuseExistingServer: false, timeout: 30000
  }
});
