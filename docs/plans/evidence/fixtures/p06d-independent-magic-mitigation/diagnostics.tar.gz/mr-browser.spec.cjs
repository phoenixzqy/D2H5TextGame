const { test, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
for (const locale of ['zh-CN', 'en']) {
  test(`fresh native character MR row ${locale}`, async ({ page }) => {
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.setViewportSize({width:360,height:640});
    await page.goto('/');await page.waitForLoadState('networkidle');
    await page.getByTestId('home-new-game').click();
    await page.getByTestId('class-sorceress').click();
    await page.getByTestId('character-name-input').fill('MR Browser');
    await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    await page.locator('a[href="/settings"]').first().click();
    await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
    await page.getByTestId('character-hud').click();
    await expect(page.getByTestId('character-screen')).toBeVisible();
    const row=page.getByText(locale==='en'?'Magic Resist':'魔法防御',{exact:true}).locator('..');
    await expect(row).toHaveText(locale==='en'?'Magic Resist0':'魔法防御0');
    for(const width of [320,360,768,1024,1280,1440]) {
      await page.setViewportSize({width,height:width<768?640:800});
      await expect(row).toBeVisible();
      expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(width);
    }
    await page.setViewportSize({width:360,height:640});
    await row.scrollIntoViewIfNeeded();
    await expect(row).toBeInViewport();
    await page.screenshot({path:__dirname+`/mr-character-${locale}-360-row.png`});
    expect(errors).toEqual([]);
  });
}
