# Next-slice draft — Double Swing repeated cleaves

Draft only, not an accepted contract or implementation. Complete Leap delivery
first. BUG214's single-enemy proof requires two independently resolved attempts;
both current locales also promise up to three enemies. Existing hitSequence
counts total rotated attempts, so simply adding strikes:2 would still hit a
single-enemy twice but could not express two cleaves across three original
selected targets. Do not claim full repair from that symptom patch.

Proposed explicit author adaptation: existing densest cross targeting, cap3,
then two ordered passes across that original pool. Each still-living original
target receives one independent attempt per pass. Misses consume their slot;
dead originals are skipped without replacing them or redistributing attempts.
Caster death stops the rest. One10MP/action/CD1 covers the cast. Preserve native
unlock6/cap20/Bash prerequisite and authored Physical40–60/+4rank per attempt.
The existing weapon-equipment eligibility stays unchanged. Cross is a new
explicit spatial adaptation; the old prose does not specify a footprint.

Prefer one narrow opted-in sequence mode, e.g. each-original, in the existing
JSON/schema/SkillHitSequence/adapter/runtime/display pipeline. Preserve the
current default rotated attempt semantics for Fury/Jab/Talon/Dragon Claw.
Never use strikes:6, since it gives a singleton six attempts; never reselect
or re-run AOE after kills. Schema must require the complete actual Double Swing
identity and reject mode use by unrelated skills or contradictory ownership.

Write REDs before production changes: native rank1/2/20 and multiple seeds;
1/2/3/4/9 enemies, deterministic densest-cross ties and cap; independent miss/
crit/mitigation; actual HP loss, early death, shields/reflection/source death;
fixed original pool after death; one payment/cooldown and readiness; seeded
immutable replay and all-resource/living-status playback; sibling default
rotation controls. Pure and actual bilingual UI should explain two passes,
per-attempt damage, target cap/shape/order, miss/death and one paid cast.
Production public creation/import/allocation/priority/cast/save/reopen across
locales/mobile/desktop, five-size geometry and inspected screenshots precede
credit. Keep synthetic mechanics distinct from earned balance. Independent
review/earned class acceptance stays open. No genuine campaign/remote action.
