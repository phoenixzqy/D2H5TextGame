"""Retain this task's evidence after all validation commands finish."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

scratch = Path(__file__).resolve().parent
repo = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
target = repo / 'docs/plans/evidence/fixtures/psychic-hammer'
assert scratch == Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-hammer-3d_s7863')
assert not target.exists(), 'Do not overwrite retained evidence'

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

freeze = json.loads((scratch / 'freeze.json').read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
keys = list(freeze['source'])
batch = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=repo,
    input=('\n'.join(head + ':' + name for name in keys) + '\n').encode())
stream = io.BytesIO(batch)
for name in keys:
    header = stream.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob', (name, header)
    content = stream.read(int(header[2]))
    assert stream.read(1) == b'\n'
    assert digest(content) == freeze['source'][name] == digest((repo / name).read_bytes()), name
for name, expected in freeze['build'].items():
    assert digest((scratch / 'build' / name).read_bytes()) == expected, name
genuine = repo / 'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz'
assert digest(gzip.decompress(genuine.read_bytes())) == freeze['genuine']

required = ['full', 'engine', 'focused-delivery', 'types-delivery', 'lint-delivery', 'build', 'browser-corrected']
for name in required:
    receipt = json.loads((scratch / (name + '.json')).read_text())
    assert receipt['exit'] == 0, receipt

receipts = []
pids = set()
for path in scratch.glob('*-live.json'):
    value = json.loads(path.read_text())
    for key in ['pid', 'wrapperPid']:
        if key in value:
            pids.add(value[key])
    if value.get('name'):
        final = scratch / (value['name'] + '.json')
        assert final.is_file(), path
        receipts.append(json.loads(final.read_text()))
for pid in sorted(pids):
    assert not Path('/proc', str(pid)).exists(), ('task process remains', pid)

target.mkdir()
source = {'commit': head, 'source': freeze['source'], 'build': freeze['build'],
    'genuine': freeze['genuine'], 'sourceDrift': [], 'buildDrift': [],
    'committedBlobDrift': [], 'sourceFiles': len(keys), 'buildFiles': len(freeze['build']),
    'fullTestTextLimit': 'One UI String-conversion expectation correction followed full start; final focused37/4, lint and typecheck cover final test bytes.'}
dump(target / 'source-delivered.json', source)
for name in ['browser-audit.json', 'save-pairs-audit.json', 'author-review.json', 'build-audit.json']:
    (target / name).write_bytes((scratch / name).read_bytes())

excluded = {'browser-template.cjs', 'browser-template-suite.py'}
files = [p for p in sorted(scratch.rglob('*')) if p.is_file() and
    'build' not in p.relative_to(scratch).parts and p.name not in excluded]
assert all(not p.is_symlink() for p in files)
members = {p.relative_to(scratch).as_posix(): {'sha256': digest(p.read_bytes()), 'bytes': p.stat().st_size} for p in files}
archive = target / 'raw.tar.gz'
with tarfile.open(archive, 'w:gz') as out:
    for path in files:
        out.add(path, arcname=path.relative_to(scratch).as_posix(), recursive=False)
with tarfile.open(archive, 'r:gz') as retained:
    assert set(retained.getnames()) == set(members)
    for member in retained:
        content = retained.extractfile(member).read()
        assert len(content) == members[member.name]['bytes'] and digest(content) == members[member.name]['sha256']
packet = {'archiveSha256': digest(archive.read_bytes()), 'members': members,
    'terminalReceipts': receipts, 'verifiedRawMembers': len(members),
    'recordedPids': sorted(pids), 'allRecordedPidsAbsent': True,
    'excludedDisposable': ['build/', *sorted(excluded)], 'scratch': str(scratch)}
dump(target / 'packet.json', packet)
print(json.dumps({'commit': head, 'rawMembers': len(members), 'terminalReceipts': len(receipts),
    'pidsAbsent': len(pids), 'archiveBytes': archive.stat().st_size, 'sha256': packet['archiveSha256']}))
