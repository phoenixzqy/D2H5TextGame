from pathlib import Path
import collections
import csv
import hashlib
import io
import json
import re
import subprocess

scratch = Path(__file__).resolve().parent
repo = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
required = ['full', 'engine-delivery', 'focused-verified', 'types-delivery',
            'lint-delivery', 'build-delivery', 'browser-final']
receipts = {n: json.loads((scratch / (n + '.json')).read_text()) for n in required}
assert all(r['exit'] == 0 for r in receipts.values())
log = (scratch / 'full.log').read_text()
assert re.search(r'Test Files\s+679 passed', log)
assert re.search(r'Tests\s+15025 passed\s*\|\s*2 skipped', log)
duration = re.search(r'Duration\s+([\d.]+)s', log).group(1)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head != json.loads((scratch / 'freeze.json').read_text())['head']
short = head[:8]
(scratch / 'final-validation-summary.json').write_text(json.dumps({
    'sourceCommit': head, 'fullTests': 15025, 'fullFiles': 679, 'existingSkips': 2,
    'vitestSeconds': float(duration), 'receipts': receipts}, indent=2) + '\n')

inventory = repo / 'docs/plans/skill-inventory.csv'
before = (scratch / 'inventory-before.csv').read_bytes()
assert inventory.read_bytes() == before
lines = before.splitlines(keepends=True)
index = next(i for i, line in enumerate(lines) if line.startswith(b'barbarian,skills-barbarian-leap,'))
fields = next(csv.reader([lines[0].decode()]))
row = dict(zip(fields, next(csv.reader([lines[index].decode()]))))
row.update(adapter_route='buff|debuff', declared_statuses='leap|stun',
    risk_flags='provisional-control-adaptation|provisional-tuning|independent-acceptance-open|earned-balance-open',
    behavior_verification='bounded-functional;independent-acceptance-open',
    contract_evidence='docs/plans/decisions/D04-leap-v1.md;docs/plans/evidence/d04-leap.md')
out = io.StringIO(newline='')
csv.writer(out, lineterminator='\r\n' if lines[index].endswith(b'\r\n') else '\n').writerow([row[k] for k in fields])
updated = list(lines)
updated[index] = out.getvalue().encode()
assert all(a == b for i, (a, b) in enumerate(zip(lines, updated)) if i != index)
inventory.write_bytes(b''.join(updated))
rows = list(csv.DictReader(io.StringIO(inventory.read_text())))
assert len(rows) == 213
counts = dict(collections.Counter(r['behavior_verification'] for r in rows))
assert sum(n for k, n in counts.items() if k.startswith('bounded-functional;')) == 111
assert counts['unverified'] == 100
audit = {'creditedOnly': 'skills-barbarian-leap', 'rows': len(rows),
    'otherRowsByteExact': 212, 'orderPreserved': True, 'counts': counts,
    'barbarianBounded': 13, 'beforeSha256': hashlib.sha256(before).hexdigest(),
    'afterSha256': hashlib.sha256(inventory.read_bytes()).hexdigest()}
(scratch / 'inventory-audit.json').write_text(json.dumps(audit, indent=2) + '\n')

text = f'''# D04 — Leap's actual control and paid physical follow-up

2026-10-25; local author verification under
[contract](../decisions/D04-leap-v1.md) and
[BUG213](../../../production/bugs/BUG-213-leap-inert-knockback.md).
Independent design/QA, earned balance and complete privatev1 remain open.

## Change

Replace inert Knockback with existing shared Stun:1s normally,0.5s on bosses.
The paid non-damaging cast controls all currently living hostiles without an
accuracy roll or movement. Preserve the existing physicalDamagePct=.01/rank
as a paid personal direct Physical damage bonus, capped at20/+20%, for3000ms.
The3s duration is new provisional author tuning; the Stun is an explicit author
adaptation. Neither is an earned balance or independent design acceptance.

JSON owns duration/scaling and the closed schema rejects contradictory effect,
damage, geometry and sequence metadata. An exact registry/native-rank boundary
precedes payment. Source-owned immutable paid potency uses existing finite
status clocks, shared Stun/scheduler and direct-damage input. Learning grants
no passive power. No active refresh, new movement stat or saved combat field.

Preserve unlock6/cap20/no prerequisite and existing rank scaling: ranks1/2/20
cost8/8/6MP with raw cooldown3/2.95/2.05s, whose existing one-decimal runtime/
display rounding yields3/3/2s. One action/payment/cooldown supplies both effects.
Paid potency remains through respec until expiry; fresh allocation affects
future casts. Existing next-wave carry/rebase never renews the interval or
refills pools. Save/import persists allocation/priority, with no version bump.

## Causal and native proof

60new cases across four files:25schema/adapter/display/native-authority/carry,
25causal combat,2store lifecycle/save and8bilingual actual UI. The three paid
cast cases cover36scenarios: ranks1/2/20 ×seeds7/19/41/97 ×trash/boss/chapter-boss.
Each casts once at1700ms, spends8/8/6MP, applies three Stuns and captures personal
potency until4700ms. Enemy Stun expires2700ms normally or2200ms on bosses;
their actual first action shifts2000→4000ms. Leap itself deals no damage, moves
no position and controls neither dead enemies nor allies.

Actual paid state is captured through playback and rebased, then paired with
the identical snapshot with only its paid marker removed. Base100direct
Physical damage with an existing25% increase becomes126/127/145 at ranks1/2/20,
versus125without Leap; after expiry both125. An actual registered Bash hit gets
the same20% rank20 bonus. Arcane/Fire/Thorns controls remain unchanged. The tests
require independent seeded hit outcomes, actual HP settlement and literal
additive scaling; no scalar event is duplicated to imitate causality.

Active rank20 casts occur1700/5100/8500ms, preventing refresh even when the2s
cooldown has expired. Malformed/foreign/extended markers grant no potency;
duplicates do not stack. Fractional clock rebase preserves the exact finite
interval, including exclusive expiry. Inputs remain immutable, seeded replay
and ordinary runBattle results agree, and playback matches all HP/MP plus
living active-status views. Future/dead raw markers are outside that view.

Native allocation leaves the current recorded wave frozen, changes the next
wave and preserves prior resources/base stats. Save/import keeps learned rank
and priority without restoring a combat team, status or pool refill. These
synthetic mechanical checks provide no earned class/build acceptance.

## Production browser proof

Four cases cover en/zh-CN ×360×640/1280×800 using public create/export/import,
allocation rank1→2, priority selection, actual paid cast/buff/all-enemy Stun and
visible MP use. Eight Save-close-new-page-Continue pairs preserve player,
inventory,map,mercs,formation exactly. Meta idle clocks may advance on real
reopen and are outside those five exact domains.

Twenty geometry checks cover360×640,412×915,640×360,1280×800,1920×1080, with no
horizontal overflow and allocation controls≥44px. Sixteen screenshots, four
individually inspected, show readable current/next paid-bonus/cost/CD and
bilingual actual buff/Stun logs. The Chinese desktop also shows stunned
enemies unable to act. Browser4/4 and no page errors. Synthetic L30/resources/
imported helmet/fixed combat Date.now are explicit, with ordinary timers and
public controls, no test bridge. Existing navigation glyphs/full a11y/offline
and device acceptance remain open.

## Validation and corrections

Final focused60/4, engine7778/288 and full15025/679/two existing skips PASS.
Full Vitest{duration}s, wrapper{receipts['full']['seconds']:.3f}s. Types, lint and
production build PASS. All final source/tests/build bytes were frozen before
final full/engine/types/lint/browser checks started. Four generated JavaScript
chunks are free of test bridges; all756precache URLs exist. Existing test,
bundle/PWA and performance budgets remain unaccepted.

Original native RED33failed/7passed and UI RED8failed are retained. The first
patched run passed44and failed4expectations that assumed unrounded2.95/2.05s
cooldowns. Source review confirmed existing one-decimal rounding in runtime
and display; the contract/expectations were corrected without changing global
timing. A subsequent8case log-copy RED found missing bilingual paid-buff/status
names; both combat locale files now supply them.

TypeScript5.4 required typed flatMap discrimination and omission of an optional
property instead of explicit undefined. Three lint corrections use a boolean
damage-presence check, remove a redundant condition and use an optional-chain
existence check. Earlier passing focused/types/engine/browser results are
retained. The first full was explicitly cancelled after105s because production
display code needed those lint corrections. Only verified task-owned descendant
PIDs were signalled; its exit−15 is retained separately as full-before-lint,
with reason and original identity. This was not an observation timeout or pass.
Two superseded760file builds were hash-verified and exactly removed before the
final build. No original failure is omitted.

Author five-axis/security review has no required finding; independent acceptance
remains open. The bounded typed module follows the existing Burst/Cloak status
pattern and adds one bounded status scan to direct Physical inputs. No new
dependency, credential, CI, permission, remote or genuine campaign action.

## Delivery and remaining scope

Source/tests/contract committed as `{short}`. All1175frozen source/config/
contract files are checked against actual committed blobs; all760build files
and the genuine save hash are checked before retention. Only Leap gains credit:
111bounded-functional/100unverified/one engine-only/one review-needed;
Barbarian13/30. The other212inventory rows remain byte-exact, with213IDs/order.

RETENTION-CLEANUP-PENDING

[Raw archive](fixtures/leap/raw.tar.gz),
[member manifest](fixtures/leap/packet.json),
[source audit](fixtures/leap/source-delivered.json),
[browser audit](fixtures/leap/browser-audit.json) and
[cleanup receipt](fixtures/leap/cleanup.json) retain the evidence.

Double Swing is separately reproduced in24native scenarios, including a
standard-grid rerun, without a source repair or credit;
[next reproduction](d04-double-swing-repro.md). Genuine Ancients/Rite remains
L33/XP149261/nextNormal402/Nightmare0/Baal uncleared, decompressed SHA256
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`.
C0/C1 retain narrow exits; C2–C4/fullG0–G7/all-class earned builds/30–50hour
pacing/economy/endgame/independent acceptance and full privatev1 remain open.
Umbrella goal/branch/worktree/claim remain active.
'''
(repo / 'docs/plans/evidence/d04-leap.md').write_text(text)
bug = repo / 'production/bugs/BUG-213-leap-inert-knockback.md'
old = bug.read_text()
old = old.replace('- Status: reproduced; author adaptation contract and repair open.',
    f'- Status: locally fixed in `{short}`; independent and earned acceptance open.')
bug.write_text(old + f'''

## Local repair

`{short}` implements the explicit [author contract](../../docs/plans/decisions/D04-leap-v1.md):
shared finite Stun and a paid3s personal Physical bonus from existing rank
metadata, with no movement, active refresh or saved combat payload. Tests:
`src/engine/skills/leap.test.ts`, `src/stores/leap.causal.test.ts`,
`src/stores/leap-native.test.ts`, `src/features/skills/SkillsScreen.leap.test.tsx`.
Focused60/4, engine7778/288, full15025/679/two existing skips and types/lint/build/
four production browser cases pass. [Delivery evidence](../../docs/plans/evidence/d04-leap.md)
records causal state/timing/damage, native save/wave behavior, disclosed synthetic
fixtures, retained failures and exact task-owned cleanup. Independent design/QA
and earned balance remain open; historical reproduction above is preserved.
''')
repro = repo / 'docs/plans/evidence/d04-leap-repro.md'
repro.write_text(repro.read_text() + f'''

## Subsequent local repair

`{short}` implements the explicit [author contract](../decisions/D04-leap-v1.md).
[Delivery verification](d04-leap.md) records actual paid control/Physical benefit,
finite carry, native lifecycle, full checks and production browser evidence.
This historical prepatch reproduction is unchanged; independent/earned acceptance
remains open.
''')
ledger = repo / 'docs/plans/execution-ledger.md'
lines = ledger.read_text().splitlines(keepends=True)
i = next(i for i, line in enumerate(lines) if line.startswith('| D04 Leap / BUG213 |'))
lines[i] = f'| D04 Leap / BUG213 | locally fixed/verified; independent and earned acceptance open | Source/tests/contract `{short}`: shared all-hostile Stun1s/boss0.5s plus paid3s direct Physical+.01/rank, strict native/registry/carry authority and truthful bilingual previews.60new cases; engine7778/288, full15025/679/two existing skips, types/lint/build PASS. Production4/4/eight exact five-domain Continue pairs/20geometry/16screenshots/four inspected. [Evidence](evidence/d04-leap.md). All1175source committed blobs/760build/genuine checked. Only Leap credited:111bounded/100unverified/one engine-only/one review-needed; Barbarian13/30. New3s tuning/provisional adaptation, earned balance/independent gates/C2-C4/fullG0-G7/privatev1 remain open; genuineL33/next402/Baal uncleared unchanged. |\n'
lines.insert(i + 1, '| D04 Double Swing / BUG214 | missing second attempt reproduced; contract/repair open |24native rank1/2/20 ×four seeds ×one/four enemies cases pay10MP once. Single enemy receives one attempt; four enemies receive one attempt each on first two. Standard-grid rerun agrees; original col3 is accepted by engine but outside usual layout. [Reproduction](evidence/d04-double-swing-repro.md). No Double Swing patch/credit. |\n')
ledger.write_text(''.join(lines) + f'''

## 2026-10-25 — Paid Leap control/Physical benefit verified; Double Swing reproduced

Source/tests/contract `{short}` fixes BUG213 with explicit provisional shared
Stun1s/boss0.5s plus a paid3s personal direct Physical bonus from existing
.01/rank metadata.36rank/seed/tier scenarios show actual interruption and paid
potency. Causal playback/rebase comparisons show126/127/145versus125Physical
damage, expiry reversal and unchanged other types; real Bash shares the bonus.
Native authority, no active refresh, carried potency/respec, immutable replay,
next-wave allocation and save/import preserve resources and avoid saved combat
payloads. [Evidence](evidence/d04-leap.md).

Focused60/4, engine7778/288, full15025/679/two existing skips PASS; full{duration}s
Vitest ({receipts['full']['seconds']:.3f}s wrapper). Types/lint/build PASS. Final
source/tests/build frozen before all final checks. Production4/4/eight exact
five-domain Continue pairs/20geometry/16screenshots/four inspected pass, using
declared synthetic L30/resources/imported helmet/fixed combat Date.now. All1175
source committed blobs/760build/genuine bytes are checked; four bridge-free
chunks/756present precache URLs. Original RED/type/lint failures, rounded-CD
fixture correction and explicit source-correction cancellation of first full
are retained. No earned balance or independent acceptance follows.

Only Leap credited:213IDs/order,212other rows byte-exact;111bounded-functional/
100unverified/one engine-only/one review-needed, Barbarian13/30. Retention and
cleanup details are recorded in the linked delivery evidence/receipts.

Double Swing independently reproduces one attempt instead of the advertised
two in12single-enemy cases;12standard-grid four-enemy cases resolve one attempt
on each of first two enemies. Original nonstandard column3 is accepted by
engine validation; standard-layout rerun removes geometry ambiguity. Complete
observations precede intentional exit1. BUG214/contract/repair remain open,
with no Double Swing credit. Genuine Ancients/Rite remainsL33/XP149261/
nextNormal402/Nightmare0/Baal uncleared and its exact hash is unchanged. C0/C1
retain narrow exits; C2 underway, C3/C4/fullG0-G7/all-class earned builds/
30–50hour pacing/economy/endgame/independent QA and complete privatev1 remain
unfinished. No genuine campaign or remote action. Root sole writer/reviewer;
umbrella goal/branch/worktree/claim remain active.
''')
print(json.dumps({'sourceCommit': head, 'inventory': audit, 'fullVitestSeconds': duration}))
