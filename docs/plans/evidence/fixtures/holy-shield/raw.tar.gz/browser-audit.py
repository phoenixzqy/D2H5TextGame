from pathlib import Path
import json,hashlib,socket
p=Path(__file__).parent
cases=[];pairs=[];geometry=[];screens=[]
for locale,width,folder in [('en',1280,'browser-en-desktop'),('en',360,'browser-en-mobile'),('zh-CN',1280,'browser-zh-desktop'),('zh-CN',360,'browser-zh-mobile')]:
 label=locale+'-'+str(width);d=p/folder
 report=json.loads((d/'browser-report.json').read_text());assert not report['failures'] and len(report['cases'])==1
 c=report['cases'][0];assert c['pass'] and c['errors']==[] and c['pairs']==['rank19','rank20']
 assert len(c['combat'])==1 and c['combat'][0]['actualPreventionLog'] and c['combat'][0]['localizedPositiveChip']
 actual=json.loads((d/(label+'-combat.json')).read_text());assert 0<actual['lifePercent']<100
 assert ('Holy Shield prevents' if locale=='en' else '神圣之盾减免了') in actual['text']
 for key,rank,points in [('rank19',19,1),('rank20',20,0)]:
  before=list(d.glob(label+'-'+key+'-before-*.json'));after=list(d.glob(label+'-'+key+'-after-*.json'));assert len(before)==len(after)==1
  a=json.loads(before[0].read_text());b=json.loads(after[0].read_text());assert a['version']==b['version']==22
  domains=['player','inventory','map','mercs','formation'];assert {k:a[k] for k in domains}=={k:b[k] for k in domains}
  assert b['player']['skillPoints']==points and b['player']['skillLevels']=={'paladin.smite':1,'paladin.charge':1,'paladin.holy_shield':rank}
  assert b['player']['comboOrder']==['skills-paladin-holy-shield'] and 'holyShield' not in json.dumps(b)
  pairs.append({'label':label,'rank':rank,'domains_exact':domains,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p))})
 assert len(report['geometry'])==5
 for g in report['geometry']:assert g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
 geometry.extend(report['geometry']);cases.append({'label':label,'pass':True,'actual_prevention':True})
 for kind in ['details','combat']:
  f=d/(label+'-'+kind+'.png');assert f.is_file();screens.append({'file':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
owner=json.loads((p/'browser-server-server-owner.json').read_text());assert not Path('/proc/'+str(owner['pid'])).exists()
s=socket.socket();assert s.connect_ex(('127.0.0.1',4485))!=0;s.close()
r={'cases':cases,'pairs':pairs,'geometry_samples':len(geometry),'screenshots':screens,'page_errors':[],'preview_pid_absent':True,'port4485_closed':True,'synthetic_fixture':True,'earned_acceptance':False}
out=p/'browser-evidence-audit.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'cases':len(cases),'pairs':len(pairs),'geometry':len(geometry),'screenshots':len(screens),'all_exact':True}))
