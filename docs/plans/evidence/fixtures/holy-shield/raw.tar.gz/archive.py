from pathlib import Path
import tarfile,hashlib,json
p=Path(__file__).parent
assert p.name=='d2h5-holy-shield-6q01qwxk'
assert json.loads((p/'ownership.json').read_text())['root']==str(p)
out=Path.cwd()/'docs/plans/evidence/fixtures/holy-shield'
out.mkdir(parents=True,exist_ok=True)
archive=out/'raw.tar.gz';assert not archive.exists()
files=[f for f in sorted(p.rglob('*')) if f.is_file() and not f.is_symlink() and not any(part in ['production-dist','production-dist-initial'] for part in f.relative_to(p).parts)]
members={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
with tarfile.open(archive,'w:gz')as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(archive)as t:
 assert len(t.getmembers())==len(members)
 for name,entry in members.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==entry['sha256'],name
receipts={}
for f in files:
 if f.suffix=='.json':
  try:r=json.loads(f.read_text())
  except (ValueError,UnicodeDecodeError):continue
  if isinstance(r,dict) and 'argv'in r and 'exit'in r:receipts[str(f.relative_to(p))]=r
(out/'packet.json').write_text(json.dumps({'archive':'raw.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'raw_files':len(members),'members':members,'terminal_command_receipts':len(receipts),'synthetic_browser_and_combat_fixtures':True,'independent_earned_acceptance':False},indent=2)+'\n')
(out/'terminal-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
for name in ['author-review.json','build-audit.json','browser-evidence-audit.json','browser-terminal-audit.json','visual-inspection.json','post-full-freeze-audit.json','committed-source-audit.json','conversion-result.json','conversion-findings.json']:
 (out/name).write_bytes((p/name).read_bytes())
print(json.dumps({'archive':str(archive),'raw_files':len(members),'receipts':len(receipts),'all_members_byte_verified':True}))
