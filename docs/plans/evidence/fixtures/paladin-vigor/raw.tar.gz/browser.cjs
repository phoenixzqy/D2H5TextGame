const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = __dirname;
const baseURL = 'http://127.0.0.1:4468';
const ids = ['vigor'];
const names = {
 en: ['Vigor'],
 'zh-CN': ['活力']
};
const allIds = ['might','holy-fire','conviction','meditation','thorns','blessed-aim','concentration','holy-freeze','holy-shock','sanctuary','fanaticism','prayer','resist-fire','defiance','resist-cold','cleansing','resist-lightning','vigor','redemption','salvation'];
const summary = {cases:[], geometry:[], failures:[]};
let serial = 0;
async function exportSave(page, label) {
 const pending = page.waitForEvent('download');
 await page.getByTestId('export-save-button').click();
 const dl = await pending, target = path.join(root, `${label}-${++serial}.json`);
 await dl.saveAs(target);
 return JSON.parse(await fs.readFile(target, 'utf8'));
}
async function nav(page, route) {
 await page.locator(`a[href="/${route}"]`).first().click();
 await expect(page.getByTestId(`${route}-screen`)).toBeVisible();
}
function domains(save) {return Object.fromEntries(['player','inventory','map','mercs','formation'].map(k=>[k,save[k]]));}
async function continuePair(page, context, locale, label) {
 await nav(page,'settings');
 await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();
 await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');
 const before=await exportSave(page,label+'-before');
 assert.equal(before.version,22);
 await page.close(); page=await context.newPage();
 await page.goto(baseURL,{waitUntil:'networkidle'});
 await expect(page.getByTestId('home-continue')).toBeEnabled();
 await page.getByTestId('home-continue').click();
 await expect(page.getByTestId('town-screen')).toBeVisible();
 await nav(page,'settings');
 const after=await exportSave(page,label+'-after');
 assert.deepEqual(domains(after),domains(before));
 await nav(page,'skills');
 return {page,selection:after.player.selectedAuraId};
}
async function geometry(page,label) {
 const original=page.viewportSize();
 for (const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]) {
  await page.setViewportSize({width,height});
  const sizes=await page.locator('input[name="selected-player-aura"]').evaluateAll(inputs=>inputs.map(input=>{
    const r=input.closest('label').getBoundingClientRect();return {id:input.value,width:r.width,height:r.height};
  }));
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
  assert.ok(overflow<=0,`${label} overflow ${overflow}`);
  assert.equal(sizes.length,19);
  for(const size of sizes) assert.ok(size.width>=44&&size.height>=44,JSON.stringify(size));
  summary.geometry.push({label,width,height,overflow,sizes});
 }
 await page.setViewportSize(original);
}
(async()=>{
 const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});
 try {
 for(const locale of ['en','zh-CN']) for(const viewport of [{width:1280,height:800},{width:360,height:640}]) {
  const label=`${locale}-${viewport.width}`;
  const context=await browser.newContext({viewport,locale,acceptDownloads:true});
  const errors=[];
  context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
  await context.tracing.start({screenshots:true,snapshots:true,sources:false});
  let page=await context.newPage();
  const result={label,pairs:[],errors};
  try {
   await page.goto(baseURL,{waitUntil:'networkidle'});
   assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');
   await page.getByTestId('home-new-game').click();
   await page.getByTestId('class-paladin').click();
   await page.getByTestId('character-name-input').fill('AuraCheck');
   await page.getByTestId('character-start-btn').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();
   await nav(page,'settings');
   await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
   const fresh=await exportSave(page,label+'-fresh');
   assert.equal(fresh.player.level,1);
   assert.equal(fresh.player.skillPoints,1);
   assert.equal(fresh.player.selectedAuraId,undefined);
   // Constructed level18 fixture; no earned progression or genuine save mutation.
   const constructed={...fresh,player:{...fresh.player,level:18,skillPoints:4}};
   await fs.writeFile(path.join(root,label+'-constructed-input.json'),JSON.stringify(constructed,null,2));
   await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   const dialog=page.getByRole('dialog');
   await dialog.getByRole('textbox').fill(JSON.stringify(constructed));
   await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   await expect(dialog).toHaveCount(0);
   const imported=await exportSave(page,label+'-imported');
   assert.equal(imported.player.level,18); assert.equal(imported.player.skillPoints,4);
   assert.equal(imported.player.selectedAuraId,undefined);
   await nav(page,'skills');
   // First Skills entry removes the starter passive/locked Zeal combo under existing sanitization.
   await nav(page,'settings');
   const prepared=await exportSave(page,label+'-prepared');
   assert.deepEqual(prepared.player,{...imported.player,comboOrder:[]});
   for(const key of ['inventory','map','mercs','formation']) assert.deepEqual(prepared[key],imported[key]);
   await nav(page,'skills');
   await page.getByTestId('skill-node-skills-paladin-prayer').click();
   await page.getByTestId('skill-detail-panel').getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
   await expect(page.getByRole('radio',{name:locale==='en'?'Prayer':'祈祷',exact:true})).not.toBeChecked();
   for(const slug of ['cleansing','defiance']) {
    await page.getByTestId('skill-node-skills-paladin-'+slug).click();
    await page.getByTestId('skill-detail-panel').getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
   }
   for(let i=0;i<ids.length;i++) {
    await page.getByTestId('skill-node-skills-paladin-'+ids[i]).click();
    let detail=page.getByTestId('skill-detail-panel');
    await expect(page.getByRole('radio',{name:names[locale][i],exact:true})).toBeDisabled();
    await detail.getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
    const radio=page.getByRole('radio',{name:names[locale][i],exact:true});
    await expect(radio).toBeEnabled(); await expect(radio).not.toBeChecked();
    await radio.check();
    await expect(radio).toBeChecked();
    await expect(page.getByRole('status').first()).toContainText(names[locale][i]);
    await page.getByTestId('skill-node-skills-paladin-'+ids[i]).click();
    detail=page.getByTestId('skill-detail-panel');
    await expect(detail).toContainText(locale==='en'?'These rank bonuses require selecting this aura.':'这些等级加成仅在选择此光环时生效。');
    for(const text of (locale==='en' ? ['maximum life +2%','Attack Speed +0.5%','rounded down','does not heal','living fielded mercenary','HP orbs','capped to the base maximum'] : ['最大生命+2%','攻击速度+0.5%','向下取整','不会治疗','存活的上阵佣兵','生命球','基础上限'])) await expect(detail).toContainText(text);
    await expect(detail).not.toContainText('{{');
    await geometry(page,label+'-'+ids[i]);
    await detail.scrollIntoViewIfNeeded();
    await page.mouse.move(1,1);
    await expect(detail).toContainText(names[locale][i]);
    await page.screenshot({path:path.join(root,label+'-'+ids[i]+'-detail.png')});
    let     pair=await continuePair(page,context,locale,label+'-'+ids[i]); page=pair.page;
    assert.equal(pair.selection,'paladin.'+ids[i]);
    await expect(page.getByRole('radio',{name:names[locale][i],exact:true})).toBeChecked();
    result.pairs.push({kind:'constructed-L18-public-allocation',selection:pair.selection});
   }
   await page.getByRole('radio',{name:locale==='en'?'None':'无',exact:true}).check();
   const cleared=await continuePair(page,context,locale,label+'-none');page=cleared.page;
   assert.equal(cleared.selection,undefined);result.pairs.push({kind:'None'});
   assert.deepEqual(errors,[]);result.pass=true;
   await context.tracing.stop();
   console.log(label+' PASS: '+result.pairs.length+' exact Continue pairs');
  } catch(error) {
   result.pass=false;result.error=String(error.stack||error);summary.failures.push(label);
   await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});
   await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});
   throw error;
  } finally {
   summary.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(summary,null,2));
   await context.close();
  }
 }
 } finally {await browser.close();}
 assert.equal(summary.cases.length,4);assert.deepEqual(summary.failures,[]);
 console.log('All browser cases passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
