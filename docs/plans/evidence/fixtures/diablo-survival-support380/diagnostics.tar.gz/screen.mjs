import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/survival-preparation380';
const input=repo+'/docs/plans/evidence/fixtures/earned-tyrael-and-river-through379/retained-final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,380);assert.equal(save.player.skillPoints,3);assert.equal(save.player.statPoints,5);
const policy={kind:'bounded owned physical-survival search; no genuine action',builds:[{id:'retained-stats-survival',reset:false},{id:'balanced-stats-survival',reset:true}],heuristic:'Three fixed coordinate passes over head/chest/gloves/boots/belt/offhand/weapon/amulet/left-ring/right-ring. Exclude two-handed candidates, reserve original Rogue equipment. Maximize life / (((.9*mitigatePhysical525+.1*mitigatePhysical918.75)*max(.05,.85-physDodge)) + .1*mitigateFire400*max(.05,.85-magicDodge)). Use native mitigation. Minimum manaMax270, attackSpeed200, fire60, cold40, lightning40; no attack or critical floor. Native proof must pass, proxy cannot qualify. Retained stats +5Dex, or one free reset then90Dex/65Vit; three earned skill points to ColdMastery14. Original priority and Rogue unchanged.',acceptance:'Freeze32 new paired seeds, first16/last16. At least26/32 total and12/16 second-half wins in BOTH full Chaos and full River. Stop each projection at first nonwin; stop candidate if area fails; select first qualifier. Max128 projections. No save promotion or actual supplied gameplay seed.'};
await writeFile(root+'/frozen-policy.json',JSON.stringify(policy,null,2)+'\n',{flag:'wx'});
const server=await createServer({root:repo,configFile:false,cacheDir:root+'/vite-cache',server:{middlewareMode:true,hmr:false,ws:false},resolve:{alias:{'@':repo+'/src'}}});
try{
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts'),{useInventoryStore}=await load('/src/stores/inventoryStore.ts'),{usePlayerStore}=await load('/src/stores/playerStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{useMercStore}=await load('/src/stores/mercStore.ts'),{prepareTownRespec,executeTownRespec}=await load('/src/stores/respecActions.ts'),{prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts'),{loadItemBases}=await load('/src/data/loaders/loot.ts'),{checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts'),{isTwoHanded}=await load('/src/engine/inventory/equipValidator.ts'),{mitigateDamage}=await load('/src/engine/combat/damage.ts'),{hashSeed}=await load('/src/engine/rng.ts');
 const npc=JSON.parse(await readFile(repo+'/src/data/respec.json','utf8')).townNpcs['4'];
 const slots=['head','chest','gloves','boots','belt','offhand','weapon','amulet','ring-left','ring-right'],bases=loadItemBases();
 const reserved=new Set(Object.values(save.mercs.mercEquipment).flatMap(Object.values).filter(Boolean).map(i=>i.id));
 const report={policy,inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),seeds:Array.from({length:32},(_,i)=>hashSeed('diablo380-owned-survival-v1:'+i)),proposals:[],rows:[],summary:[],selected:null};
 await writeFile(root+'/seeds.json',JSON.stringify(report.seeds)+'\n',{flag:'wx'});
 function points(p){
  if(p.reset){const q=prepareTownRespec(npc,'stat');assert.equal(q.kind,'ok');assert.equal(q.cost,0);assert.equal(executeTownRespec(q.request),'ok');assert.equal(usePlayerStore.getState().player.statPoints,155);assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:90,vitality:65,energy:0},usePlayerStore.getState().player),'ok');}
  else assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:5,vitality:0,energy:0},usePlayerStore.getState().player),'ok');
  for(let n=0;n<3;n++)assert.equal(usePlayerStore.getState().allocateSkillPoint('skills-sorceress-cold-mastery'),'ok');
 }
 const hit=(raw,s,type)=>mitigateDamage(raw,{type,defenderResistances:s.resistances,defenderArmor:s.defense,defenderMagicResist:s.magicResist}).final;
 const metric=s=>s.lifeMax/((.9*hit(525,s,'physical')+.1*hit(918.75,s,'physical'))*Math.max(.05,.85-s.physDodge)+.1*hit(400,s,'fire')*Math.max(.05,.85-s.magicDodge));
 for(const build of policy.builds){
  restoreEarnedSave(save,0);points(build);const person=structuredClone(usePlayerStore.getState().player),derive=prepareEquippedPlayerStats(person,person.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
  const eligible=new Map(slots.map(slot=>[slot,save.inventory.backpack.filter(item=>!reserved.has(item.id)&&!isTwoHanded(bases.get(item.baseId))&&slotMatches(bases.get(item.baseId)?.slot,slot)&&checkEligibility(item,person,bases).eligible)]));
  let gear={...save.inventory.equipped};
  const score=g=>{const s=derive(g);return s.manaMax>=270&&s.attackSpeed>=200&&s.resistances.fire>=60&&s.resistances.cold>=40&&s.resistances.lightning>=40?metric(s):-Infinity;};
  assert(Number.isFinite(score(gear)));
  for(let pass=0;pass<3;pass++)for(const slot of slots){
   const occupied=new Set(Object.entries(gear).filter(([k])=>k!==slot).map(([,item])=>item?.id));let best=gear,value=score(gear);
   for(const item of eligible.get(slot)){if(occupied.has(item.id))continue;const next={...gear,[slot]:item},n=score(next);if(n>value+1e-12){best=next;value=n;}}
   gear=best;
  }
  const changes=slots.filter(slot=>gear[slot]?.id!==save.inventory.equipped[slot]?.id).map(slot=>({slot,from:save.inventory.equipped[slot]?.id??null,to:gear[slot].id}));
  const proposal={...build,coreStats:person.coreStats,derivedStats:derive(gear),changes,baselineMetric:metric(derive(save.inventory.equipped)),proposedMetric:metric(derive(gear))};report.proposals.push(proposal);process.stdout.write(JSON.stringify({proposal})+'\n');
 }
 await writeFile(root+'/proposals.json',JSON.stringify(report.proposals,null,2)+'\n',{flag:'wx'});
 function prepare(p){
  restoreEarnedSave(save,0);points(p);
  for(const c of p.changes){const i=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(i);assert.deepEqual(useInventoryStore.getState().equipItem(i,c.slot),{ok:true});}
  const person=usePlayerStore.getState().player;assert.deepEqual(person.derivedStats,p.derivedStats);assert.deepEqual(person.coreStats,p.coreStats);
  assert.equal(person.skillLevels['sorceress.cold_mastery'],14);assert.equal(person.statPoints,0);assert.equal(person.skillPoints,0);assert.deepEqual(person.comboOrder,save.player.comboOrder);assert.deepEqual(useMercStore.getState().mercEquipment,save.mercs.mercEquipment);assert.deepEqual(useInventoryStore.getState().currencies,save.inventory.currencies);assert.equal(person.derivedStats.life,save.player.derivedStats.life);assert.equal(person.derivedStats.mana,save.player.derivedStats.mana);
  return {coreStats:person.coreStats,derivedStats:person.derivedStats,skillLevels:person.skillLevels,respecsRemaining:person.respecsRemaining};
 }
 for(const proposal of report.proposals){let qualified=true;for(const area of ['chaos-sanctuary','river-of-flame']){
  const preparation=prepare(proposal);
  for(const [i,seed]of report.seeds.entries()){
   prepare(proposal);const h=startEarnedRun({act:4,subAreaId:'areas/act4-'+area,mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,380);const waves=[];
   for(let index=0;index<h.totalWaves;index++){const w=playEarnedWave(h,index);waves.push({wave:index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana})),remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life}))});if(w.advanceResult!=='next-wave')break;}
   report.rows.push({build:proposal.id,area,seed,group:i<16?'screen':'second-half',won:waves.length===h.totalWaves&&waves.every(w=>w.winner==='player'),waves});useCombatStore.getState().endCombat();
  }
  const rows=report.rows.filter(r=>r.build===proposal.id&&r.area===area),wins=rows.filter(r=>r.won).length,second=rows.filter(r=>r.group==='second-half'&&r.won).length;
  report.summary.push({build:proposal.id,area,n:32,wins,secondHalfWins:second,preparation});await writeFile(root+'/partial.json',JSON.stringify(report,null,2)+'\n');process.stdout.write(JSON.stringify({build:proposal.id,area,wins,secondHalfWins:second})+'\n');if(wins<26||second<12){qualified=false;break;}
 }
 if(qualified){report.selected=proposal;break;}}
 assert(report.rows.length<=128);assert.deepEqual(await readFile(input),raw);await writeFile(root+'/screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({selected:report.selected?.id??null})+'\n');
}finally{await server.close();}
