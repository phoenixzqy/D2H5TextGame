# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: bone-armor.spec.ts >> necromancer.bone_armor native allocation and exact Continue en
- Location: tests/pwa/bone-armor.spec.ts:30:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
-   "necromancer.raise_skeleton",
+   "skills-necromancer-raise-skeleton",
  ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "Main navigation" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "Town" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: Town
      - listitem [ref=e10]:
        - link "Map" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: Map
      - listitem [ref=e14]:
        - link "Combat" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: Combat
      - listitem [ref=e18]:
        - link "Inventory" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: Inventory
      - listitem [ref=e22]:
        - link "Skills" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: Skills
      - listitem [ref=e26]:
        - link "Mercs" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: Mercs
      - listitem [ref=e30]:
        - link "Quests" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: Quests
      - listitem [ref=e34]:
        - link "Settings" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: Settings
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e40]: Settings
      - button "Bone Armor fixtu · Level 1. Open character sheet." [ref=e42] [cursor=pointer]:
        - generic [ref=e44]: "1"
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: Bone Armor fixtu
            - generic [ref=e48]: Level 1
          - generic [ref=e49]:
            - generic [ref=e50]: HP
            - progressbar "HP" [ref=e51]
          - generic [ref=e53]:
            - generic [ref=e54]: MP
            - progressbar "MP" [ref=e55]
          - generic [ref=e57]:
            - generic [ref=e58]: XP
            - progressbar "XP" [ref=e59]
    - main [ref=e60]:
      - generic [ref=e61]:
        - generic [ref=e62]:
          - heading "Language" [level=2] [ref=e63]
          - generic [ref=e64]:
            - button "简体中文" [ref=e65] [cursor=pointer]
            - button "English" [pressed] [ref=e66] [cursor=pointer]
        - generic [ref=e67]:
          - generic [ref=e68] [cursor=pointer]:
            - generic [ref=e69]:
              - generic [ref=e70]: Stealth Mode
              - generic [ref=e71]: Hide icons and colors for workplace discretion
            - checkbox "Stealth Mode" [ref=e72]
          - generic [ref=e74] [cursor=pointer]:
            - generic [ref=e76]: Sound
            - checkbox "Sound" [checked] [ref=e77]
          - generic [ref=e79] [cursor=pointer]:
            - generic [ref=e81]: Music
            - checkbox "Music" [checked] [ref=e82]
        - generic [ref=e83]:
          - heading "Save Management" [level=2] [ref=e84]
          - generic [ref=e85]:
            - button "Save" [ref=e86] [cursor=pointer]
            - button "Export Save" [active] [ref=e87] [cursor=pointer]
            - button "Import Save" [ref=e88] [cursor=pointer]
            - button "Delete Save" [ref=e89] [cursor=pointer]
        - generic [ref=e90]:
          - link "☕ Buy me a coffee" [ref=e91] [cursor=pointer]:
            - /url: https://www.buymeacoffee.com/
          - generic [ref=e92]: "Version: 0.1.0"
```

# Test source

```ts
  35  |         const watch = (p: Page) => {
  36  |           p.on('pageerror', (error) => errors.push(error.message));
  37  |           p.on('console', (message) => {
  38  |             if (message.type() === 'error') errors.push(message.text());
  39  |           });
  40  |         };
  41  |         let page = initial;
  42  |         watch(page);
  43  |         await page.goto('/');
  44  |         await page.waitForLoadState('networkidle');
  45  |         await createCharacter(page, { class: c.classId, name: 'Bone Armor fixture' });
  46  |         await navTo(page, 'settings');
  47  |         await page
  48  |           .getByRole('button', { name: english ? 'English' : '简体中文', exact: true })
  49  |           .click();
  50  |         const fresh = await backup(page);
  51  |         expect(fresh.player.level).toBe(1);
  52  |         expect(fresh.player.skillPoints).toBe(1);
  53  |         const prepared = fresh;
  54  |         await navTo(page, 'skills');
  55  |         await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  56  |         const id = 'skills-' + c.classId + '-' + c.slug;
  57  |         await page.getByTestId('skill-node-' + id).click();
  58  |         await page.mouse.move(1, 1);
  59  |         const panel = page.getByTestId('skill-detail-panel');
  60  |         await expect(panel).toContainText(english ? '12 absorption per rank' : '每级提供12点吸收');
  61  |         await expect(panel).toContainText(english ? 'next fresh area run' : '下次新区域挑战');
  62  |         await expect(panel).toContainText(english ? 'does not refill between waves' : '波次之间不补充');
  63  |         await expect(panel).toContainText(english ? 'maximum 20 ranks' : '最高20级');
  64  |         await expect(panel).not.toContainText('{{');
  65  |         await expect(panel).not.toContainText(english ? 'movement speed' : '移动速度');
  66  |         const allocate = panel.getByRole('button');
  67  |         await allocate.scrollIntoViewIfNeeded();
  68  |         const bounds = await allocate.boundingBox();
  69  |         expect(bounds?.width).toBeGreaterThanOrEqual(44);
  70  |         expect(bounds?.height).toBeGreaterThanOrEqual(44);
  71  |         const current = panel.locator('section').filter({
  72  |           has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true })
  73  |         });
  74  |         const next = panel.locator('section').filter({
  75  |           has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true })
  76  |         });
  77  |         for (const rank of [1]) {
  78  |           await allocate.click();
  79  |           await expect(panel).toContainText(
  80  |             english ? 'Lv. ' + String(rank) + '/20' : '等级 ' + String(rank) + '/20'
  81  |           );
  82  |           for (const [en, zh, bonus] of c.rows) {
  83  |             const label = english ? en : zh;
  84  |             await expect(
  85  |               current.locator('dt').filter({ hasText: label }).locator('+ dd')
  86  |             ).toHaveText(String(bonus * rank));
  87  |             await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(
  88  |               new RegExp(
  89  |                 '^' +
  90  |                   String(bonus * (rank + 1)).replace('.', '[.]') +
  91  |                   '[ ]*[(][+]'  +
  92  |                   String(bonus).replace('.', '[.]') +
  93  |                   '[)]$'
  94  |               )
  95  |             );
  96  |           }
  97  |         }
  98  |         expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  99  |           true
  100 |         );
  101 |         await info.attach('allocated-bone-armor', {
  102 |           body: await page.screenshot(),
  103 |           contentType: 'image/png'
  104 |         });
  105 |         const dimensions = [];
  106 |         for (const [width, height] of [[360,640], [412,915], [640,360], [1280,800], [1920,1080]]) {
  107 |           await page.setViewportSize({ width, height });
  108 |           await panel.scrollIntoViewIfNeeded();
  109 |           expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  110 |           await allocate.scrollIntoViewIfNeeded();
  111 |           const b = await allocate.boundingBox();
  112 |           expect(b?.width).toBeGreaterThanOrEqual(44);
  113 |           expect(b?.height).toBeGreaterThanOrEqual(44);
  114 |           dimensions.push({ width, height, button: b });
  115 |         }
  116 |         await info.attach('responsive-dimensions', { body: JSON.stringify(dimensions), contentType: 'application/json' });
  117 |         await page.setViewportSize(info.project.name.includes('mobile') ? {width:360,height:640} : {width:1280,height:800});
  118 |         const allocated = await backup(page);
  119 |         expect(allocated.player.skillPoints).toBe(0);
  120 |         expect(allocated.player.skillLevels).toEqual({
  121 |           ...prepared.player.skillLevels,
  122 |           [c.canonical]: 1
  123 |         });
  124 |         expect(allocated.player.derivedStats).toEqual(prepared.player.derivedStats);
  125 |         expect(allocated.inventory).toEqual(prepared.inventory);
  126 |         expect(allocated.map).toEqual(prepared.map);
  127 |         expect(allocated.mercs).toEqual(prepared.mercs);
  128 |         expect(allocated.formation).toEqual(prepared.formation);
  129 |         await navTo(page, 'skills');
  130 |         await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  131 |         const slot = page.getByRole('combobox', { name: english ? 'Slot 1' : '槽位 1', exact: true });
  132 |         await expect(slot.locator('option[value="' + id + '"]')).toHaveCount(0);
  133 |         expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  134 |         const saved = await backup(page);
> 135 |         expect(saved.player.comboOrder).toEqual(prepared.player.comboOrder);
      |                                         ^ Error: expect(received).toEqual(expected) // deep equality
  136 |         expect(saved.player.skillLevels?.[c.canonical]).toBe(1);
  137 |         expect(saved.player.derivedStats).toEqual(prepared.player.derivedStats);
  138 |         await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  139 |         await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  140 |         await page.close();
  141 |         page = await context.newPage();
  142 |         watch(page);
  143 |         await page.goto('/');
  144 |         await page.getByTestId('home-continue').click();
  145 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  146 |         const loaded = await backup(page);
  147 |         expect(loaded.player).toEqual(saved.player);
  148 |         expect(loaded.inventory).toEqual(saved.inventory);
  149 |         expect(loaded.map).toEqual(saved.map);
  150 |         expect(loaded.mercs).toEqual(saved.mercs);
  151 |         expect(loaded.formation).toEqual(saved.formation);
  152 |         await navTo(page, 'skills');
  153 |         await page.getByTestId('skill-node-' + id).click();
  154 |         await page.mouse.move(1, 1);
  155 |         await page.getByTestId('skill-detail-panel').scrollIntoViewIfNeeded();
  156 |         expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
  157 |           true
  158 |         );
  159 |         await info.attach('bone-armor-after-Continue', {
  160 |           body: await page.screenshot(),
  161 |           contentType: 'image/png'
  162 |         });
  163 |         await info.attach('exact-Continue', {
  164 |           body: JSON.stringify({ saved, loaded, errors }, null, 2),
  165 |           contentType: 'application/json'
  166 |         });
  167 |         expect(JSON.stringify(loaded)).not.toContain('boneArmor');
  168 |         expect(errors).toEqual([]);
  169 |       }
  170 |     );
  171 |   }
  172 | }
  173 | 
```