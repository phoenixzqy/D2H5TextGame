import json, os, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parent
label, *command = sys.argv[1:]
start = time.time()
with (root / (label + '.log')).open('w') as log:
    p = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    (root / (label + '.process.json')).write_text(json.dumps({'pid': p.pid, 'command': command, 'started': start}))
    code = p.wait()
receipt = {'command': command, 'exit': code, 'seconds': round(time.time()-start, 3)}
(root / (label + '.result.json')).write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt))
lines = (root / (label + '.log')).read_text().splitlines()
print('\n'.join(lines[-45:]))
sys.exit(code)
