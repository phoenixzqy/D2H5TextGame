from pathlib import Path
import json, hashlib, tarfile, datetime, stat

raw=Path(__file__).resolve().parent
wt=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=wt/'docs/plans/evidence/fixtures/p02b05d-current-moor-idle'
dest.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
identities={};commands=[]
for p in sorted(raw.glob('*.meta.json')):
    r=json.loads(p.read_text())
    if 'command' in r:commands.append({'path':p.name,**r})
for p in sorted(raw.glob('*.processes.json')):
    r=json.loads(p.read_text());assert not r['remainingNonZombie'],p
    for row in r['observations']:identities[(row['pid'],row['startTicks'])]=row
for (pid,ticks),row in identities.items():
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
        assert int(fields[19])!=ticks or fields[0]=='Z',row
    except FileNotFoundError:pass
(raw/'process-audit.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(identities),'identities':list(identities.values()),'remainingNonZombie':[]},indent=2)+'\n')
records=[];directories=[]
for p in sorted(raw.rglob('*')):
    mode=p.lstat().st_mode;assert not stat.S_ISLNK(mode),p
    if stat.S_ISDIR(mode):directories.append(str(p.relative_to(raw)))
    else:
        assert stat.S_ISREG(mode),p
        b=p.read_bytes();records.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
archive=dest/'raw.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    for r in records:tar.add(raw/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(records)
    for r in records:
        m=tar.getmember(r['path']);assert m.isfile()and m.size==r['bytes']
        assert sha(tar.extractfile(m).read())==r['sha256']
        assert sha((raw/r['path']).read_bytes())==r['sha256']
packet={'card':'P02b05d','sourceParent':'bff6ce1c6f32ff318fb3063fa62cb03c33f36c82','scope':'one failed same40A current-head production Moor pilot; no clear/idle acceptance','rawPath':str(raw),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'records':records,'directories':directories,'fileCount':len(records),'rawBytes':sum(r['bytes']for r in records),'commands':commands,'processIdentityCount':len(identities),'rawArchiveVerified':True,'inheritedUTL':'P16a01 packet/current unchanged source/test bytes; no new U/T/L run','cleanupOwner':'root after independent final packet review and all reader release'}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'packetSha256':sha((dest/'packet.json').read_bytes()),'archive':packet['archive'],'files':len(records),'rawBytes':packet['rawBytes'],'commands':len(commands),'processIdentities':len(identities)}))
