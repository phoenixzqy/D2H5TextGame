All commands use claimed worktree /home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2.
Prefix each with python /home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-moor-current-5ex61d2z/bounded_runner.py <name>:

list: node_modules/.bin/playwright test --config tests/pwa/blood-moor-earned-idle.config.ts --list
build: npm run check:test-bridge-shake
pilot: node_modules/.bin/playwright test --config tests/pwa/blood-moor-earned-idle.config.ts --reporter=line,json

Sequence: independent plan/concrete/source-expectation review → hash/command freeze → all readers release → list → clean build/bridge → single pilot. No build overlaps source/fingerprint readers. No gameplay retry, matrix or fallback. No new U/T/L command unless source/test bytes change; prior final P16 complete checks apply to these unchanged bytes and are separately linked, not claimed rerun. No new coverage check.

Runner sets exact RAW/output/report/port52991, removes VITE_E2E, preserves native timers. Config uses 180s case/one worker/retries0/traceoff; runner list30/build210/pilot240+2s cleanup,32MiB log/report,64MiBRAW+dist+.vite. Production build checks bridge stripping before browser; server only previews those bytes. Native renderer uses no custom FONTCONFIG_FILE in this English-only pilot. No tools/install or shared-cache removal.

Initial P16-owned dist/.vite have been exactly removed; emptycoverage preserved. Newly created dist/.vite and all nextRAW records are task-owned. Root tracks every process by PID/birth identity and preserves any failure before diagnosis. Exact cleanup waits for all reviews/consumers and durable verification; root owns it. No push/PR/merge/deploy.
