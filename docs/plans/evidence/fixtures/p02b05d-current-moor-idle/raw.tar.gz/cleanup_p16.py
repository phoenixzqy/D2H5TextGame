from pathlib import Path
import json, hashlib, tarfile, stat, datetime

wt = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
raw = Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-combat-readable-5nscfev_')
dest = wt / 'docs/plans/evidence/fixtures/p16a01-combat-readability'
next_raw = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
p = json.loads((dest / 'packet.json').read_text())
assert p['rawPath'] == str(raw)
assert sha((dest/'raw.tar.gz').read_bytes()) == p['archive']['sha256']
assert len(p['records']) == 111
actual = [x for x in raw.rglob('*') if not x.is_dir()]
assert {str(x.relative_to(raw)) for x in actual} == {r['path'] for r in p['records']}
with tarfile.open(dest/'raw.tar.gz') as tar:
    for r in p['records']:
        b=(raw/r['path']).read_bytes()
        assert len(b)==r['bytes'] and sha(b)==r['sha256']
        assert sha(tar.extractfile(r['path']).read())==r['sha256']
for row in json.loads((raw/'process-audit.json').read_text())['identities']:
    try:
        fields=Path(f"/proc/{row['pid']}/stat").read_text().rsplit(')',1)[1].split()
        assert int(fields[19])!=row['startTicks'] or fields[0]=='Z', row
    except FileNotFoundError:
        pass

def remove_exact(root):
    assert root in [raw,wt/'dist',wt/'node_modules/.vite']
    assert root.resolve()==root and root.is_dir() and not root.is_symlink()
    records=[];dirs=[]
    for child in sorted(root.rglob('*')):
        mode=child.lstat().st_mode
        assert not stat.S_ISLNK(mode), child
        if stat.S_ISDIR(mode):dirs.append(child)
        else:
            assert stat.S_ISREG(mode), child
            b=child.read_bytes();records.append({'path':str(child.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
    for r in records:
        child=root/r['path'];assert sha(child.read_bytes())==r['sha256'];child.unlink()
    for child in sorted(dirs,key=lambda x:len(x.parts),reverse=True):child.rmdir()
    root.rmdir();assert not root.exists()
    return {'root':str(root),'files':len(records),'records':records,'absenceVerified':True}

result={'card':'P16a01','implementation':'2768502','readersReleased':['root','producer','qa_save_review','design_contracts'],'archiveRawVerified':True,'processIdentitiesNonlive':p['processIdentityCount'],'signals':[],'removed':[],'preserved':['pre-existing empty coverage','installed dependencies/browser/tools','shared caches','source/history/durable evidence','claimed umbrella worktree'],'nextRaw':str(next_raw),'cleanupOwner':'root','at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
for target in [raw,wt/'dist',wt/'node_modules/.vite']:result['removed'].append(remove_exact(target))
coverage=wt/'coverage';assert coverage.is_dir() and not list(coverage.iterdir())
(dest/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
(next_raw/'p16-cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'removed':[{k:r[k] for k in ['root','files','absenceVerified']} for r in result['removed']],'processIdentitiesNonlive':p['processIdentityCount'],'coveragePreservedEmpty':True}))
