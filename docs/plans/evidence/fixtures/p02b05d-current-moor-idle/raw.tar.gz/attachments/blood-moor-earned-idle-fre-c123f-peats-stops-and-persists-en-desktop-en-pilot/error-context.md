# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: blood-moor-earned-idle.spec.ts >> fresh earned Blood Moor unlocks active idle, repeats, stops and persists en
- Location: tests/pwa/blood-moor-earned-idle.spec.ts:169:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "Main navigation" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "Town" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: Town
      - listitem [ref=e10]:
        - link "Map" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: Map
      - listitem [ref=e14]:
        - link "Combat" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: Combat
      - listitem [ref=e18]:
        - link "Inventory" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: Inventory
      - listitem [ref=e22]:
        - link "Skills" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: Skills
      - listitem [ref=e26]:
        - link "Mercs" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: Mercs
      - listitem [ref=e30]:
        - link "Quests" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: Quests
      - listitem [ref=e34]:
        - link "Settings" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: Settings
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]: Wave 3 / 3 · Blood Moor · Elite wave
          - generic [ref=e44]: Act 1 · Rogue Encampment
        - generic [ref=e45]:
          - button "Formation" [ref=e46] [cursor=pointer]
          - button "Pause" [disabled] [ref=e47]
          - button "Speed" [disabled] [ref=e48]: 1x
          - button "Skip" [disabled] [ref=e49]
          - generic [ref=e50] [cursor=pointer]:
            - checkbox "Auto" [checked] [ref=e51]
            - text: Auto
          - button "Flee" [ref=e52] [cursor=pointer]
    - main [ref=e53]:
      - generic [ref=e54]:
        - heading "Battlefield" [level=2] [ref=e55]
        - group "MP" [ref=e56]:
          - generic [ref=e57]:
            - generic [ref=e58]:
              - generic [ref=e59]: MP
              - generic [ref=e60]: 111 / 137
            - progressbar [ref=e62]
        - generic [ref=e63]:
          - region "Allies" [ref=e64]:
            - generic [ref=e65]: Allies
            - generic [ref=e66]:
              - generic "Rogue Scout — Inner Sight" [ref=e70]:
                - img "Rogue Scout — Inner Sight" [ref=e72]
                - generic [ref=e74]: Rogue Scout — Inner Sight
              - generic [ref=e78]: No units
              - generic [ref=e80]: No units
              - generic [ref=e82]: No units
              - generic "Earned Moor" [ref=e86]:
                - img "Earned Moor" [ref=e88]
                - generic [ref=e90]: Earned Moor
              - generic [ref=e94]: No units
              - generic [ref=e96]: No units
              - generic [ref=e98]: No units
              - generic [ref=e100]: No units
          - generic [ref=e101]:
            - generic [ref=e102]:
              - generic [ref=e103]: Wave
              - generic [ref=e104]: 3/3
            - generic [ref=e106]: Clash
          - region "Enemies" [ref=e107]:
            - generic [ref=e108]: Enemies
            - generic [ref=e109]:
              - generic "Zombie F" [ref=e113]:
                - img "Zombie F" [ref=e115]
                - generic [ref=e117]: Zombie F
              - generic "Zombie B" [ref=e122]:
                - img "Zombie B" [ref=e124]
                - generic [ref=e126]: Zombie B
              - generic "Quill Rat G" [ref=e131]:
                - img "Quill Rat G" [ref=e133]
                - generic [ref=e135]: Quill Rat G
              - generic "Quill Rat C" [ref=e140]:
                - img "Quill Rat C" [ref=e142]
                - generic [ref=e144]: Quill Rat C
              - generic [ref=e147]:
                - generic "Zombie A" [ref=e149]:
                  - img "Zombie A" [ref=e151]
                  - generic [ref=e153]: Zombie A
                - generic: Burn
              - generic "Quill Rat D" [ref=e159]:
                - img "Quill Rat D" [ref=e161]
                - generic [ref=e163]: Quill Rat D
              - generic "Quill Rat H" [ref=e168]:
                - img "Quill Rat H" [ref=e170]
                - generic [ref=e172]: Quill Rat H
              - generic "Zombie E" [ref=e177]:
                - img "Zombie E" [ref=e179]
                - generic [ref=e181]: Zombie E
              - generic "Zombie I" [ref=e186]:
                - img "Zombie I" [ref=e188]
                - generic [ref=e190]: Zombie I
              - generic "Zombie J" [ref=e195]:
                - img "Zombie J" [ref=e197]
                - generic [ref=e199]: Zombie J
              - generic "Quill Rat K" [ref=e204]:
                - img "Quill Rat K" [ref=e206]
                - generic [ref=e208]: Quill Rat K
              - generic [ref=e211]: No enemies
      - generic [ref=e213]:
        - heading "Combat Log" [level=2] [ref=e214]
        - log [ref=e215]:
          - generic [ref=e216]: 12:00:00Zombie F attacks Earned Moor for 1 physical damage.
          - generic [ref=e217]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e218]: 12:00:00Earned Moor attacks Zombie A for 12 cold damage.
          - generic [ref=e219]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e220]: 12:00:00CRITICAL! Earned Moor hits Zombie F for 64 cold damage!
          - generic [ref=e221]: 12:00:00Zombie F is afflicted with [chill].
          - generic [ref=e222]: 12:00:00Zombie F falls.
          - generic [ref=e223]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e224]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 4 physical damage.
          - generic [ref=e225]: 12:00:00Zombie A takes 2 damage over time.
          - generic [ref=e226]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e227]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e228]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e229]: 12:00:00Earned Moor attacks Zombie A for 3 fire damage.
          - generic [ref=e230]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e231]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e232]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 2 physical damage.
          - generic [ref=e233]: 12:00:00Turn 6 begins
          - generic [ref=e234]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e235]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e236]: 12:00:00Earned Moor attacks Zombie A for 14 cold damage.
          - generic [ref=e237]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e238]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e239]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e240]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e241]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e242]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e243]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e244]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e245]: 12:00:00Earned Moor attacks Zombie A for 5 fire damage.
          - generic [ref=e246]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e247]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e248]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 2 physical damage.
          - generic [ref=e249]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e250]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e251]: 12:00:00Zombie A attacks Earned Moor for 1 physical damage.
          - generic [ref=e252]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e253]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e254]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e255]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e256]: 12:00:00Turn 7 begins
          - generic [ref=e257]: 12:00:00Zombie A takes 2 damage over time.
          - generic [ref=e258]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e259]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e260]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e261]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e262]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e263]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e264]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e265]: 12:00:00Earned Moor attacks Zombie A for 12 cold damage.
          - generic [ref=e266]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e267]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e268]: 12:00:00Zombie A attacks Earned Moor for 1 physical damage.
          - generic [ref=e269]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e270]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e271]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e272]: 12:00:00Earned Moor attacks Zombie A for 2 fire damage.
          - generic [ref=e273]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e274]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e275]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e276]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e277]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e278]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e279]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e280]: 12:00:00Earned Moor attacks Zombie A for 10 cold damage.
          - generic [ref=e281]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e282]: 12:00:00Turn 8 begins
          - generic [ref=e283]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e284]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e285]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e286]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e287]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e288]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e289]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e290]: 12:00:00Earned Moor attacks Zombie A for 2 fire damage.
          - generic [ref=e291]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e292]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e293]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 2 physical damage.
          - generic [ref=e294]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e295]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e296]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e297]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e298]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e299]: 12:00:00Rogue Scout — Inner Sight dodges Zombie A's attack!
          - generic [ref=e300]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e301]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e302]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e303]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e304]: 12:00:00Earned Moor attacks Zombie A for 7 fire damage.
          - generic [ref=e305]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e306]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e307]: 12:00:00Zombie A dodges Rogue Scout — Inner Sight's attack!
          - generic [ref=e308]: 12:00:00Turn 9 begins
          - generic [ref=e309]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e310]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e311]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e312]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e313]: 12:00:00Earned Moor attacks Zombie A for 10 cold damage.
          - generic [ref=e314]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e315]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e316]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e317]: 12:00:00CRITICAL! Rogue Scout — Inner Sight hits Zombie A for 25 physical damage!
          - generic [ref=e318]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e319]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e320]: 12:00:00Earned Moor dodges Zombie A's attack!
          - generic [ref=e321]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e322]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e323]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e324]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e325]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e326]: 12:00:00Earned Moor attacks Zombie A for 13 cold damage.
          - generic [ref=e327]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e328]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e329]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e330]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e331]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e332]: 12:00:00Turn 10 begins
          - generic [ref=e333]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e334]: 12:00:00Earned Moor attacks Zombie A for 2 fire damage.
          - generic [ref=e335]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e336]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e337]: 12:00:00Zombie A dodges Rogue Scout — Inner Sight's attack!
          - generic [ref=e338]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e339]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e340]: 12:00:00Zombie A attacks Earned Moor for 1 physical damage.
          - generic [ref=e341]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e342]: 12:00:00Earned Moor attacks Zombie A for 11 cold damage.
          - generic [ref=e343]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e344]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e345]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e346]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 3 physical damage.
          - generic [ref=e347]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e348]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e349]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e350]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e351]: 12:00:00Earned Moor attacks Zombie A for 10 fire damage.
          - generic [ref=e352]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e353]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e354]: 12:00:00CRITICAL! Rogue Scout — Inner Sight hits Zombie A for 14 physical damage!
          - generic [ref=e355]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e356]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e357]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e358]: 12:00:00Turn 11 begins
          - generic [ref=e359]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e360]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e361]: 12:00:00Rogue Scout — Inner Sight dodges Zombie A's attack!
          - generic [ref=e362]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e363]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e364]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e365]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e366]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e367]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e368]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e369]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e370]: 12:00:00Zombie A attacks Rogue Scout — Inner Sight for 1 physical damage.
          - generic [ref=e371]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e372]: 12:00:00Earned Moor attacks Zombie A for 11 cold damage.
          - generic [ref=e373]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e374]: 12:00:00Zombie A is afflicted with [freeze].
          - generic [ref=e375]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e376]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 4 physical damage.
          - generic [ref=e377]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e378]: 12:00:00Rogue Scout — Inner Sight dodges Zombie A's attack!
          - generic [ref=e379]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e380]: 12:00:00Earned Moor attacks Zombie A for 7 fire damage.
          - generic [ref=e381]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e382]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e383]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e384]: 12:00:00Turn 12 begins
          - generic [ref=e385]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e386]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e387]: 12:00:00Zombie A dodges Earned Moor's attack!
          - generic [ref=e388]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e389]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e390]: 12:00:00Zombie A attacks Earned Moor for 1 physical damage.
          - generic [ref=e391]: 12:00:00Rogue Scout — Inner Sight casts Inner Sight.
          - generic [ref=e392]: 12:00:00Zombie A is afflicted with [Inner Sight].
          - generic [ref=e393]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e394]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e395]: 12:00:00Earned Moor attacks Zombie A for 5 fire damage.
          - generic [ref=e396]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e397]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e398]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e399]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e400]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e401]: 12:00:00Rogue Scout — Inner Sight dodges Zombie A's attack!
          - generic [ref=e402]: 12:00:00Earned Moor casts Frost Nova.
          - generic [ref=e403]: 12:00:00Earned Moor attacks Zombie A for 12 cold damage.
          - generic [ref=e404]: 12:00:00Zombie A is afflicted with [chill].
          - generic [ref=e405]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e406]: 12:00:00Rogue Scout — Inner Sight casts Basic Arrow.
          - generic [ref=e407]: 12:00:00Rogue Scout — Inner Sight attacks Zombie A for 1 physical damage.
          - generic [ref=e408]: 12:00:00Turn 13 begins
          - generic [ref=e409]: 12:00:00Zombie A takes 1 damage over time.
          - generic [ref=e410]: 12:00:00Zombie A casts Weak Melee.
          - generic [ref=e411]: 12:00:00Zombie A attacks Earned Moor for 1 physical damage.
          - generic [ref=e412]: 12:00:00Earned Moor casts Fire Bolt.
          - generic [ref=e413]: 12:00:00Earned Moor attacks Zombie A for 4 fire damage.
          - generic [ref=e414]: 12:00:00Zombie A is afflicted with [burn].
          - generic [ref=e415]: 12:00:00The battle ends in a draw.
      - generic [ref=e416]: Next wave in 1.5s…
```

# Test source

```ts
  30  |     const open = indexedDB.open('D2H5TextGame');
  31  |     open.onerror = () => { reject(new Error('Could not open saved character')); };
  32  |     open.onsuccess = () => {
  33  |       const db = open.result;
  34  |       const get = db.transaction('saves', 'readonly').objectStore('saves').get('current');
  35  |       get.onerror = () => { db.close(); reject(new Error('Could not read saved character')); };
  36  |       get.onsuccess = () => {
  37  |         const record = get.result as { data: SaveCurrent } | undefined;
  38  |         db.close();
  39  |         if (!record) reject(new Error('No committed character'));
  40  |         else resolve(record.data);
  41  |       };
  42  |     };
  43  |   }));
  44  | }
  45  | async function production(page: Page) {
  46  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  47  |   expect(await page.evaluate(() => navigator.serviceWorker.controller?.state)).toBe('activated');
  48  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  49  | }
  50  | async function tree(page: Page, skill: string) {
  51  |   await navTo(page, 'skills');
  52  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  53  |   await page.getByTestId(`skill-node-${skill}`).click();
  54  |   return page.getByTestId('skill-detail-panel');
  55  | }
  56  | async function slots(page: Page, english: boolean, selected: readonly string[]) {
  57  |   await navTo(page, 'skills');
  58  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  59  |   for (let slot = 1; slot <= 9; slot += 1) {
  60  |     const select = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(slot)}`, exact: true });
  61  |     await select.selectOption(selected[slot - 1] ?? '');
  62  |     await expect(select).toHaveValue(selected[slot - 1] ?? '');
  63  |   }
  64  |   await production(page);
  65  | }
  66  | async function countMonsters(cards: Locator) {
  67  |   let count = 0;
  68  |   for (const card of await cards.all()) {
  69  |     const badge = card.locator(':scope > div:first-of-type > div').filter({ hasText: /^\+\d+$/ });
  70  |     expect(await badge.count()).toBeLessThanOrEqual(1);
  71  |     count += 1 + (await badge.count() ? Number((await badge.innerText()).slice(1)) : 0);
  72  |   }
  73  |   return count;
  74  | }
  75  | async function enter(page: Page, english: boolean, area = 'a1-blood-moor', started?: () => void) {
  76  |   await navTo(page, 'map');
  77  |   await page.getByTestId(`sub-area-row-${area}`)
  78  |     .getByRole('button', { name: english ? 'Enter' : '进入', exact: true }).click();
  79  |   started?.();
  80  |   await expect(page.getByTestId('combat-screen')).toBeVisible();
  81  |   expect(await wave(page)).toBe(1);
  82  | }
  83  | async function wave(page: Page) {
  84  |   const value = /^\D*(\d+)/.exec(await page.getByTestId('wave-counter').innerText())?.[1];
  85  |   if (!value) throw new Error('Missing numeric wave');
  86  |   return Number(value);
  87  | }
  88  | async function pause(page: Page, english: boolean) {
  89  |   await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click({ timeout: 500 });
  90  |   await expect(page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true }))
  91  |     .toHaveAttribute('aria-pressed', 'true');
  92  | }
  93  | async function flee(page: Page, english: boolean) {
  94  |   await page.getByRole('button', { name: english ? 'Flee' : '逃跑', exact: true }).click();
  95  |   await expect(page.getByTestId('map-screen')).toBeVisible();
  96  | }
  97  | async function attach(info: TestInfo, label: string, value: unknown) {
  98  |   await info.attach(label, { body: JSON.stringify(value), contentType: 'application/json' });
  99  | }
  100 | /** One readonly DOM observation before native inter-wave navigation can replace it. */
  101 | async function terminalDOM(page: Page) {
  102 |   return page.evaluate(() => {
  103 |     const hero = document.querySelector('[data-testid="unit-card-player-1792497600000"]');
  104 |     const log = Array.from(document.querySelectorAll('[data-testid="combat-log"] > div > span:last-child'), node => node.textContent ?? '');
  105 |     return {
  106 |       waveText: document.querySelector('[data-testid="wave-counter"]')?.textContent,
  107 |       waveKind: document.querySelector('[data-testid="wave-kind-label"]')?.textContent,
  108 |       heroPresent: hero !== null,
  109 |       heroDead: hero?.getAttribute('data-dead') ?? null,
  110 |       heroHPPercent: Number.parseFloat(hero?.querySelector<HTMLElement>('.bg-red-600')?.style.width ?? 'NaN'),
  111 |       idleMode: document.querySelector('[data-testid="idle-loop-label"]') !== null,
  112 |       enemyRoster: Array.from(document.querySelectorAll('[data-testid="enemies-grid"] [data-testid^="unit-card-"]'),
  113 |         node => ({ id: node.getAttribute('data-testid'), dead: node.getAttribute('data-dead') === 'true' })),
  114 |       liveEnemies: document.querySelectorAll('[data-testid="enemies-grid"] [data-testid^="unit-card-"]:not([data-dead="true"])').length,
  115 |       defeatPanels: document.querySelectorAll('[data-testid="defeat-panel"]').length,
  116 |       deadMerc: document.querySelectorAll('[data-testid="allies-grid"] [data-kind="merc"][data-dead="true"]').length,
  117 |       skipDisabled: document.querySelector<HTMLButtonElement>('[data-testid="skip-button"]')?.disabled,
  118 |       log,
  119 |       allies: document.querySelector('[data-testid="allies-grid"]')?.textContent,
  120 |       enemies: document.querySelector('[data-testid="enemies-grid"]')?.textContent
  121 |     };
  122 |   });
  123 | }
  124 | function expectTerminal(result: Awaited<ReturnType<typeof terminalDOM>>, expectedWave: number, opening: Awaited<ReturnType<typeof terminalDOM>>, idleMode = false) {
  125 |   expect(Number(/^\D*(\d+)/.exec(result.waveText ?? '')?.[1])).toBe(expectedWave);
  126 |   expect(result.idleMode).toBe(idleMode);
  127 |   expect(opening.idleMode).toBe(idleMode);
  128 |   expect(opening.enemyRoster.length).toBeGreaterThan(0);
  129 |   expect(result.enemyRoster.map(enemy => enemy.id)).toEqual(opening.enemyRoster.map(enemy => enemy.id));
> 130 |   expect(result.enemyRoster.every(enemy => enemy.dead)).toBe(true);
      |                                                         ^ Error: expect(received).toBe(expected) // Object.is equality
  131 |   expect(Number.isFinite(result.heroHPPercent)).toBe(true);
  132 |   expect(result.heroHPPercent).toBeGreaterThan(0);
  133 |   expect(result.skipDisabled).toBe(true);
  134 |   expect(result.log.at(-1)).toBe('Victory! All enemies are defeated.');
  135 |   expect(result.defeatPanels).toBe(0);
  136 |   expect(result.liveEnemies).toBe(0);
  137 |   expect(result.heroPresent).toBe(true);
  138 |   expect(result.heroDead).not.toBe('true');
  139 | }
  140 | function expectPlayer(actual: SaveCurrent, configured: SaveCurrent, totalXP: number, fireRank: number, spent: number, questPoints = 0) {
  141 |   const level = totalXP >= 11013 ? 6 : totalXP >= 5423 ? 5 : totalXP >= 2223 ? 4 : totalXP >= 665 ? 3 : totalXP >= 100 ? 2 : 1;
  142 |   expect(actual.player).toEqual({ ...configured.player, level, experience: totalXP - (reachXP[level] ?? -1),
  143 |     experienceToNextLevel: nextXP[level], statPoints: (level - 1) * 5,
  144 |     skillPoints: level - 1 - spent + questPoints,
  145 |     skillLevels: { ...ranks, 'sorceress.fire_bolt': fireRank },
  146 |     derivedStats: { ...configured.player.derivedStats, lifeMax: 120 + 8 * (level - 1),
  147 |       manaMax: 102 + 4 * (level - 1), attack: 22 + 2 * (level - 1), defense: 20 + 3 * (level - 1) } });
  148 | }
  149 | function expectMerc(actual: SaveCurrent, hired: SaveCurrent, earnedXP: number, equipment = hired.mercs.mercEquipment) {
  150 |   const initial = hired.mercs.ownedMercs[0];
  151 |   if (!initial) throw new Error('Missing normally hired mercenary');
  152 |   let level = 3;
  153 |   let xp = earnedXP;
  154 |   const threshold = (rank: number) => Math.floor(60 * rank * 1.3 ** (rank - 1));
  155 |   while (xp >= threshold(level)) { xp -= threshold(level); level += 1; }
  156 |   const gains = level - 3;
  157 |   expect(actual.mercs).toEqual({ ...hired.mercs, mercEquipment: equipment, ownedMercs: [{ ...initial, level,
  158 |     coreStats: { ...initial.coreStats, strength: initial.coreStats.strength + gains,
  159 |       dexterity: initial.coreStats.dexterity + 3 * gains, energy: initial.coreStats.energy + gains },
  160 |     derivedStats: { ...initial.derivedStats, life: initial.derivedStats.life + 8 * gains,
  161 |       lifeMax: initial.derivedStats.lifeMax + 8 * gains } }],
  162 |     mercProgress: { [merc]: { experience: xp, experienceToNextLevel: threshold(level) } } });
  163 | }
  164 | // Independently frozen literals from accepted merc-gear-earned.spec.ts; no item injection.
  165 | const mercGlove: Item = { id: 'it-8jv2k-1', baseId: 'items/base/glove-leather', rarity: 'normal', level: 2, ilvl: 2, baseRolls: { defense: 4 }, affixes: [], generatedName: {}, identified: true, equipped: false };
  166 | const heroGlove: Item = { id: 'it-96fga-3', baseId: 'items/base/glove-leather', rarity: 'normal', level: 2, ilvl: 2, baseRolls: { defense: 5 }, affixes: [], generatedName: {}, identified: true, equipped: false };
  167 | const heroBoots: Item = { id: 'it-5iwwr-4', baseId: 'items/base/boot-leather', rarity: 'normal', level: 2, ilvl: 2, baseRolls: { defense: 3 }, affixes: [], generatedName: {}, identified: true, equipped: false };
  168 | 
  169 | test('fresh earned Blood Moor unlocks active idle, repeats, stops and persists en', async ({ page, context }, info) => {
  170 |   test.setTimeout(180_000);
  171 |   const english = true;
  172 |   const counts = { starts: 0, computedWaves: 0, skipClicks: 0, observedSettlements: 0 };
  173 |   let phase = 'creation';
  174 |   let activePage = page;
  175 |   const errors: string[] = [];
  176 |   let lastJournal: SaveCurrent | null = null;
  177 |   let lastTerminal: Awaited<ReturnType<typeof terminalDOM>> | null = null;
  178 |   const reads: { label: string; elapsedMs: number; items: number; shards: number | undefined }[] = [];
  179 |   const began = performance.now();
  180 |   async function committed(label: string, previous: SaveCurrent) {
  181 |     let current = previous;
  182 |     await expect.poll(async () => {
  183 |       current = await stored(page);
  184 |       reads.push({ label, elapsedMs: performance.now() - began, items: current.inventory.backpack.length,
  185 |         shards: current.inventory.currencies['rune-shard'] });
  186 |       return current.inventory.backpack.length > previous.inventory.backpack.length &&
  187 |         (current.inventory.currencies['rune-shard'] ?? 0) > (previous.inventory.currencies['rune-shard'] ?? 0);
  188 |     }, { timeout: 1000, intervals: [25] }).toBe(true);
  189 |     lastJournal = current;
  190 |     await attach(info, label, current);
  191 |     return current;
  192 |   }
  193 |   const watch = (watched: Page) => {
  194 |     watched.on('pageerror', error => errors.push(error.message));
  195 |     watched.on('console', message => { if (['warning', 'error'].includes(message.type())) errors.push(message.text()); });
  196 |   };
  197 |   watch(page);
  198 |   try {
  199 |     await page.clock.setFixedTime(fixedTime); // Date only; timers remain native.
  200 |     await page.goto('/');
  201 |     await createCharacter(page, { class: 'sorceress', name });
  202 |     await navTo(page, 'settings');
  203 |     await page.getByRole('button', { name: 'English', exact: true }).click();
  204 |     await expect.poll(() => page.evaluate(() => navigator.serviceWorker.controller?.state), { timeout: 60_000 }).toBe('activated');
  205 |     const fresh = await backup(page);
  206 |     expect(fresh.map.clearedSubAreas).toEqual([]);
  207 |     expect(fresh.meta.idleState.idleTarget).toBeUndefined();
  208 |     await navTo(page, 'map');
  209 |     await expect(page.getByTestId('farm-locked-a1-blood-moor')).toBeDisabled();
  210 |     await attach(info, 'fresh', fresh);
  211 |     expect(fresh.player).toMatchObject({ level: 1, experience: 0, statPoints: 0, skillPoints: 1, skillLevels: ranks });
  212 |     expect(fresh.inventory.backpack).toEqual([]);
  213 |     expect(fresh.inventory.equipped).toEqual({});
  214 |     const locked = await tree(page, frost);
  215 |     await expect(locked.getByRole('button', { name: 'Requires Lv. 6', exact: true })).toBeDisabled();
  216 |     expect(await backup(page)).toEqual({ ...fresh, player: { ...fresh.player, comboOrder: [ice] } });
  217 |     await navTo(page, 'mercs');
  218 |     await page.getByTestId(`hire-merc-${merc}`).getByRole('button', { name: 'Hire', exact: true }).click();
  219 |     const hired = await backup(page);
  220 |     await attach(info, 'hired', hired);
  221 |     expect(hired.inventory).toEqual(fresh.inventory);
  222 |     expect(hired.mercs.fieldedMercId).toBe(merc);
  223 |     expect(hired.mercs.ownedMercs).toHaveLength(1);
  224 |     expect(hired.mercs.ownedMercs[0]?.level).toBe(3);
  225 |     expect(hired.mercs.mercProgress).toEqual({ [merc]: { experience: 0, experienceToNextLevel: 304 } });
  226 |     await tree(page, fire);
  227 |     await page.getByTestId('skill-detail-panel').getByRole('button', { name: 'Allocate', exact: true }).click();
  228 |     const learned = await backup(page);
  229 |     expect(learned).toEqual({ ...hired, player: { ...hired.player, skillPoints: 0,
  230 |       skillLevels: { ...ranks, 'sorceress.fire_bolt': 1 } } });
```