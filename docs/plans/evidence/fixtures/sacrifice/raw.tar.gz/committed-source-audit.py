import pathlib,subprocess,json,hashlib,io
p=pathlib.Path(__file__).parent;wd=pathlib.Path.cwd()
source=json.loads((p/'frozen-inputs.json').read_text())['source']
names=list(source)
query=''.join('HEAD:'+name+'\n' for name in names).encode()
result=subprocess.run(['git','cat-file','--batch'],input=query,stdout=subprocess.PIPE,check=True)
stream=io.BytesIO(result.stdout)
for name in names:
 header=stream.readline().decode().split();assert len(header)==3 and header[1]=='blob',(name,header)
 payload=stream.read(int(header[2]));assert stream.read(1)==b'\n'
 assert hashlib.sha256(payload).hexdigest()==source[name],('committed mismatch',name)
 assert hashlib.sha256((wd/name).read_bytes()).hexdigest()==source[name],('disk mismatch',name)
assert stream.read()==b''
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
value={'head':head,'source_files':len(source),'all_tested_committed_blobs_exact':True,'all_tested_disk_files_exact':True}
f=p/'committed-source-audit.json';assert not f.exists();f.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
