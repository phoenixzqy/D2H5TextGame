import pathlib,json,hashlib,tarfile,shutil,datetime
p=pathlib.Path(__file__).parent.resolve();wd=pathlib.Path.cwd()
assert p.name=='d2h5-sacrifice-repair-4hsgvq1u'
assert wd==pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=wd/'docs/plans/evidence/fixtures/sacrifice'
assert not out.exists();out.mkdir()
def digest(raw):return hashlib.sha256(raw).hexdigest()
receipts={}
for f in sorted(p.glob('*.json')):
 value=json.loads(f.read_text())
 if isinstance(value,dict) and {'argv','cwd','exit','seconds','finished'}<=value.keys():receipts[f.name]=value
assert receipts and receipts['sacrifice-final-full.json']['exit']==0
for name in ['sacrifice-corrected-engine.json','sacrifice-corrected-types.json','sacrifice-corrected-lint.json','sacrifice-production-build.json','browser-evidence-review.json','post-full-freeze.json','committed-source-review.json']:assert receipts[name]['exit']==0,(name,receipts.get(name))
(p/'terminal-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
files=[]
for f in sorted(p.rglob('*')):
 assert not f.is_symlink(),f
 if f.is_file() and 'production-dist' not in f.relative_to(p).parts:files.append(f)
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)),recursive=False)
manifest={str(f.relative_to(p)):{'size':f.stat().st_size,'sha256':digest(f.read_bytes())} for f in files}
with tarfile.open(archive) as t:
 assert sorted(t.getnames())==sorted(manifest)
 for name,item in manifest.items():
  raw=t.extractfile(name).read();assert len(raw)==item['size'] and digest(raw)==item['sha256'],name
copies=['author-review.json','browser-evidence-audit.json','build-audit.json','committed-source-audit.json','frozen-inputs.json','post-full-freeze-audit.json','terminal-receipts.json','inventory-reconciliation.json']
for name in copies:
 shutil.copyfile(p/name,out/name);assert (p/name).read_bytes()==(out/name).read_bytes()
for locale in ['en','zh-CN']:
 f=p/('browser-'+locale+'-360')/(locale+'-360-sacrifice-details.png');shutil.copyfile(f,out/('sacrifice-'+locale+'-mobile.png'))
packet={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':'raw.tar.gz','sha256':digest(archive.read_bytes()),'raw_files':len(files),'terminal_receipts':len(receipts),'all_members_byte_verified':True,'files':manifest,'omitted':'Disposable production-dist bytes only; complete build hash map retained in frozen-inputs.json. No failures or screenshots omitted.'}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({k:v for k,v in packet.items() if k!='files'}))
