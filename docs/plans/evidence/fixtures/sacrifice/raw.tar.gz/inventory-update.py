import pathlib,csv,io,json,hashlib,subprocess,collections
p=pathlib.Path(__file__).parent;path=pathlib.Path('docs/plans/skill-inventory.csv')
before=path.read_bytes();text=before.decode();rows=list(csv.DictReader(io.StringIO(text))); ids=[r['data_id'] for r in rows]
assert len(ids)==len(set(ids))==213
baseline=subprocess.check_output(['git','show','cd23690:docs/plans/skill-inventory.csv']);assert before==baseline
old='paladin,skills-paladin-sacrifice,paladin.sacrifice,active,damage,,src/data/skills/paladin.json,,unverified,'
new='paladin,skills-paladin-sacrifice,paladin.sacrifice,active,damage+actual-enemy-HP-self-life-debit,,src/data/skills/paladin.json,provisional-self-damage-tuning|earned-class-build-balance-open,bounded-functional;independent-acceptance-open,docs/plans/decisions/D04-paladin-sacrifice-v1.md|docs/plans/evidence/d04-paladin-sacrifice.md'
assert text.splitlines().count(old)==1
updated=text.replace(old+'\n',new+'\n');assert updated!=text
rows2=list(csv.DictReader(io.StringIO(updated)));assert [r['data_id'] for r in rows2]==ids
changed=[a['data_id'] for a,b in zip(rows,rows2) if a!=b];assert changed==['skills-paladin-sacrifice']
def counts(data):return dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in data))
assert counts(rows2)=={'unverified':118,'bounded-functional':93,'bounded-engine-functional':1,'review-needed':1}
path.write_text(updated)
result={'rows':213,'ids_order_preserved':True,'changed_rows':changed,'before_counts':counts(rows),'after_counts':counts(rows2),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'new_record':next(r for r in rows2 if r['data_id']==changed[0]),'independent_earned_acceptance_open':True}
f=p/'inventory-reconciliation.json';assert not f.exists();f.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
