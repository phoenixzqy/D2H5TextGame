import pathlib,subprocess
p=pathlib.Path(__file__).parent
for locale,width in [('en','360'),('zh-CN','1280'),('zh-CN','360')]:
 label='browser-'+locale+'-'+width
 subprocess.run(['python3',str(p/'run.py'),label,'env','BROWSER_RUN='+label,'BROWSER_LOCALE='+locale,'BROWSER_WIDTH='+width,
  'python3','.github/skills/webapp-testing/scripts/with_server.py','--server','exec python3 '+str(p/'serve.py'),'--port','4483','--','node',str(p/'browser-current.cjs')],check=True)
