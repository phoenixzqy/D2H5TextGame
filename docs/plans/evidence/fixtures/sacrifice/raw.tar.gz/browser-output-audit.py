import pathlib,json,os,socket,re,hashlib
p=pathlib.Path(__file__).parent
results=[]
for locale,width in [('en',1280),('en',360),('zh-CN',1280),('zh-CN',360)]:
 label=locale+'-'+str(width); d=p/('browser-'+label)
 report=json.loads((d/'browser-report.json').read_text())
 assert report['failures']==[] and len(report['cases'])==1
 case=report['cases'][0]
 assert case['label']==label and case['pass'] is True and case['errors']==[]
 assert case['pairs']==['rank1','rank2']
 pairs=[]
 for rank in [1,2]:
  names=[next(d.glob(label+'-rank'+str(rank)+'-'+side+'-*.json')) for side in ['before','after']]
  before,after=[json.loads(n.read_text()) for n in names]
  assert before['version']==after['version']==22
  for key in ['player','inventory','map','mercs','formation']:assert before[key]==after[key],(label,rank,key)
  player=after['player']
  assert player['level']==30 and player['skillLevels']=={'paladin.sacrifice':rank}
  assert player['skillPoints']==2-rank and player['comboOrder']==[('paladin.sacrifice' if rank==1 else 'skills-paladin-sacrifice') ]
  pairs.append({'rank':rank,'domains_exact':5,'before':names[0].name,'after':names[1].name})
 assert len(case['combat'])==1 and case['combat'][0]['slug']=='sacrifice'
 combat=case['combat'][0]; lines=combat['log']
 self_hits=[m for m in lines if m.count('PaladinCheck')==2 and ('physical' if locale=='en' else '物理') in m and re.search(r'for [1-9]\d* ' if locale=='en' else r'造成 [1-9]\d* 点',m)]
 assert self_hits,(label,lines)
 assert any(combat['name'] in m and ('casts' if locale=='en' else '施放了') in m for m in lines)
 assert len(report['geometry'])==5
 assert [(x['width'],x['height']) for x in report['geometry']]==[(360,640),(412,915),(640,360),(1280,800),(1920,1080)]
 for g in report['geometry']:assert g['overflow']==0 and min(g['allocate']['width'],g['allocate']['height'])>=44
 text=(d/(label+'-sacrifice-details.txt')).read_text()
 for expected in (['Self damage','8%','can kill'] if locale=='en' else ['自身伤害','8%','可能致死']):assert expected in text,(label,expected)
 assert '{{' not in text and 'undefined' not in text and 'NaN' not in text
 owner=json.loads((p/('browser-'+label+'-server-owner.json')).read_text())
 try:os.kill(owner['pid'],0)
 except ProcessLookupError:pass
 else:raise AssertionError('Task server PID still alive: '+str(owner['pid']))
 screenshots=[d/(label+'-sacrifice-'+kind+'.png') for kind in ['details','combat']]
 for path in screenshots:assert path.is_file() and path.stat().st_size>1000
 results.append({'label':label,'pairs':pairs,'positive_self_damage':self_hits,'geometry':5,'page_errors':[], 'server_pid':owner['pid'],'server_absent':True,'screenshots':[{ 'path':str(x.relative_to(p)),'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in screenshots]})
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',4483))!=0
out={'synthetic':True,'cases':results,'continue_pairs':8,'positive_self_damage_cases':4,'geometry_samples':20,'screenshots':8,'port_4483_closed':True}
f=p/'browser-evidence-audit.json';assert not f.exists();f.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,ensure_ascii=False))
