import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
import { useInventoryStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/inventoryStore';
import { useMapStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/mapStore';
import { useFormationStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/formationStore';
import authored from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/paladin.json';
const hold=(at=0):ActiveStatus=>({id:'stun',stacks:1,remaining:-1,sourceId:'synthetic-hold',appliedAtMs:at});
function fixture(slug:string,rank:number,mr=0){
 useInventoryStore.getState().reset();useMapStore.getState().reset();useFormationStore.getState().reset();
 const id='paladin.'+slug.replaceAll('-','_');
 const native=playerToCombatUnit({...createMockPlayer('Synthetic native Paladin probe','paladin'),id:'probe-hero',level:30,skillLevels:{...Object.fromEntries(authored.filter(s=>s.trigger==='active').map(s=>['paladin.'+s.id.replace('skills-paladin-','').replaceAll('-','_'),1])),[id]:rank},comboOrder:['skills-paladin-'+slug]});
 const mana=0;
 const hero:CombatUnit={...native,life:5000,mana,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,manaRegenCarry:0,manaRegenCompensation:0,manaRegenExactCarry:'0',statuses:[hold(1701)],stats:{...native.stats,life:10000,lifeMax:10000,mana:100,manaMax:100,attack:1,attackSpeed:100,critChance:0}};
 const enemy:CombatUnit={...hero,id:'probe-target',side:'enemy',kind:'monster',life:100000,mana:0,statuses:[hold()],skillOrder:[],skillLevels:{},increasedDamagePct:{},stats:{...hero.stats,life:100000,lifeMax:100000,defense:0,magicResist:mr,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}}};
 return {id,native,mana,input:{seed:7,playerTeam:[hero],enemyTeam:[enemy]}};
}
const cases=[];
for(const rank of [1,20]){
 const f=fixture('sacrifice',rank),before=structuredClone(f.input),out=runBattleRecorded(f.input);
 const attacks=out.events.filter(e=>e.kind==='damage'&&e.source===f.native.id&&e.target==='probe-target');
 const actions=out.events.filter(e=>e.kind==='action'&&e.actor===f.native.id);
 const controls={nativeSelection:f.native.skillOrder.length===1&&f.native.skillOrder[0]==='skills-paladin-sacrifice',oneCast:actions.length===1&&actions[0]?.skillId===f.id,positiveEnemyDamage:attacks.some(e=>e.kind==='damage'&&e.amount>0),zeroManaRetained:out.result.playerTeam[0]?.mana===0,immutable:true,replay:true};
 assert.deepEqual(f.input,before);assert.deepEqual(runBattleRecorded(f.input),out);assert.ok(Object.values(controls).every(Boolean));
 const selfDamage=out.events.filter(e=>e.kind==='damage'&&e.source===f.native.id&&e.target===f.native.id);
 const requirements={actualCasterHpLoss:(out.result.playerTeam[0]?.life??5000)<5000,selfDamagePlayback:selfDamage.some(e=>e.kind==='damage'&&e.amount>0)};
 cases.push({rank,controls,requirements,observations:{attacks,selfDamage,heroLife:out.result.playerTeam[0]?.life,enemyLife:out.result.enemyTeam[0]?.life,actions}});
}
const failures=cases.flatMap(c=>Object.entries(c.requirements).filter(([,pass])=>!pass).map(([requirement])=>({rank:c.rank,requirement})));
const result={fixture:'Synthetic native L30 Paladin, ranks1/20, seed7, zero MP/ordinary regeneration, no gear/aura; target held, hero held after first real action. No earned campaign claim.',cases,failures};
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-sacrifice-_rpinmv9/native-red-result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));assert.deepEqual(failures,[],'Actual Sacrifice hits must damage the caster');
