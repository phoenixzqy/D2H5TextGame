import gzip,hashlib,json,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
original=load(REPO/'docs/plans/evidence/fixtures/earned-act3-through362/retained-final.json.gz')
report=json.loads((ROOT/'native/report.json').read_text())
assert report['status']=='observed',report.get('failure')
assert report['errors']==[] and report['console']==[] and report['retries']==0
assert not report.get('cleanupErrors')
freeze=json.loads((ROOT/'freeze.json').read_text())
assert all(sha((REPO/f).read_bytes())==h for f,h in freeze['source'].items())
assert all(sha((ROOT/'dist'/f).read_bytes())==h for f,h in freeze['dist'].items())
assert sha((ROOT/'native.mjs').read_bytes())==freeze['nativeScriptSHA256']
served={}
for f,h in freeze['dist'].items():
 if f.startswith('assets/') and f.endswith('.js'):
  b=urllib.request.urlopen('http://127.0.0.1:4434/'+f).read();assert sha(b)==h
  assert not any(x in b for x in [b'__GAME__',b'seedItem',b'attachTestBridge'])
  served[f]=h
assert len(served)==4

def owned(s):
 rows=[*s['inventory']['backpack'],*s['inventory']['stash'],*s['inventory']['equipped'].values(),*(i for gear in s['mercs']['mercEquipment'].values() for i in gear.values())]
 rows=[i for i in rows if i];d={i['id']:i for i in rows};assert len(d)==len(rows);return d

def xp(s):
 return s['player']['experience']+sum(int(100*(lv**2.5)) for lv in range(1,s['player']['level']))

input_items=owned(original)
for path in (ROOT/'native').glob('*.json.gz'):
 s=load(path)
 if 'player' not in s:continue
 now=owned(s)
 assert all(now.get(k)==v for k,v in input_items.items()),path
 assert s['player']['skillLevels']==original['player']['skillLevels']
 assert s['player']['coreStats']==original['player']['coreStats']
 assert s['player']['comboOrder']==original['player']['comboOrder']
 assert s['player']['respecsRemaining']==original['player']['respecsRemaining']
 assert s['inventory']['equipped']==original['inventory']['equipped']
 assert s['mercs']['mercEquipment']==original['mercs']['mercEquipment']
 assert s['map']['questProgress']==original['map']['questProgress']
 assert s['map']['questReceipts']==original['map']['questReceipts']
 assert s['inventory']['questItems']==original['inventory']['questItems']
 assert s['endgame']==original['endgame']
 assert s['map']['challengeOrdinals']['nightmare']==0
final=load(ROOT/'native/final.json.gz')
assert report['launches']==[{'ordinal':363+i,'alias':'travincal'} for i in range(len(report['launches']))]
assert 1<=len(report['launches'])<=12
assert final['map']['challengeOrdinals']['normal']==363+len(report['launches'])==report['finalOrdinal']
win_waves=[w for a in report['areas'] for w in a['waves'] if w['outcome']=='victory']
assert xp(final)-xp(original)==report['totalXP']==sum(w['delta']['xp'] for w in win_waves)
assert len(owned(final))-len(input_items)==sum(len(w['delta']['newItems']) for w in win_waves)
pairs=[]
for path in (ROOT/'native').glob('*-saved.json.gz'):
 suffix=path.name.partition('-')[2].replace('-saved.json.gz','-continued.json.gz')
 matches=list((ROOT/'native').glob('*-'+suffix));assert len(matches)==1,(path,matches)
 cont=matches[0]
 assert load(cont)==load(path),(path,cont)
 pairs.append([path.name,cont.name])
for area in report['areas']:
 assert area['alias']=='travincal'
 for w in area['waves']:
  stem=f"{area['ordinal']}-w{w['wave']}"
  before=load(ROOT/'native'/(stem+'-initial.json.gz'))
  end=load(ROOT/'native'/(stem+'-terminal.json.gz'))
  assert set(before['enemyIds']).issubset(end['enemyIds'])
  if w['outcome']=='victory':
   assert end['liveEnemies']==0 and end['log'][-1]=='Victory! All enemies are defeated.'
  else:
   assert end['defeat'] and w['delta']['xp']==0 and w['delta']['newItems']==[]
summary={'sourceFiles':len(freeze['source']),'sourceDrift':[],'buildFiles':len(freeze['dist']),'served':served,'challenges':len(report['launches']),'fullClears':sum(a.get('outcome')=='victory' for a in report['areas']),'winningWaves':len(win_waves),'nonwins':sum(w['outcome']!='victory' for a in report['areas'] for w in a['waves']),'exactDurablePairs':len(pairs),'pairs':pairs,'initialOwned':len(input_items),'finalOwned':len(owned(final)),'earnedGear':len(owned(final))-len(input_items),'earnedHeroXP':xp(final)-xp(original),'level':final['player']['level'],'experience':final['player']['experience'],'nextNormal':final['map']['challengeOrdinals']['normal'],'statPoints':final['player']['statPoints'],'skillPoints':final['player']['skillPoints'],'finalRawSHA256':sha(gzip.decompress((ROOT/'native/final.json.gz').read_bytes())),'scope':'genuine historical earned continuation; no complete C2 or campaign pacing acceptance'}
(ROOT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['served','pairs']},indent=2))
