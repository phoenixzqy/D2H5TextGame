from pathlib import Path
import csv, io, json, subprocess, collections

repo=Path.cwd()
p=Path(__file__).parent
path=repo/'docs/plans/skill-inventory.csv'
old=path.read_bytes()
assert old==subprocess.check_output(['git','show','HEAD:docs/plans/skill-inventory.csv'])
lines=old.decode().splitlines(keepends=True)
header=next(csv.reader([lines[0]]))
before=list(csv.DictReader(io.StringIO(old.decode())))
ids=['skills-druid-feral-rage','skills-druid-hunger']
seen=[]
for i,line in enumerate(lines[1:],1):
    values=next(csv.reader([line]))
    r=dict(zip(header,values))
    if r['data_id'] not in ids: continue
    seen.append(r['data_id'])
    feral=r['data_id']==ids[0]
    r.update(adapter_route='damage+explicit-hit-recovery'+('+finite-self-speed' if feral else ''),
        declared_statuses='bleed' if feral else '',
        risk_flags=('provisional-sustain-and-bleed-tuning' if feral else 'provisional-sustain-tuning')+'|earned-balance-open',
        behavior_verification='bounded-functional;independent-acceptance-open',
        contract_evidence='docs/plans/evidence/d04-druid-sustain.md')
    output=io.StringIO(newline='')
    csv.writer(output,lineterminator='\r\n' if line.endswith('\r\n') else '\n').writerow([r[k] for k in header])
    lines[i]=output.getvalue()
assert seen==ids
new=''.join(lines)
after=list(csv.DictReader(io.StringIO(new)))
assert len(after)==213 and [r['data_id'] for r in before]==[r['data_id'] for r in after]
changed=[b['data_id'] for a,b in zip(before,after) if a!=b]
assert changed==ids
counts=dict(collections.Counter(r['behavior_verification'] for r in after))
assert counts=={'unverified':135,'bounded-functional;independent-acceptance-open':73,'bounded-functional;earned-balance-open':3,'bounded-engine-functional;independent-acceptance-open':1,'review-needed':1},counts
path.write_bytes(new.encode())

bug=repo/'production/bugs/BUG-193-druid-sustain-markers.md'
text=bug.read_text()
assert 'Status: Reproduced; mechanics contract and repair pending.' in text
text=text.replace('Status: Reproduced; mechanics contract and repair pending.','Status: Locally fixed and verified; independent design/QA and earned balance open.')
text=text.replace('neither skill gains functional credit.','neither skill gained functional credit from the reproduction alone.')
text+='''

## Local repair and validation

Runtime `7b7f3b2`, presentation `801d97f`, and the
[controlling contract](../../docs/plans/decisions/D04-druid-sustain-v1.md)
add explicit provisional10%/50% actual-hit-HP recovery, authenticated Feral5%
speed stacks (cap5/8s) and10% final-hit/s primary Bleed. Reflection/death settlement
precedes recovery; no resurrection, periodic/basic drain, mana recovery or new
RNG. Native authority/rebase and existing ordinary current-configuration replay
are preserved, with no Save22 change. Both forms and human attacks remain legal.
The initial replay assumption and a real introduced cadence rounding defect were
corrected without changing controlling replay semantics or global cadence.

[Repair evidence](../../docs/plans/evidence/d04-druid-sustain.md): original six
RED cases now GREEN;114 new tests, final full13519/591/two existing skips,
engine7027/246, types/lint/clean explicit-false build/bridge pass. Production4/4,
eight positive hero-recovery attacks, eight exact five-domain Continue pairs,
20geometry samples,16 screenshots/eight inspected. Source/build/Git/genuine
freeze and actual1316 committed source blobs verified. All original failures and
synthetic fixture corrections are retained. Exactly these two skills now have
bounded functional credit; independent acceptance, earned builds/balance,
mobile occlusion, performance and full privatev1 remain open. GenuineL33/next402
is unchanged and Baal remains uncleared. No campaign or remote action.
'''
bug.write_text(text)

ledger=repo/'docs/plans/execution-ledger.md'
text=ledger.read_text()
lines=text.splitlines(keepends=True)
found=[]
for i,line in enumerate(lines):
    if line.startswith('| D04 Feral Rage/Hunger / BUG193 |'):
        found.append(i)
        lines[i]='| D04 Feral Rage/Hunger / BUG193 | locally fixed/verified; independent and earned acceptance open | Runtime `7b7f3b2`, presentation `801d97f`; explicit provisional10%/50% actual-HP recovery, Feral5% self-speed/cap5/8s and primary10% Bleed. Existing reflection/death order, native authority/rebase/current-configuration replay and Save22 preserved. Final full13519/591/two existing skips, engine7027/246, types/lint/build/bridge PASS; production4/4/eight positive recovery attacks/eight exact five-domain Continue pairs/20geometry/16screenshots/eight inspected. [Evidence](evidence/d04-druid-sustain.md); all1316source/760build hashes, HEAD/Git/genuine exact through482.649s full; committed source blobs checked. Real introduced rounding and incorrect replay/fixture assumptions corrected; all original failures retained. Exactly two credits:213 IDs/order,135unverified/76bounded-functional/one engine-only/one review-needed. Synthetic proof only; genuineL33/next402 unchanged/Baal uncleared. Cleanup/retention receipts accompany raw packet. Independent/earned balance, C2-C4/fullG0-G7/privatev1 remain open; root sole writer, local only, umbrella goal/worktree active. |\n'
assert len(found)==1
text=''.join(lines)
text+='''

## D04 — Feral Rage and Hunger recovery / BUG193

Runtime `7b7f3b2` and presentation `801d97f` implement the explicit provisional
actual-hit recovery/Feral-speed contract and truthful bilingual playback.
Recovery observes actual enemy HP removed after existing death/orb/reflection
settlement, with no resurrection, later drain or extra RNG. Native sanitized
authority, residual clock rebasing, next-wave changes and existing ordinary
current-configuration replay are retained; Save22 is unchanged. A real introduced
speed rounding defect was fixed without global cadence changes. Initial replay,
miss/form/cooldown/UI and browser fixture assumptions were corrected; original
sources/failures and audit filename-collision recovery remain evidence.

[Evidence](evidence/d04-druid-sustain.md):114 new cases, full13519/591/two existing
skips (482.649s), engine7027/246, types/lint/explicitfalse build/bridge PASS.
Four terminal production cases provide eight actual positive hero-recovery
attacks, eight separately audited exact five-domain Continue pairs,20 geometry
samples and16 screenshots/eight individually inspected. Browser gear is
synthetic, not earned balance. Existing mobile occlusion/icon fallback and
test/runtime budgets remain open. All1316source/760build hashes, HEAD/Git and
genuine digest stayed exact through the full run; actual committed source blobs
match. Raw byte-verification and exact cleanup receipts accompany the packet.

Exactly two inventory rows gain credit:213 IDs/order unchanged,135unverified/
76bounded-functional/one engine-only/one review-needed. These proof scopes are
not an overall completion percentage. Genuine claimed Ancients/Rite save remains
L33/XP149261/23682gear/nextNormal402/Nightmare0/Baal uncleared. C0/C1 retain narrow
acceptance; C2-C4/fullG0-G7/all-class earned builds/pacing/economy/endgame and
independent review remain open. No campaign or remote action. Root sole writer;
umbrella goal/branch/worktree continue.
'''
ledger.write_text(text)

report=dict(rows=len(after),changed=changed,idsAndOrderExact=True,counts=counts)
(p/'inventory-publication-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
