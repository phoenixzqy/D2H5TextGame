from pathlib import Path
import hashlib, json, os, socket, tarfile, datetime

p=Path(__file__).parent
assert str(p)=='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-sustain-fix-erqp85uj'
assert p.resolve()==p and not p.is_symlink()
repo=Path.cwd()
target=repo/'docs/plans/evidence/fixtures/druid-sustain'
inventory=json.loads((target/'cleanup-inventory.json').read_text())
assert inventory['root']==str(p)
manifest=json.loads((target/'manifest.json').read_text())
assert manifest['owner']=='root' and manifest['worktree']==str(repo)
assert json.loads((target/'retention-audit.json').read_text())['allBytesExact']
digest=lambda b:hashlib.sha256(b).hexdigest()
assert digest((target/'raw.tar.gz').read_bytes())==manifest['archiveSha256']
with tarfile.open(target/'raw.tar.gz','r:gz') as archive:
    members={m.name:m for m in archive.getmembers()}
    for n,v in manifest['files'].items():
        storage=v['storage']
        data=(target/storage['attachment']).read_bytes() if 'attachment' in storage else archive.extractfile(members[n]).read()
        assert len(data)==v['bytes'] and digest(data)==v['sha256'],n
assert not Path('/proc/392639').exists(), 'Owned preview still live'
with socket.socket() as s:
    assert s.connect_ex(('127.0.0.1',4479))!=0, 'Preview port still open'
actual={str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}
assert actual==set(inventory['files']), 'Uninventoried task files'
for n,v in inventory['files'].items():
    f=p/n
    assert not f.is_symlink() and f.resolve().is_relative_to(p)
    assert f.stat().st_size==v['bytes'] and digest(f.read_bytes())==v['sha256'],n
directories=sorted([f for f in p.rglob('*') if f.is_dir()],key=lambda f:len(f.parts),reverse=True)
removed=[]
failures=[]
for n in inventory['files']:
    try:
        (p/n).unlink()
        removed.append(n)
    except OSError as e: failures.append(dict(path=str(p/n),error=str(e)))
for directory in directories+[p]:
    try: directory.rmdir()
    except OSError as e: failures.append(dict(path=str(directory),error=str(e)))
remaining=[str(f) for f in p.rglob('*')] if p.exists() else []
report=dict(taskRoot=str(p),filesRemoved=len(removed),remaining=remaining,failures=failures,
    scratchAbsent=not p.exists(),ownedPreviewPid=392639,ownedPreviewAbsent=not Path('/proc/392639').exists(),
    port=4479,portClosed=True,retentionVerifiedBeforeDeletion=True,
    preserved='Source/history/umbrella worktree/shared caches/older required campaign evidence',
    finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
(target/'cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert report['scratchAbsent'] and not remaining and not failures
