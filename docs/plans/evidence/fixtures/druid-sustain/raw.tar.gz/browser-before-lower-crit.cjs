const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises'), path = require('node:path'), assert = require('node:assert/strict');
const root=path.join(__dirname,process.env.BROWSER_RUN||'browser-final'), baseURL='http://127.0.0.1:4479', report={cases:[],geometry:[],failures:[]};let serial=0;
async function nav(page,route){await page.locator(`a[href="/${route}"]`).first().click();await expect(page.getByTestId(`${route}-screen`)).toBeVisible();}
async function exported(page,label){const pending=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const download=await pending,target=path.join(root,`${label}-${++serial}.json`);await download.saveAs(target);return JSON.parse(await fs.readFile(target,'utf8'));}
function domains(save){return Object.fromEntries(['player','inventory','map','mercs','formation'].map(key=>[key,save[key]]));}
async function pair(page,context,locale,label){await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');const before=await exported(page,label+'-before');assert.equal(before.version,22);await page.close();page=await context.newPage();await page.goto(baseURL,{waitUntil:'networkidle'});await expect(page.getByTestId('home-continue')).toBeEnabled();await page.getByTestId('home-continue').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');const after=await exported(page,label+'-after');assert.deepEqual(domains(before),domains(after));return {page,save:after};}
async function geometry(page,label){const original=page.viewportSize();for(const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]){await page.mouse.move(1,1);await page.setViewportSize({width,height});const button=page.getByTestId('skill-detail-panel').getByRole('button');await button.scrollIntoViewIfNeeded();const box=await button.boundingBox();const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);assert.ok(overflow<=0);assert.ok(box&&box.width>=44&&box.height>=44);report.geometry.push({label,width,height,overflow,allocate:box});}await page.mouse.move(1,1);await page.setViewportSize(original);await page.mouse.move(1,1);}

const spells=[['feral-rage','Feral Rage','野性狂暴'],['hunger','Hunger','饥饿']];
async function fight(page,locale,label,slug){
 await nav(page,'map');await page.getByTestId('sub-area-row-a1-catacombs').getByRole('button',{name:locale==='en'?'Enter':'进入',exact:true}).click();await expect(page.getByTestId('combat-screen')).toBeVisible();
 const auto=page.getByRole('checkbox');if(await auto.isChecked())await auto.uncheck();await page.mouse.move(1,1);
 const healPattern=locale==='en'?/recovers [1-9]\d* HP/:/恢复了 [1-9]\d* 点生命/;
 await expect(page.getByTestId('combat-log')).toContainText(healPattern,{timeout:20000});
 if(slug==='feral-rage')await expect(page.getByTestId('combat-log')).toContainText(locale==='en'?'damage over time':'持续伤害',{timeout:15000});
 await page.getByRole('button',{name:locale==='en'?'Pause':'暂停',exact:true}).click();
 const log=await page.getByTestId('combat-log').innerText();assert.ok(log.includes(spells.find(s=>s[0]===slug)[locale==='en'?1:2]));assert.match(log,healPattern);
 let positive=false;
 if(slug==='feral-rage'){
   const chips=page.getByTestId('allies-grid').getByTestId('unit-effect-chips');
   const feral=chips.locator('span').filter({hasText:locale==='en'?'Feral Rage':'野性狂暴'});
   await expect(feral).toHaveCount(1);await expect(feral).toHaveClass(/text-blue-200/);positive=true;
 }
 const hp=await page.getByTestId('enemies-grid').locator('[data-testid^="unit-card-"]').evaluateAll(nodes=>nodes.map(node=>({id:node.dataset.testid,life:node.querySelector('div.bg-red-600')?.style.width,text:node.innerText})));
 assert.ok(hp.some(x=>Number.parseFloat(x.life)>0&&Number.parseFloat(x.life)<100));
 await page.screenshot({path:path.join(root,label+'-'+slug+'-combat.png'),fullPage:true});
 await fs.writeFile(path.join(root,label+'-'+slug+'-combat.json'),JSON.stringify({log,hp,positive},null,2));
 await page.getByRole('button',{name:locale==='en'?'Flee':'逃跑',exact:true}).click();await expect(page.getByTestId('map-screen')).toBeVisible();
 return {slug,actualRecoveryLog:true,positive,damagedLivingEnemy:true};
}
(async()=>{await fs.mkdir(root,{recursive:true});const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});try{
 for(const locale of ['en','zh-CN'].filter(x=>x===process.env.BROWSER_LOCALE))for(const viewport of [{width:1280,height:800},{width:360,height:640}].filter(x=>String(x.width)===process.env.BROWSER_WIDTH)){
  const label=`${locale}-${viewport.width}`,context=await browser.newContext({viewport,locale,acceptDownloads:true}),errors=[];context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));let page=await context.newPage();const result={label,errors,pairs:[],combat:[]};await context.tracing.start({screenshots:true,snapshots:true,sources:false});
  try{
   await page.goto(baseURL,{waitUntil:'networkidle'});assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');await page.getByTestId('home-new-game').click();await page.getByTestId('class-druid').click();await page.getByTestId('character-name-input').fill('SustainCheck');await page.getByTestId('character-start-btn').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();const fresh=await exported(page,label+'-fresh');
   const prerequisites={'druid.werewolf':1,'druid.lycanthropy':1,'druid.werebear':1,'druid.feral_rage':1};
   const levels={...prerequisites,...Object.fromEntries(spells.map(s=>['druid.'+s[0].replaceAll('-','_'),1]))};
   const cap={id:'synthetic-druid-sustain-browser-cap',baseId:'items/base/helm-cap',rarity:'rare',level:1,socketCapacity:0,identified:true,equipped:true,affixes:[{affixId:'fixture-imported',values:[['statMods.life',50000],['statMods.mana',50000],['statMods.attack',0],['statMods.defense',100],['statMods.attackSpeed',-80],['statMods.critChance',1],['statMods.critDamage',2]]}]};
   const constructed={...fresh,player:{...fresh.player,level:30,skillPoints:2,skillLevels:levels,comboOrder:['druid.feral_rage']},inventory:{...fresh.inventory,equipped:{helm:cap}}};
   await fs.writeFile(path.join(root,label+'-synthetic-input.json'),JSON.stringify(constructed,null,2));await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(constructed));await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();await expect(dialog).toHaveCount(0);const imported=await exported(page,label+'-imported');assert.deepEqual(imported.player.skillLevels,levels);
   let continued=await pair(page,context,locale,label+'-rank1');page=continued.page;result.pairs.push('rank1');
   for(const [slug,en,zh] of spells){
    await nav(page,'skills');await page.mouse.move(1,1);await page.getByTestId('skill-node-skills-druid-'+slug).click();const panel=page.getByTestId('skill-detail-panel');await expect(panel.getByRole('heading',{level:2})).toHaveText(locale==='en'?en:zh);await expect(panel).toContainText(locale==='en'?'rounded down':'向下取整');await expect(panel).toContainText(locale==='en'?(slug==='feral-rage'?'10% of actual direct HP removed':'50% of actual direct HP removed'):(slug==='feral-rage'?'10%的直接实际生命损失':'50%的直接实际生命损失'));
    await expect(panel).toContainText(locale==='en'?'any form':'任何形态');await expect(panel).not.toContainText('{{');
    if(slug==='feral-rage')await geometry(page,label);
    await panel.getByRole('button').click();await page.mouse.move(1,1);await panel.scrollIntoViewIfNeeded();
    await page.screenshot({path:path.join(root,label+'-'+slug+'-details.png')});
    await page.getByRole('tab',{name:locale==='en'?'Active Skills':'主动技能',exact:true}).click();
    await page.getByTestId('skills-active-panel').getByRole('combobox').first().selectOption({label:locale==='en'?en:zh});
    result.combat.push(await fight(page,locale,label,slug));
   }
   continued=await pair(page,context,locale,label+'-rank2');page=continued.page;result.pairs.push('rank2');assert.equal(continued.save.player.skillPoints,0);assert.deepEqual(continued.save.player.skillLevels,{...prerequisites,...Object.fromEntries(spells.map(s=>['druid.'+s[0].replaceAll('-','_'),2]))});assert.deepEqual(continued.save.player.comboOrder,['skills-druid-hunger']);assert.deepEqual(errors,[]);result.pass=true;await context.tracing.stop();console.log(label+' PASS');
  }catch(error){result.pass=false;result.error=String(error.stack||error);report.failures.push(label);await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});throw error;}finally{report.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(report,null,2));await context.close();}
 }
 }finally{await browser.close();}assert.equal(report.cases.length,1);assert.deepEqual(report.failures,[]);console.log('1 final browser case / 2 real recovery attack entries pass.');})().catch(error=>{console.error(error);process.exitCode=1;});
