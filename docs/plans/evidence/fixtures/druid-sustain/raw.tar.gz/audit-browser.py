from pathlib import Path
import json,re
p=Path(__file__).parent
cases=[];pairs=[];geometry=[]
for locale in ['en','zh-CN']:
 for width in [1280,360]:
  label=f'{locale}-{width}'; d=p/f'browser-verified-{label}'
  receipt=json.loads((p/f'browser-verified-{label}.json').read_text());assert receipt['exit']==0
  report=json.loads((d/'browser-report.json').read_text());assert not report['failures']
  assert len(report['cases'])==1
  c=report['cases'][0];assert c['pass'] and not c['errors'] and c['pairs']==['rank1','rank2']
  assert len(c['combat'])==2 and all(x['actualRecoveryLog'] and x['damagedLivingEnemy'] for x in c['combat'])
  assert c['combat'][0]['positive'] is True
  for attack in ['feral-rage','hunger']:
   combat=json.loads((d/f'{label}-{attack}-combat.json').read_text())
   pattern=r'SustainCheck recovers ([1-9]\d*) HP\.' if locale=='en' else r'SustainCheck 恢复了 ([1-9]\d*) 点生命。'
   amounts=[int(n) for n in re.findall(pattern,combat['log'])];assert amounts,(label,attack)
   assert 'feral-rage' not in combat['log']
   combat['verifiedHeroRecoveryAmounts']=amounts
   c['combat'][0 if attack=='feral-rage' else 1]['verifiedHeroRecoveryAmounts']=amounts
  for rank in [1,2]:
   before=list(d.glob(f'{label}-rank{rank}-before-*.json'));after=list(d.glob(f'{label}-rank{rank}-after-*.json'))
   assert len(before)==len(after)==1
   a=json.loads(before[0].read_text());b=json.loads(after[0].read_text())
   assert a['version']==b['version']==22
   for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==b[domain],(label,rank,domain)
   for skill in ['druid.feral_rage','druid.hunger']:assert b['player']['skillLevels'][skill]==rank
   assert not re.search(r'feralRage|expiresAtMs',json.dumps(b))
   pairs.append({'label':label,'rank':rank,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
  assert len(report['geometry'])==5
  for g in report['geometry']:assert g['overflow']==0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
  geometry.extend(report['geometry']);cases.append(c)
assert len(pairs)==8 and len(geometry)==20
out=dict(cases=cases,pairs=pairs,geometry=geometry,syntheticScope='Imported L30/learned prerequisites/resources/slow speed/guaranteed critical gear; actual public allocation and native combat. No earned campaign proof.',limitations=['Existing mobile nested scrolling/header/nav occlusion','Existing font/icon fallback','No independent design or QA acceptance','No earned balance/pacing/endgame/PWA/performance/a11y acceptance'])
(p/'browser-attachment-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('PASS: 4 terminal browser cases, 8 attacks with positive actual recovery, 8 exact five-domain Continue pairs, 20 geometry samples.')
