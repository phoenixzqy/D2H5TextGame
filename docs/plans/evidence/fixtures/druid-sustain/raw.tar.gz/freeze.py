from pathlib import Path
import hashlib,gzip,subprocess,json,sys
p=Path(__file__).parent
repo=Path.cwd()
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def current():
 names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines()
 source={n:digest(repo/n) for n in names if (n.startswith(('src/','tests/','scripts/')) or '/' not in n and n.endswith(('.json','.ts','.js','.mjs','.cjs','.yml'))) and (repo/n).is_file()}
 build={str(f.relative_to(p/'production')):digest(f) for f in (p/'production').rglob('*') if f.is_file()}
 genuine=hashlib.sha256(gzip.decompress((repo/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
 return dict(source=source,build=build,genuine=genuine,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','status','--porcelain=v1'],text=True))
r=current()
if sys.argv[1]=='before':
 assert not (p/'frozen-before.json').exists()
 (p/'frozen-before.json').write_text(json.dumps(r,indent=2)+'\n')
else:
 before=json.loads((p/'frozen-before.json').read_text())
 assert before==r,'Frozen source/build/genuine/HEAD/status changed'
 (p/'frozen-after.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(sourceCount=len(r['source']),buildCount=len(r['build']),genuine=r['genuine'],head=r['head'],mode=sys.argv[1])))
