from pathlib import Path
import json,hashlib,tarfile,shutil
p=Path(__file__).parent
assert p.resolve()==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-control-ekpj8kx6')
d=Path.cwd()/'docs/plans/evidence/fixtures/paladin-control'
assert not d.exists();d.mkdir()
receipts={}
for f in sorted(p.glob('*.json')):
 v=json.loads(f.read_text())
 if isinstance(v,dict) and all(k in v for k in ['argv','cwd','exit','seconds','finished']):receipts[f.stem]=v
assert receipts['frozen-full']['exit']==receipts['corrected-final-lint']['exit']==receipts['corrected-types']['exit']==0
assert json.loads((p/'post-full-freeze-audit.json').read_text())['all_exact']
assert json.loads((p/'committed-source-audit.json').read_text())['all_exact']
(p/'terminal-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
files=sorted(f for f in p.rglob('*') if f.is_file())
assert not any(f.is_symlink() for f in p.rglob('*'))
owned=[str(f.relative_to(p)) for f in files]+['cleanup-inventory.json']
(p/'cleanup-inventory.json').write_text(json.dumps({'root':str(p),'exact_files':sorted(owned),'build_files_omitted_from_archive':760},indent=2)+'\n')
files=sorted(f for f in p.rglob('*') if f.is_file() and 'production-dist' not in f.relative_to(p).parts)
manifest={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
with tarfile.open(d/'raw.tar.gz','w:gz') as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
with tarfile.open(d/'raw.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for m in members:
  assert m.isfile() and m.name in manifest
  assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==manifest[m.name]
for name in ['post-full-freeze-audit.json','committed-source-audit.json','browser-evidence-audit.json','build-audit.json','author-review.json','visual-inspection.json','terminal-receipts.json','cleanup-inventory.json','inventory-reconciliation.json']:
 shutil.copyfile(p/name,d/name)
for a,b in [('browser-en-360/en-360-zeal-details.png','paladin-control-en-mobile.png'),('browser-zh-CN-360/zh-CN-360-charge-details.png','paladin-control-zh-CN-mobile.png')]:shutil.copyfile(p/a,d/b)
packet={'task':'BUG198 Paladin target/control attacks','sole_writer':'root','synthetic_functional_proof_only':True,'raw_files':len(manifest),'raw_members':manifest,'raw_archive_sha256':hashlib.sha256((d/'raw.tar.gz').read_bytes()).hexdigest(),'all_raw_members_byte_verified':True,'terminal_receipts':len(receipts),'source_files':1352,'omitted_build_files':760,'build_map':'raw.tar.gz:frozen-inputs.json#build','scratch_root':str(p),'cleanup_receipt':'cleanup.json','full_v1_complete':False,'independent_acceptance':False}
(d/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'destination':str(d),'raw_files':len(manifest),'terminal_receipts':len(receipts),'all_byte_verified':True}))
