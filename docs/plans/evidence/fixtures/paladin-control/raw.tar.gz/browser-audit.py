from pathlib import Path
import json,re,socket,os,hashlib
p=Path(__file__).parent
cases=[];pairs=[];geometry=[];screens=[]
spells=['zeal','smite','charge','fist-of-heavens']
prereqs={'paladin.sacrifice':1,'paladin.holy_bolt':1,'paladin.blessed_hammer':1}
def domains(s):return {k:s[k] for k in ['player','inventory','map','mercs','formation']}
for locale,width in [('en',1280),('en',360),('zh-CN',1280),('zh-CN',360)]:
 label=locale+'-'+str(width);d=p/('browser-'+label)
 report=json.loads((d/'browser-report.json').read_text());assert not report['failures']
 assert len(report['cases'])==1
 c=report['cases'][0];assert c['pass'] and c['errors']==[] and c['pairs']==['rank1','rank2']
 assert [e['slug'] for e in c['combat']]==spells
 for e in c['combat']:
  slug=e['slug'];assert e['log'] and e['units']
  if slug=='zeal':assert len(e['firstCompleteCastAttempts'])==3
  else:
   status={'en':{'stun':'Stun','paralyze':'Paralyze'},'zh-CN':{'stun':'眩晕','paralyze':'麻痹'}}[locale]['paralyze' if slug=='fist-of-heavens' else 'stun']
   assert any(status in line for line in e['log']),(label,slug,status)
  assert any('PaladinCheck' in line and re.search(r'for [1-9]\d* |造成 [1-9]\d* 点',line) for line in e['log'])
  detail=(d/(label+'-'+slug+'-details.txt')).read_text();assert not any(t in detail for t in ['{{','undefined','NaN','details.'])
  for kind in ['combat','details']:
   f=d/(label+'-'+slug+'-'+kind+'.png');assert f.is_file();screens.append({'file':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 for key,rank,points,combo in [('rank1',1,4,'paladin.zeal'),('rank2',2,0,'skills-paladin-fist-of-heavens')]:
  before=list(d.glob(label+'-'+key+'-before-*.json'));after=list(d.glob(label+'-'+key+'-after-*.json'));assert len(before)==len(after)==1
  a=json.loads(before[0].read_text());b=json.loads(after[0].read_text());assert a['version']==b['version']==22;assert domains(a)==domains(b)
  assert b['player']['skillPoints']==points
  assert b['player']['skillLevels']=={**prereqs,**{'paladin.'+s.replace('-','_'):rank for s in spells}}
  assert b['player']['comboOrder']==[combo]
  pairs.append({'label':label,'rank':rank,'domains_exact':list(domains(a))})
 assert len(report['geometry'])==20
 for g in report['geometry']:assert g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
 geometry.extend(report['geometry'])
 owner=json.loads((p/('browser-'+label+'-server-owner.json')).read_text());assert not Path('/proc/'+str(owner['pid'])).exists()
 cases.append({'label':label,'pass':True,'positive_attacks':4,'zeal_complete_cast_attempts':3})
s=socket.socket();assert s.connect_ex(('127.0.0.1',4484))!=0;s.close()
r={'cases':cases,'pairs':pairs,'geometry_samples':len(geometry),'screenshots':screens,'page_errors':[],'owned_preview_pids_absent':True,'port4484_closed':True,'synthetic_fixture':True,'earned_acceptance':False}
f=p/'browser-evidence-audit.json';assert not f.exists();f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
