from pathlib import Path
import json,hashlib,subprocess,gzip
p=Path(__file__).parent;wd=Path.cwd();frozen=json.loads((p/'frozen-inputs.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();assert head.startswith('ed37092')
process=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for name,expected in frozen['source'].items():
 process.stdin.write(('HEAD:'+name+'\n').encode());process.stdin.flush()
 header=process.stdout.readline().decode().split();assert len(header)==3 and header[1]=='blob',name
 data=process.stdout.read(int(header[2]));assert process.stdout.read(1)==b'\n'
 assert hashlib.sha256(data).hexdigest()==expected,name
 assert hashlib.sha256((wd/name).read_bytes()).hexdigest()==expected,name
process.stdin.close();assert process.wait()==0
for name,expected in frozen['build'].items():assert hashlib.sha256((p/'production-dist'/name).read_bytes()).hexdigest()==expected,name
genuine=hashlib.sha256(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest();assert genuine==frozen['genuine']
r={'head':head,'runtime_commit':'e2ea27c','presentation_commit':'ed37092','source_files':len(frozen['source']),'build_files':len(frozen['build']),'genuine':genuine,'all_actual_committed_blobs_and_disk_exact':True,'all_exact':True,'mismatches':[]}
f=p/'committed-source-audit.json';assert not f.exists();f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
