const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises'), path = require('node:path'), assert = require('node:assert/strict');
const en = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/i18n/locales/en/skills.json');
const zh = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/i18n/locales/zh-CN/skills.json');
const enCombat = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/i18n/locales/en/combat.json');
const zhCombat = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/i18n/locales/zh-CN/combat.json');
const root=path.join(__dirname,process.env.BROWSER_RUN),baseURL='http://127.0.0.1:4484',report={cases:[],geometry:[],failures:[]};let serial=0;
const spells=['zeal','smite','charge','fist-of-heavens'];
async function nav(page,route){await page.locator('a[href="/'+route+'"]').first().click();await expect(page.getByTestId(route+'-screen')).toBeVisible();}
async function exported(page,label){const pending=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const download=await pending,target=path.join(root,label+'-'+(++serial)+'.json');await download.saveAs(target);return JSON.parse(await fs.readFile(target,'utf8'));}
function domains(save){return Object.fromEntries(['player','inventory','map','mercs','formation'].map(key=>[key,save[key]]));}
async function pair(page,context,locale,label){await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');const before=await exported(page,label+'-before');assert.equal(before.version,22);await page.close();page=await context.newPage();await page.goto(baseURL,{waitUntil:'networkidle'});await expect(page.getByTestId('home-continue')).toBeEnabled();await page.getByTestId('home-continue').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');const after=await exported(page,label+'-after');assert.deepEqual(domains(before),domains(after));return {page,save:after};}
async function geometry(page,label){const original=page.viewportSize();for(const [width,height]of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]){await page.mouse.move(1,1);await page.setViewportSize({width,height});const button=page.getByTestId('skill-detail-panel').getByRole('button');await button.scrollIntoViewIfNeeded();const box=await button.boundingBox();const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);assert.ok(overflow<=0);assert.ok(box&&box.width>=44&&box.height>=44);report.geometry.push({label,width,height,overflow,allocate:box});}await page.setViewportSize(original);await page.mouse.move(1,1);}
async function messages(page){return page.getByTestId('combat-log').locator(':scope > div > span:last-child').allTextContents();}
async function fight(page,locale,label,slug){
  const english=locale==='en',copy=english?enCombat:zhCombat,name=(english?en:zh).paladin[slug].name;
  await nav(page,'map');await page.getByTestId('sub-area-row-a1-blood-moor').getByRole('button',{name:english?'Enter':'进入',exact:true}).click();await expect(page.getByTestId('combat-screen')).toBeVisible();
  const auto=page.getByRole('checkbox');if(await auto.isChecked())await auto.uncheck();
  const cast=m=>m.includes('PaladinCheck')&&m.includes(name)&&m.includes(english?'casts':'施放了');
  const outgoing=m=>m.includes('PaladinCheck')&&(english?/PaladinCheck (attacks|hits) /.test(m):/PaladinCheck (普攻|对) /.test(m))||m.includes(english?"dodges PaladinCheck's":"闪避了 PaladinCheck");
  await expect.poll(async()=>(await messages(page)).filter(cast).length,{timeout:20000}).toBeGreaterThanOrEqual(slug==='zeal'?2:1);
  const type=slug==='fist-of-heavens'?'lightning':'physical';
  await expect.poll(async()=>(await messages(page)).some(m=>m.includes('PaladinCheck')&&m.includes(copy.damageType[type])&&(english?/for [1-9]\d* /.test(m):/造成 [1-9]\d* 点/.test(m))),{timeout:20000}).toBe(true);
  if(slug!=='zeal')await expect(page.getByTestId('combat-log')).toContainText(copy.effect.status[slug==='fist-of-heavens'?'paralyze':'stun'],{timeout:20000});
  await page.getByRole('button',{name:english?'Pause':'暂停',exact:true}).click();
  const lines=await messages(page),indices=lines.flatMap((m,i)=>cast(m)?[i]:[]);
  const firstCast=slug==='zeal'?lines.slice(indices[0]+1,indices[1]).filter(outgoing):[];
  if(slug==='zeal')assert.equal(firstCast.length,3,JSON.stringify({firstCast,lines}));
  const entry={slug,name,log:lines,firstCompleteCastAttempts:firstCast,units:await page.locator('[data-testid^="unit-card-"]').evaluateAll(nodes=>nodes.map(n=>({id:n.dataset.testid,text:n.innerText}))),mana:await page.locator('[data-testid="combat-screen"] [role="progressbar"]:not([aria-label])').getAttribute('aria-valuenow')};
  await fs.writeFile(path.join(root,label+'-'+slug+'-combat.json'),JSON.stringify(entry,null,2));await page.screenshot({path:path.join(root,label+'-'+slug+'-combat.png'),fullPage:true});
  await page.getByRole('button',{name:english?'Flee':'逃跑',exact:true}).click();await expect(page.getByTestId('map-screen')).toBeVisible();return entry;
}
(async()=>{await fs.mkdir(root,{recursive:true});const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});try{
  const locale=process.env.BROWSER_LOCALE,english=locale==='en',viewport={width:Number(process.env.BROWSER_WIDTH),height:process.env.BROWSER_WIDTH==='360'?640:800},label=locale+'-'+viewport.width;
  const context=await browser.newContext({viewport,locale,acceptDownloads:true}),errors=[];context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));let page=await context.newPage();const result={label,errors,pairs:[],combat:[]};await context.tracing.start({screenshots:true,snapshots:false,sources:false});
  try{
    await page.goto(baseURL,{waitUntil:'networkidle'});assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');await page.getByTestId('home-new-game').click();await page.getByTestId('class-paladin').click();await page.getByTestId('character-name-input').fill('PaladinCheck');await page.getByTestId('character-start-btn').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');await page.getByRole('button',{name:english?'English':'简体中文',exact:true}).click();const fresh=await exported(page,label+'-fresh');
    const prerequisites={'paladin.sacrifice':1,'paladin.holy_bolt':1,'paladin.blessed_hammer':1},levels={...prerequisites,...Object.fromEntries(spells.map(s=>['paladin.'+s.replaceAll('-','_'),1]))};
    const cap={id:'synthetic-paladin-browser-cap',baseId:'items/base/helm-cap',rarity:'rare',level:1,socketCapacity:0,identified:true,equipped:true,affixes:[{affixId:'fixture-imported',values:[['statMods.life',50000],['statMods.mana',50000],['statMods.attackSpeed',-80]]}]};
    const constructed={...fresh,player:{...fresh.player,level:30,skillPoints:4,skillLevels:levels,comboOrder:['paladin.zeal']},inventory:{...fresh.inventory,equipped:{helm:cap}}};
    await fs.writeFile(path.join(root,label+'-synthetic-input.json'),JSON.stringify(constructed,null,2));await page.getByRole('button',{name:english?'Import Save':'导入存档',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(constructed));await dialog.getByRole('button',{name:english?'Import Save':'导入存档',exact:true}).click();await expect(dialog).toHaveCount(0);const imported=await exported(page,label+'-imported');assert.deepEqual(imported.player.skillLevels,levels);
    let continued=await pair(page,context,locale,label+'-rank1');page=continued.page;result.pairs.push('rank1');
    for(const slug of spells){
      const name=(english?en:zh).paladin[slug].name;
      await nav(page,'skills');await page.mouse.move(1,1);await page.getByTestId('skill-node-skills-paladin-'+slug).click();const panel=page.getByTestId('skill-detail-panel');await expect(panel.getByRole('heading',{level:2})).toHaveText(name);await expect(panel).not.toContainText('{{');
      if(slug==='zeal'){await expect(panel).toContainText(english?'Max targets':'目标上限');await expect(panel).toContainText(english?'up to 3':'最多 3');}
      else{await expect(panel).toContainText(english?'Misses apply no':'未命中不附加');await expect(panel).toContainText(english?'1 s':'1 秒');if(slug==='charge')await expect(panel).toContainText(english?'position stays the same':'位置不变');}
      await geometry(page,label+'-'+slug);
      await panel.getByRole('button').click();await page.mouse.move(1,1);await panel.scrollIntoViewIfNeeded();await fs.writeFile(path.join(root,label+'-'+slug+'-details.txt'),await panel.innerText());await page.screenshot({path:path.join(root,label+'-'+slug+'-details.png')});
      await page.getByRole('tab',{name:english?'Active Skills':'主动技能',exact:true}).click();await page.getByTestId('skills-active-panel').getByRole('combobox').first().selectOption({label:name});
      result.combat.push(await fight(page,locale,label,slug));
    }
    continued=await pair(page,context,locale,label+'-rank2');page=continued.page;result.pairs.push('rank2');assert.equal(continued.save.player.skillPoints,0);assert.deepEqual(continued.save.player.skillLevels,{...prerequisites,...Object.fromEntries(spells.map(s=>['paladin.'+s.replaceAll('-','_'),2]))});assert.deepEqual(continued.save.player.comboOrder,['skills-paladin-fist-of-heavens']);assert.deepEqual(errors,[]);result.pass=true;await context.tracing.stop();console.log(label+' PASS');
  }catch(error){result.pass=false;result.error=String(error.stack||error);report.failures.push(label);await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});throw error;}finally{report.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(report,null,2));await context.close();}
}finally{await browser.close();}assert.deepEqual(report.failures,[]);console.log('Four actual Paladin attacks, exact Zeal cast cardinality, public allocations and two exact five-domain Continue pairs pass.');})().catch(error=>{console.error(error);process.exitCode=1;});
