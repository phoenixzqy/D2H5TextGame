from pathlib import Path
import json,hashlib,sys
raw=Path(__file__).resolve().parent
worktree=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd().resolve()==worktree
assert json.loads((raw/'ownership.json').read_text())['distInitiallyAbsent'] is True
out=raw/(sys.argv[1]+'.json');assert not out.exists()
target=worktree/'dist';assert target.is_dir() and not target.is_symlink()
paths=list(target.rglob('*'));assert all(not p.is_symlink() and (p.is_file() or p.is_dir()) for p in paths)
files=[p for p in paths if p.is_file()]
record={'path':str(target),'owner':'root','readers':'all released; prior command finished','records':[{'path':str(p.relative_to(target)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]}
for p in files:p.unlink()
for p in sorted((p for p in paths if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.rmdir()
target.rmdir();assert not target.exists();record['absenceVerified']=True
out.write_text(json.dumps(record,indent=2)+'\n')
print('Removed exact task-owned dist:',len(files),'files; absence verified')
