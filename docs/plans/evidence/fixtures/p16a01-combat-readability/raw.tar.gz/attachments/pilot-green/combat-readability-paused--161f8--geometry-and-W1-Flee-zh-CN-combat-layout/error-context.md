# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: combat-readability.spec.ts >> paused responsive geometry and W1 Flee zh-CN
- Location: tests/pwa/combat-readability.spec.ts:109:3

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 785
Received:    784.9650268554688
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 903
Received:    902.8306274414062
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 167
Received:    166.75306701660156
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 287
Received:    286.762451171875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 287
Received:    286.8009948730469
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 215.671875
Received:    215.63687133789062
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 411.796875
Received:    411.6274719238281
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "主导航" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "营地" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: 营地
        - listitem [ref=e10]:
          - link "地图" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: 地图
        - listitem [ref=e14]:
          - link "战斗" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: 战斗
        - listitem [ref=e18]:
          - link "背包" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: 背包
        - listitem [ref=e22]:
          - link "技能" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: 技能
        - listitem [ref=e26]:
          - link "佣兵" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: 佣兵
        - listitem [ref=e30]:
          - link "任务" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: 任务
        - listitem [ref=e34]:
          - link "设置" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: 设置
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]: 世界地图
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - button "第 1 章 · 第一幕 — 失明之眼" [expanded] [ref=e44] [cursor=pointer]:
              - generic [ref=e46]: 第 1 章 · 第一幕 — 失明之眼
              - generic [ref=e48]: ▾
            - list [ref=e49]:
              - listitem [ref=e50]:
                - generic [ref=e52]:
                  - generic [ref=e53]:
                    - generic [ref=e54]: 血腥旷野
                    - generic [ref=e55]: 未通过
                  - generic [ref=e56]: "推荐等级: 2 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e57]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e58]: 🔒 在此挂机
                  - button "进入" [ref=e59] [cursor=pointer]
              - listitem [ref=e60]:
                - generic [ref=e62]:
                  - generic [ref=e63]:
                    - generic [ref=e64]: 邪恶巢穴
                    - generic [ref=e65]: 未通过
                  - generic [ref=e66]: "推荐等级: 3 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e67]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e68]: 🔒 在此挂机
                  - button "进入" [ref=e69] [cursor=pointer]
              - listitem [ref=e70]:
                - generic [ref=e72]:
                  - generic [ref=e73]:
                    - generic [ref=e74]: 冰冷平原
                    - generic [ref=e75]: 未通过
                  - generic [ref=e76]: "推荐等级: 5 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e77]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e78]: 🔒 在此挂机
                  - button "进入" [ref=e79] [cursor=pointer]
              - listitem [ref=e80]:
                - generic [ref=e82]:
                  - generic [ref=e83]:
                    - generic [ref=e84]: 墓地
                    - generic [ref=e85]: 未通过
                  - generic [ref=e86]: "推荐等级: 7 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e87]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e88]: 🔒 在此挂机
                  - button "进入" [ref=e89] [cursor=pointer]
              - listitem [ref=e90]:
                - generic [ref=e92]:
                  - generic [ref=e93]:
                    - generic [ref=e94]: 黑色森林
                    - generic [ref=e95]: 未通过
                    - generic [ref=e96]: 构筑检查
                  - generic [ref=e97]: "推荐等级: 9 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e98]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e99]: 🔒 在此挂机
                  - button "进入" [ref=e100] [cursor=pointer]
              - listitem [ref=e101]:
                - generic [ref=e103]:
                  - generic [ref=e104]:
                    - generic [ref=e105]: 地下墓穴 (安达利尔)
                    - generic [ref=e106]: 未通过
                    - generic "安达莉尔" [ref=e107]: 首领
                    - generic [ref=e108]: 章节决战
                  - generic [ref=e109]: "推荐等级: 12 · 挑战循环：每波 8–20 只怪物"
                - generic [ref=e110]:
                  - button "请先通关此区域以解锁挂机" [disabled] [ref=e111]: 🔒 在此挂机
                  - button "进入" [ref=e112] [cursor=pointer]
          - button "第 2 章 · 第二幕 — 维兹杰雷的秘密 击败 安达莉尔 以解锁第 2 章" [ref=e114] [cursor=pointer]:
            - generic [ref=e116]: 第 2 章 · 第二幕 — 维兹杰雷的秘密
            - generic [ref=e117]:
              - generic "击败 安达莉尔 以解锁第 2 章" [ref=e118]: 🔒 锁定
              - generic [ref=e119]: ▸
          - button "第 3 章 · 第三幕 — 地狱之门 击败 督瑞尔 以解锁第 3 章" [ref=e121] [cursor=pointer]:
            - generic [ref=e123]: 第 3 章 · 第三幕 — 地狱之门
            - generic [ref=e124]:
              - generic "击败 督瑞尔 以解锁第 3 章" [ref=e125]: 🔒 锁定
              - generic [ref=e126]: ▸
          - button "第 4 章 · 第四幕 — 折磨 击败 墨菲斯托 以解锁第 4 章" [ref=e128] [cursor=pointer]:
            - generic [ref=e130]: 第 4 章 · 第四幕 — 折磨
            - generic [ref=e131]:
              - generic "击败 墨菲斯托 以解锁第 4 章" [ref=e132]: 🔒 锁定
              - generic [ref=e133]: ▸
          - button "第 5 章 · 第五幕 — 毁灭之王 击败 迪亚波罗 以解锁第 5 章" [ref=e135] [cursor=pointer]:
            - generic [ref=e137]: 第 5 章 · 第五幕 — 毁灭之王
            - generic [ref=e138]:
              - generic "击败 迪亚波罗 以解锁第 5 章" [ref=e139]: 🔒 锁定
              - generic [ref=e140]: ▸
        - status [ref=e141]:
          - generic [ref=e142]: 选择已通关地图开始挂机刷图
  - button "ReadabilityProof · 等级 1。点击查看角色面板。" [ref=e143] [cursor=pointer]:
    - generic [ref=e145]: "1"
    - generic [ref=e146]:
      - generic [ref=e147]:
        - generic [ref=e148]: ReadabilityProof
        - generic [ref=e149]: 等级 1
      - generic [ref=e150]:
        - generic [ref=e151]: HP
        - progressbar "HP" [ref=e152]
      - generic [ref=e154]:
        - generic [ref=e155]: MP
        - progressbar "MP" [ref=e156]
      - generic [ref=e158]:
        - generic [ref=e159]: XP
        - progressbar "XP" [ref=e160]
```

# Test source

```ts
  96  |           if (/(hidden|clip)/.test(`${s.overflowX} ${s.overflowY}`)) clippingAncestors.push(rect(node));
  97  |         }
  98  |         const badge = outer.querySelector('[data-testid="combat-event-fx"]');
  99  |         return { id: outer.dataset.testid, name: name.textContent, card: rect(card), hp: rect(hp), lines,
  100 |           font: Number.parseFloat(style.fontSize), lineHeight: Number.parseFloat(style.lineHeight),
  101 |           whiteSpace: style.whiteSpace, ellipsis: style.textOverflow, clippingAncestors,
  102 |           image: rect(card.children[0]!), badge: badge ? rect(badge) : null };
  103 |       })
  104 |     };
  105 |   });
  106 | }
  107 | 
  108 | for (const locale of ['en', 'zh-CN'] as const) {
  109 |   test(`paused responsive geometry and W1 Flee ${locale}`, async ({ page }, info) => {
  110 |     const english = locale === 'en';
  111 |     const errors: string[] = [];
  112 |     page.on('pageerror', error => errors.push(error.message));
  113 |     page.on('console', message => { if (['error', 'warning'].includes(message.type())) errors.push(message.text()); });
  114 |     await enter(page, english);
  115 |     await expect(page.getByTestId('combat-event-fx').first()).toBeVisible({ timeout: 15_000 });
  116 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  117 |     await expect(page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true })).toHaveAttribute('aria-pressed', 'true');
  118 |     const before = await visibleState(page);
  119 |     expect(before.wave).toMatch(english ? /^Wave 1 / : /^第 1 波/);
  120 |     expect(before.cells).toHaveLength(18);
  121 |     expect(before.cells.flatMap(cell => cell.cards)).toHaveLength(10);
  122 |     expect(before.cells.flatMap(cell => cell.cards).some(card => card.feedback)).toBe(true);
  123 |     if (!english) {
  124 |       const cdp = await page.context().newCDPSession(page);
  125 |       try {
  126 |         await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  127 |         const document = await cdp.send('DOM.getDocument');
  128 |         const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId, selector: '[data-testid="combat-sub-area-name"]' });
  129 |         const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  130 |         await attach(info, 'actual-cjk-platform-fonts', fonts);
  131 |         expect(fonts.fonts.some(font => /WenQuanYi|WQY/i.test(font.familyName) && font.glyphCount > 0)).toBe(true);
  132 |       } finally { await cdp.detach(); }
  133 |     }
  134 |     const saved = await stored(page);
  135 |     const samples = [];
  136 |     for (const [width, height] of sizes) {
  137 |       await page.setViewportSize({ width, height });
  138 |       const g = await geometry(page); samples.push(g);
  139 |       expect.soft(g.overflow, `${width}: no horizontal overflow`).toEqual({ document: 0, main: 0 });
  140 |       expect.soft(g.main.height, `${width}: usable scrollport`).toBeGreaterThanOrEqual(120);
  141 |       expect.soft(g.columns).toEqual([3, 3]);
  142 |       for (const cell of g.cells) {
  143 |         expect.soft(cell.minimum).toBe(width < 1024 ? 112 : 168);
  144 |         expect.soft(cell.rect.height).toBeGreaterThanOrEqual(width < 1024 ? 112 : 168);
  145 |         if (cell.emptyMinimum !== null) expect.soft(cell.emptyMinimum).toBe(width < 1024 ? 0 : 152);
  146 |       }
  147 |       if (width < 1024) expect.soft(g.metadata.bottom).toBeLessThanOrEqual(Math.min(...g.controls.map(control => control.top)));
  148 |       if (width < 1024) {
  149 |         expect.soft(g.allies.bottom).toBeLessThanOrEqual(g.separator.top);
  150 |         expect.soft(g.separator.bottom).toBeLessThanOrEqual(g.enemies.top);
  151 |         expect.soft(g.separator.height).toBeGreaterThanOrEqual(40);
  152 |         expect.soft(g.separator.height).toBeLessThanOrEqual(48);
  153 |       } else {
  154 |         expect.soft(g.allies.right).toBeLessThanOrEqual(g.separator.left);
  155 |         expect.soft(g.separator.right).toBeLessThanOrEqual(g.enemies.left);
  156 |         expect.soft(g.separator.height).toBeGreaterThanOrEqual(288);
  157 |       }
  158 |       for (const control of g.controls) {
  159 |         expect.soft(control.width).toBeGreaterThanOrEqual(44);
  160 |         expect.soft(control.height).toBeGreaterThanOrEqual(44);
  161 |         expect.soft(control.left).toBeGreaterThanOrEqual(0);
  162 |         expect.soft(control.right).toBeLessThanOrEqual(width);
  163 |       }
  164 |       for (let i = 0; i < g.controls.length; i++) for (const other of g.controls.slice(i + 1)) {
  165 |         const c = g.controls[i]!;
  166 |         expect.soft(c.right + 7.9 <= other.left || other.right + 7.9 <= c.left ||
  167 |           c.bottom + 7.9 <= other.top || other.bottom + 7.9 <= c.top, 'toolbar target spacing').toBe(true);
  168 |       }
  169 |       for (const c of g.cards) {
  170 |         if (width < 1024) {
  171 |           expect.soft(c.card.width).toBeGreaterThanOrEqual(width === 360 ? 84 : width === 412 ? 100 : 80);
  172 |           expect.soft(c.font).toBeGreaterThanOrEqual(14);
  173 |           expect.soft(c.lineHeight).toBeGreaterThanOrEqual(18);
  174 |           expect.soft(c.whiteSpace).not.toBe('nowrap');
  175 |           expect.soft(c.ellipsis).not.toBe('ellipsis');
  176 |           expect.soft(c.hp.height).toBeGreaterThanOrEqual(6);
  177 |           expect.soft(c.image.height).toBe(64);
  178 |           if (width === 360 && c.name === heroName) expect.soft(c.lines.length).toBeGreaterThanOrEqual(2);
  179 |           for (const line of c.lines) for (const ancestor of [c.card, ...c.clippingAncestors]) {
  180 |             expect.soft(line.left).toBeGreaterThanOrEqual(ancestor.left - 1);
  181 |             expect.soft(line.right).toBeLessThanOrEqual(ancestor.right + 1);
  182 |             expect.soft(line.top).toBeGreaterThanOrEqual(ancestor.top - 1);
  183 |             expect.soft(line.bottom).toBeLessThanOrEqual(ancestor.bottom + 1);
  184 |           }
  185 |         } else {
  186 |           expect.soft(c.font).toBe(10);
  187 |           expect.soft(c.hp.height).toBe(4);
  188 |         }
  189 |         expect.soft(c.hp.left).toBeGreaterThanOrEqual(c.card.left - 1);
  190 |         expect.soft(c.hp.right).toBeLessThanOrEqual(c.card.right + 1);
  191 |         expect.soft(c.hp.top).toBeGreaterThanOrEqual(c.card.top - 1);
  192 |         expect.soft(c.hp.bottom).toBeLessThanOrEqual(c.card.bottom + 1);
  193 |         if (c.badge) {
  194 |           expect.soft(c.badge.left).toBeGreaterThanOrEqual(c.card.left - 1);
  195 |           expect.soft(c.badge.right).toBeLessThanOrEqual(c.card.right + 1);
> 196 |           expect.soft(c.badge.top).toBeGreaterThanOrEqual(c.card.top - 1);
      |                                    ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  197 |           expect.soft(c.badge.bottom).toBeLessThanOrEqual(c.card.bottom + 1);
  198 |         }
  199 |       }
  200 |       // Ordinary scrolling must reveal complete name+HP for each team and the log.
  201 |       for (const side of ['allies', 'enemies']) {
  202 |         const card = page.getByTestId(`${side}-grid`).locator('[title]').first();
  203 |         await card.scrollIntoViewIfNeeded();
  204 |         const r = await card.boundingBox(); const m = await page.locator('main').boundingBox();
  205 |         expect.soft(r!.y).toBeGreaterThanOrEqual(m!.y - 1);
  206 |         expect.soft(r!.y + r!.height).toBeLessThanOrEqual(m!.y + m!.height + 1);
  207 |       }
  208 |       await page.getByTestId('combat-log').scrollIntoViewIfNeeded();
  209 |       await expect(page.getByTestId('combat-log')).toBeInViewport();
  210 |       expect(await visibleState(page)).toEqual(before);
  211 |       expect(await stored(page)).toEqual(saved);
  212 |       // Two representative shots per locale; all eight sizes retain numeric geometry.
  213 |       if (width === 360 || width === 1280) {
  214 |         await page.getByTestId('allies-grid').locator('[title]').first().scrollIntoViewIfNeeded();
  215 |         await info.attach(`layout-${width}`, { body: await page.screenshot(), contentType: 'image/png' });
  216 |       }
  217 |     }
  218 |     await attach(info, 'paused-visible-state', before);
  219 |     await attach(info, 'all-eight-geometry-samples', samples);
  220 |     await attach(info, 'stable-committed-save', saved);
  221 |     await page.getByRole('button', { name: english ? 'Flee' : '逃跑', exact: true }).click();
  222 |     await expect(page.getByTestId('map-screen')).toBeVisible();
  223 |     await attach(info, 'browser-errors', errors); expect(errors).toEqual([]);
  224 |   });
  225 | 
  226 |   test(`native toolbar and terminal return ${locale}`, async ({ page }, info) => {
  227 |     const english = locale === 'en';
  228 |     const errors: string[] = [];
  229 |     page.on('pageerror', error => errors.push(error.message));
  230 |     page.on('console', message => { if (['error', 'warning'].includes(message.type())) errors.push(message.text()); });
  231 |     await enter(page, english);
  232 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  233 |     const paused = await visibleState(page);
  234 |     const initialCards = paused.cells.flatMap(cell => cell.cards);
  235 |     expect(initialCards.length).toBeGreaterThan(0);
  236 |     for (const card of initialCards) {
  237 |       const hp = Number.parseFloat(card.hp ?? 'NaN');
  238 |       expect(Number.isFinite(hp)).toBe(true); expect(hp).toBeGreaterThanOrEqual(0); expect(hp).toBeLessThanOrEqual(100);
  239 |     }
  240 |     expect(paused.mp).toMatch(/\d+ \/ \d+/);
  241 |     await page.getByTestId('formation-editor-open').click();
  242 |     await expect(page.getByRole('dialog')).toBeVisible();
  243 |     await page.keyboard.press('Escape'); // Close only; assignments are immediate, not transactional.
  244 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  245 |     expect(await visibleState(page)).toEqual(paused);
  246 |     const auto = page.getByRole('checkbox'); const initialAuto = await auto.isChecked();
  247 |     await auto.setChecked(!initialAuto); await expect(auto).toBeChecked({ checked: !initialAuto });
  248 |     await auto.setChecked(initialAuto); await expect(auto).toBeChecked({ checked: initialAuto });
  249 |     const speed = page.getByRole('button', { name: english ? 'Speed' : '速度', exact: true });
  250 |     for (const n of [2, 4, 1]) { await speed.click(); await expect(speed).toHaveText(`${n}x`); }
  251 |     await page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true }).click();
  252 |     await expect.poll(async () => {
  253 |       const state = await visibleState(page);
  254 |       return state.mp !== paused.mp || state.cells.flatMap(cell => cell.cards).some(card =>
  255 |         initialCards.some(before => before.id === card.id && before.hp !== card.hp));
  256 |     }, { timeout: 15_000, intervals: [50] }).toBe(true);
  257 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  258 |     const resumed = await visibleState(page);
  259 |     expect(resumed.log).not.toBe(paused.log);
  260 |     await attach(info, 'native-controls', { paused, resumed, initialAuto });
  261 |     // One ordinary run, at most three waves; either native terminal outcome is acceptable.
  262 |     for (let wave = 1; wave <= 3; wave++) {
  263 |       await page.getByTestId('skip-button').click();
  264 |       await expect.poll(async () => {
  265 |         if (await page.getByTestId('return-to-map').isVisible()) return true;
  266 |         return (await page.getByTestId('wave-counter').innerText()).includes(english ? `Wave ${wave + 1} ` : `第 ${wave + 1} 波`);
  267 |       }, { timeout: 7000 }).toBe(true);
  268 |       if (await page.getByTestId('return-to-map').isVisible()) break;
  269 |     }
  270 |     await expect(page.getByTestId('return-to-map')).toBeVisible();
  271 |     await page.getByTestId('return-to-map').scrollIntoViewIfNeeded();
  272 |     await page.getByTestId('return-to-map').click();
  273 |     await expect(page.getByTestId('map-screen')).toBeVisible();
  274 |     await attach(info, 'terminal-exit', { destination: 'map', scope: 'return-control only; no clear/balance claim' });
  275 |     await attach(info, 'browser-errors', errors); expect(errors).toEqual([]);
  276 |   });
  277 | }
  278 | 
```