# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: combat-readability.spec.ts >> paused responsive geometry and W1 Flee en
- Location: tests/pwa/combat-readability.spec.ts:109:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 12
Received:    143.75
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 466
Received:    844
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 376
Received:    754
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 48
Received:    288
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 56.296875
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 51.296875
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 56.296875
Received:    174.015625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 92.59375
Received:    157.578125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 87.59375
Received:    157.578125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 92.59375
Received:    157.578125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    275.609375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 248.390625
Received:    275.609375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    275.609375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    312.453125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 284.6875
Received:    312.453125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    312.453125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 267.390625
Received:    237
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 404
Received:    400.2789306640625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.3125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 326
Received:    347.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 321
Received:    347.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 326
Received:    347.640625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    276.265625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 248.390625
Received:    276.265625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    276.265625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 231.09375
Received:    200.703125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 554
Received:    550.087646484375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    312.421875
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 284.6875
Received:    312.421875
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    312.421875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 267.390625
Received:    237
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 554
Received:    550.5938110351562
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.3125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 326
Received:    362.21875
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 321
Received:    362.21875
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 326
Received:    362.21875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    289.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 248.390625
Received:    289.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 253.390625
Received:    289.640625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 84
Received:    20.296875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    313.28125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 284.6875
Received:    313.28125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 289.6875
Received:    313.28125
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 144
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 128
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 12
Received:    143.75
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 406
Received:    784
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 316
Received:    694
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 48
Received:    288
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.953125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 64.953125
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 59.953125
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 64.953125
Received:    174.015625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 109.921875
Received:    166.234375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 104.921875
Received:    166.234375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 109.921875
Received:    166.234375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    301.609375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 283.0625
Received:    301.609375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    301.609375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 328.03125
Received:    347.125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 302.0625
Received:    280.34375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 344
Received:    340.2018737792969
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 378
Received:    390.984375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 373
Received:    390.984375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 378
Received:    390.984375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    302.265625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 283.0625
Received:    302.265625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    302.265625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 257.09375
Received:    235.375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 494
Received:    490.4734802246094
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.09375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 328.03125
Received:    347.09375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.09375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 302.0625
Received:    280.34375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 494
Received:    490.0485534667969
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 378
Received:    405.5625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 373
Received:    405.5625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 378
Received:    405.5625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    315.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 283.0625
Received:    315.640625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 288.0625
Received:    315.640625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 100
Received:    28.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 109.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.953125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 328.03125
Received:    347.953125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 333.03125
Received:    347.953125
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 12
Received:    81.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 19
Received:    435
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= -109
Received:    307
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 48
Received:    288
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.953125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 98.953125
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 93.953125
Received:    174.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 98.953125
Received:    174.015625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 179.921875
Received:    202.234375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 174.921875
Received:    202.234375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 179.921875
Received:    202.234375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= -81
Received:    -81.41000366210938
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 95
Received:    93.50408935546875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 80
Received:    62.96875
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 12
Received:    81.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= -257
Received:    159
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= -385
Received:    31
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 48
Received:    288
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 219.453125
Received:    266.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 214.453125
Received:    266.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 219.453125
Received:    266.015625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= -181
Received:    -181.132080078125
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 112
Received: 168
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 152
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 12
Received:    81.5
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 95.34375
Received:    515.703125
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= -32.65625
Received:    383.34375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 48
Received:    288
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 137.84375
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 237.453125
Received:    266.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 232.453125
Received:    266.015625
```

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 237.453125
Received:    266.015625
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 137.859375
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 14
Received:    10
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 18
Received:    12.5
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "nowrap"
```

```
Error: expect(received).not.toBe(expected) // Object.is equality

Expected: not "ellipsis"
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 6
Received:    4
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 64
Received: 133.5
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 4.21875
Received:    4.183736324310303
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 197.015625
Received:    196.84622192382812
```

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 44
Received:    40
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "Main navigation" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "Town" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: Town
        - listitem [ref=e10]:
          - link "Map" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: Map
        - listitem [ref=e14]:
          - link "Combat" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: Combat
        - listitem [ref=e18]:
          - link "Inventory" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: Inventory
        - listitem [ref=e22]:
          - link "Skills" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: Skills
        - listitem [ref=e26]:
          - link "Mercs" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: Mercs
        - listitem [ref=e30]:
          - link "Quests" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: Quests
        - listitem [ref=e34]:
          - link "Settings" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: Settings
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]: World Map
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - button "Act 1 · Act I — Sightless Eye" [expanded] [ref=e44] [cursor=pointer]:
              - generic [ref=e46]: Act 1 · Act I — Sightless Eye
              - generic [ref=e48]: ▾
            - list [ref=e49]:
              - listitem [ref=e50]:
                - generic [ref=e52]:
                  - generic [ref=e53]:
                    - generic [ref=e54]: Blood Moor
                    - generic [ref=e55]: Not cleared
                  - generic [ref=e56]: "Recommended Lv: 2 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e57]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e58]: 🔒 Farm Here
                  - button "Enter" [ref=e59] [cursor=pointer]
              - listitem [ref=e60]:
                - generic [ref=e62]:
                  - generic [ref=e63]:
                    - generic [ref=e64]: Den of Evil
                    - generic [ref=e65]: Not cleared
                  - generic [ref=e66]: "Recommended Lv: 3 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e67]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e68]: 🔒 Farm Here
                  - button "Enter" [ref=e69] [cursor=pointer]
              - listitem [ref=e70]:
                - generic [ref=e72]:
                  - generic [ref=e73]:
                    - generic [ref=e74]: Cold Plains
                    - generic [ref=e75]: Not cleared
                  - generic [ref=e76]: "Recommended Lv: 5 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e77]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e78]: 🔒 Farm Here
                  - button "Enter" [ref=e79] [cursor=pointer]
              - listitem [ref=e80]:
                - generic [ref=e82]:
                  - generic [ref=e83]:
                    - generic [ref=e84]: Burial Grounds
                    - generic [ref=e85]: Not cleared
                  - generic [ref=e86]: "Recommended Lv: 7 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e87]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e88]: 🔒 Farm Here
                  - button "Enter" [ref=e89] [cursor=pointer]
              - listitem [ref=e90]:
                - generic [ref=e92]:
                  - generic [ref=e93]:
                    - generic [ref=e94]: Dark Wood
                    - generic [ref=e95]: Not cleared
                    - generic [ref=e96]: Build check
                  - generic [ref=e97]: "Recommended Lv: 9 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e98]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e99]: 🔒 Farm Here
                  - button "Enter" [ref=e100] [cursor=pointer]
              - listitem [ref=e101]:
                - generic [ref=e103]:
                  - generic [ref=e104]:
                    - generic [ref=e105]: Catacombs (Andariel)
                    - generic [ref=e106]: Not cleared
                    - generic "Andariel" [ref=e107]: BOSS
                    - generic [ref=e108]: Act finale
                  - generic [ref=e109]: "Recommended Lv: 12 · Challenge loop: 8–20 monsters/wave"
                - generic [ref=e110]:
                  - button "Clear this area first to enable idle farming" [disabled] [ref=e111]: 🔒 Farm Here
                  - button "Enter" [ref=e112] [cursor=pointer]
          - button "Act 2 · Act II — Secret of the Vizjerei Defeat Andariel to unlock Act 2" [ref=e114] [cursor=pointer]:
            - generic [ref=e116]: Act 2 · Act II — Secret of the Vizjerei
            - generic [ref=e117]:
              - generic "Defeat Andariel to unlock Act 2" [ref=e118]: 🔒 Locked
              - generic [ref=e119]: ▸
          - button "Act 3 · Act III — Infernal Gate Defeat Duriel to unlock Act 3" [ref=e121] [cursor=pointer]:
            - generic [ref=e123]: Act 3 · Act III — Infernal Gate
            - generic [ref=e124]:
              - generic "Defeat Duriel to unlock Act 3" [ref=e125]: 🔒 Locked
              - generic [ref=e126]: ▸
          - button "Act 4 · Act IV — Harrowing Defeat Mephisto to unlock Act 4" [ref=e128] [cursor=pointer]:
            - generic [ref=e130]: Act 4 · Act IV — Harrowing
            - generic [ref=e131]:
              - generic "Defeat Mephisto to unlock Act 4" [ref=e132]: 🔒 Locked
              - generic [ref=e133]: ▸
          - button "Act 5 · Act V — Lord of Destruction Defeat Diablo to unlock Act 5" [ref=e135] [cursor=pointer]:
            - generic [ref=e137]: Act 5 · Act V — Lord of Destruction
            - generic [ref=e138]:
              - generic "Defeat Diablo to unlock Act 5" [ref=e139]: 🔒 Locked
              - generic [ref=e140]: ▸
        - status [ref=e141]:
          - generic [ref=e142]: Choose a cleared map to start auto farming
  - button "ReadabilityProof · Level 1. Open character sheet." [ref=e143] [cursor=pointer]:
    - generic [ref=e145]: "1"
    - generic [ref=e146]:
      - generic [ref=e147]:
        - generic [ref=e148]: ReadabilityProof
        - generic [ref=e149]: Level 1
      - generic [ref=e150]:
        - generic [ref=e151]: HP
        - progressbar "HP" [ref=e152]
      - generic [ref=e154]:
        - generic [ref=e155]: MP
        - progressbar "MP" [ref=e156]
      - generic [ref=e158]:
        - generic [ref=e159]: XP
        - progressbar "XP" [ref=e160]
```

# Test source

```ts
  60  |     mp: root.querySelector('[role="group"]')?.textContent,
  61  |     log: root.querySelector('[data-testid="combat-log"]')?.textContent
  62  |   }));
  63  | }
  64  | async function geometry(page: Page) {
  65  |   return page.getByTestId('combat-screen').evaluate(root => {
  66  |     const rect = (node: Element) => {
  67  |       const r = node.getBoundingClientRect();
  68  |       return { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height };
  69  |     };
  70  |     const main = root.querySelector('main')!;
  71  |     const field = root.querySelector('[data-testid="combat-battlefield"]')!;
  72  |     const allies = field.children[0]!;
  73  |     const separator = field.children[1]!;
  74  |     const enemies = field.children[2]!;
  75  |     return {
  76  |       viewport: { width: innerWidth, height: innerHeight }, main: rect(main),
  77  |       overflow: { document: document.documentElement.scrollWidth - innerWidth, main: main.scrollWidth - main.clientWidth },
  78  |       allies: rect(allies), separator: rect(separator), enemies: rect(enemies),
  79  |       metadata: rect(root.querySelector('[data-testid="wave-counter"]')!.parentElement!),
  80  |       cells: Array.from(field.querySelectorAll('[data-testid*="-grid-cell-"]'), cell => ({
  81  |         rect: rect(cell), minimum: Number.parseFloat(getComputedStyle(cell).minHeight),
  82  |         emptyMinimum: cell.querySelector('[title]') ? null : Number.parseFloat(getComputedStyle(cell.children[0]!).minHeight)
  83  |       })),
  84  |       columns: [allies, enemies].map(side => getComputedStyle(side.querySelector('[data-testid$="-grid"]')!).gridTemplateColumns.split(' ').length),
  85  |       controls: Array.from(root.querySelectorAll('header button, header label'), node => ({ text: node.textContent, ...rect(node) })),
  86  |       cards: Array.from(field.querySelectorAll<HTMLElement>('[data-testid^="unit-card-"]'), outer => {
  87  |         const card = outer.querySelector('[title]')!;
  88  |         const name = card.children[1]!.children[0]!;
  89  |         const hp = outer.querySelector('.bg-red-600')!.parentElement!;
  90  |         const range = document.createRange(); range.selectNodeContents(name);
  91  |         const lines = Array.from(range.getClientRects(), r => ({ left: r.left, right: r.right, top: r.top, bottom: r.bottom }));
  92  |         const style = getComputedStyle(name);
  93  |         const clippingAncestors = [];
  94  |         for (let node: Element | null = name; node && node !== main; node = node.parentElement) {
  95  |           const s = getComputedStyle(node);
  96  |           if (/(hidden|clip)/.test(`${s.overflowX} ${s.overflowY}`)) clippingAncestors.push(rect(node));
  97  |         }
  98  |         const badge = outer.querySelector('[data-testid="combat-event-fx"]');
  99  |         return { id: outer.dataset.testid, name: name.textContent, card: rect(card), hp: rect(hp), lines,
  100 |           font: Number.parseFloat(style.fontSize), lineHeight: Number.parseFloat(style.lineHeight),
  101 |           whiteSpace: style.whiteSpace, ellipsis: style.textOverflow, clippingAncestors,
  102 |           image: rect(card.children[0]!), badge: badge ? rect(badge) : null };
  103 |       })
  104 |     };
  105 |   });
  106 | }
  107 | 
  108 | for (const locale of ['en', 'zh-CN'] as const) {
  109 |   test(`paused responsive geometry and W1 Flee ${locale}`, async ({ page }, info) => {
  110 |     const english = locale === 'en';
  111 |     const errors: string[] = [];
  112 |     page.on('pageerror', error => errors.push(error.message));
  113 |     page.on('console', message => { if (['error', 'warning'].includes(message.type())) errors.push(message.text()); });
  114 |     await enter(page, english);
  115 |     await expect(page.getByTestId('combat-event-fx').first()).toBeVisible({ timeout: 15_000 });
  116 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  117 |     await expect(page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true })).toHaveAttribute('aria-pressed', 'true');
  118 |     const before = await visibleState(page);
  119 |     expect(before.wave).toMatch(english ? /^Wave 1 / : /^第 1 波/);
  120 |     expect(before.cells).toHaveLength(18);
  121 |     expect(before.cells.flatMap(cell => cell.cards)).toHaveLength(10);
  122 |     expect(before.cells.flatMap(cell => cell.cards).some(card => card.feedback)).toBe(true);
  123 |     if (!english) {
  124 |       const cdp = await page.context().newCDPSession(page);
  125 |       try {
  126 |         await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  127 |         const document = await cdp.send('DOM.getDocument');
  128 |         const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId, selector: '[data-testid="combat-sub-area-name"]' });
  129 |         const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  130 |         await attach(info, 'actual-cjk-platform-fonts', fonts);
  131 |         expect(fonts.fonts.some(font => /WenQuanYi|WQY/i.test(font.familyName) && font.glyphCount > 0)).toBe(true);
  132 |       } finally { await cdp.detach(); }
  133 |     }
  134 |     const saved = await stored(page);
  135 |     const samples = [];
  136 |     for (const [width, height] of sizes) {
  137 |       await page.setViewportSize({ width, height });
  138 |       const g = await geometry(page); samples.push(g);
  139 |       expect.soft(g.overflow, `${width}: no horizontal overflow`).toEqual({ document: 0, main: 0 });
  140 |       expect.soft(g.main.height, `${width}: usable scrollport`).toBeGreaterThanOrEqual(120);
  141 |       expect.soft(g.columns).toEqual([3, 3]);
  142 |       for (const cell of g.cells) {
  143 |         expect.soft(cell.minimum).toBe(width < 1024 ? 112 : 168);
  144 |         expect.soft(cell.rect.height).toBeGreaterThanOrEqual(width < 1024 ? 112 : 168);
  145 |         if (cell.emptyMinimum !== null) expect.soft(cell.emptyMinimum).toBe(width < 1024 ? 0 : 152);
  146 |       }
  147 |       if (width < 1024) expect.soft(g.metadata.bottom).toBeLessThanOrEqual(Math.min(...g.controls.map(control => control.top)));
  148 |       if (width < 1024) {
  149 |         expect.soft(g.allies.bottom).toBeLessThanOrEqual(g.separator.top);
  150 |         expect.soft(g.separator.bottom).toBeLessThanOrEqual(g.enemies.top);
  151 |         expect.soft(g.separator.height).toBeGreaterThanOrEqual(40);
  152 |         expect.soft(g.separator.height).toBeLessThanOrEqual(48);
  153 |       } else {
  154 |         expect.soft(g.allies.right).toBeLessThanOrEqual(g.separator.left);
  155 |         expect.soft(g.separator.right).toBeLessThanOrEqual(g.enemies.left);
  156 |         expect.soft(g.separator.height).toBeGreaterThanOrEqual(288);
  157 |       }
  158 |       for (const control of g.controls) {
  159 |         expect.soft(control.width).toBeGreaterThanOrEqual(44);
> 160 |         expect.soft(control.height).toBeGreaterThanOrEqual(44);
      |                                     ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  161 |         expect.soft(control.left).toBeGreaterThanOrEqual(0);
  162 |         expect.soft(control.right).toBeLessThanOrEqual(width);
  163 |       }
  164 |       for (let i = 0; i < g.controls.length; i++) for (const other of g.controls.slice(i + 1)) {
  165 |         const c = g.controls[i]!;
  166 |         expect.soft(c.right + 7.9 <= other.left || other.right + 7.9 <= c.left ||
  167 |           c.bottom + 7.9 <= other.top || other.bottom + 7.9 <= c.top, 'toolbar target spacing').toBe(true);
  168 |       }
  169 |       for (const c of g.cards) {
  170 |         if (width < 1024) {
  171 |           expect.soft(c.card.width).toBeGreaterThanOrEqual(width === 360 ? 84 : width === 412 ? 100 : 80);
  172 |           expect.soft(c.font).toBeGreaterThanOrEqual(14);
  173 |           expect.soft(c.lineHeight).toBeGreaterThanOrEqual(18);
  174 |           expect.soft(c.whiteSpace).not.toBe('nowrap');
  175 |           expect.soft(c.ellipsis).not.toBe('ellipsis');
  176 |           expect.soft(c.hp.height).toBeGreaterThanOrEqual(6);
  177 |           expect.soft(c.image.height).toBe(64);
  178 |           if (width === 360 && c.name === heroName) expect.soft(c.lines.length).toBeGreaterThanOrEqual(2);
  179 |           for (const line of c.lines) for (const ancestor of [c.card, ...c.clippingAncestors]) {
  180 |             expect.soft(line.left).toBeGreaterThanOrEqual(ancestor.left - 1);
  181 |             expect.soft(line.right).toBeLessThanOrEqual(ancestor.right + 1);
  182 |             expect.soft(line.top).toBeGreaterThanOrEqual(ancestor.top - 1);
  183 |             expect.soft(line.bottom).toBeLessThanOrEqual(ancestor.bottom + 1);
  184 |           }
  185 |         } else {
  186 |           expect.soft(c.font).toBe(10);
  187 |           expect.soft(c.hp.height).toBe(4);
  188 |         }
  189 |         expect.soft(c.hp.left).toBeGreaterThanOrEqual(c.card.left - 1);
  190 |         expect.soft(c.hp.right).toBeLessThanOrEqual(c.card.right + 1);
  191 |         expect.soft(c.hp.top).toBeGreaterThanOrEqual(c.card.top - 1);
  192 |         expect.soft(c.hp.bottom).toBeLessThanOrEqual(c.card.bottom + 1);
  193 |         if (c.badge) {
  194 |           expect.soft(c.badge.left).toBeGreaterThanOrEqual(c.card.left - 1);
  195 |           expect.soft(c.badge.right).toBeLessThanOrEqual(c.card.right + 1);
  196 |           expect.soft(c.badge.top).toBeGreaterThanOrEqual(c.card.top - 1);
  197 |           expect.soft(c.badge.bottom).toBeLessThanOrEqual(c.card.bottom + 1);
  198 |         }
  199 |       }
  200 |       // Ordinary scrolling must reveal complete name+HP for each team and the log.
  201 |       for (const side of ['allies', 'enemies']) {
  202 |         const card = page.getByTestId(`${side}-grid`).locator('[title]').first();
  203 |         await card.scrollIntoViewIfNeeded();
  204 |         const r = await card.boundingBox(); const m = await page.locator('main').boundingBox();
  205 |         expect.soft(r!.y).toBeGreaterThanOrEqual(m!.y - 1);
  206 |         expect.soft(r!.y + r!.height).toBeLessThanOrEqual(m!.y + m!.height + 1);
  207 |       }
  208 |       await page.getByTestId('combat-log').scrollIntoViewIfNeeded();
  209 |       await expect(page.getByTestId('combat-log')).toBeInViewport();
  210 |       expect(await visibleState(page)).toEqual(before);
  211 |       expect(await stored(page)).toEqual(saved);
  212 |       // Two representative shots per locale; all eight sizes retain numeric geometry.
  213 |       if (width === 360 || width === 1280) {
  214 |         await page.getByTestId('allies-grid').locator('[title]').first().scrollIntoViewIfNeeded();
  215 |         await info.attach(`layout-${width}`, { body: await page.screenshot(), contentType: 'image/png' });
  216 |       }
  217 |     }
  218 |     await attach(info, 'paused-visible-state', before);
  219 |     await attach(info, 'all-eight-geometry-samples', samples);
  220 |     await attach(info, 'stable-committed-save', saved);
  221 |     await page.getByRole('button', { name: english ? 'Flee' : '逃跑', exact: true }).click();
  222 |     await expect(page.getByTestId('map-screen')).toBeVisible();
  223 |     await attach(info, 'browser-errors', errors); expect(errors).toEqual([]);
  224 |   });
  225 | 
  226 |   test(`native toolbar and terminal return ${locale}`, async ({ page }, info) => {
  227 |     const english = locale === 'en';
  228 |     const errors: string[] = [];
  229 |     page.on('pageerror', error => errors.push(error.message));
  230 |     page.on('console', message => { if (['error', 'warning'].includes(message.type())) errors.push(message.text()); });
  231 |     await enter(page, english);
  232 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  233 |     const paused = await visibleState(page);
  234 |     const initialCards = paused.cells.flatMap(cell => cell.cards);
  235 |     expect(initialCards.length).toBeGreaterThan(0);
  236 |     for (const card of initialCards) {
  237 |       const hp = Number.parseFloat(card.hp ?? 'NaN');
  238 |       expect(Number.isFinite(hp)).toBe(true); expect(hp).toBeGreaterThanOrEqual(0); expect(hp).toBeLessThanOrEqual(100);
  239 |     }
  240 |     expect(paused.mp).toMatch(/\d+ \/ \d+/);
  241 |     await page.getByTestId('formation-editor-open').click();
  242 |     await expect(page.getByRole('dialog')).toBeVisible();
  243 |     await page.keyboard.press('Escape'); // Close only; assignments are immediate, not transactional.
  244 |     await expect(page.getByRole('dialog')).toHaveCount(0);
  245 |     expect(await visibleState(page)).toEqual(paused);
  246 |     const auto = page.getByRole('checkbox'); const initialAuto = await auto.isChecked();
  247 |     await auto.setChecked(!initialAuto); await expect(auto).toBeChecked({ checked: !initialAuto });
  248 |     await auto.setChecked(initialAuto); await expect(auto).toBeChecked({ checked: initialAuto });
  249 |     const speed = page.getByRole('button', { name: english ? 'Speed' : '速度', exact: true });
  250 |     for (const n of [2, 4, 1]) { await speed.click(); await expect(speed).toHaveText(`${n}x`); }
  251 |     await page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true }).click();
  252 |     await expect.poll(async () => {
  253 |       const state = await visibleState(page);
  254 |       return state.mp !== paused.mp || state.cells.flatMap(cell => cell.cards).some(card =>
  255 |         initialCards.some(before => before.id === card.id && before.hp !== card.hp));
  256 |     }, { timeout: 15_000, intervals: [50] }).toBe(true);
  257 |     await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  258 |     const resumed = await visibleState(page);
  259 |     expect(resumed.log).not.toBe(paused.log);
  260 |     await attach(info, 'native-controls', { paused, resumed, initialAuto });
```