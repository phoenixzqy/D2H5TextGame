from pathlib import Path
import hashlib,json
p=Path(__file__).parent
pairs=[];geometry=[];screens=[]
for name in ['en-desktop','zh-desktop','en-mobile','zh-mobile']:
 d=p/('browser-'+name);r=json.loads((d/'browser-report.json').read_text())
 assert len(r['cases'])==1 and r['cases'][0]['pass'] and not r['failures'] and not r['cases'][0]['errors']
 geometry.extend(r['geometry']);screens.extend(str(f.relative_to(p)) for f in sorted(d.glob('*.png')))
 for stage in ['rank1','rank2']:
  before=list(d.glob('*-'+stage+'-before-*.json'));after=list(d.glob('*-'+stage+'-after-*.json'));assert len(before)==len(after)==1
  b=json.loads(before[0].read_text());a=json.loads(after[0].read_text());domains=['player','inventory','map','mercs','formation']
  for domain in domains:assert a[domain]==b[domain],(name,stage,domain)
  digest=lambda v:hashlib.sha256(json.dumps({k:v[k] for k in domains},sort_keys=True,separators=(',',':')).encode()).hexdigest()
  assert digest(a)==digest(b)
  assert a['player']['skillLevels']['amazon.impale']==(1 if stage=='rank1' else 2)
  pairs.append({'case':name,'stage':stage,'exact_domains':domains,'domain_sha256':digest(a)})
assert len(pairs)==8 and len(geometry)==20 and len(screens)==20
reviewed=['browser-en-mobile/en-360-description.png','browser-en-mobile/en-360-details-lower.png','browser-zh-mobile/zh-CN-360-description.png','browser-zh-mobile/zh-CN-360-bleed-visible.png','browser-en-desktop/en-1280-details.png','browser-en-desktop/en-1280-bleed-visible.png','browser-zh-desktop/zh-CN-1280-details.png','browser-zh-desktop/zh-CN-1280-bleed-visible.png']
assert set(reviewed)<=set(screens)
(p/'browser-audit.json').write_text(json.dumps({'cases':4,'pairs':pairs,'geometry':geometry,'screenshots':screens,'synthetic_L30_Amazon_and_resource_cap':True,'combat_fixed_Date_now':'2026-10-25T12:30:00Z','ordinary_timers':True,'test_bridge_absent':True},indent=2)+'\n')
(p/'visual-review.json').write_text(json.dumps({'individually_inspected':reviewed,'readable_Impale_description_and_rank_rules':True,'actual_localized_Bleed_chip_visible':True,'mobile_details_accessible_by_ordinary_scrolling':True,'existing_icon_fallback_and_fixed_bars':'observed; full accessibility/PWA/device-performance gates remain open','independent_acceptance':False},indent=2)+'\n')
print('PASS 4browser cases/8exact five-domain pairs/20geometry/20screenshots/8individually inspected')
