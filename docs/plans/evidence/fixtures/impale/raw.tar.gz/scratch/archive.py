from pathlib import Path
import tarfile,hashlib,json
p=Path(__file__).parent;wd=Path.cwd();out=wd/'docs/plans/evidence/fixtures/impale';assert not out.exists()
assert json.loads((p/'full.json').read_text())['exit_code']==0
assert json.loads((p/'committed-source-audit.json').read_text())['actual_git_blobs_and_disk_exact']
files=[f for f in sorted(p.rglob('*')) if f.is_file() and f.relative_to(p).parts[0]!='production-dist']
assert all(not f.is_symlink() and f.resolve().is_relative_to(p.resolve()) for f in files)
members=[];receipts=[]
for f in files:
 data=f.read_bytes();rel=str(f.relative_to(p));members.append({'path':'scratch/'+rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 if f.suffix=='.json':
  try:r=json.loads(data)
  except (ValueError,UnicodeDecodeError):continue
  if isinstance(r,dict) and 'command' in r and 'exit_code' in r:receipts.append({'path':'scratch/'+rel,'exit_code':r['exit_code']})
out.mkdir(parents=True);archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in files:t.add(f,arcname='scratch/'+str(f.relative_to(p)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert sorted(t.getnames())==sorted(m['path'] for m in members)
 for m in members:
  data=t.extractfile(m['path']).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
packet={'root':str(p),'members':members,'terminal_receipts':receipts,'member_hashes_verified':True,'raw_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'build_hash_maps':{'production-dist':'scratch/frozen-inputs.json'},'final_evidence':['full.json','post-full-freeze-audit.json','browser-audit.json','visual-review.json','committed-source-audit.json'],'next_jab_reproduction_credit':False}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
for name in ['committed-source-audit.json','inventory-reconciliation.json']:(out/name).write_bytes((p/name).read_bytes())
print(json.dumps({'raw_members':len(members),'terminal_receipts':len(receipts),'hashes_verified':True,'archive_bytes':archive.stat().st_size}))
