from pathlib import Path
import json,subprocess,hashlib,gzip
p=Path(__file__).parent;frozen=json.loads((p/'frozen-inputs.json').read_text());assert json.loads((p/'full.json').read_text())['exit_code']==0
assert json.loads((p/'post-full-freeze-audit.json').read_text())['exact']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files={**frozen['source'],**frozen['design']}
blob=subprocess.run(['git','cat-file','--batch'],input=''.join('HEAD:'+n+'\n' for n in files).encode(),capture_output=True,check=True).stdout
offset=0
for name,digest in files.items():
 end=blob.index(b'\n',offset);header=blob[offset:end].split();assert len(header)==3 and header[1]==b'blob',name
 size=int(header[2]);start=end+1;content=blob[start:start+size];assert blob[start+size:start+size+1]==b'\n';offset=start+size+1
 assert hashlib.sha256(content).hexdigest()==digest,name
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
assert offset==len(blob)
for name,digest in frozen['build'].items():assert hashlib.sha256((p/'production-dist'/name).read_bytes()).hexdigest()==digest
assert hashlib.sha256(gzip.decompress(Path('docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()==frozen['genuine']
assert json.loads((p/'next-jab-source-audit.json').read_text())['source']==frozen['source']
result={'head':head,'source_files':len(frozen['source']),'design_files':len(frozen['design']),'build_files':len(frozen['build']),'genuine':frozen['genuine'],'actual_git_blobs_and_disk_exact':True,'next_jab_repro_sources_exact':True}
assert not (p/'committed-source-audit.json').exists();(p/'committed-source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
