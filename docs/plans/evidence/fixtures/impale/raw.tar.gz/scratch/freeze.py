from pathlib import Path
import json,hashlib,gzip,subprocess,sys,tarfile
p=Path(__file__).parent;wd=Path.cwd()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
with tarfile.open(wd/'docs/plans/evidence/fixtures/freezing-arrow/raw.tar.gz') as t:
 prior=json.loads(t.extractfile('scratch/frozen-inputs15.json').read())
files=set(prior['source'])|{'src/stores/impale.causal.test.ts','src/engine/skills/impale.test.ts','src/features/skills/SkillsScreen.impale.test.tsx'}
source={name:sha(wd/name) for name in sorted(files)}
design={name:sha(wd/name) for name in ['docs/design/skills-spec.md','docs/plans/decisions/D04-impale-v1.md']}
build={str(f.relative_to(p/'production-dist')):sha(f) for f in sorted((p/'production-dist').rglob('*')) if f.is_file()}
genuine=hashlib.sha256(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
assert genuine=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577'
now={'source':source,'design':design,'build':build,'genuine':genuine,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
if sys.argv[1]=='before':
 for name in ['engine','typecheck-verified','lint-verified','build','focused-closed','data-compat','original-repro-repaired','browser-en-desktop','browser-zh-desktop','browser-en-mobile','browser-zh-mobile']:
  assert json.loads((p/(name+'.json')).read_text())['exit_code']==0,name
 assert (p/'browser-audit.json').exists() and (p/'visual-review.json').exists()
 assert not (p/'frozen-inputs.json').exists();(p/'frozen-inputs.json').write_text(json.dumps(now,indent=2)+'\n')
else:
 assert json.loads((p/'full.json').read_text())['exit_code']==0
 assert now==json.loads((p/'frozen-inputs.json').read_text())
 (p/'post-full-freeze-audit.json').write_text(json.dumps({'exact':True,'source_files':len(source),'design_files':len(design),'build_files':len(build),'head':now['head'],'genuine':genuine},indent=2)+'\n')
print(json.dumps({'exact':True,'source_files':len(source),'design_files':len(design),'build_files':len(build),'mode':sys.argv[1]}))
