from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,socket
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-impale-vk9px62n');out=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/impale')
packet=json.loads((out/'packet.json').read_text());assert packet['root']==str(root)
assert root.is_dir() and not root.is_symlink();assert hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest()==packet['raw_archive_sha256']
expected={}
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
 assert sorted(t.getnames())==sorted(m['path'] for m in packet['members'])
 for m in packet['members']:
  rel=PurePosixPath(m['path']);assert rel.parts[0]=='scratch' and '..' not in rel.parts
  data=t.extractfile(m['path']).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
  expected[str(PurePosixPath(*rel.parts[1:]))]=m['sha256']
for rel,digest in json.loads((root/'frozen-inputs.json').read_text())['build'].items():
 assert not PurePosixPath(rel).is_absolute() and '..' not in PurePosixPath(rel).parts
 expected['production-dist/'+rel]=digest
paths=list(root.rglob('*'));assert all(not p.is_symlink() and p.resolve().is_relative_to(root.resolve()) for p in paths)
actual={str(p.relative_to(root)) for p in paths if p.is_file()};assert actual==set(expected),{'unexpected':sorted(actual-set(expected)),'missing':sorted(set(expected)-actual)}
for rel,digest in expected.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
pids={json.loads((root/'impale-preview-server-owner.json').read_text())['pid']}
for p in root.glob('*-owner.json'):
 owner=json.loads(p.read_text())
 for key in ['pid','wrapper_pid']:
  if key in owner:pids.add(owner[key])
for p in root.glob('*stop.json'):
 stop=json.loads(p.read_text())
 for proc in stop.get('verified_owned_tree',[]):pids.add(proc['pid'])
for pid in pids:assert not Path(f'/proc/{pid}').exists(),pid
with socket.socket() as s:
 s.settimeout(.2);assert s.connect_ex(('127.0.0.1',4489))!=0
for rel in sorted(expected):(root/rel).unlink()
for p in sorted([p for p in paths if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
root.rmdir();assert not root.exists()
r={'root':str(root),'archive_members_verified':len(packet['members']),'removed_exact_files':len(expected),'root_absent':True,'owned_pids_absent':sorted(pids),'owned_ports_closed':[4489],'remaining':[],'failures':[],'older_roots_and_shared_caches':'preserved'}
(out/'cleanup.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
