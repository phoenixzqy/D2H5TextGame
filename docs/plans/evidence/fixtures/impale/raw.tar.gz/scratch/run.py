import subprocess,time,json,sys,os,pathlib
p=pathlib.Path(__file__).parent;wd=pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
name=sys.argv[1];command=sys.argv[2:]
assert name.replace('-','').isalnum()
for suffix in ['.json','.log','-owner.json']:assert not (p/(name+suffix)).exists()
start=time.monotonic();child=subprocess.Popen(command,cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(p/(name+'-owner.json')).write_text(json.dumps({'pid':child.pid,'wrapper_pid':os.getpid(),'command':command},indent=2)+'\n')
output=child.communicate()[0];(p/(name+'.log')).write_bytes(output)
result={'command':command,'exit_code':child.returncode,'seconds':time.monotonic()-start}
(p/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(output.decode(errors='replace')[-2600:]);print(json.dumps(result));sys.exit(child.returncode)
