from pathlib import Path
import csv,io,json,collections,hashlib,subprocess
p=Path(__file__).parent;target=Path('docs/plans/skill-inventory.csv');before=target.read_bytes()
assert json.loads((p/'committed-source-audit.json').read_text())['actual_git_blobs_and_disk_exact']
assert json.loads((p/'full.json').read_text())['exit_code']==0
baseline=subprocess.check_output(['git','show','2d7cc6ce:docs/plans/skill-inventory.csv'])
assert before==baseline,'Inventory changed unexpectedly before reconciliation'
rows=list(csv.DictReader(io.StringIO(before.decode())));old=[dict(r) for r in rows];fields=list(rows[0]);assert len(rows)==213
impale=next(r for r in rows if r['data_id']=='skills-amazon-impale');assert impale['behavior_verification']=='unverified'
impale.update({'adapter_route':'damage+explicit-bleed+ordinary-defense-bypass','risk_flags':'independent-design-qa-and-earned-balance-open','behavior_verification':'bounded-functional;independent-acceptance-open','contract_evidence':'docs/plans/decisions/D04-impale-v1.md;docs/plans/evidence/d04-impale.md;production/bugs/BUG-202-impale-inert-bleed-and-defense.md'})
jab=next(r for r in rows if r['data_id']=='skills-amazon-jab');assert jab['behavior_verification']=='unverified'
jab.update({'risk_flags':'repeated-attacks-metadata-missing','contract_evidence':'docs/plans/evidence/d04-jab-repro.md;docs/plans/decisions/D04-jab-v1.md;production/bugs/BUG-203-jab-missing-repeated-attacks.md'})
assert [r['data_id'] for r in rows]==[r['data_id'] for r in old]
changed=[r['data_id'] for r,o in zip(rows,old) if r!=o];assert changed==['skills-amazon-jab','skills-amazon-impale']
counts=collections.Counter(r['behavior_verification'] for r in rows);assert sum(n for k,n in counts.items() if k.startswith('bounded-functional;'))==101
assert counts['unverified']==110
stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);target.write_text(stream.getvalue())
audit={'rows':213,'IDs_and_order_unchanged':True,'credited':['skills-amazon-impale'],'evidence_only_unverified':['skills-amazon-jab'],'changed_rows':changed,'counts':dict(counts),'baseline_sha256':hashlib.sha256(before).hexdigest(),'final_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'other211rows_exact':True}
(p/'inventory-reconciliation.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
