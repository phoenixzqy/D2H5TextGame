from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path(__file__).parent;out=root/'docs/plans/evidence/fixtures/sorceress-cold-attacks'
frozen=json.loads((p/'frozen.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
entries=subprocess.check_output(['git','ls-tree','-r','-z',head],cwd=root).split(bytes([0]));blobs={}
for entry in entries:
 if not entry:continue
 metadata,name=entry.split(bytes([9]),1);blobs[name.decode()]=metadata.split()[2].decode()
for name,want in frozen['source'].items():
 raw=(root/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==want,name
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+bytes([0])+raw).hexdigest()==blobs.get(name),name
for name,want in frozen['build'].items():assert hashlib.sha256((p/'build'/name).read_bytes()).hexdigest()==want,name
assert hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()==frozen['genuine']
result={'commit':head,'sourceFiles':len(frozen['source']),'committedSourceBlobsMatch':True,'buildFiles':len(frozen['build']),'sourceDrift':[],'buildDrift':[],'genuine':frozen['genuine'],'pass':True}
(out/'source-delivered.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'source-diff-audit.json').write_bytes((p/'source-diff-audit.json').read_bytes())
review={'reviewer':'root author only; no independent approval','commit':head,'verdict':'local author review pass','security':'pass: first-party local game data/UI/tests; no credentials, dependencies, save version, CI, permission or remote changes','correctness':'Actual Orb cone and Blizzard all-hostile targeting, native eligibility/payment/control/mitigation/replay/playback/save and truthful current/next/MAX values verified. Existing tuning preserved.','readability':'Uses existing selectors/projectors and pure display resolver; no new combat loop or ad hoc target patch.','architecture':'JSON owns tuning, schemas guard skill identity, engine has no React/DOM imports, UI formats engine values, save22 unchanged.','performance':'Existing bounded cone selector reused; no new hot-path loops or dependency. Production entry/chunks precached. Existing test-speed and broad bundle/art-manifest warnings remain open.','resolvedFindings':['Readonly fixture/event narrowing and optional-property typing corrected without casts or assertion weakening','Unsafe matcher assignments and redundant UI guard corrected','Copied warcry prose browser expectation corrected to cold contract; original failure retained','Two receiptless143collectors retained separately; final groups all terminal0'],'limitations':['Provisional four-cell cone adaptation','Independent design/QA and earned balance remain open','No earned campaign/pacing/endgame or full a11y acceptance']}
(out/'author-review.json').write_text(json.dumps(review,indent=2)+'\n')
print('Verified',len(frozen['source']),'committed source blobs and',len(frozen['build']),'build files; author review recorded.')
