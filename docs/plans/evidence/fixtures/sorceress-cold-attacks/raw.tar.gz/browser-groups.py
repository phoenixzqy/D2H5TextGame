from pathlib import Path
import os,sys,subprocess,concurrent.futures
p=Path(__file__).parent
def run(case):
 locale,width=case;label='browser-'+locale+'-'+width
 env={**os.environ,'BROWSER_PORT':'4510','BROWSER_LOCALE':locale,'BROWSER_WIDTH':width,'BROWSER_RUN':label}
 code=subprocess.call([sys.executable,str(p/'run.py'),label+'-final','node',str(p/'browser.cjs')],env=env)
 print(label,code,flush=True)
 return code
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 codes=list(pool.map(run,[('en','360'),('zh-CN','360'),('en','1280'),('zh-CN','1280')]))
assert codes==[0,0,0,0],codes
