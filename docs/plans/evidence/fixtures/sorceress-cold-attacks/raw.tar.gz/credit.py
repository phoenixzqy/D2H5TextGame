from pathlib import Path
import csv,io,json,collections,subprocess
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=root/'docs/plans/evidence/fixtures/sorceress-cold-attacks'
assert json.loads((out/'terminal-results.json').read_text())['fullTests']==15610
assert json.loads((out/'save-pairs-audit.json').read_text())['pass']
file=root/'docs/plans/skill-inventory.csv';before=file.read_bytes().decode('utf-8');lines=before.splitlines(keepends=True)
header=next(csv.reader([lines[0]]));index={k:i for i,k in enumerate(header)}
ids={'skills-sorceress-'+slug for slug in ['ice-bolt','frost-nova','frozen-orb','blizzard']};changed=[];after=[]
for line in lines[1:]:
 row=next(csv.reader([line]));id=row[index['data_id']]
 if id in ids:
  assert row[index['behavior_verification']]=='unverified'
  row[index['behavior_verification']]='bounded-functional;independent-acceptance-open'
  row[index['contract_evidence']]='docs/plans/decisions/D04-sorceress-cold-attacks-v1.md;docs/plans/evidence/d04-sorceress-cold-attacks.md'
  stream=io.StringIO();csv.writer(stream,lineterminator='\n').writerow(row);line=stream.getvalue();changed.append(id)
 after.append(line)
assert set(changed)==ids and len(changed)==4
result=lines[0]+''.join(after);rows=list(csv.DictReader(io.StringIO(result)));old=list(csv.DictReader(io.StringIO(before)))
assert len(rows)==213 and [r['data_id'] for r in rows]==[r['data_id'] for r in old]
assert sum(a==b for a,b in zip(lines[1:],after))==209
counts=collections.Counter(r['behavior_verification'] for r in rows)
bounded=sum(n for k,n in counts.items() if k.startswith('bounded-functional;'))
assert bounded==128 and counts['unverified']==83 and counts['review-needed']==1
assert sum(r['class']=='sorceress' and r['behavior_verification'].startswith('bounded-functional;') for r in rows)==12
file.write_text(result)
(out/'inventory-audit.json').write_text(json.dumps({'changedIds':changed,'otherRowsByteExact':209,'idsAndOrderUnchanged':True,'total':213,'boundedFunctional':bounded,'unverified':83,'engineOnly':1,'reviewNeeded':1,'sorceressBounded':12,'independentAndEarnedAcceptance':'open'},indent=2)+'\n')
print('Credited exactly four Sorceress skills; 128 bounded, 83 unverified, 1 engine-only, 1 review-needed.')
