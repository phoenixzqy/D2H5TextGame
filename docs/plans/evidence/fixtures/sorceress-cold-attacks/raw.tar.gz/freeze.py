from pathlib import Path
import json,hashlib,gzip,subprocess
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path(__file__).parent
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src','tests','scripts','package.json','package-lock.json','index.html','vite.config.ts','vitest.config.ts','vitest.workspace.ts','tsconfig.json','tsconfig.node.json','tsconfig.app.json','tailwind.config.ts','postcss.config.js','playwright.config.ts','docs/plans/decisions/D04-sorceress-cold-attacks-v1.md'],cwd=root,text=True).splitlines()
def sha(file):return hashlib.sha256(file.read_bytes()).hexdigest()
source={name:sha(root/name) for name in sorted(set(paths)) if (root/name).is_file()}
build={str(file.relative_to(p/'build')):sha(file) for file in sorted((p/'build').rglob('*')) if file.is_file()}
genuine=hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
assert genuine=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577'
assert source and build
(p/'frozen.json').write_text(json.dumps({'source':source,'build':build,'genuine':genuine},indent=2)+'\n')
print('Frozen',len(source),'source/config/test/contract files and',len(build),'production build files; genuine save unchanged.')
