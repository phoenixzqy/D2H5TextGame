from pathlib import Path
import json, hashlib, tarfile, re, gzip

root = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p = Path(__file__).parent
out = root / 'docs/plans/evidence/fixtures/sorceress-cold-attacks'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(file, value):
    file.write_text(json.dumps(value, indent=2) + '\n')

labels = ['focused-final', 'causal-final', 'engine-final', 'types-final-green', 'lint-corrected', 'lint-tail', 'loader-final', 'build-final-green', 'precache-final-green', 'full-quiet', 'browser-en-360-final', 'browser-zh-CN-360-final', 'browser-en-1280-final', 'browser-zh-CN-1280-final']
receipts = {label: json.loads((p / (label + '-result.json')).read_text()) for label in labels}
for label, receipt in receipts.items():
    assert receipt['exitCode'] == 0, (label, receipt)
full = (p / 'full-quiet.log').read_text(errors='replace')
m = re.search(r'Test Files\s+(\d+) passed.*?Tests\s+(\d+) passed\s*\|\s*(\d+) skipped', full, re.S)
assert m
full_files, full_tests, skips = map(int, m.groups())
assert (full_files, full_tests, skips) == (711, 15610, 2)
frozen = json.loads((p / 'frozen.json').read_text())
for key, base in [('source', root), ('build', p / 'build')]:
    for name, want in frozen[key].items():
        assert sha((base / name).read_bytes()) == want, (key, name)
assert sha(gzip.decompress((root / 'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())) == frozen['genuine']
all_receipts = {str(q.relative_to(p)).removesuffix('-result.json'): json.loads(q.read_text())
                for q in sorted(p.rglob('*-result.json'))}
failed = {key: value for key, value in all_receipts.items() if value['exitCode'] != 0}
other_pass = {key: value for key, value in all_receipts.items() if key not in receipts and value['exitCode'] == 0}
assert failed['geometry-red']['exitCode'] == 1
assert failed['types-final']['exitCode'] == 2
assert failed['browser-en-360']['exitCode'] == 1
dump(out / 'terminal-results.json', {'finalPass': receipts, 'otherPass': other_pass,
     'failed': failed, 'fullTests': full_tests, 'fullFiles': full_files, 'existingSkips': skips,
     'correctionNotes': 'Original geometry/schema/UI REDs, initial contract field assumptions, copied browser warcry prose expectation, and test-only TypeScript corrections are retained separately. No weakened combat assertions or timeouts.'})
files = [q for q in sorted(p.rglob('*')) if q.is_file() and not q.is_symlink() and not q.is_relative_to(p / 'build')]
archive = out / 'raw.tar.gz'
members = []
with tarfile.open(archive, 'w:gz') as tar:
    for file in files:
        name = str(file.relative_to(p))
        members.append({'path': name, 'sha256': sha(file.read_bytes()), 'bytes': file.stat().st_size})
        tar.add(file, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {m['path'] for m in members}
    for member in members:
        stream = tar.extractfile(member['path'])
        assert stream is not None and sha(stream.read()) == member['sha256']
dump(out / 'packet.json', {'archive': 'raw.tar.gz', 'archiveSha256': sha(archive.read_bytes()),
     'archiveBytes': archive.stat().st_size, 'members': members,
     'excludedDisposable': {'build': '761build assets represented by frozen hashes; no duplicate build copy'},
     'traceRetention': 'Original browser failure screenshot and full trace zip retained byte-exact.',
     'receiptNote': 'Only finalPass entries establish the final handoff checks. All original failures and intermediate passes remain separate.',
     'verification': {'archiveMembers': len(members), 'allMemberHashesMatch': True,
                      'sourceFiles': len(frozen['source']), 'buildFiles': len(frozen['build']),
                      'fullFiles': full_files, 'fullTests': full_tests, 'skips': skips}})
print(json.dumps({'archiveMembers': len(members), 'archiveBytes': archive.stat().st_size,
                  'fullFiles': full_files, 'fullTests': full_tests, 'skips': skips}))
