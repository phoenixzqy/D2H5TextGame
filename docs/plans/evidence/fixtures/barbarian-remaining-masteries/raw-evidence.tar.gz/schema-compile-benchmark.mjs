// Exploratory benchmark; run from the claimed repository, never a release gate.
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { readFileSync, writeFileSync, renameSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
const require = createRequire(resolve('package.json'));
const Ajv2020 = require('ajv/dist/2020').default;
const schema = JSON.parse(readFileSync('src/data/schema/skill.schema.json', 'utf8'));
const rows = JSON.parse(readFileSync('src/data/skills/barbarian.json', 'utf8'));
function measure(shared) {
  const start = performance.now();
  let validate;
  for (let i = 0; i < 24; i++) {
    if (!validate || !shared) validate = new Ajv2020({ strict: true, allErrors: true }).compile(schema);
    if (!rows.every(row => validate(row))) throw new Error('Authored schema rejected data');
  }
  return { compilations: shared ? 1 : 24, validations: 24 * rows.length, elapsedMs: performance.now() - start };
}
const result = { context: 'Exploratory local CPU benchmark while full unit suite runs; no application-performance acceptance', schema: schema.$id, baseline: measure(false), shared: measure(true) };
const taskRoot = '/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-remaining-masteries-i5r4g6lk/';
renameSync(taskRoot + 'schema-compile-cost.json', taskRoot + 'schema-compile-cost-initial.json');
writeFileSync(taskRoot + 'schema-compile-cost.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result));
