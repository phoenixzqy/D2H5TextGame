Previous goal turn: progress. Cleansing runtime dcaa59b and verification1da15e1 committed; complete private v1 remains open.
Worktree claim: existing human-worktree-2 in_use, session01a1577a-5af4-70e3-8699-50a906877d8f verified read-only. Preserve branch, original checkout and umbrella claim. Root sole writer; no subagents, campaign actions or remote publication.

Security check: pass
Scope: selected Redemption local JSON/schema, engine, native integration, bilingual UI and verification.
Summary: no actionable security concern; strict copied tuning and living ownership guards remain required.
Findings: none. No credentials, dependencies, CI bypass, network publication or authorization changes.

Plan review: ready
Root cause: advertised Redemption has neither selected projection nor corpse/recovery consumer. Reuse existing wave-local FIFO corpse pool and shared aura timeline; never create a second death observer/pool or substitute the separately governed item.redemption self-heal.
Contract: preserve unlock30, Meditation prerequisite, cap20 and authored2% life/mana recovery per rank. Provisional JSON redemption={intervalMs:5000,life:20,mana:10}. One oldest primary enemy-monster corpse per due pulse restores both living eligible recipients, each resource independently floored/capped. Skip without debit when no positive recovery is possible. No free baseline regen, Prayer/Meditation synergy, action/mana/RNG cost or corpse/timer/potency save.
Order: periodic deaths and baseline mana settlement, then aura consumption/recovery, then surviving actions. Existing earlier CE/PE casts win; a due pulse wins a tie with a later action. Keep deadline/action-cap/battle-end/hero-death guards and existing primary/orphan/summon/deathsHandled rules.
RED actual resource/corpse consequences and controls, then strict schema/definition copying, native public learning/replay/import and bilingual UI. Implement incrementally; focused/engine/types/lint/build/bridge/browser checks, then full alone with source/build/HEAD/status/genuine-save hashes frozen. Retain original failures, final results and exact cleanup receipt; local commits only.
