import gzip,hashlib,json,shutil,socket,tarfile
from pathlib import Path
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-radament-calibration-79tbdt04')
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
browser=root/'browser256'
report=json.loads((browser/'report.json').read_text());assert report['status']=='observed'
audit=json.loads((browser/'audit.json').read_text());assert audit['nextOrdinal']==257
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',4407))!=0,'preview still live'
removed=[];absent=[]
for name in ['dist','downloads']:
 p=root/name
 if p.exists():
  assert not p.is_symlink() and p.resolve()==root.resolve()/name
  count=sum(1 for f in p.rglob('*') if f.is_file())
  shutil.rmtree(p);assert not p.exists();removed.append({'path':str(p),'files':count})
 else:absent.append(str(p))
cleanup={'removed':removed,'alreadyAbsent':absent,'remaining':[],'failures':[],
 'previewPortClosed':4407,'validationAndBrowserTerminal':True}
(root/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
owner=json.loads((root/'artifact-ownership.json').read_text())
owner['retainedReason']='Independent review and full-v1 campaign integration consumers; root removes after consumers finish.'
owner['exactRetainedFiles']=sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())
(root/'artifact-ownership.json').write_text(json.dumps(owner,indent=2)+'\n')
packet=repo/'docs/plans/evidence/fixtures/earned-radament-attempt256'
packet.mkdir(parents=True,exist_ok=False)
raw=(browser/'final.json.gz').read_bytes()
(packet/'retained-final.json.gz').write_bytes(raw)
inventory=[]
for p in sorted(root.rglob('*')):
 if p.is_file():
  assert not p.is_symlink()
  inventory.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
archive=packet/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for row in inventory:tar.add(root/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(inventory)
 for member,row in zip(members,inventory):
  assert member.name==row['path'] and member.isfile()
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
save=json.loads(gzip.decompress(raw))
manifest={'runtime':report['runtime'],'kind':'Historical earned continuation; not fresh-current C2 or full balance acceptance',
 'inputRawSha256':'5105a89cc1584baa2a4aea3140147965d1c54bb2570c16e29d70512df7a32573',
 'finalRawSha256':hashlib.sha256(gzip.decompress(raw)).hexdigest(),
 'retainedFinalGzipSha256':hashlib.sha256(raw).hexdigest(),'finalLevel':save['player']['level'],
 'experience':save['player']['experience'],'skillPoints':save['player']['skillPoints'],
 'normalOrdinalBefore':256,'normalOrdinalAfter':257,'outcome':report['outcome'],
 'ancestralItems':audit['ancestralItems'],'finalItems':audit['finalItems'],
 'archive':{'file':'raw.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'records':len(inventory),'inventory':inventory},
 'diagnosticRetention':{'path':str(root),'owner':'root','reason':owner['retainedReason']},'cleanup':cleanup}
(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='archive'},indent=2))
print(json.dumps({k:v for k,v in manifest['archive'].items() if k!='inventory'},indent=2))
