import { readFile, writeFile, readdir } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-radament-calibration-79tbdt04/browser256';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try{
 const {validateSave}=await server.ssrLoadModule('/src/engine/save/validate.ts');
 const all=[];
 for(const file of (await readdir(root)).filter(x=>x.endsWith('.json.gz'))){
  const s=JSON.parse(gunzipSync(await readFile(root+'/'+file)));
  if(s.version===20&&s.player){validateSave(s);all.push(file);}
 }
 const read=async n=>JSON.parse(gunzipSync(await readFile(root+'/'+n+'.json.gz')));
 const input=await read('input'),final=await read('final');
 assert.equal(input.map.challengeOrdinals.normal,256);
 assert.equal(final.map.challengeOrdinals.normal,257);
 const owned=s=>{
  const items=[...s.inventory.backpack,...s.inventory.stash,...Object.values(s.inventory.equipped),...Object.values(s.mercs.mercEquipment).flatMap(Object.values)].filter(Boolean);
  const map=new Map(items.map(x=>[x.id,x]));assert.equal(map.size,items.length);return map;
 };
 const old=owned(input),now=owned(final);
 for(const [id,item] of old)assert.deepEqual(now.get(id),item,id);
 const pairs=[];
 for(const file of all.filter(x=>x.endsWith('-saved.json.gz'))){
  const prefix=file.slice(0,-'-saved.json.gz'.length),a=await read(prefix+'-saved'),b=await read(prefix+'-continued');
  const idle=b.meta.idleState;
  assert.deepEqual(b,{...a,timestamp:b.timestamp,meta:{...a.meta,idleState:{...a.meta.idleState,
   lastOnline:idle.lastOnline,offlineTime:idle.offlineTime,activeMultiplier:idle.activeMultiplier,multiplierSecondsRemaining:idle.multiplierSecondsRemaining}}});
  pairs.push(prefix);
 }
 const report=JSON.parse(await readFile(root+'/report.json','utf8'));
 assert.equal(report.status,'observed');assert.equal(report.launches,1);assert.equal(report.retries,0);
 assert.deepEqual(report.errors,[]);assert.deepEqual(report.console,[]);assert.deepEqual(report.freezeDrift,[]);
 const audit={kind:'root self-audit, not independent acceptance',nativeSaves:all,durablePairs:pairs,
  ancestralItems:old.size,finalItems:now.size,newItems:now.size-old.size,outcome:report.outcome,
  nextOrdinal:257,retainedFinal:'final.json.gz'};
 await writeFile(root+'/audit.json',JSON.stringify(audit,null,2)+'\n');process.stdout.write(JSON.stringify(audit)+'\n');
}finally{await server.close();}
