import hashlib,json,os,subprocess,time
from pathlib import Path
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-radament-calibration-79tbdt04')
env=dict(os.environ);env.pop('VITE_E2E',None)
def snapshot():
 paths=[]
 for name in ['src','tests']:
  paths.extend(p for p in (repo/name).rglob('*') if p.is_file() and 'node_modules' not in p.parts)
 paths.extend(p for p in repo.iterdir() if p.is_file() and p.suffix in ['.json','.ts','.js','.mjs'])
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=snapshot();(root/'source-freeze.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[
 ('typecheck',['npm','run','typecheck']),
 ('lint',['npm','run','lint']),
 ('engine',['npm','run','test:engine']),
 ('full',['npm','test']),
 ('build',['npm','run','build','--','--outDir',str(root/'dist')])]
results=[]
for name,cmd in commands:
 start=time.monotonic()
 with (root/(name+'.log')).open('w') as f:
  p=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start}
 results.append(row);print(json.dumps(row),flush=True)
 (root/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode:raise SystemExit(p.returncode)
assert snapshot()==before,'source drift during validation'
build={str(p.relative_to(root/'dist')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'dist').rglob('*')) if p.is_file()}
js=[p for p in (root/'dist').rglob('*.js') if p.is_file()]
tokens=['__GAME__','__testBridge','window.__game','VITE_E2E']
for p in js:
 text=p.read_text()
 for token in tokens:assert token not in text,(p,token)
(root/'build-freeze.json').write_text(json.dumps(build,indent=2)+'\n')
print(json.dumps({'sourceCount':len(before),'buildCount':len(build),'bridgeFreeJS':len(js),'drift':[]}),flush=True)
