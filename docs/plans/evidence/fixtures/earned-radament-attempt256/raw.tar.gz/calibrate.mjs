import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import { readFile, writeFile } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-radament-calibration-79tbdt04';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const phase=process.argv[2];assert(['before','after'].includes(phase));
const raw=gunzipSync(await readFile(repo+'/docs/plans/evidence/fixtures/earned-radament-attempt255/retained-final.json.gz'));
const hash=createHash('sha256').update(raw).digest('hex');
assert.equal(hash,'5105a89cc1584baa2a4aea3140147965d1c54bb2570c16e29d70512df7a32573');
const save=JSON.parse(raw);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
const percentiles=values=>{const a=[...values].sort((x,y)=>x-y);return {p50:a[Math.floor((a.length-1)*.5)]??null,p95:a[Math.floor((a.length-1)*.95)]??null};};
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave,observeEarnedState}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {playerToCombatUnit}=await load('/src/stores/combatHelpers.ts');
 const {mercToCombatUnit}=await load('/src/stores/mercToCombatUnit.ts');
 const {runBattleRecorded}=await load('/src/engine/combat/combat.ts');
 const {buildMonsterUnit}=await load('/src/engine/combat/monster-factory.ts');
 const {createRng}=await load('/src/engine/rng.ts');
 const {resolveChallengeWavePlan}=await load('/src/engine/combat/sub-area-run.ts');
 const {resolveSubArea}=await load('/src/stores/subAreaResolver.ts');
 const {monsters}=await load('/src/data/index.ts');
 const defs=new Map(monsters.map(x=>[x.id,x]));
 const rad=defs.get('monsters/act2.radament');assert(rad);
 const native=[];
 for(let seed=1;seed<=64;seed++){
  restoreEarnedSave(save,0);
  const prepared=observeEarnedState();assert.equal(prepared.map.challengeOrdinals.normal,256);
  const handle=startEarnedRun({act:2,subAreaId:'areas/act2-far-oasis',mode:'manual',runSeed:seed});
  assert.equal(handle.challengeOrdinal,256);
  const target=playEarnedTarget(handle),after=observeEarnedState();
  assert.equal(after.map.challengeOrdinals.normal,257);
  const waves=target.waves.map(w=>{
   const boss=w.opening.enemyTeam.find(x=>x.monsterArchetypeId==='monsters/act2.radament');
   const endBoss=boss&&w.played.outcome.finalEnemyTeam.find(x=>x.id===boss.id);
   const actions=w.opening.recordedEvents.filter(e=>e.kind==='action');
   const damage=w.opening.recordedEvents.filter(e=>e.kind==='damage');
   if(w.played.outcome.winner!=='player'){
    assert.equal(w.actualDelta.xp,0);assert.deepEqual(w.actualDelta.addedItems,[]);
   }
   return {index:w.index,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,xp:w.actualDelta.xp,
    gear:w.actualDelta.addedItems.length,...(boss?{bossLife:boss.life,remaining:endBoss.life,
     bossActions:Object.fromEntries([...new Set(actions.filter(e=>e.actor===boss.id).map(e=>e.skillId))].map(id=>[id,actions.filter(e=>e.actor===boss.id&&e.skillId===id).length])),
     damageBySource:Object.fromEntries([...new Set(damage.filter(e=>e.target===boss.id).map(e=>e.source))].map(id=>[id,damage.filter(e=>e.target===boss.id&&e.source===id).reduce((n,e)=>n+e.amount,0)])),
     heroManaAtEntry:w.opening.playerTeam.find(x=>x.kind==='hero').mana}:{}),
    heroAlive:w.played.outcome.finalPlayerTeam.find(x=>x.kind==='hero').life>0};
  });
  native.push({seed,phase:seed<=32?'screen':'holdout',terminal:target.terminalAdvance,waves});
  useCombatStore.getState().endCombat();
  if(seed%8===0)process.stdout.write(`${phase} native ${seed}/64\n`);
 }
 const nativeSummary=['screen','holdout'].map(group=>{
  const a=native.filter(x=>x.phase===group),wins=a.filter(x=>x.terminal==='victory');
  return {group,n:a.length,wins:wins.length,deaths:a.filter(x=>!x.waves.at(-1).heroAlive).length,
   bossTTK:percentiles(wins.map(x=>x.waves.at(-1).ms)),
   totalTTK:percentiles(wins.map(x=>x.waves.reduce((n,w)=>n+w.ms,0))),
   failures:a.filter(x=>x.terminal!=='victory').map(x=>({seed:x.seed,wave:x.waves.at(-1).index+1,outcome:x.waves.at(-1).winner}))};
 });
 await writeFile(root+'/'+phase+'-native.json',JSON.stringify({inputHash:hash,ordinal:256,kind:'independent full-area projections; native entry/playback/awards/carry; no state promoted',definition:rad,nativeSummary,rows:native},null,2)+'\n');
 process.stdout.write(JSON.stringify({nativeSummary})+'\n');
 restoreEarnedSave(save,0);
 const hero=playerToCombatUnit(save.player);hero.life=hero.stats.lifeMax;hero.mana=hero.stats.manaMax;
 const merc=save.mercs.ownedMercs.find(x=>x.id===save.mercs.fieldedMercId);assert(merc);
 const rogue=mercToCombatUnit(merc,save.formation.mercPosition,save.mercs.mercEquipment[merc.id]);
 const area=resolveSubArea(2,'areas/act2-far-oasis');assert(area);
 const isolated=[];
 for(let seed=1;seed<=1000;seed++){
  const plan=resolveChallengeWavePlan({subArea:area,fallbackArchetypeId:'monsters/act2.sand-raider',fallbackLevel:18,seed,challengeOrdinal:256,mode:'manual',idleEliteMisses:0});
  const wi=plan.waves.findIndex(w=>w.spawns.some(s=>s.archetypeId===rad.id));assert(wi>=0);
  const waveSeed=(seed^((wi+1)*0x9e3779b1))>>>0,rng=createRng(waveSeed);
  const enemies=plan.waves[wi].spawns.map(spawn=>buildMonsterUnit({def:defs.get(spawn.archetypeId),level:spawn.level,tier:spawn.tier,index:spawn.index,rng}));
  const boss=enemies.find(x=>x.monsterArchetypeId===rad.id);assert(boss);
  const battle=runBattleRecorded({seed:waveSeed,act:2,playerTeam:[hero,rogue],enemyTeam:enemies});
  const end=battle.events.at(-1),remaining=battle.result.enemyTeam.find(x=>x.id===boss.id).life;
  isolated.push({seed,winner:battle.result.winner,ms:end.simClockMs,bossLife:boss.life,remaining,
   heroAlive:battle.result.playerTeam.find(x=>x.kind==='hero').life>0,
   damage:boss.life-remaining});
  if(seed%250===0)process.stdout.write(`${phase} isolated ${seed}/1000\n`);
 }
 const wins=isolated.filter(x=>x.winner==='player');
 const isolatedSummary={n:isolated.length,wins:wins.length,deaths:isolated.filter(x=>!x.heroAlive).length,
  bossLife:[Math.min(...isolated.map(x=>x.bossLife)),Math.max(...isolated.map(x=>x.bossLife))],
  victoryTTK:percentiles(wins.map(x=>x.ms)),failureTime:percentiles(isolated.filter(x=>x.winner!=='player').map(x=>x.ms)),
  meanBossDamage:isolated.reduce((n,x)=>n+x.damage,0)/isolated.length};
 await writeFile(root+'/'+phase+'-isolated.json',JSON.stringify({inputHash:hash,kind:'1000 isolated optimistic boss-wave projections; full resources; not full-area/earned/cross-class acceptance',definition:rad,isolatedSummary,rows:isolated},null,2)+'\n');
 process.stdout.write(JSON.stringify({isolatedSummary})+'\n');
}finally{await server.close();}
