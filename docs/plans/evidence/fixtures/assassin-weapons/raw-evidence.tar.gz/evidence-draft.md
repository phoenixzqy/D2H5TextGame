# D05 — Assassin weapons and learned weapon passives / BUG176

Local implementation in the existing claimed worktree. Independent acceptance,
earned class/build balance and C2–C4/full G0–G7 remain open.

Hero explicit offhand selection now accepts authored one-handed weapons, with
picker, preview and transaction using canonical base compatibility. Automatic
equips retain the main-hand destination. Owned-instance authority, requirements,
backpack capacity and two-handed displacement remain atomic. Existing aggregate
weapon stats count both items once; no alternating attacks, extra RNG or save fields.
Mercenary slot policy stays separate.

Six localized claw bases copy existing one-handed sword tuning at levels1/8/22/
32/50/60; the dagger art proxy is reused.27 ordinary sword allocations now supply
29claw entries. Hand Scythe and Runic Talons share the existing Greater/Feral Claws
allocations in Act III/V trash respectively. All38table totals and level bands
are conserved. Recombining claw shares reconstructs the original tables exactly;
forced unique/set entries and legacy unique-base mappings remain unchanged.

Claw Mastery adds2.5%Attack/0.5pp critical chance per rank with a main-hand one-handed
claw. Weapon Block adds1pp physical/0.5pp magical dodge per rank with two distinct
one-handed weapon instances and learned Claw Mastery. Unlocks1/12 and caps20 come
from strict copied JSON definitions. Exact aliases resolve maximum once; invalid
allocations, classes, levels and equipment cannot grant the effects. Composition
is fresh at the player boundary and affects the next wave without persisting the
bonuses or refilling pools. Bilingual descriptions/current-next rows match runtime.

Verification results will be filled from terminal process receipts.

The initial full run exposed16failures: five quest Claim/UI cases correctly refused
unsupported forced unique rewards; other failures were literal catalog/loot
assertions. Two new regressions failed causally before restoring forced-template
rows. No rarity downgrade or guard was permitted. That correction exposed two
unreachable claw tiers; ordinary sources now make all six obtainable. Three earlier
acquisition oracle failures confused drop eligibility with equip requirement and
were corrected against the unchanged donor bands. Type/lint authoring errors and
every failed/abandoned attempt remain in raw evidence; no test/timeout was weakened.

Genuine campaign resume remains byte-exact at decompressed SHA256
c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577,
nextNormal402. No genuine action or diagnostic promotion occurred. Existing bundle,
PWA-manifest and test/performance budget limits remain unresolved. Root self-review
only. No remote publication or deployment.
