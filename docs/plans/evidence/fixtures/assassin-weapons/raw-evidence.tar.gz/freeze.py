import sys,json,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
paths=sorted(set(p for p in files if p and (p.startswith(('src/','tests/','scripts/')) or '/' not in p) and Path(p).is_file()))
snapshot={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'status':subprocess.check_output(['git','status','--porcelain=v1','-uall'],text=True),
 'hashes':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}}
if sys.argv[1]=='before':
 (root/'full-before.json').write_text(json.dumps(snapshot,indent=2))
 print(json.dumps({'frozenFiles':len(paths),'head':snapshot['head']}))
else:
 before=json.loads((root/'full-before.json').read_text())
 changes=[p for p in set(before['hashes'])|set(snapshot['hashes']) if before['hashes'].get(p)!=snapshot['hashes'].get(p)]
 result={'files':len(paths),'headUnchanged':before['head']==snapshot['head'],'statusUnchanged':before['status']==snapshot['status'],'changedFiles':changes}
 (root/'full-freeze-verification.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result));assert before==snapshot
