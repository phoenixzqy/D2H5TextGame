import subprocess
paths=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z']).decode().split('\0')
paths=sorted(set(p for p in paths if p.endswith(('.ts','.tsx'))))
print('Explicit lint paths:',len(paths),flush=True)
subprocess.run(['node_modules/.bin/eslint',*paths,'--no-ignore','--max-warnings=0'],check=True)
