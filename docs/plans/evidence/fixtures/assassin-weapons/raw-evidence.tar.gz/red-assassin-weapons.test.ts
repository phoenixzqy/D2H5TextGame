import { beforeEach, expect, it } from 'vitest';
import { createMockPlayer } from '@/features/character/createMockPlayer';
import { loadItemBases } from '@/data/loaders/loot';
import { slotCandidates, compareEquip } from '@/features/inventory/compareEquip';
import { playerToCombatUnit } from './combatHelpers';
import { useInventoryStore } from './inventoryStore';
import { usePlayerStore } from './playerStore';
import type { Item } from '@/engine/types/items';
const item = (id: string, baseId = 'items/base/wp1h-short-sword'): Item => ({ id, baseId,
  rarity: 'normal', level: 1, identified: true, equipped: false });
beforeEach(() => {
  useInventoryStore.getState().reset(); usePlayerStore.getState().reset();
  usePlayerStore.getState().setPlayer({ ...createMockPlayer('Constructed Assassin', 'assassin'), level: 30 });
});
it('equips an owned one-handed weapon into the explicit offhand with a matching preview', () => {
  const main = item('main'), other = item('other');
  useInventoryStore.getState().addItem(main); useInventoryStore.getState().addItem(other);
  expect(useInventoryStore.getState().equipItem(main)).toEqual({ ok: true });
  const player = usePlayerStore.getState().player; if (!player) throw new Error('Missing player');
  const preview = compareEquip(player, other, 'offhand', useInventoryStore.getState().equipped);
  expect(slotCandidates(useInventoryStore.getState().backpack, 'offhand')).toContainEqual(other);
  expect(useInventoryStore.getState().equipItem(other, 'offhand')).toEqual({ ok: true });
  expect(useInventoryStore.getState().equipped.weapon?.id).toBe(main.id);
  expect(useInventoryStore.getState().equipped.offhand?.id).toBe(other.id);
  expect(usePlayerStore.getState().player?.derivedStats.attack).toBe(preview.stats.attack.candidate);
});
it('provides a real level-one claw base instead of treating Assassin claws as swords', () => {
  const claw = loadItemBases().get('items/base/wp1h-katar');
  expect(claw).toMatchObject({ type: 'weapon', slot: 'weapon', handedness: 'oneHanded', weaponType: 'claw', reqLevel: 1 });
});
it('applies Weapon Block to two distinct equipped one-handed weapons at the authored cap', () => {
  const player = usePlayerStore.getState().player; if (!player) throw new Error('Missing player');
  useInventoryStore.setState({ equipped: { weapon: item('main'), offhand: item('other') } });
  const plain = playerToCombatUnit(player);
  const actual = playerToCombatUnit({ ...player, skillLevels: { 'assassin.claw_mastery': 1, 'assassin.weapon_block': 20 } });
  expect(actual.stats.physDodge).toBeCloseTo(plain.stats.physDodge + .2, 12);
  expect(actual.stats.magicDodge).toBeCloseTo(plain.stats.magicDodge + .1, 12);
});

it('applies Claw Mastery Attack and critical chance only with a main-hand claw', () => {
  const player = usePlayerStore.getState().player; if (!player) throw new Error('Missing player');
  useInventoryStore.setState({ equipped: { weapon: item('claw', 'items/base/wp1h-katar') } });
  const plain = playerToCombatUnit(player);
  const actual = playerToCombatUnit({ ...player, skillLevels: { 'assassin.claw_mastery': 20 } });
  expect(actual.stats.attack).toBeCloseTo(plain.stats.attack * 1.5, 12);
  expect(actual.stats.critChance).toBeCloseTo(plain.stats.critChance + .1, 12);
  expect(actual.life).toBe(plain.life); expect(actual.mana).toBe(plain.mana);
});
