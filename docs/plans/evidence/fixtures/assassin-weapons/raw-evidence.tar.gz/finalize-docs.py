import csv,io,json,re,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert sha!='c5a20f72735cdaab2744f5fb45b902f3b71af655'
for path,digest in json.loads((root/'full-before.json').read_text())['hashes'].items():
 assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==digest,path
checks={name:json.loads((root/(name+'.result.json')).read_text()) for name in ['full-complete','engine-complete','types-complete','lint-complete','changed-lint-complete','build-complete','browser-complete']}
assert all(d['exit']==0 for d in checks.values())
freeze=json.loads((root/'full-freeze-verification.json').read_text())
assert freeze['headUnchanged'] and freeze['statusUnchanged'] and not freeze['changedFiles']
full=(root/'full-complete.log').read_text();m=re.search(r'Tests\s+(\d+) passed \| (\d+) skipped',full);assert m
passed,skipped=map(int,m.groups());assert passed==12028 and skipped==2
validation=f"""- Final engine:5936PASS/194files,{checks['engine-complete']['seconds']}s.
- Final full:`npm test -- --reporter=dot`:12028PASS/491files,two existing skips,
  {checks['full-complete']['seconds']}s. All{freeze['files']}source/test/config files, HEAD and full Git state
  stayed unchanged for the complete run. The earlier pre-grant full12017PASS/490
  and failed full11998PASS/16FAIL are retained separately.
- Final typecheck, standard lint and explicit28changed-file lint PASS.
  Production build with VITE_E2E=false PASS; all4JS chunks pass all5repository
  bridge-symbol checks. Existing bundle/PWA-manifest warnings and test/performance
  budgets remain open.
"""
draft=(root/'evidence-complete-draft.md').read_text().replace('FINAL_RESULTS',validation)
draft=draft.replace('Local implementation in the existing claimed worktree.',f'2026-10-24. Implementation `{sha[:7]}`, baseline `c5a20f7`.\nLocal implementation in the existing claimed worktree.')
(repo/'docs/plans/evidence/d05-assassin-weapons.md').write_text(draft)
f=repo/'production/bugs/BUG-176-assassin-weapon-foundations.md'
s=f.read_text().replace('Status: reproduced; implementation in progress.',f'Status: fixed locally in `{sha[:7]}`; independent acceptance and earned balance open.')
s+='\nFinal verification and retained causal regressions: [D05 evidence](../../docs/plans/evidence/d05-assassin-weapons.md).\n'
f.write_text(s)
f=repo/'docs/plans/skill-inventory.csv';lines=f.read_text().splitlines(keepends=True)
header=next(csv.reader([lines[0]]));ids={'skills-assassin-claw-mastery','skills-assassin-weapon-block'};changed=[]
for i,line in enumerate(lines[1:],1):
 row=next(csv.reader([line]));d=dict(zip(header,row))
 if d['data_id'] not in ids:continue
 assert d['behavior_verification']=='unverified'
 for key,value in {'adapter_route':'buff-metadata+weapon-gated-fresh-player-composition','risk_flags':'earned-class-build-balance-open','behavior_verification':'bounded-functional;independent-acceptance-open','contract_evidence':'docs/plans/evidence/d05-assassin-weapons.md'}.items():row[header.index(key)]=value
 out=io.StringIO();csv.writer(out,lineterminator='\n').writerow(row);lines[i]=out.getvalue();changed.append(d['data_id'])
assert set(changed)==ids
f.write_text(''.join(lines));rows=list(csv.DictReader(f.open()));assert len(rows)==213 and sum(r['behavior_verification']=='unverified' for r in rows)==187
f=repo/'docs/plans/execution-ledger.md';s=f.read_text();anchor='| --- | --- | --- |\n';assert anchor in s
card=f"| D05 Assassin weapons / BUG176 | implemented in `{sha[:7]}`; locally verified; independent acceptance pending | Six obtainable claw tiers, explicit one-handed offhand equip, canonical preview/transaction/runeword grants, learned Claw Mastery/Weapon Block and truthful bilingual details. Focused85, loot/quest138, grant78; engine5936/194, full12028/491+two existing skips; types/lint/build/bridge PASS. Production8/8, eight exact Continue pairs, no retries/errors;1202source hashes/Git state unchanged. [Evidence](evidence/d05-assassin-weapons.md).187unverified skills remain; earned class/build balance and C2–C4/fullG open. Genuine Ancients save unchanged/next402; no campaign action or remote publication. |\n"
f.write_text(s.replace(anchor,anchor+card,1))
(root/'validation-summary.json').write_text(json.dumps({'implementation':sha,'checks':checks,'freeze':freeze,'inventory':{'total':213,'unverified':187,'changed':changed}},indent=2))
print(json.dumps({'implementation':sha,'inventoryRowsChanged':changed,'passed':passed,'unverified':187}))
