from pathlib import Path
import json,hashlib,tarfile,shutil,socket
root=Path('/tmp/d2h5-assassin-weapons-b3rh1x0t')
dest=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/assassin-weapons')
assert root.exists() and root.resolve()==root and not root.is_symlink()
manifest=json.loads((dest/'manifest.json').read_text());archive=dest/'raw-evidence.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive']['sha256']
with tarfile.open(archive,'r:gz') as tar:
 for f in manifest['files']:
  data=tar.extractfile(f['name']).read();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256']
with socket.socket() as s:assert s.connect_ex(('127.0.0.1',4458))!=0
ownedDirectories=sorted(str(p) for p in root.iterdir() if p.is_dir())
shutil.rmtree(root)
assert not root.exists()
with socket.socket() as s:closed=s.connect_ex(('127.0.0.1',4458))!=0
assert closed
receipt={'removedRoot':str(root),'rootAbsent':True,'disposableDirectories':ownedDirectories,'port4458Closed':closed,'archiveByteVerifiedBeforeRemoval':True,'failures':[],'remainingTaskScratchPaths':[],'claim':'preserved for active full-v1 goal'}
(dest/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
