import { readFile, readdir } from 'node:fs/promises';
const { default: Ajv } = await import(process.cwd() + '/node_modules/ajv/dist/2020.js');
const read = async path => JSON.parse(await readFile(path, 'utf8'));
const cases = [['item-base', 'src/data/items/bases.json'], ['drop-table', 'src/data/loot/treasure-classes.json']];
const ajv = new Ajv({ strict: true, allErrors: true }); let count = 0;
for (const [kind, file] of cases) {
  const validate = ajv.compile(await read('src/data/schema/' + kind + '.schema.json'));
  for (const row of await read(file)) { if (!validate(row)) throw Error(row.id + JSON.stringify(validate.errors)); count++; }
}
const validate = ajv.compile(await read('src/data/schema/skill.schema.json'));
for (const file of await readdir('src/data/skills')) {
  if (!file.endsWith('.json')) continue;
  const rows = await read('src/data/skills/' + file);
  if (!Array.isArray(rows)) continue;
  for (const row of rows) { if (!validate(row)) throw Error(row.id + JSON.stringify(validate.errors)); count++; }
}
console.log(JSON.stringify({ validRows: count, strict: true, allErrors: true }));
