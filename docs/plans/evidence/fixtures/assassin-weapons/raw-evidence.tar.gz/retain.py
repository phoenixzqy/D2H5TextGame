import json,hashlib,tarfile,shutil,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=repo/'docs/plans/evidence/fixtures/assassin-weapons'
assert root==Path('/tmp/d2h5-assassin-weapons-b3rh1x0t') and not root.is_symlink()
processes=[]
for p in sorted(root.glob('*.process.json')):
 r=p.with_name(p.name.replace('.process.json','.result.json'))
 assert r.is_file(),p
 a=json.loads(p.read_text());b=json.loads(r.read_text())
 assert a['pid']==b['pid'] and a['command']==b['command']
 processes.append({'name':b['name'],'pid':b['pid'],'exit':b['exit'],'seconds':b['seconds']})
for n in ['full-complete','browser-complete','engine-complete','types-complete','lint-complete','build-complete']:
 assert json.loads((root/(n+'.result.json')).read_text())['exit']==0,n
freeze=json.loads((root/'full-freeze-verification.json').read_text())
assert freeze['headUnchanged'] and freeze['statusUnchanged'] and not freeze['changedFiles']
files=sorted(f for f in root.iterdir() if f.is_file())
manifest=[{'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for f in files:tar.add(f,arcname=f.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(manifest)
 for row in manifest:
  data=tar.extractfile(row['name']).read()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
for name in ['browser-complete-summary.json','full-freeze-verification.json','loot-conservation.json','campaign-unchanged.json']:
 shutil.copyfile(root/name,dest/name)
for i in [0,15]:shutil.copyfile(root/f'complete-inspect-{i}.png',dest/f'inspect-{i}.png')
receipt={'files':manifest,'processes':processes,'archive':{'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyMemberByteVerified':True}}
(dest/'manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'terminalProcesses':len(processes),'archive':str(archive),'verified':True}))
