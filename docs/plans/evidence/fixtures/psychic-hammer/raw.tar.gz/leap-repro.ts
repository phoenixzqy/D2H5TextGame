import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills, getSkill, registerSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry();loadDefaultSkills();
const id='skills-barbarian-leap',original=getSkill(id);assert.ok(original);const observations=[];
const hold:ActiveStatus={id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1,appliedAtMs:1701};
for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Leap','barbarian'),id:'hero',level:30,skillLevels:{[id]:rank},comboOrder:[id]});
 assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:100000,mana:100,statuses:[hold],manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
  stats:{...native.stats,lifeMax:100000,manaMax:100,attackSpeed:100,critChance:0,defense:0,magicResist:0}};
 const enemyTeam:CombatUnit[]=Array.from({length:3},(_,i)=>({...hero,id:'target-'+i,kind:'monster',side:'enemy',skillOrder:[],skillLevels:{},statuses:[],gridPosition:{row:0,col:i},
  stats:{...hero.stats,attackSpeed:0},basicAttack:{damage:[1,1],damageType:'physical'}}));
 const input={seed,playerTeam:[hero],enemyTeam},before=structuredClone(input);
 registerSkill(original);const actual=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),actual);
 registerSkill({...original,effects:original.effects.map(e=>e.kind==='debuff'?{...e,statusId:'synthetic-inert-control'}:e)});const control=runBattleRecorded(input);assert.deepEqual(input,before);
 const clocks=(out:typeof actual)=>Object.fromEntries(enemyTeam.map(u=>[u.id,out.events.filter(e=>e.kind==='action'&&e.actor===u.id).map(e=>e.simClockMs)]));
 const actualClocks=clocks(actual),controlClocks=clocks(control),knockback=actual.events.filter(e=>e.kind==='status'&&e.statusId==='knockback');
 const actualGrid=actual.result.enemyTeam.map(u=>u.gridPosition),controlGrid=control.result.enemyTeam.map(u=>u.gridPosition);
 const actions=actual.events.filter(e=>e.kind==='action'&&e.actor==='hero'),payments=actual.events.filter(e=>e.kind==='mana'&&e.reason==='cast');
 assert.equal(actions.length,1);assert.equal(payments.length,1);assert.equal(knockback.length,3);
 observations.push({rank,seed,actions,payments,knockback,actualClocks,controlClocks,actualGrid,controlGrid,
  heroBaseStats:native.stats,heroFinalStats:actual.result.playerTeam[0]?.stats,events:actual.events,
  controlConsequence:JSON.stringify(actualClocks)!==JSON.stringify(controlClocks)||JSON.stringify(actualGrid)!==JSON.stringify(controlGrid)});
}
registerSkill(original);
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-hammer-3d_s7863/leap-observations.json',JSON.stringify({synthetic:true,registered:original,observations},null,2));
console.log(JSON.stringify(observations.map(({rank,seed,knockback,controlConsequence})=>({rank,seed,markers:knockback.length,controlConsequence})),null,2));
assert.ok(observations.some(o=>o.controlConsequence),'Native paid Leap emits Knockback but no timing or spatial consequence in all twelve paired cases');
