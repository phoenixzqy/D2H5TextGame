from pathlib import Path
import json,re,hashlib
root=Path(__file__).resolve().parent
labels=['engine-complete','lint-complete','types-complete','build-complete','bridge-complete','browser-complete','browser-attachment-audit','full-complete']
for label in labels:
 result=json.loads((root/(label+'.result.json')).read_text());assert result['exit']==0,(label,result)
a,b=[json.loads((root/(label+'.json')).read_text()) for label in ['before-full-final','after-full-final']]
assert a==b
log=(root/'full-complete.log').read_text()
lines=[l.strip() for l in log.splitlines() if re.match(r'\s*(Test Files|Tests|Duration)\s',l)]
assert len(lines)==3,lines
assert 'failed' not in '\n'.join(lines)
assert re.search(r'Tests\s+12822 passed \| 2 skipped',log),lines
assert re.search(r'Test Files\s+540 passed',log),lines
result={'pass':True,'sourceFiles':len(a['sources']),'buildFiles':len(a['build']),'sourceBuildHeadStatusGenuineExact':True,'summary':lines,'genuineSha256':a['genuine'],'head':a['head'],'fullSeconds':json.loads((root/'full-complete.result.json').read_text())['seconds']}
(root/'full-freeze-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
