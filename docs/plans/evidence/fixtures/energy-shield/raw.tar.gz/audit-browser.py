from pathlib import Path
import json
root=Path(__file__).resolve().parent
browser=root/'browser-verified'
report=json.loads((browser/'browser-report.json').read_text())
labels=['en-1280','en-360','zh-CN-1280','zh-CN-360']
assert [r['label'] for r in report['cases']]==labels
assert report['failures']==[]
def save(pattern):
 files=list(browser.glob(pattern));assert len(files)==1,(pattern,files)
 return json.loads(files[0].read_text())
def domains(s):return {k:s[k] for k in ['player','inventory','map','mercs','formation']}
pairs=[]
for label,row in zip(labels,report['cases']):
 assert row['pass'] and row['errors']==[] and row['pairs']==['rank19','rank20']
 inp=save(label+'-synthetic-input.json');imported=save(label+'-imported-*.json')
 assert imported['player']['skillLevels']==inp['player']['skillLevels']=={'sorceress.telekinesis':1,'sorceress.teleport':1,'sorceress.energy_shield':19}
 for stage,rank in [('rank19',19),('rank20',20)]:
  before,after=[save(label+'-'+stage+'-'+side+'-*.json') for side in ['before','after']]
  assert before['version']==after['version']==22 and domains(before)==domains(after)
  assert after['player']['skillLevels']=={'sorceress.telekinesis':1,'sorceress.teleport':1,'sorceress.energy_shield':rank}
  assert after['player']['skillPoints']==20-rank and after['player']['comboOrder']==[]
  assert 'energyShieldRank' not in json.dumps(after)
  pairs.append({'case':label,'stage':stage,'fiveDomainsExact':True,'version':22})
 assert 0<=row['combat']['mana']<row['combat']['max'] and row['combat']['passiveNoCast']
 log=(browser/(label+'-combat.txt')).read_text()
 assert 'ShieldCheck casts' not in log and 'ShieldCheck 施放' not in log
 for name in ['details','combat']: assert (browser/(label+'-'+name+'.png')).is_file()
 geo=[r for r in report['geometry'] if r['label']==label]
 assert [(r['width'],r['height']) for r in geo]==[(360,640),(412,915),(640,360),(1280,800),(1920,1080)]
 assert all(r['overflow']<=0 and r['allocate']['width']>=44 and r['allocate']['height']>=44 for r in geo)
assert len(report['geometry'])==20
result={'pass':True,'syntheticOnly':True,'cases':4,'exactPairs':pairs,'geometrySamples':20,'screenshots':8,'scope':'Separate attachment audit, not independent QA or earned class/build acceptance. Actual rate/payment correctness comes from seeded native/engine assertions; browser proves public upgrade, passive visible MP consumption and Save/Continue.'}
(root/'browser-attachment-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='exactPairs'}))
