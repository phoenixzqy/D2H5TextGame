from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parent/'build-final'
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
 def do_GET(self):
  if not Path(self.translate_path(self.path)).exists(): self.path='/index.html'
  super().do_GET()
ThreadingHTTPServer(('127.0.0.1',4472),Handler).serve_forever()
