from pathlib import Path
import json,hashlib,os,socket
root=Path(__file__).resolve().parent
owner=json.loads((root/'owner.json').read_text())
assert str(root)==owner['scratch'] and root.name=='d2h5-energy-shield-l_sdwiqp' and not root.is_symlink()
assert owner['session']=='01a1577a-5af4-70e3-8699-50a906877d8f'
sha=lambda b:hashlib.sha256(b).hexdigest()
# Every tracked child must already be terminal. Never signal an unverified/reused PID.
for p in root.glob('*.process.json'):
 receipt=json.loads(p.read_text());proc=Path('/proc')/str(receipt['pid'])/'cmdline'
 if proc.exists():
  cmd=proc.read_bytes().replace(b'\0',b' ').decode()
  assert str(root) not in cmd,(p.name,receipt['pid'],cmd)
sock=socket.socket();assert sock.connect_ex(('127.0.0.1',4473))!=0;sock.close()
manifest=json.loads(Path('docs/plans/evidence/fixtures/energy-shield/manifest.json').read_text())
for name,entry in manifest['files'].items():assert sha((root/name).read_bytes())==entry['sha256'],name
paths=list(root.rglob('*'));files=[p for p in paths if p.is_file() or p.is_symlink()]
record={'scratch':str(root),'removedFiles':[], 'remaining':[], 'failures':[], 'previewPort4473Closed':True}
for p in sorted(files):
 relative=str(p.relative_to(root));entry={'path':relative,'sha256':None if p.is_symlink() else sha(p.read_bytes())}
 try:p.unlink();record['removedFiles'].append(entry)
 except Exception as e:record['failures'].append({'path':relative,'error':str(e)})
for p in sorted([p for p in paths if p.is_dir() and not p.is_symlink()],key=lambda p:len(p.parts),reverse=True):
 try:p.rmdir()
 except Exception as e:record['failures'].append({'path':str(p.relative_to(root)),'error':str(e)})
try:root.rmdir()
except Exception as e:record['failures'].append({'path':str(root),'error':str(e)})
record['scratchAbsent']=not root.exists()
if root.exists():record['remaining']=[str(p) for p in root.rglob('*')]
Path('docs/plans/evidence/fixtures/energy-shield/cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'removedFiles':len(record['removedFiles']),'scratchAbsent':record['scratchAbsent'],'remaining':record['remaining'],'failures':record['failures']}))
assert record['scratchAbsent'] and not record['remaining'] and not record['failures']
