from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
labels=['engine-final','lint-corrected','types-current','build-final','bridge-final','browser-verified','browser-attachment-audit','full-final']
for label in labels:
 result=json.loads((root/(label+'.result.json')).read_text());assert result['exit']==0,(label,result)
a,b=[json.loads((root/(label+'.json')).read_text()) for label in ['before-full','after-full']]
assert a==b
log=(root/'full-final.log').read_text()
lines=[l.strip() for l in log.splitlines() if re.match(r'\s*(Test Files|Tests|Duration)\s',l)]
assert len(lines)==3 and 'failed' not in '\n'.join(lines),lines
assert re.search(r'Tests\s+12868 passed \| 2 skipped',log),lines
assert re.search(r'Test Files\s+545 passed',log),lines
result={'pass':True,'sourceFiles':len(a['sources']),'buildFiles':len(a['build']),'sourceBuildHeadStatusGenuineExact':True,'summary':lines,'genuineSha256':a['genuine'],'head':a['head'],'fullSeconds':json.loads((root/'full-final.result.json').read_text())['seconds']}
(root/'full-freeze-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
