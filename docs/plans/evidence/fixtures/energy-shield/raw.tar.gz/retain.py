from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parent
out=Path('docs/plans/evidence/fixtures/energy-shield')
assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[p for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and p.relative_to(root).parts[0] not in ['build-final','browser-tmp']]
manifest={str(p.relative_to(root)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files}
out.mkdir(parents=True)
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive) as t:
 assert sorted(t.getnames())==sorted(manifest)
 for name,entry in manifest.items():
  raw=t.extractfile(name).read();assert sha(raw)==entry['sha256'] and len(raw)==entry['bytes']
receipts={p.name:json.loads(p.read_text()) for p in files if p.name.endswith('.result.json')}
record={'scope':'Synthetic local Energy Shield verification; independent QA and earned acceptance remain open.',
 'owner':json.loads((root/'owner.json').read_text()),'archiveSha256':sha(archive.read_bytes()),'files':manifest,'terminalResults':receipts}
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'pass':True,'files':len(files),'terminalResults':len(receipts),'archiveSha256':record['archiveSha256']}))
