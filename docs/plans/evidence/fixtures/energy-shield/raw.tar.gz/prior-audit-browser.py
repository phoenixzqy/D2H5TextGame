from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
browser=root/'browser-complete'
report=json.loads((browser/'browser-report.json').read_text())
labels=['en-1280','en-360','zh-CN-1280','zh-CN-360']
assert [r['label'] for r in report['cases']]==labels
assert report['failures']==[]
def save(pattern):
 files=list(browser.glob(pattern))
 assert len(files)==1,(pattern,files)
 return json.loads(files[0].read_text())
def domains(s):return {k:s[k] for k in ['player','inventory','map','mercs','formation']}
pairs=[]
for label,row in zip(labels,report['cases']):
 assert row['pass'] and row['errors']==[] and row['pairs']==['dormant','learned']
 inp=save(label+'-synthetic-input.json')
 imported=save(label+'-imported-*.json')
 assert imported['player']['comboOrder']==inp['player']['comboOrder']==['barbarian.bash','sorceress.ice_blast','amazon.piercing_strike']
 assert imported['player']['skillLevels']==inp['player']['skillLevels']=={'sorceress.ice_bolt':1,'sorceress.ice_blast':20,'amazon.piercing_strike':20}
 for stage in ['dormant','learned']:
  before,after=[save(label+'-'+stage+'-'+side+'-*.json') for side in ['before','after']]
  assert before['version']==after['version']==22
  assert domains(before)==domains(after)
  assert after['player']['skillLevels']['sorceress.ice_bolt']==1
  assert after['player']['skillLevels']['sorceress.ice_blast']==20
  assert after['player']['skillLevels']['amazon.piercing_strike']==20
  if stage=='dormant':
   assert after['player']['skillLevels']==inp['player']['skillLevels']
   assert after['player']['comboOrder']==inp['player']['comboOrder']
   assert after['player']['skillPoints']==2
  else:
   assert after['player']['skillLevels']['barbarian.bash']==1
   assert after['player']['skillPoints']==1
   assert after['player']['comboOrder']==['skills-barbarian-bash']
  pairs.append({'case':label,'stage':stage,'fiveDomainsExact':True,'version':22})
 learned=(browser/(label+'-learned-combat.txt')).read_text()
 dormant=(browser/(label+'-unlearned-foreign-combat.txt')).read_text()
 cast='OwnershipCheck casts Bash.' if label.startswith('en-') else 'OwnershipCheck 施放了 重击。'
 basic='OwnershipCheck readies an attack.' if label.startswith('en-') else 'OwnershipCheck 准备出招。'
 assert cast in learned and basic in dormant
 assert 'OwnershipCheck casts' not in dormant and 'OwnershipCheck 施放' not in dormant
 assert len(list(browser.glob(label+'-*-combat.png')))==2
 geo=[r for r in report['geometry'] if r['label']==label]
 assert [(r['width'],r['height']) for r in geo]==[(360,640),(412,915),(640,360),(1280,800),(1920,1080)]
 assert all(r['overflow']<=0 and r['select']['width']>=44 and r['select']['height']>=44 for r in geo)
assert len(report['geometry'])==20
result={'pass':True,'syntheticOnly':True,'cases':4,'exactPairs':pairs,'geometrySamples':20,'combatScreenshots':8,'scope':'Separate attachment audit. Existing Skills-screen sanitizer edits dormant slots on screen open; this runtime fix preserves persisted configuration before that UI action. No earned viability, whole-screen a11y, or independent QA acceptance.'}
(root/'browser-complete-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='exactPairs'}))
