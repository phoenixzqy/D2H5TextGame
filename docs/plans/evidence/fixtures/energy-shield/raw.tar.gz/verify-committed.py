from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).resolve().parent
snapshot=json.loads((root/'after-full.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,digest in snapshot['sources'].items():
 assert sha(Path(name).read_bytes())==digest,name
 assert sha(subprocess.check_output(['git','show','HEAD:'+name]))==digest,name
result={'pass':True,'sourceFiles':len(snapshot['sources']),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtimeAndTestsMatchValidatedSnapshot':True}
(root/'committed-source-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
