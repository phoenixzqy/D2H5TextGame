import type { RestoredModeAttempt, RestoredModeOptions } from './mode-adapter';
import type { RestoredModeComparison } from './mode-comparison';
import type { SourceState } from './provenance';
export interface RestoredModeReport {
  readonly reportKind: 'restored-mode-diagnostic';
  readonly reportVersion: 1;
  readonly observationEncoding: 'd2h5-observation-v1';
  readonly protocol: { readonly baselineTag: 'restored-test-baseline-v1'; readonly cases: readonly RestoredModeOptions[] };
  readonly provenance: { readonly sourceSha: string; readonly sourceTreeHash: string; readonly dataHash: string;
    readonly nodeVersion: string; readonly vitestVersion: string; readonly protocolHash: string };
  readonly sourceBeforeImport: SourceState;
  readonly sourceAfter: SourceState;
  readonly attempts: readonly RestoredModeAttempt[];
  readonly baselineHashes: readonly string[];
  readonly comparisons: readonly (RestoredModeComparison & { readonly idleEliteMisses: 0 | 11 })[];
  readonly scope: { readonly synthetic: true; readonly directService: true; readonly uiEligible: false;
    readonly earnedClear: false; readonly routingExercised: false; readonly screening: false; readonly campaignAcceptance: false };
  readonly identityAllocation: { readonly scope: 'process-global'; readonly reset: false; readonly initialState: 'unobserved' };
  readonly timingInterpretation: { readonly logicalSimSeconds: 'sum-of-attempted-terminal-sim-clocks';
    readonly uiDelayHintSeconds: 'sum-of-attempted-recorded-event-ui-delays';
    readonly wallSeconds: 'adapter-execution-and-restoration'; readonly humanActivePlayDuration: false };
}
/** Run exactly four closed synthetic direct-service cases, verifying before-import source identity. */
export function runRestoredModeMeasurement(_beforeImportSource: SourceState): RestoredModeReport {
  throw new Error('P02b05b02b restored-mode reporting is not implemented');
}
