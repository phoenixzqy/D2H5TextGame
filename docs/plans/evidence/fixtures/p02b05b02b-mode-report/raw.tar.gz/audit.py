from pathlib import Path
import hashlib,json,collections
r=Path(__file__).parent;w=Path.cwd()
sha=lambda b:hashlib.sha256(b).hexdigest()
def canonical(v): return json.dumps(v,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode()
def fingerprint(entries):
 h=hashlib.sha256(b'd2h5-file-entries-v1\0')
 for name,b in sorted(entries): h.update(json.dumps([name,len(b)],separators=(',',':')).encode());h.update(b)
 return h.hexdigest()
preserved=json.loads((r/'preserved-baseline.json').read_text())
assert all(sha((w/p).read_bytes())==v for p,v in preserved.items())
freeze=json.loads((r/'freeze.json').read_text())
for name,target in [('mode-measurement.test.ts','tests/sim/production/mode-measurement.test.ts'),('mode-measure.test.ts','tests/sim/production/mode-measure.test.ts'),('package.candidate.json','package.json')]: assert sha((w/target).read_bytes())==freeze['hashes'][name]
records=[]
def check_source(s,override=None):
 entries=[]
 for row in s['manifest']:
  p=row['path'];b=(r/override).read_bytes() if override and p=='tests/sim/production/mode-measurement.ts' else (w/p).read_bytes()
  assert len(b)==row['byteLength'] and sha(b)==row['sha256'],p
  entries.append((p,b))
 assert s['sourceSha']==freeze['parent']
 assert fingerprint(entries)==s['sourceTreeHash']
 assert fingerprint([(p,b) for p,b in entries if p.startswith('src/data/')])==s['dataHash']
 records.append({'override':override,'sourceTreeHash':s['sourceTreeHash'],'manifestEntries':len(entries)})
for name,override in [('red-boundary','boundary.ts'),('green-source','source-check-stage.ts'),('green-first',None),('related',None)]:
 t=json.loads((r/(name+'.template.json')).read_text())['template']
 for key in ['sourceBefore','sourceAfter']:check_source(t[key],override)
d=json.loads((r/'cli-observation.json').read_text());check_source(d['sourceBeforeImport']);check_source(d['sourceAfter'])
assert (r/'cli-observation.json').stat().st_size<=freeze['reportLimitBytes']
assert d['protocol']['cases']==[a['options'] for a in d['attempts']]
assert sha(canonical(d['protocol']))==d['provenance']['protocolHash']
for a,expected in zip(d['attempts'],d['baselineHashes'],strict=True):
 for key in ['sourceBefore','sourceAfter']:check_source(a[key])
 projection={k:a[k] for k in ['baselineTag','clockEpochMs','scope','created','actions','baseline','baselineCombat','baselinePity']};projection['requestedPity']=a['options']['idleEliteMisses']
 assert sha(canonical(projection))==expected
summary=[]
for name in ['red-missing','red-boundary','green-source','green-first','related','full','cli-positive','negative-existing','negative-relative','negative-inrepo','negative-symlink']:
 path=r/(name+'.report.json')
 if not path.exists():continue
 report=json.loads(path.read_text());counts=collections.Counter(a['status'] for t in report['testResults'] for a in t['assertionResults'])
 summary.append({'name':name,'actualTestFiles':len(report['testResults']),'actualStatuses':dict(counts),'meta':json.loads((r/(name+'.meta.json')).read_text())})
for name in ['red-boundary','green-source','green-first','related']:
 a=json.loads((r/(name+'-assertions.json')).read_text());next(s for s in summary if s['name']==name)['orchestrationReachedMatchers']=sum(x['assertions'] for x in a)
result={'sourceStates':records,'preservedHashes':len(preserved),'frozenUnchanged':True,'cliBytes':(r/'cli-observation.json').stat().st_size,'nativeCLI':[{'options':a['options'],'status':a['status'],'winners':[v['opening']['outcome']['winner'] for v in a['waves']],'timings':a['timings']} for a in d['attempts']],'comparisons':[{'idleEliteMisses':c['idleEliteMisses'],'waveComparisons':c['waveComparisons']} for c in d['comparisons']],'validation':summary}
(r/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sourceStates':len(records),'preservedHashes':len(preserved),'manifestEntries':records[-1]['manifestEntries'],'cliBytes':result['cliBytes'],'actualStatuses':{s['name']:s['actualStatuses'] for s in summary}}))
