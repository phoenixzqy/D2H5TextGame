import { fileURLToPath } from 'node:url';
import { runRestoredModeOnce, type RestoredModeAttempt, type RestoredModeOptions } from './mode-adapter';
import { assertEarnedSourceStable } from './earned-measurement';
import { collectSourceState } from './provenance';
import type { RestoredModeComparison } from './mode-comparison';
import type { SourceState } from './provenance';
export interface RestoredModeReport {
  readonly reportKind: 'restored-mode-diagnostic';
  readonly reportVersion: 1;
  readonly observationEncoding: 'd2h5-observation-v1';
  readonly protocol: { readonly baselineTag: 'restored-test-baseline-v1'; readonly cases: readonly RestoredModeOptions[] };
  readonly provenance: { readonly sourceSha: string; readonly sourceTreeHash: string; readonly dataHash: string;
    readonly nodeVersion: string; readonly vitestVersion: string; readonly protocolHash: string };
  readonly sourceBeforeImport: SourceState;
  readonly sourceAfter: SourceState;
  readonly attempts: readonly RestoredModeAttempt[];
  readonly baselineHashes: readonly string[];
  readonly comparisons: readonly (RestoredModeComparison & { readonly idleEliteMisses: 0 | 11 })[];
  readonly scope: { readonly synthetic: true; readonly directService: true; readonly uiEligible: false;
    readonly earnedClear: false; readonly routingExercised: false; readonly screening: false; readonly campaignAcceptance: false };
  readonly identityAllocation: { readonly scope: 'process-global'; readonly reset: false; readonly initialState: 'unobserved' };
  readonly timingInterpretation: { readonly logicalSimSeconds: 'sum-of-attempted-terminal-sim-clocks';
    readonly uiDelayHintSeconds: 'sum-of-attempted-recorded-event-ui-delays';
    readonly wallSeconds: 'adapter-execution-and-restoration'; readonly humanActivePlayDuration: false };
}
/** Run exactly four closed synthetic direct-service cases, verifying before-import source identity. */
export function runRestoredModeMeasurement(beforeImportSource: SourceState): RestoredModeReport {
  const root = fileURLToPath(new URL('../../../', import.meta.url));
  assertEarnedSourceStable(beforeImportSource, collectSourceState(root));
  const cases: readonly RestoredModeOptions[] = [
    { mode: 'manual', idleEliteMisses: 0 }, { mode: 'idle', idleEliteMisses: 0 },
    { mode: 'manual', idleEliteMisses: 11 }, { mode: 'idle', idleEliteMisses: 11 }
  ];
  const attempts: RestoredModeAttempt[] = [];
  for (const options of cases) {
    const attempt = runRestoredModeOnce(options);
    assertEarnedSourceStable(beforeImportSource, attempt.sourceBefore);
    assertEarnedSourceStable(beforeImportSource, attempt.sourceAfter);
    assertEarnedSourceStable(beforeImportSource, collectSourceState(root));
    attempts.push(attempt);
  }
  const sourceAfter = collectSourceState(root);
  assertEarnedSourceStable(beforeImportSource, sourceAfter);
  throw new Error('P02b05b02b restored-mode reporting is not implemented');
}
