# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iron-skin.spec.ts >> Iron Skin imported eligibility, bilingual layouts and disk reload en
- Location: tests/pwa/iron-skin.spec.ts:63:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  10  |   en: 'Passive: +4% ordinary defense per allocated skill rank (up to +80% at rank 20). Unlocks at character level 18.',
  11  |   'zh-CN': '被动：每投入1点技能点，普通防御+4%（最多20点，合计+80%）。角色18级解锁。'
  12  | };
  13  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  14  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  15  | }
  16  | async function backup(page: Page): Promise<SaveCurrent> {
  17  |   await navTo(page, 'settings');
  18  |   const pending = page.waitForEvent('download');
  19  |   await page.getByTestId('export-save-button').click();
  20  |   const download = await pending;
  21  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  22  |   finally { await download.delete(); }
  23  | }
  24  | async function production(page: Page): Promise<void> {
  25  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  26  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  27  | }
  28  | function durable(save: SaveCurrent): void {
  29  |   expect(JSON.stringify(save)).not.toMatch(/"increasedDamagePct"|"manaRegenPerSecond"|"manaRegenCarry"|"manaRegenExactCarry"|"manaRegenCompensation"|"activeBuffIds"|"frozenArmor"|"carryPlayerTeam"/);
  30  | }
  31  | async function slots(page: Page, english: boolean): Promise<void> {
  32  |   await navTo(page, 'skills');
  33  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  34  |   for (let index = 1; index <= 9; index++) {
  35  |     const slot = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(index)}`, exact: true });
  36  |     await expect(slot).toHaveValue(index === 1 ? BASH : '');
  37  |     await expect(slot.locator(`option[value="${SKIN}"]`)).toHaveCount(0);
  38  |     await expect(slot.locator('option')).toHaveCount(2); // Empty and the only learned active, Bash.
  39  |   }
  40  | }
  41  | /** Read-only edge/center hits catch occlusion beyond mere DOM visibility. */
  42  | async function clearHits(target: import('@playwright/test').Locator): Promise<unknown[]> {
  43  |   await target.scrollIntoViewIfNeeded();
  44  |   const points = await target.evaluate(node => {
  45  |     const b = node.getBoundingClientRect();
  46  |     return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
  47  |       const px = b.left + b.width * x, py = b.top + b.height * y;
  48  |       const hit = document.elementFromPoint(px, py);
  49  |       return { x: px, y: py, clear: hit !== null && node.contains(hit) };
  50  |     }));
  51  |   });
  52  |   for (const point of points) expect(point).toMatchObject({ clear: true });
  53  |   return points;
  54  | }
  55  | async function selectIronSkin(page: Page): Promise<void> {
  56  |   await navTo(page, 'skills');
  57  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  58  |   await page.getByTestId(`skill-node-${SKIN}`).click();
  59  |   await page.mouse.move(1, 1); // Keep pointer clear of tree previews during resize/scroll.
  60  | }
  61  | 
  62  | for (const locale of ['en', 'zh-CN'] as const) {
  63  |   test(`Iron Skin imported eligibility, bilingual layouts and disk reload ${locale}`, async ({ page: initial, context }, info) => {
  64  |     const english = locale === 'en';
  65  |     const errors: string[] = [];
  66  |     const watch = (p: Page): void => {
  67  |       p.on('pageerror', error => errors.push(error.message));
  68  |       p.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  69  |     };
  70  |     let page = initial; watch(page);
  71  |     await page.goto('/');
  72  |     await createCharacter(page, { class: 'barbarian', name: 'Iron Skin' });
  73  |     await navTo(page, 'settings');
  74  |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  75  |     const fresh = await backup(page);
  76  |     expect(fresh.player).toMatchObject({ level: 1, skillPoints: 1, class: 'barbarian' });
  77  |     expect(fresh.player.comboOrder).toEqual(['barbarian.bash']);
  78  |     await selectIronSkin(page);
  79  |     await expect(page.getByTestId('skill-detail-panel').getByRole('button', { name: english ? 'Requires Lv. 18' : '需要等级 18', exact: true })).toBeDisabled();
  80  |     await expect(page.getByTestId('skill-detail-panel')).toContainText(prose[locale]);
  81  |     const locked = await backup(page);
  82  |     // Existing first-visit sanitizer normalizes the learned Bash identifier.
  83  |     expect(locked.player).toEqual({ ...fresh.player, comboOrder: [BASH] });
  84  |     await attach(info, '01-fresh-locked-control', locked);
  85  |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 18, skillPoints: 2,
  86  |       skillLevels: { 'barbarian.bash': 1 }, comboOrder: [BASH] } };
  87  |     const importLabel = english ? 'Import Save' : '导入存档';
  88  |     await page.getByRole('button', { name: importLabel, exact: true }).click();
  89  |     const dialog = page.getByRole('dialog');
  90  |     await dialog.getByRole('textbox').fill(JSON.stringify(incoming));
  91  |     await dialog.getByRole('button', { name: importLabel, exact: true }).click();
  92  |     await expect(dialog).toHaveCount(0);
  93  |     const prepared = await backup(page);
  94  |     expect(prepared.player).toEqual(incoming.player);
  95  |     expect(prepared.inventory).toEqual(fresh.inventory);
  96  |     expect(prepared.map).toEqual(fresh.map);
  97  |     durable(prepared);
  98  |     await attach(info, '02-explicit-imported-eligibility', prepared);
  99  |     try {
  100 |       for (const rank of [1, 2]) {
  101 |         await selectIronSkin(page);
  102 |         const panel = page.getByTestId('skill-detail-panel');
  103 |         const allocate = panel.getByRole('button');
  104 |         // Native keyboard traversal from the selected tree node; no focus() or DOM click injection.
  105 |         let reached = false;
  106 |         for (let step = 0; step < 100; step++) {
  107 |           await page.keyboard.press('Tab');
  108 |           if (await allocate.evaluate(node => node === document.activeElement)) { reached = true; break; }
  109 |         }
> 110 |         expect(reached).toBe(true);
      |                         ^ Error: expect(received).toBe(expected) // Object.is equality
  111 |         await expect(allocate).toBeFocused();
  112 |         await expect(panel.getByRole('heading', { name: english ? 'Iron Skin' : '钢铁之肤', exact: true })).toBeVisible();
  113 |         await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
  114 |         await expect(allocate).toBeEnabled();
  115 |         await page.keyboard.press('Enter');
  116 |         await expect(panel).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  117 |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true }) });
  118 |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true }) });
  119 |         const label = english ? 'Defense' : '防御';
  120 |         await expect(current.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String(rank * 4)}%`);
  121 |         await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(new RegExp(`^${String((rank + 1) * 4)}%\\s*\\(\\+4%\\)$`));
  122 |         await expect(panel).toContainText(prose[locale]);
  123 |         if (rank === 1) {
  124 |           const metrics = [];
  125 |           for (const [width, height] of sizes) {
  126 |             await page.setViewportSize({ width, height });
  127 |             const control = panel.getByRole('button');
  128 |             await control.scrollIntoViewIfNeeded();
  129 |             const bounds = await control.boundingBox();
  130 |             expect(bounds).not.toBeNull();
  131 |             expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  132 |             const controlHits = await clearHits(control);
  133 |             const headingHits = await clearHits(panel.getByRole('heading', { name: english ? 'Iron Skin' : '钢铁之肤', exact: true }));
  134 |             await production(page);
  135 |             const description = panel.getByText(prose[locale], { exact: true });
  136 |             await description.scrollIntoViewIfNeeded();
  137 |             const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  138 |             expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14);
  139 |             await expect(description).toBeVisible();
  140 |             if (!english && width === 360) {
  141 |               const cdp = await context.newCDPSession(page);
  142 |               try {
  143 |                 await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  144 |                 const document = await cdp.send('DOM.getDocument');
  145 |                 const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId,
  146 |                   selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  147 |                 const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  148 |                 await attach(info, '03-actual-Chinese-platform-fonts', fonts);
  149 |                 expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
  150 |               } finally { await cdp.detach(); }
  151 |             }
  152 |             await info.attach(`layout-${String(width)}x${String(height)}`, { body: await page.screenshot(), contentType: 'image/png' });
  153 |             for (const section of [current, next]) {
  154 |               await section.scrollIntoViewIfNeeded(); await expect(section).toBeVisible();
  155 |             }
  156 |             metrics.push({ width, height, bounds, font, controlHits, headingHits });
  157 |           }
  158 |           await attach(info, '03-layout-metrics', metrics);
  159 |         }
  160 |         await slots(page, english);
  161 |         const saved = await backup(page);
  162 |         expect(saved.player.skillLevels).toEqual({ 'barbarian.bash': 1, 'barbarian.iron_skin': rank });
  163 |         expect(saved.player.skillPoints).toBe(2 - rank); expect(saved.player.comboOrder).toEqual([BASH]);
  164 |         expect(saved.player.derivedStats).toEqual(fresh.player.derivedStats); durable(saved);
  165 |         await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  166 |         await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  167 |         await page.close(); page = await context.newPage(); watch(page);
  168 |         await page.goto('/'); await page.getByTestId('home-continue').click();
  169 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  170 |         const loaded = await backup(page);
  171 |         expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
  172 |         expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
  173 |         expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta.settings).toEqual(saved.meta.settings); durable(loaded);
  174 |         await attach(info, `04-rank${String(rank)}-actual-disk-reload`, { saved, loaded });
  175 |         await selectIronSkin(page); await expect(page.getByTestId('skill-detail-panel')).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  176 |         await production(page);
  177 |       }
  178 |       await attach(info, '05-console-errors', errors); expect(errors).toEqual([]);
  179 |     } finally { await page.close(); }
  180 |   });
  181 | }
  182 | 
```