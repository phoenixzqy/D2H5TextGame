# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: iron-skin.spec.ts >> Iron Skin imported eligibility, bilingual layouts and disk reload en
- Location: tests/pwa/iron-skin.spec.ts:63:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  27  | }
  28  | function durable(save: SaveCurrent): void {
  29  |   expect(JSON.stringify(save)).not.toMatch(/"increasedDamagePct"|"manaRegenPerSecond"|"manaRegenCarry"|"manaRegenExactCarry"|"manaRegenCompensation"|"activeBuffIds"|"frozenArmor"|"carryPlayerTeam"/);
  30  | }
  31  | async function slots(page: Page, english: boolean): Promise<void> {
  32  |   await navTo(page, 'skills');
  33  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  34  |   for (let index = 1; index <= 9; index++) {
  35  |     const slot = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(index)}`, exact: true });
  36  |     await expect(slot).toHaveValue(index === 1 ? BASH : '');
  37  |     await expect(slot.locator(`option[value="${SKIN}"]`)).toHaveCount(0);
  38  |     await expect(slot.locator('option')).toHaveCount(2); // Empty and the only learned active, Bash.
  39  |   }
  40  | }
  41  | /** Read-only edge/center hits catch occlusion beyond mere DOM visibility. */
  42  | async function clearHits(target: import('@playwright/test').Locator): Promise<unknown[]> {
  43  |   await target.scrollIntoViewIfNeeded();
  44  |   const points = await target.evaluate(node => {
  45  |     const b = node.getBoundingClientRect();
  46  |     return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
  47  |       const px = b.left + b.width * x, py = b.top + b.height * y;
  48  |       const hit = document.elementFromPoint(px, py);
  49  |       return { x: px, y: py, clear: hit !== null && node.contains(hit) };
  50  |     }));
  51  |   });
  52  |   for (const point of points) expect(point).toMatchObject({ clear: true });
  53  |   return points;
  54  | }
  55  | async function selectIronSkin(page: Page): Promise<void> {
  56  |   await navTo(page, 'skills');
  57  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  58  |   await page.getByTestId(`skill-node-${SKIN}`).click();
  59  |   await page.mouse.move(1, 1); // Keep pointer clear of tree previews during resize/scroll.
  60  | }
  61  | 
  62  | for (const locale of ['en', 'zh-CN'] as const) {
  63  |   test(`Iron Skin imported eligibility, bilingual layouts and disk reload ${locale}`, async ({ page: initial, context }, info) => {
  64  |     const english = locale === 'en';
  65  |     const errors: string[] = [];
  66  |     const watch = (p: Page): void => {
  67  |       p.on('pageerror', error => errors.push(error.message));
  68  |       p.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  69  |     };
  70  |     let page = initial; watch(page);
  71  |     await page.goto('/');
  72  |     await createCharacter(page, { class: 'barbarian', name: 'Iron Skin' });
  73  |     await navTo(page, 'settings');
  74  |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  75  |     const fresh = await backup(page);
  76  |     expect(fresh.player).toMatchObject({ level: 1, skillPoints: 1, class: 'barbarian' });
  77  |     expect(fresh.player.comboOrder).toEqual(['barbarian.bash']);
  78  |     await selectIronSkin(page);
  79  |     await expect(page.getByTestId('skill-detail-panel').getByRole('button', { name: english ? 'Requires Lv. 18' : '需要等级 18', exact: true })).toBeDisabled();
  80  |     await expect(page.getByTestId('skill-detail-panel')).toContainText(prose[locale]);
  81  |     const locked = await backup(page);
  82  |     // Existing first-visit sanitizer normalizes the learned Bash identifier.
  83  |     expect(locked.player).toEqual({ ...fresh.player, comboOrder: [BASH] });
  84  |     await attach(info, '01-fresh-locked-control', locked);
  85  |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 18, skillPoints: 2,
  86  |       skillLevels: { 'barbarian.bash': 1 }, comboOrder: [BASH] } };
  87  |     const importLabel = english ? 'Import Save' : '导入存档';
  88  |     await page.getByRole('button', { name: importLabel, exact: true }).click();
  89  |     const dialog = page.getByRole('dialog');
  90  |     await dialog.getByRole('textbox').fill(JSON.stringify(incoming));
  91  |     await dialog.getByRole('button', { name: importLabel, exact: true }).click();
  92  |     await expect(dialog).toHaveCount(0);
  93  |     const prepared = await backup(page);
  94  |     expect(prepared.player).toEqual(incoming.player);
  95  |     expect(prepared.inventory).toEqual(fresh.inventory);
  96  |     expect(prepared.map).toEqual(fresh.map);
  97  |     durable(prepared);
  98  |     await attach(info, '02-explicit-imported-eligibility', prepared);
  99  |     try {
  100 |       for (const rank of [1, 2]) {
  101 |         await selectIronSkin(page);
  102 |         const panel = page.getByTestId('skill-detail-panel');
  103 |         const allocate = panel.getByRole('button');
  104 |         // Native keyboard traversal from the selected tree node; no focus() or DOM click injection.
  105 |         const trace = [];
  106 |         const focusSnapshot = () => page.evaluate(() => {
  107 |           const active = document.activeElement;
  108 |           const detail = document.querySelector('[data-testid="skill-detail-panel"]');
  109 |           const action = detail?.querySelector('button');
  110 |           return { time: performance.now(), active: { tag: active?.tagName,
  111 |             testId: active?.getAttribute('data-testid'), label: active?.getAttribute('aria-label'),
  112 |             text: active?.textContent?.slice(0, 160) },
  113 |             heading: detail?.querySelector('h2')?.textContent,
  114 |             button: { text: action?.textContent, disabled: action?.disabled } };
  115 |         });
  116 |         let reached = false;
  117 |         for (let step = 0; step < 100; step++) {
  118 |           const before = await focusSnapshot();
  119 |           await page.keyboard.press('Tab');
  120 |           const after = await focusSnapshot();
  121 |           trace.push({ step, before, after });
  122 |           if (await allocate.evaluate(node => node === document.activeElement)) { reached = true; break; }
  123 |         }
  124 |         await attach(info, `keyboard-trace-rank${String(rank)}`, trace);
  125 |         if (!reached) await info.attach('keyboard-failure-before-close', {
  126 |           body: await page.screenshot(), contentType: 'image/png' });
> 127 |         expect(reached).toBe(true);
      |                         ^ Error: expect(received).toBe(expected) // Object.is equality
  128 |         await expect(allocate).toBeFocused();
  129 |         await expect(panel.getByRole('heading', { name: english ? 'Iron Skin' : '钢铁之肤', exact: true })).toBeVisible();
  130 |         await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
  131 |         await expect(allocate).toBeEnabled();
  132 |         await page.keyboard.press('Enter');
  133 |         await expect(panel).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  134 |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true }) });
  135 |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true }) });
  136 |         const label = english ? 'Defense' : '防御';
  137 |         await expect(current.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String(rank * 4)}%`);
  138 |         await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(new RegExp(`^${String((rank + 1) * 4)}%\\s*\\(\\+4%\\)$`));
  139 |         await expect(panel).toContainText(prose[locale]);
  140 |         if (rank === 1) {
  141 |           const metrics = [];
  142 |           for (const [width, height] of sizes) {
  143 |             await page.setViewportSize({ width, height });
  144 |             const control = panel.getByRole('button');
  145 |             await control.scrollIntoViewIfNeeded();
  146 |             const bounds = await control.boundingBox();
  147 |             expect(bounds).not.toBeNull();
  148 |             expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  149 |             const controlHits = await clearHits(control);
  150 |             const headingHits = await clearHits(panel.getByRole('heading', { name: english ? 'Iron Skin' : '钢铁之肤', exact: true }));
  151 |             await production(page);
  152 |             const description = panel.getByText(prose[locale], { exact: true });
  153 |             await description.scrollIntoViewIfNeeded();
  154 |             const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  155 |             expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14);
  156 |             await expect(description).toBeVisible();
  157 |             if (!english && width === 360) {
  158 |               const cdp = await context.newCDPSession(page);
  159 |               try {
  160 |                 await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  161 |                 const document = await cdp.send('DOM.getDocument');
  162 |                 const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId,
  163 |                   selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  164 |                 const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  165 |                 await attach(info, '03-actual-Chinese-platform-fonts', fonts);
  166 |                 expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
  167 |               } finally { await cdp.detach(); }
  168 |             }
  169 |             await info.attach(`layout-${String(width)}x${String(height)}`, { body: await page.screenshot(), contentType: 'image/png' });
  170 |             for (const section of [current, next]) {
  171 |               await section.scrollIntoViewIfNeeded(); await expect(section).toBeVisible();
  172 |             }
  173 |             metrics.push({ width, height, bounds, font, controlHits, headingHits });
  174 |           }
  175 |           await attach(info, '03-layout-metrics', metrics);
  176 |         }
  177 |         await slots(page, english);
  178 |         const saved = await backup(page);
  179 |         expect(saved.player.skillLevels).toEqual({ 'barbarian.bash': 1, 'barbarian.iron_skin': rank });
  180 |         expect(saved.player.skillPoints).toBe(2 - rank); expect(saved.player.comboOrder).toEqual([BASH]);
  181 |         expect(saved.player.derivedStats).toEqual(fresh.player.derivedStats); durable(saved);
  182 |         await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  183 |         await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  184 |         await page.close(); page = await context.newPage(); watch(page);
  185 |         await page.goto('/'); await page.getByTestId('home-continue').click();
  186 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  187 |         const loaded = await backup(page);
  188 |         expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
  189 |         expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
  190 |         expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta.settings).toEqual(saved.meta.settings); durable(loaded);
  191 |         await attach(info, `04-rank${String(rank)}-actual-disk-reload`, { saved, loaded });
  192 |         await selectIronSkin(page); await expect(page.getByTestId('skill-detail-panel')).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  193 |         await production(page);
  194 |       }
  195 |       await attach(info, '05-console-errors', errors); expect(errors).toEqual([]);
  196 |     } finally { await page.close(); }
  197 |   });
  198 | }
  199 | 
```