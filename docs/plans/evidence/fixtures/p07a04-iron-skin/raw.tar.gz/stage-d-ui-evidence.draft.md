

## Bilingual skill details / Stage D

`UI_COMMIT` normalizes the two exact allocated aliases once using the same
immutable rank resolver, interpolates the JSON-derived definition in both
locales, and corrects only the Iron Skin spec row. The existing name 钢铁之肤
remains. No runtime/data tuning or generalized passive composition changed.

[BUG-065](../../../production/bugs/BUG-065-iron-skin-details.md) was recorded
before patching. Actual unchanged-production UI RED20=12 failed/8 passed: each
locale fails authored prose, legacy fallback, alias-order rank19→1, uncapped
rank99/20 label, fractional allocation and near-miss normalization. Reverse
order, NaN+valid alias, real learning at18 and recording/resource controls already
pass; numeric4/8 and level18 were existing controls. Hard failures prevented
later assertions in their cases; the full original JSON and classification stay
preserved. Four production hashes were verified unchanged around RED execution.

| Final gate | Result | Duration |
|---|---|---|
| Focused Iron Skin/Lightning/Might/main Skills | 100 cases, 4 files | 5.803 s Vitest / 7.043 s wrapper |
| Type checking | pass | 11.852 s |
| Full unit | 4,749 cases, 191 files | 78.921 s / 80.294 s |
| Lint + engine purity | pass | 30.554 s |
| Fresh production build + bridge exclusion | pass | 9.107 s |

All six commands including intended RED run serially with no stops/signals or
pending/todo cases. Five final gates pass; full15s timing target and known build
warnings remain. Locale validation confirms the same bonus/maxBonus/cap/level
placeholders and complete exact bilingual expected prose. UI fixtures import
level18 and do not establish earned progression. GD/TD exact source and QA/
producer whole evidence approve; root-transcribed reviews remain in RAW.

Root retains the exact761 outputs40,965,478B for the immediate Stage E production
browser consumer: claimed-worktree `dist/` (760 files) and
`node_modules/.vite/vitest/results.json` (one file), enumerated with hashes in
stage-d-ui-output-inventory.json. Owner root; reason fresh bridge-free preview;
remove after browser and all reviewer readers finish, with fresh source, process
and output hash checks. They are not yet removed. All910 StageD PID/birth
identities are absent. Browser acceptance, broader mobile/a11y/performance,
campaign/balance/coverage and full private-v1 remain open. Source/history/font/
shared caches and original checkout are preserved; umbrella claim continues,
no remote action. RAW remains at the exact Iron path above until its independently
verified durable packet and exact cleanup. Key records: stage-d-ui-draft-freeze-v1,
baseline-freeze, red-classification, source-freeze, locale-validation, final-gates,
process-union and output-inventory JSON files.
