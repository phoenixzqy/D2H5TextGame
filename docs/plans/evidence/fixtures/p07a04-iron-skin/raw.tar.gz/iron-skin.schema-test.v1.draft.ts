import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import barbarianSkills from '../../data/skills/barbarian.json';
import skillSchema from '../../data/schema/skill.schema.json';
import sorceressSkills from '../../data/skills/sorceress.json';
import paladinSkills from '../../data/skills/paladin.json';

const authored = () => {
  const row = barbarianSkills.find(row => row.id === 'skills-barbarian-iron-skin');
  if (!row) throw new Error('Missing authored Iron Skin');
  return structuredClone(row);
};
const validate = new Ajv2020({ strict: true, allErrors: true }).compile(skillSchema);

const malformedRows = [
  { requiredLevel: undefined },
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '18', null].map(requiredLevel => ({ requiredLevel })),
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '20', null].map(maxLevel => ({ maxLevel })),
  { scaling: undefined }, { scaling: {} }, { scaling: { passiveStatsPerLevel: {} } },
  ...[-0.01, NaN, Infinity, -Infinity, '0.04', null].map(defensePct =>
    ({ scaling: { passiveStatsPerLevel: { defensePct } } })),
  { trigger: 'active' }, { target: 'single-enemy' }, { passive: false },
  { aura: true }, { summon: true },
  ...[1, -1, NaN, Infinity, -Infinity, '0', null].map(cooldown => ({ cooldown })),
  { cost: {} }, { cost: { mana: 0 } }, { cost: { life: 0 } },
  { damage: { min: 1, max: 1, breakdown: { physical: 1 } } }, { damageType: 'physical' },
  { appliesStatus: [] }, { appliesStatus: ['burn'] }, { statusEffect: { chance: 1 } },
  { additionalStatusEffects: { freeze: { chance: 1 } } },
  { appliesTags: ['fire'] }, { synergies: { fire: 1.2 } },
  { heal: { min: 1, max: 1, target: 'self' } }, { summonId: 'skeleton' },
  { aoeShape: 'single' }, { requires: {} }, { requires: { weaponType: ['staff'] } },
  { scaling: { passiveStatsPerLevel: { defensePct: 0.04, coldDamagePct: 0.1 } } },
  { scaling: { passiveStatsPerLevel: { defensePct: 0.04, typo: 0.1 } } },
  ...['damagePerLevel', 'cooldownPerLevel', 'costPerLevel'].map(key =>
    ({ scaling: { passiveStatsPerLevel: { defensePct: 0.04 }, [key]: 0 } })),
  { scaling: { passiveStatsPerLevel: { defensePct: 0.04 }, summonStatsPerLevel: { attack: 1 } } },
  { scaling: { passiveStatsPerLevel: { defensePct: 0.04 }, summonMaxCount: { kind: 'first-three-then-every-three' } } },
  { scaling: { passiveStatsPerLevel: { defensePct: 0.04 }, typo: 1 } },
  { typo: 1 }
];

describe('P07a04A exact Iron Skin schema', () => {
  it('preserves authored passive/self tuning and authoritative unlock18 over legacy minLevel1', () => {
    const row = authored();
    expect(validate(row)).toBe(true);
    expect(row).toMatchObject({ id: 'skills-barbarian-iron-skin', trigger: 'passive',
      target: 'self', requiredLevel: 18, minLevel: 1, maxLevel: 20, cooldown: 0,
      scaling: { passiveStatsPerLevel: { defensePct: 0.04 } } });
    expect(row).not.toHaveProperty('cost');
    expect(row).not.toHaveProperty('damage');
  });

  it.each([0, 0.125, 3])('accepts finite nonnegative defense coefficient %s without a balance ceiling', defensePct => {
    expect(validate({ ...authored(), scaling: { passiveStatsPerLevel: { defensePct } } })).toBe(true);
  });

  it('permits alternative positive integer unlock/cap and explicit passive classification', () => {
    expect(validate({ ...authored(), requiredLevel: 9, maxLevel: 31,
      passive: true, aura: false, summon: false })).toBe(true);
  });

  it.each(malformedRows)('rejects malformed exact Iron Skin row %j', fields => {
    expect(validate({ ...authored(), ...fields })).toBe(false);
  });

  it('preserves every other currently authored Barbarian skill', () => {
    for (const row of barbarianSkills.filter(row => row.id !== 'skills-barbarian-iron-skin')) {
      expect(validate(row), row.id).toBe(true);
    }
  });

  it('preserves neighboring exact player contracts and all authored Sorceress/Paladin rows', () => {
    for (const row of [...sorceressSkills, ...paladinSkills]) expect(validate(row), row.id).toBe(true);
  });

  it('does not impose the exact-player contract on a distinct passive identity', () => {
    expect(validate({ ...authored(), id: 'skills-other-defense', requiredLevel: undefined,
      scaling: undefined, cooldown: 1, cost: { mana: 1 } })).toBe(true);
  });
});

