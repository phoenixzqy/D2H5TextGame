import { runBattle, runBattleRecorded, type CombatSnapshot } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { ActiveStatus, CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
import type { DamageType, DerivedStats } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/types/attributes';
import { composeHeroRecovery } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/progression/warmth';
import { getSkill, loadDefaultSkills, registerSkill, resetRegistry } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import * as rngModule from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/rng';

const MASTERY = 'skills-sorceress-fire-mastery';
const WARMTH = 'skills-sorceress-warmth';
const stats: DerivedStats = {
  life: 200, lifeMax: 200, mana: 200, manaMax: 200, attack: 1, defense: 0, magicResist: 0,
  attackSpeed: 100, critChance: 0, critDamage: 1.5, physDodge: 0, magicDodge: 0,
  magicFind: 0, goldFind: 0,
  resistances: { fire: 0, cold: 0, lightning: 0, poison: 0, arcane: 0, physical: 0 }
};
const hold = (appliedAtMs = 0): ActiveStatus => ({
  id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1, appliedAtMs
});
const unit = (id: string, side: CombatUnit['side'], overrides: Partial<CombatUnit> = {}): CombatUnit =>
  ({ id, name: id, side, level: 40, tier: 'trash', stats, life: 200, mana: 200,
    statuses: [], cooldowns: {}, skillOrder: [], activeBuffIds: [], enraged: false, ...overrides });

/** Imported ranks/stun/resources isolate real spell consumption, never campaign balance. */
function snapshot(masteryRank = 20, warmthRank = 0): CombatSnapshot {
  const skillLevels = { [MASTERY]: masteryRank, [WARMTH]: warmthRank, 'skills-sorceress-fire-bolt': 20 };
  const { increasedDamagePct } = composeHeroRecovery({
    classId: 'sorceress', level: 40, effectiveEnergy: 20, skillLevels
  });
  return { seed: 7,
    playerTeam: [unit('sorceress', 'player', { kind: 'hero', mana: 8, skillLevels,
      increasedDamagePct, skillOrder: ['skills-sorceress-fire-bolt'], statuses: [hold(1701)] })],
    enemyTeam: [unit('target', 'enemy', { life: 500,
      stats: { ...stats, life: 500, lifeMax: 500 }, statuses: [hold()] })] };
}
const withHero = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, playerTeam: input.playerTeam.map(u => ({ ...u, ...fields })) });
const withTarget = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, enemyTeam: input.enemyTeam.map(u => ({ ...u, ...fields })) });

resetRegistry(); loadDefaultSkills();
console.log(JSON.stringify(runBattleRecorded(snapshot(0, 1))));
