# P07a02A — Fire Mastery definition prerequisite

Root owns writes/execution in the continuing claimed umbrella worktree. Existing
agents independently review read-only; no new agent. Start after P07b01 packet
closure/release. The complete private-v1 goal remains open.

Four writable repository files: src/data/schema/skill.schema.json;
src/engine/skills/fire-mastery.ts; src/engine/skills/fire-mastery.test.ts;
docs/plans/decisions/D05-fire-mastery-v1.md. No runtime wiring or data/copy edits.

GD/TD approve authored requiredLevel30 over legacy minLevel12, cap20 and fire
fraction.04 per rank. Document older spec L12/+30% and fixed30% locales as
superseded; reconcile them in a separate3file increment before full acceptance.
Definition/rank alone does not implement the passive.

1. Freeze/review concrete schema-only tests outside repository, then install
   only matching test file and run genuine schema RED before schema edits.
   Exact authored identity has passive/self/zeroCD, required positive unlock,
   positive integer cap and required finite nonnegative fire coefficient without
   a ceiling. Passive true/absent; aura/summon false/absent. Scaling contains
   exactly passiveStatsPerLevel.fireDamagePct. Exclude cost, direct damage/type,
   offensive status/tag/synergy, heal, summonId, AoE and equipment-gate metadata.
   Other skill identities retain their current schema behavior. Real data hash
   is unchanged. Keep invalid NaN/Infinity/-Infinity/string/null/negative cases,
   alternative valid tuning including zero and above-one coefficients, and
   unknown/extra field negative controls.
2. Append separately reviewed definition/rank tests to the same test file;
   preserve missing-module capability failure separately from behavioral RED.
   Add exact schema conditional and standalone immutable JSON-derived definition.
   API exports readonly FireMasteryDefinition{requiredLevel,maxRank,
   fireDamagePctPerRank}, resolveFireMasteryDefinition(rows:readonly unknown[]),
   FIRE_MASTERY_DEFINITION and allocation-only resolveFireMasteryRank(levels?,def?).
   Definition selects exactly one authored identity and validates with the
   existing strict Ajv2020 schema. Copy/freeze only primitives, never caller data.
   Rank accepts finite positive integers at exact authored/canonical aliases,
   takes MAX once and clamps to copied cap; invalid/missing/wrong aliases0.
   Tests cover mutable input independence, alternate valid JSON tuning,
   malformed/missing/duplicate definitions, rank1/10/20/overcap, duplicate/conflicting
   alias permutations and no rank-one fallback. Class/level eligibility is
   deferred to later authoritative hero composition (no CombatUnit kind/class gate).
3. Minimal GREEN; preserve original tests/candidates/errors and review any
   provably incorrect oracle correction before execution. Focused/engine/full
   unit/type/lint/clean production bridge build run sequentially with existing
   bounded runner limits and caps. Existing timing misses/warnings are disclosed.
   No need to rerun browser for this unconnected pure representation slice.
4. Independent exact-source/gate review; commit4file increment, record evidence
   and whole-packet review, remove exact owned outputs only after readers release.
   Continue later composition, imported-combo inactivity, directfire/Burn,
   authoritative class/level and native/no-refill/save/browser proof.

Security check: pass. Local typed JSON definition/schema/rank only; no new network,
credentials, dependency, CI/permission, save format, external publication, policy
or validation bypass. Process handling retains exact-owned PID/startTick safety.

Bounds: focused30/engine120/unit120/types90/lint90/build210seconds+2s cleanup;
32MiB per log/report,64MiB RAW+dist+.vite. Runner SHA358f8e249fd7a8f8018a978b9746e8ffde7e530298b21c47cbeb35ad6ef6fdb5
includes independently approved vanished-entry monitor fix; caps/ownership unchanged.
