import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { runBattle, runBattleRecorded, type CombatSnapshot } from './combat';
import type { ActiveStatus, CombatUnit } from './types';
import type { DamageType, DerivedStats } from '../types/attributes';
import { composeHeroRecovery } from '../progression/warmth';
import { getSkill, loadDefaultSkills, registerSkill, resetRegistry } from '../skills/registry';
import * as rngModule from '../rng';

const MASTERY = 'skills-sorceress-fire-mastery';
const WARMTH = 'skills-sorceress-warmth';
const stats: DerivedStats = {
  life: 200, lifeMax: 200, mana: 200, manaMax: 200, attack: 1, defense: 0, magicResist: 0,
  attackSpeed: 100, critChance: 0, critDamage: 1.5, physDodge: 0, magicDodge: 0,
  magicFind: 0, goldFind: 0,
  resistances: { fire: 0, cold: 0, lightning: 0, poison: 0, arcane: 0, physical: 0 }
};
const hold = (appliedAtMs = 0): ActiveStatus => ({
  id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1, appliedAtMs
});
const unit = (id: string, side: CombatUnit['side'], overrides: Partial<CombatUnit> = {}): CombatUnit =>
  ({ id, name: id, side, level: 40, tier: 'trash', stats, life: 200, mana: 200,
    statuses: [], cooldowns: {}, skillOrder: [], activeBuffIds: [], enraged: false, ...overrides });

/** Imported ranks/stun/resources isolate real spell consumption, never campaign balance. */
function snapshot(masteryRank = 20, warmthRank = 0): CombatSnapshot {
  const skillLevels = { [MASTERY]: masteryRank, [WARMTH]: warmthRank, 'skills-sorceress-fire-bolt': 20 };
  const { increasedDamagePct } = composeHeroRecovery({
    classId: 'sorceress', level: 40, effectiveEnergy: 20, skillLevels
  });
  return { seed: 7,
    playerTeam: [unit('sorceress', 'player', { kind: 'hero', mana: 8, skillLevels,
      increasedDamagePct, skillOrder: ['skills-sorceress-fire-bolt'], statuses: [hold(1701)] })],
    enemyTeam: [unit('target', 'enemy', { life: 500,
      stats: { ...stats, life: 500, lifeMax: 500 }, statuses: [hold()] })] };
}
const withHero = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, playerTeam: input.playerTeam.map(u => ({ ...u, ...fields })) });
const withTarget = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, enemyTeam: input.enemyTeam.map(u => ({ ...u, ...fields })) });

beforeEach(() => { resetRegistry(); loadDefaultSkills(); });
afterEach(() => { vi.restoreAllMocks(); resetRegistry(); loadDefaultSkills(); });

describe('P07a02B real Fire Bolt with automatic Fire Mastery and Warmth', () => {
  it.each([
    { rank: 0, warmth: 0, hit: 106, dots: [[3400, 17], [4700, 13]], hp: 364 },
    { rank: 1, warmth: 0, hit: 110, dots: [[3400, 18], [4700, 15]], hp: 357 },
    { rank: 10, warmth: 0, hit: 148, dots: [[3400, 23], [4700, 19]], hp: 310 },
    { rank: 20, warmth: 0, hit: 190, dots: [[3400, 32], [4700, 25]], hp: 253 },
    { rank: 1, warmth: 1, hit: 111, dots: [[3400, 18], [4700, 15]], hp: 356 },
    { rank: 20, warmth: 20, hit: 212, dots: [[3400, 35], [4700, 28]], hp: 225 }
  ])('uses literal rank$rank/Warmth$warmth direct fire and Burn once', ({ rank, warmth, hit, dots, hp }) => {
    expect(getSkill('skills-sorceress-fire-bolt')).toMatchObject({ id: 'sorceress.fire_bolt',
      manaCost: 8, effects: [{ kind: 'damage', damageType: 'fire', base: [30, 45],
        perRank: [4, 4], applyStatus: { id: 'burn', dotPctOfDamage: 0.1 } }] });
    const input = snapshot(rank, warmth);
    const before = structuredClone(input);
    const spell = structuredClone(getSkill('sorceress.fire_bolt'));
    const passive = structuredClone(getSkill('sorceress.fire_mastery'));
    const result = runBattleRecorded(input);
    // Seed7 range106; final floor(106*(1+.04*rank+.01*warmth)). Burn rate=floor(hit*.1).
    expect.soft(result.events.filter(e => e.kind === 'action')).toEqual([
      expect.objectContaining({ skillId: 'sorceress.fire_bolt', simClockMs: 1700 })
    ]);
    expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ source: 'sorceress', target: 'target', amount: hit,
        damageType: 'fire', crit: false, dodged: false, simClockMs: 1700 })
    ]);
    expect.soft(result.events.filter(e => e.kind === 'dot').map(e => [e.simClockMs, e.amount])).toEqual(dots);
    expect.soft(result.result.enemyTeam[0]?.life).toBe(hp);
    expect(result.result.playerTeam[0]?.mana).toBe(0);
    expect(result.result.playerTeam[0]?.activeBuffIds).toEqual([]);
    expect(runBattle(input)).toEqual(result.result);
    expect(runBattleRecorded(input)).toEqual(result);
    expect(input).toEqual(before);
    expect(getSkill('sorceress.fire_bolt')).toEqual(spell);
    expect(getSkill('sorceress.fire_mastery')).toEqual(passive);
  });

  it('adds both passives before combo, crit, resistance, ordinary defense and floor', () => {
    const input = withTarget(withHero(snapshot(20, 20), { stats: { ...stats, critChance: 1, critDamage: 2 } }), {
      stats: { ...stats, life: 500, lifeMax: 500, defense: 7,
        resistances: { ...stats.resistances, fire: 25 } },
      statuses: [hold(), { id: 'paralyze', sourceId: 'fixture', stacks: 1, remaining: -1 }]
    });
    const result = runBattleRecorded(input);
    // floor(106*2*1.2*2*.75-7)=374. Burn37/s integrates1700ms then1300ms.
    expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ amount: 374, crit: true, dodged: false, simClockMs: 1700 })
    ]);
    expect.soft(result.events.filter(e => e.kind === 'dot').map(e => [e.simClockMs, e.amount]))
      .toEqual([[3400, 62], [4700, 49]]);
    expect.soft(result.result.enemyTeam[0]?.life).toBe(15);
  });

  it.each(['skills-sorceress-fire-mastery', 'sorceress.fire_mastery'])(
    'never executes imported passive %s or spends a passive action/resource/CD/marker', id => {
      expect(getSkill(id)).toMatchObject({ trigger: 'passive', manaCost: 0, cooldown: 0 });
      const result = runBattleRecorded(withHero(snapshot(), { skillOrder: [id, 'skills-sorceress-fire-bolt'] }));
      expect.soft(result.events.filter(e => e.kind === 'action')).toEqual([
        expect.objectContaining({ skillId: 'sorceress.fire_bolt', simClockMs: 1700 })
      ]);
      expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([expect.objectContaining({ amount: 190 })]);
      expect(result.events.filter(e => e.kind === 'buff')).toEqual([]);
      expect(result.result.playerTeam[0]?.activeBuffIds).toEqual([]);
      expect(result.result.playerTeam[0]?.cooldowns).toEqual({});
      expect(result.result.playerTeam[0]?.mana).toBe(0);
    });

  it('retains the same hit/range/crit/status RNG stream with unchanged action/death topology', () => {
    const random = rngModule.createRng(7);
    const range = vi.spyOn(random, 'nextInt');
    const chance = vi.spyOn(random, 'chance');
    vi.spyOn(rngModule, 'createRng').mockReturnValue(random);
    expect.soft(runBattle(snapshot(20, 20)).enemyTeam[0]?.life).toBe(225);
    expect(range.mock.calls).toEqual([[106, 121]]);
    expect(chance.mock.calls).toEqual([[0.85], [0], [1]]);
    expect(random.next()).toBe(0.5214452685322613);
  });

  it.each(['cold', 'lightning', 'arcane', 'poison', 'physical', 'thorns'] as const)(
    'does not increase fixed100 %s probe damage or mutate attack', (damageType: DamageType) => {
      registerSkill({ id: 'fixture.mastery-probe', archetype: 'fixture', target: 'single-enemy',
        manaCost: 0, cooldown: 0, minLevel: 1, effects: [{ kind: 'damage', damageType, base: [100, 100] }] });
      const result = runBattleRecorded(withHero(snapshot(20, 20), { skillOrder: ['fixture.mastery-probe'] }));
      expect(result.events.filter(e => e.kind === 'damage')).toEqual([
        expect.objectContaining({ damageType, amount: 100, crit: false, dodged: false, simClockMs: 1700 })
      ]);
      expect(result.result.enemyTeam[0]?.life).toBe(400);
      expect(result.result.playerTeam[0]?.stats).toEqual(stats);
      expect(result.result.playerTeam[0]?.mana).toBe(8);
    });

  it('preserves pre-existing Burn potency/source/start/longer expiry and caps stacks', () => {
    const legacy: ActiveStatus = { id: 'burn', sourceId: 'old', appliedAtMs: 0,
      expiresAtMs: 100000, remaining: 100, stacks: 4, dotPerStack: 7, damageType: 'fire' };
    const input = withTarget(withHero(snapshot(20, 20), { mana: 16, statuses: [hold(3401)] }), {
      life: 10000, stats: { ...stats, life: 10000, lifeMax: 10000 }, statuses: [hold(), legacy]
    });
    const result = runBattleRecorded(input);
    // Two real spell hits212+224; existing rate7/stacks4→5 integrates2088; no replacement/multiplication.
    expect.soft(result.events.filter(e => e.kind === 'damage').map(e => [e.simClockMs, e.amount]))
      .toEqual([[1700, 212], [3400, 224]]);
    expect.soft(result.events.filter(e => e.kind === 'dot').reduce((sum, e) => sum + e.amount, 0)).toBe(2088);
    expect.soft(result.result.enemyTeam[0]?.life).toBe(7476);
    expect(result.result.enemyTeam[0]?.statuses).toEqual([hold(), { ...legacy, stacks: 5 }]);
  });
});

describe('P07a02B canonical fresh Burn and allied boundaries', () => {
  it('retains initial enhanced Burn rate21 when second hit224 refreshes its stacks/expiry', () => {
    const input = withTarget(withHero(snapshot(20, 20), { mana: 16, statuses: [hold(3401)] }), {
      life: 1000, stats: { ...stats, life: 1000, lifeMax: 1000 }
    });
    const before = structuredClone(input);
    const result = runBattleRecorded(input);
    expect.soft(result.events.filter(e => e.kind === 'damage').map(e => [e.simClockMs, e.amount]))
      .toEqual([[1700, 212], [3400, 224]]);
    // Initial21/s survives refresh: floor cumulative35.7+71.4+54.6=161, no second fire multiplier.
    expect.soft(result.events.filter(e => e.kind === 'dot').map(e => [e.simClockMs, e.amount]))
      .toEqual([[3400, 35], [5100, 72], [6400, 54]]);
    expect.soft(result.result.enemyTeam[0]?.life).toBe(403);
    expect(result.result.enemyTeam[0]?.statuses).toEqual([hold()]);
    expect(result.result.playerTeam[0]?.mana).toBe(0);
    expect(input).toEqual(before);
  });

  it('does not inherit hero Mastery/Warmth on a second actual allied Fire Bolt', () => {
    const input = snapshot(20, 20);
    const result = runBattleRecorded({ ...input, playerTeam: [...input.playerTeam,
      unit('ally', 'player', { kind: 'merc', mana: 8, stats: { ...stats, attackSpeed: 87 },
        skillOrder: ['skills-sorceress-fire-bolt'], skillLevels: { 'sorceress.fire_bolt': 20 },
        statuses: [hold(1805)] })] });
    expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ source: 'sorceress', amount: 212, simClockMs: 1700 }),
      expect.objectContaining({ source: 'ally', amount: 112, simClockMs: 1804 })
    ]);
    expect(result.result.playerTeam[1]?.increasedDamagePct).toBeUndefined();
    expect(result.result.playerTeam.map(u => u.mana)).toEqual([0, 0]);
  });
});
