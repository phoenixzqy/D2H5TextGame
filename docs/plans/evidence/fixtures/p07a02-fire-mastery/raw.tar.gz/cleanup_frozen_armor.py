from pathlib import Path
import json,hashlib,tarfile,stat,datetime,sys
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
r=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-frozen-armor-wtwinptx')
dest=w/'docs/plans/evidence/fixtures/p07b01-frozen-armor'
next_raw=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-fire-mastery-3c7zf7mr')
sha=lambda b:hashlib.sha256(b).hexdigest()
packet_bytes=(dest/'packet.json').read_bytes()
assert len(sys.argv)==2 and sha(packet_bytes)==sys.argv[1]
p=json.loads(packet_bytes)
assert sha((dest/'raw.tar.gz').read_bytes())==p['archive']['sha256']
review=json.loads((dest/'final-review.json').read_text())
assert review['allReadersReleased'] and review['producer']=='APPROVE' and review['QA']=='APPROVE'
assert review['packetSHA256']==sha(packet_bytes)
assert sha(Path(__file__).read_bytes())==next(x['sha256'] for x in p['records'] if x['path']=='cleanup_frozen_armor.py')
assert r.resolve()==r and r.is_dir() and not r.is_symlink()
actual=[]
for f in r.rglob('*'):
 m=f.lstat().st_mode;assert not stat.S_ISLNK(m),f
 if not stat.S_ISDIR(m):
  assert stat.S_ISREG(m),f
  actual.append(str(f.relative_to(r)))
assert set(actual)=={x['path'] for x in p['records']}
with tarfile.open(dest/'raw.tar.gz') as tar:
 for row in p['records']:
  b=(r/row['path']).read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256']
  assert sha(tar.extractfile(row['path']).read())==row['sha256']
audit=json.loads((r/'final-process-audit.json').read_text())
for row in audit['identities']:
 try:
  f=Path(f"/proc/{row['pid']}/stat").read_text().rsplit(')',1)[1].split()
  assert int(f[19])!=row['startTicks'] or f[0]=='Z',row
 except FileNotFoundError:pass
expected={str(r):p['records']}
for group in json.loads((r/'final-owned-output.json').read_text()):expected[group['root']]=group['records']
result={'card':'P07b01','runtime':['ed05766','93022ee'],'browser':'562da72','owner':'root','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allReadersReleased':True,'archiveRawVerified':True,'nonliveProcessIdentities':audit['identityCount'],'signals':[],'removed':[],'nextRaw':str(next_raw),'preserved':['pre-existing empty coverage','installed tools/dependencies/browser','shared caches','source/history/durable evidence','umbrella worktree']}
for root in [r,w/'dist',w/'node_modules/.vite']:
 assert root.resolve()==root and root.is_dir() and not root.is_symlink()
 files=[];dirs=[]
 for f in root.rglob('*'):
  m=f.lstat().st_mode;assert not stat.S_ISLNK(m),f
  if stat.S_ISDIR(m):dirs.append(f)
  else:
   assert stat.S_ISREG(m),f
   b=f.read_bytes();files.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
 assert {x['path']:(x['bytes'],x['sha256']) for x in files}=={x['path']:(x['bytes'],x['sha256']) for x in expected[str(root)]}
 for row in files:
  f=root/row['path'];assert sha(f.read_bytes())==row['sha256'];f.unlink()
 for d in sorted(dirs,key=lambda x:len(x.parts),reverse=True):d.rmdir()
 root.rmdir();assert not root.exists()
 result['removed'].append({'root':str(root),'files':len(files),'records':files,'absenceVerified':True})
assert (w/'coverage').is_dir() and not list((w/'coverage').iterdir())
with (dest/'cleanup.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
with (next_raw/'frozen-armor-cleanup.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'removed':[{k:x[k] for k in ['root','files','absenceVerified']} for x in result['removed']],'nonliveProcessIdentities':p['processIdentityCount'],'coveragePreservedEmpty':True}))
