import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { startSubAreaRun, abortSubAreaRun, resetIdleElitePity, resolveCombatUnitDisplayName } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { useCombatStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatStore';
import { usePlayerStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/playerStore';
import { useInventoryStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/inventoryStore';
import { useMapStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/mapStore';
import { useMercStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/mercStore';
import { useFormationStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/formationStore';
import { useMetaStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/metaStore';
import { eventToLocalizedLogEntry } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/eventToLogI18n';
import { hashSeed } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/rng';
import { getSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import i18n from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/i18n';
const AREA = 'areas/act1-blood-moor';
const FIXED = '2026-10-20T12:00:00.000Z';
const BOLT = 'skills-sorceress-fire-bolt';
const MASTERY = 'sorceress.fire_mastery';
const stores = [useCombatStore, usePlayerStore, useInventoryStore, useMapStore, useMercStore, useFormationStore, useMetaStore];
const originalNow = Date.now;
Date.now = () => new Date(FIXED).getTime();
const captures = [];
try {
  for (const rank of [0, 1, 2]) {
    abortSubAreaRun(); resetIdleElitePity();
    for (const store of stores) store.getState().reset();
    const fresh = createMockPlayer('Fire Mastery', 'sorceress');
    const fixture = { ...fresh, level: 30, skillPoints: 2 - rank,
      skillLevels: { 'sorceress.fire_bolt': 1, ...(rank ? { [MASTERY]: rank } : {}) }, comboOrder: [BOLT] };
    usePlayerStore.getState().setPlayer(fixture);
    useMapStore.getState().setCurrentLocation(1, AREA);
    await i18n.changeLanguage('en');
    const runSeed = hashSeed(`${AREA}|${String(Date.now())}`);
    const run = startSubAreaRun({ runSeed, challengeOrdinal: 0 });
    if (!run) throw new Error('Native route failed');
    const state = useCombatStore.getState();
    const teams = structuredClone({ player: state.playerTeam, enemy: state.enemyTeam });
    const events = structuredClone(state.recordedEvents);
    let casts = 0; let witnessIndex = -1;
    for (let index = 0; index < events.length; index++) {
      const event = events[index];
      if (event?.kind === 'action' && event.actor === fixture.id) {
        if (event.skillId !== BOLT && event.skillId !== 'sorceress.fire_bolt') break;
        casts++;
        if (casts > 3) break;
      }
      if (casts && event?.kind === 'damage' && event.source === fixture.id && event.damageType === 'fire' && !event.dodged && event.amount > 0) {
        witnessIndex = index; break;
      }
    }
    const localized: Record<string, unknown> = {};
    for (const locale of ['en', 'zh-CN']) {
      await i18n.changeLanguage(locale);
      const names = new Map([...teams.player, ...teams.enemy].map(unit => [unit.id, resolveCombatUnitDisplayName(unit)]));
      localized[locale] = { names: [...names], logs: events.map(event => eventToLocalizedLogEntry(event, names)) };
    }
    await i18n.changeLanguage('en');
    const timeline = [{ index: -1, mp: teams.player[0]?.mana, heroHP: teams.player[0]?.life, enemyHP: teams.enemy.map(unit => [unit.id, unit.life]) }];
    const stop = witnessIndex >= 0 ? witnessIndex : events.length - 1;
    for (let index = 0; index <= stop; index++) {
      useCombatStore.getState().advanceEvent();
      const next = useCombatStore.getState();
      timeline.push({ index, mp: next.playerTeam[0]?.mana, heroHP: next.playerTeam[0]?.life, enemyHP: next.enemyTeam.map(unit => [unit.id, unit.life]) });
    }
    captures.push({ rank, fixture, inventory: useInventoryStore.getState().equipped,
      map: { currentAct: 1, currentSubAreaId: AREA, clearedSubAreas: [] }, formation: useFormationStore.getState().playerPosition,
      run, teams, bolt: getSkill(BOLT), events, outcome: state.outcome, localized, casts, witnessIndex, witness: events[witnessIndex] ?? null, timeline });
  }
  writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-fire-mastery-3c7zf7mr/browser-native-capture.json', JSON.stringify({ fixedTime: FIXED, seedFormula: 'hashSeed(AREA + | + Date.now())', captures }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(captures.map(({rank, run, casts, witnessIndex, witness, timeline}) => ({rank, run, casts, witnessIndex, witness, timeline}))));
} finally {
  Date.now = originalNow; abortSubAreaRun();
  for (const store of stores) store.getState().reset();
}
