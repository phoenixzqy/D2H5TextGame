# P07a02B — automatic Fire Mastery composition

Root owns all repository writes/execution in continuing claimed umbrella worktree.
Stage A must be committed with final current-byte gates/review before this begins.
Existing producer/QA/GD/TD review read-only, no new agents. Whole private v1 open.

Five writable paths: src/engine/progression/warmth.ts; new adjacent
fire-mastery-composition.test.ts; new src/engine/combat/fire-mastery.test.ts;
new src/stores/fire-mastery-composition.test.ts; production/bugs/BUG-059-fire-mastery.md.
No combat/store/catalog runtime edit unless genuine RED establishes missing
integration, requiring a separately scoped increment. D05 remains controlling.

Freeze/review concrete tests before installation. Run genuine behavioral RED
against Stage A (schema/definition alone); preserve all failures and controls.
Write structured BUG-059 before modifying warmth.ts. Preserve a complete actual
unaffected prepatch recording, not just an event count/digest computed by the
new runtime. Store original tests and any proposed incorrect-oracle correction
separately for independent review before running corrected assertions.

Minimal source change imports FIRE_MASTERY_DEFINITION/resolveFireMasteryRank into
composeHeroRecovery. Independently gate Sorceress+finite level>=copied unlock,
resolve allocated capped maximum alias rank, add coefficient*rank alongside
existing Warmth fire. Preserve Warmth recovery/eligibility and immutable shape.
Existing playerToCombatUnit/playWave writes fresh composition, direct damage
reads increasedPct and fresh Burn derives from finalhit once. Existing passive
trigger guard must exclude forged/imported combo execution.

Pure tests: current rank0/1/10/20, both aliases/max/duplicates/overcap/runtime
invalid values; L29/L30/finite level/wrong class gates independently of Warmth;
combined ranks1+1=.05,20+20=1; removal/repeated immutable no accumulation; recovery
unchanged, no other passive inheritance. No CombatUnit class/kind gate.

Combat: production FireBolt rank20 seed7, literal known base106; no Mastery combo
needed, both imported aliases produce no Mastery action/MP/CD/marker. Pin initial
fire bonus, ordinary ordering and Burn potency/timing once, canonical active
refresh, unchanged nonfire and allied damage, same topology RNG control,
recorded/unrecorded/replay/input/catalog immutability. Fixture stun/HP/resources
are explicit engine scaffolding, no acquisition/balance claim.

Native: actual store allocate/upgrade at imported eligibleL30 with points; real
Moor seed7/ordinal0 plan/playback/awards plus disclosed gear/finisher scaffolding.
Current recording immutable on mutations; next real wave pulls fresh ranks;
removal clears only Mastery while preserving Warmth; replay always begins from
stored original input resources/exact recovery carry, no stack/refill/rewards.
Adapter class/level gates, fresh run reset and full save/export/reload absence of
runtime fields must be tested through existing boundaries. Native synthetic
configuration is labeled and not ordinary earned campaign proof.

Sequential bounded focused/E/U/T/L/production bridge build, no coverage/budget
relaxation. Exact-source/gate independent review before commit. Preserve RAW until
whole Fire Mastery packet consumers finish; archive all stages/failures/reviews
then remove only exact-owned outputs after readers/processes release. Runner
bounds/caps/ownership unchanged from Stage A. Separate three-file spec/en/zh
correction and production browser route remain required before full acceptance.
No seed search, recipe escalation, save migration, broad process kills, remote
publication, campaign/balance or complete private-v1 claim.

GD-DESIGN-REVIEW/TD-ARCH-REVIEW: APPROVE runtime shape; concrete tests/gates pending.
Security check: PASS local deterministic composition only; no credentials,
network/dependency/permissions/CI/save-format change or validation bypass.
