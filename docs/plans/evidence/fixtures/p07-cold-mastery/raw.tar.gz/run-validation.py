import hashlib, json, os, re, subprocess, time
from pathlib import Path
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cold-mastery-z8mtwgmg')
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
paths=[p for p in paths if p.startswith(('src/','tests/','scripts/')) or ('/' not in p and p.endswith(('.ts','.json','.mjs','.cjs')))]
def freeze():
 return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
before=freeze(); (root/'source-freeze.json').write_text(json.dumps(before,indent=2))
report={'sourceFiles':len(before),'stages':[],'processes':[]}
env=dict(os.environ);env.pop('VITE_E2E',None)
stages=[('types',['npm','run','typecheck']),('lint',['npm','run','lint']),('engine',['npm','run','test:engine']),('build',['npm','run','build','--','--outDir',str(root/'dist')]),('full',['npm','test'])]
for name,command in stages:
 start=time.monotonic()
 with (root/f'{name}.log').open('w') as log:
  child=subprocess.Popen(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  report['processes'].append({'stage':name,'pid':child.pid,'command':command,'terminal':False})
  (root/'validation.json').write_text(json.dumps(report,indent=2))
  print(f'{name}: running PID {child.pid}',flush=True)
  code=child.wait()
 report['processes'][-1]['terminal']=True
 report['stages'].append({'stage':name,'exit':code,'seconds':round(time.monotonic()-start,3)})
 report['sourceDrift']=[p for p,h in before.items() if freeze()[p]!=h]
 (root/'validation.json').write_text(json.dumps(report,indent=2))
 print(f'{name}: exit {code}, {report["stages"][-1]["seconds"]}s',flush=True)
 if code or report['sourceDrift']: raise SystemExit(code or 2)
 if name=='build':
  chunks=list((root/'dist').rglob('*.js'))
  patterns=[r'__GAME__',r'\bseedItem\b',r'\bseedMerc\b',r'\binstallTestBridge\b',r'[,{]flushSave:']
  bad=[str(p.relative_to(root/'dist')) for p in chunks if any(re.search(pattern,p.read_text()) for pattern in patterns)]
  bridge={'chunks':len(chunks),'violations':bad,'sha256':{str(p.relative_to(root/'dist')):hashlib.sha256(p.read_bytes()).hexdigest() for p in chunks}}
  (root/'bridge-scan.json').write_text(json.dumps(bridge,indent=2))
  if bad: raise SystemExit('Production bridge markers found')
print('All serial checks passed without source drift.',flush=True)
