import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cold-mastery-z8mtwgmg';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try{
 const { validateSave }=await server.ssrLoadModule('/src/engine/save/validate.ts');
 const report=JSON.parse(await readFile(root+'/browser-results.json','utf8'));
 assert.equal(report.cases.length,10);let saves=0,pairs=0;
 for(const c of report.cases){assert.equal(c.status,'pass');assert.deepEqual(c.pageErrors,[]);assert.deepEqual(c.console,[]);
  for(const save of Object.values(c.states)){const before=JSON.stringify(save);validateSave(save);assert.equal(JSON.stringify(save),before);saves++;}
  const {fresh,imported,saved,continued}=c.states;
  assert.equal(fresh.player.level,1);assert.equal(imported.player.level,30);assert.equal(imported.player.skillPoints,2);
  assert.deepEqual(saved,continued);pairs++;
  assert.equal(saved.player.skillPoints,0);assert.equal(saved.player.skillLevels['sorceress.cold_mastery'],2);
  assert.equal(saved.player.level,30);assert.deepEqual(saved.player.derivedStats,imported.player.derivedStats);
  assert.ok(!('coldResistanceReductionPct' in saved.player));
  for(const domain of ['inventory','merc','map','formation','endgame'])assert.deepEqual(saved[domain],imported[domain]);
 }
 const frozen=JSON.parse(await readFile(root+'/source-freeze.json','utf8'));const drift=[];
 for(const [path,hash]of Object.entries(frozen))if(createHash('sha256').update(await readFile(repo+'/'+path)).digest('hex')!==hash)drift.push(path);
 assert.deepEqual(drift,[]);
 const receipt={kind:'root self-audit; independent acceptance pending',cases:10,nativeSaves:saves,exactDurablePairs:pairs,
  sourceFiles:Object.keys(frozen).length,sourceDrift:drift,combatLaunches:0,status:'pass'};
 await writeFile(root+'/browser-audit.json',JSON.stringify(receipt,null,2));process.stdout.write(JSON.stringify(receipt)+'\n');
}finally{await server.close();}
