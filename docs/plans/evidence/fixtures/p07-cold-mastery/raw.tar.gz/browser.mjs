import { chromium, expect } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cold-mastery-z8mtwgmg';
const base='http://127.0.0.1:4403';
const report={kind:'constructed production skill allocation and persistence; zero combat, no earned or balance claim',retries:0,cases:[]};
const sizes=[{width:360,height:640},{width:412,height:915},{width:640,height:360},{width:1280,height:800},{width:1920,height:1080}];
let prepared;
await mkdir(root+'/browser-evidence',{recursive:true});
const browser=await chromium.launch({headless:true,downloadsPath:root+'/downloads'});
try {
 for(const locale of ['en','zh-CN'])for(const viewport of sizes){
  const key=`${locale}-${viewport.width}x${viewport.height}`;
  const result={key,status:'running',pageErrors:[],console:[],states:{},geometry:[]};report.cases.push(result);
  const context=await browser.newContext({viewport,acceptDownloads:true});
  context.on('page',page=>{page.on('pageerror',e=>result.pageErrors.push(e.message));page.on('console',m=>{
   if(['warning','error'].includes(m.type()))result.console.push({type:m.type(),text:m.text()});});});
  const labels=locale==='en'?{save:'Save',import:'Import Save',current:'Current',next:'Next Level',reduction:'Cold Resistance Ignored',
   title:'Cold Mastery',preview:'Learned at Lv. 1',description:'Your direct cold hits ignore 15 percentage points'}:
   {save:'保存',import:'导入存档',current:'当前',next:'下一级',reduction:'无视冰冷抗性',title:'冰冷精通',preview:'学习后 Lv.1',description:'自身直接冰冷伤害在1级时无视敌人15个百分点'};
  async function open(){const p=await context.newPage();await p.clock.setFixedTime(new Date('2026-10-24T05:00:00Z'));
   await p.goto(base);await p.waitForLoadState('networkidle');return p;}
  async function nav(p,path){await p.locator(`a[href="/${path}"]`).first().click();await expect(p.getByTestId(`${path}-screen`)).toBeVisible();}
  async function exported(p,label){const pending=p.waitForEvent('download');await p.getByTestId('export-save-button').click();
   const file=await pending;const s=JSON.parse(await readFile(await file.path(),'utf8'));await file.delete();result.states[label]=s;return s;}
  async function detail(p){await nav(p,'skills');await p.getByTestId('skill-node-skills-sorceress-cold-mastery').click();
   const panel=p.getByTestId('skill-detail-panel');await expect(panel.getByRole('heading',{name:labels.title,exact:true})).toBeVisible();return panel;}
  function section(panel,title){return panel.locator('section').filter({has:panel.page().getByRole('heading',{name:title,exact:true})});}
  async function reduction(panel,title,expected){// Select the definition term's exact adjacent value, independent of text-node whitespace.
   const term=section(panel,title).locator('dt').filter({hasText:labels.reduction});await expect(term).toHaveCount(1);
   await expect(term.locator('xpath=following-sibling::dd')).toHaveText(expected);}
  async function checkGeometry(p,panel,label){await panel.getByRole('button').scrollIntoViewIfNeeded();
   const metrics=await panel.evaluate(el=>{const b=el.querySelector('button').getBoundingClientRect();return {
    documentOverflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,
    panelOverflow:el.scrollWidth-el.clientWidth,buttonWidth:b.width,buttonHeight:b.height};});
   assert.ok(metrics.documentOverflow<=0&&metrics.panelOverflow<=1,JSON.stringify(metrics));
   assert.ok(metrics.buttonWidth>=44&&metrics.buttonHeight>=44,JSON.stringify(metrics));
   result.geometry.push({label,...metrics});await p.screenshot({path:`${root}/browser-evidence/${key}-${label}.png`});}
  let page=await open();
  try{
   await page.getByTestId('home-new-game').click();await page.getByTestId('class-sorceress').click();
   await page.getByTestId('character-name-input').fill('Cold mastery tester');await page.getByTestId('character-start-btn').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');
   await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
   const fresh=await exported(page,'fresh');
   let panel=await detail(page);await expect(panel.getByRole('button')).toBeDisabled();
   await reduction(panel,labels.preview,'15%');await checkGeometry(page,panel,'locked');
   if(!prepared){await writeFile(root+'/browser-fresh.json',JSON.stringify(fresh,null,2));
    execFileSync('node',[root+'/prepare-browser.mjs'],{stdio:['ignore','pipe','pipe']});
    prepared=JSON.parse(await readFile(root+'/browser-prepared.json','utf8'));}
   const input=structuredClone(prepared);input.meta.settings.locale=locale;
   await nav(page,'settings');await page.getByRole('button',{name:labels.import,exact:true}).click();
   const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(input));
   await dialog.getByRole('button',{name:labels.import,exact:true}).click();await expect(dialog).toHaveCount(0);
   await exported(page,'imported');panel=await detail(page);
   await expect(panel).toContainText(labels.description);await expect(panel.getByRole('button')).toBeEnabled();
   await panel.getByRole('button').click();await reduction(panel,labels.current,'15%');
   await reduction(panel,labels.next,/^19%\s*\(\+4%\)$/);await checkGeometry(page,panel,'rank1');
   await panel.getByRole('button').click();await reduction(panel,labels.current,'19%');
   await reduction(panel,labels.next,/^23%\s*\(\+4%\)$/);await expect(panel.getByRole('button')).toBeDisabled();
   await checkGeometry(page,panel,'rank2');await nav(page,'settings');
   await page.getByRole('button',{name:labels.save,exact:true}).click();
   await expect(page.getByText(locale==='en'?'Saved':'已保存',{exact:true})).toBeVisible();
   const saved=await exported(page,'saved');assert.equal(saved.player.skillLevels['sorceress.cold_mastery'],2);
   assert.equal(saved.player.skillPoints,0);assert.equal(saved.meta.settings.locale,locale);
   assert.ok(!('coldResistanceReductionPct' in saved.player));
   for(const domain of ['inventory','merc','map','formation','endgame'])assert.deepEqual(saved[domain],input[domain]);
   await page.close();page=await open();await page.getByTestId('home-continue').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');
   const continued=await exported(page,'continued');assert.deepEqual(continued,saved);
   panel=await detail(page);await reduction(panel,labels.current,'19%');
   await expect(panel).toContainText(labels.description);await checkGeometry(page,panel,'continued');
   assert.deepEqual(result.pageErrors,[]);assert.deepEqual(result.console,[]);result.status='pass';
   process.stdout.write(`${key}: pass\n`);
  }catch(e){result.status='fail';result.failure={message:e.message,stack:e.stack};
   try{await page.screenshot({path:`${root}/browser-evidence/${key}-failure.png`});result.dom=await page.locator('body').innerText();}catch{}
   throw e;
  }finally{await context.close();await writeFile(root+'/browser-results.json',JSON.stringify(report,null,2));}
 }
}finally{await browser.close();await writeFile(root+'/browser-results.json',JSON.stringify(report,null,2));}
