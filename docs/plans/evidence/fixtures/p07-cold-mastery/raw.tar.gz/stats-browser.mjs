import { chromium, expect } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cold-mastery-z8mtwgmg';
const original=JSON.parse(await readFile(root+'/browser-results.json','utf8'));
const report={kind:'additional mobile scroll/readability check from actual passed rank2 saves',retries:0,cases:[]};
const browser=await chromium.launch({headless:true,downloadsPath:root+'/downloads'});
try{for(const locale of ['en','zh-CN']){
 const c={locale,status:'running',errors:[],console:[],rows:[]};report.cases.push(c);
 const context=await browser.newContext({viewport:{width:360,height:640}});const page=await context.newPage();
 page.on('pageerror',e=>c.errors.push(e.message));page.on('console',m=>{if(['error','warning'].includes(m.type()))c.console.push(m.text());});
 try{
  await page.clock.setFixedTime(new Date('2026-10-24T05:00:00Z'));await page.goto('http://127.0.0.1:4403');await page.waitForLoadState('networkidle');
  await page.getByTestId('home-new-game').click();await page.getByTestId('class-sorceress').click();
  await page.getByTestId('character-name-input').fill('Readability check');await page.getByTestId('character-start-btn').click();
  await expect(page.getByTestId('town-screen')).toBeVisible();await page.locator('a[href="/settings"]').first().click();
  await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
  const label=locale==='en'?'Import Save':'导入存档';await page.getByRole('button',{name:label,exact:true}).click();
  const dialog=page.getByRole('dialog');const save=original.cases.find(x=>x.key===`${locale}-360x640`).states.continued;
  await dialog.getByRole('textbox').fill(JSON.stringify(save));await dialog.getByRole('button',{name:label,exact:true}).click();await expect(dialog).toHaveCount(0);
  await page.locator('a[href="/skills"]').first().click();await page.getByTestId('skill-node-skills-sorceress-cold-mastery').click();
  const panel=page.getByTestId('skill-detail-panel');
  for(const [title,value]of [[locale==='en'?'Current':'当前','19%'],[locale==='en'?'Next Level':'下一级',/^23%\s*\(\+4%\)$/]]){
   const section=panel.locator('section').filter({has:page.getByRole('heading',{name:title,exact:true})});
   const term=section.locator('dt').filter({hasText:locale==='en'?'Cold Resistance Ignored':'无视冰冷抗性'});
   const row=term.locator('xpath=following-sibling::dd');await expect(row).toHaveText(value);
   await section.scrollIntoViewIfNeeded();await expect(row).toBeInViewport({ratio:1});
   const rect=await row.boundingBox();assert.ok(rect.y>=123&&rect.y+rect.height<=584,JSON.stringify(rect));
   c.rows.push({title,text:await row.innerText(),rect});await page.screenshot({path:`${root}/browser-evidence/${locale}-360x640-stats-${c.rows.length}.png`});
  }
  assert.deepEqual(c.errors,[]);assert.deepEqual(c.console,[]);c.status='pass';process.stdout.write(`${locale}: stat rows reachable and fully visible\n`);
 }catch(e){c.status='fail';c.failure={message:e.message,stack:e.stack};throw e;}
 finally{await context.close();await writeFile(root+'/stats-browser-results.json',JSON.stringify(report,null,2));}
}}finally{await browser.close();}
