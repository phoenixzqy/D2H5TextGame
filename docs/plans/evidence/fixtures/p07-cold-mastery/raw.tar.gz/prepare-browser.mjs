import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import { readFile, writeFile } from 'node:fs/promises';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cold-mastery-z8mtwgmg';
const vite=await createServer({root:repo,configFile:false,server:{middlewareMode:true},resolve:{alias:{'@':repo+'/src'}}});
try {
 const { deriveEquippedPlayerStats }=await vite.ssrLoadModule('/src/engine/progression/equipped-stats.ts');
 const { validateSave }=await vite.ssrLoadModule('/src/engine/save/validate.ts');
 const fresh=JSON.parse(await readFile(root+'/browser-fresh.json','utf8'));
 const prepared=structuredClone(fresh);
 prepared.player.level=30;prepared.player.skillPoints=2;prepared.player.skillLevels={};
 prepared.player.derivedStats=deriveEquippedPlayerStats(prepared.player,30,prepared.inventory.equipped,
  prepared.map.questProgress,prepared.inventory.questItems,prepared.map.questReceipts);
 validateSave(prepared);
 await writeFile(root+'/browser-prepared.json',JSON.stringify(prepared,null,2));
 await writeFile(root+'/browser-preparation.json',JSON.stringify({kind:'constructed L30 eligibility from actual fresh production UI export; not earned progression',
  source:'browser-fresh.json',changed:['player.level=30','player.skillPoints=2','player.skillLevels={}',
  'player.derivedStats recomposed by production deriveEquippedPlayerStats'],nativeValidation:'pass',
  inventedGear:false,combatLaunches:0},null,2));
}finally{await vite.close();}
