import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { getSkill, listSkills } from "/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry.ts";
const phase = process.env.BENCH_PHASE;
if (phase !== 'final') throw new Error('Unexpected catalog phase');
const json = JSON.stringify(listSkills().map(id => [id, getSkill(id)]), (_key, value) =>
  value instanceof Map ? { mapEntries: [...value] } : value instanceof Set ? { setValues: [...value] } : value);
writeFileSync("/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-damage-masteries-in_ia_ab" + '/catalog-' + phase + '.json', json);
console.log(JSON.stringify({ phase, registered: listSkills().length, catalogSHA256: createHash('sha256').update(json).digest('hex') }));
