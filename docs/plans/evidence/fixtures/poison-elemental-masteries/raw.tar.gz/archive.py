from pathlib import Path
import sys,json,hashlib,tarfile,shutil
root=Path(sys.argv[1]); destination=Path(sys.argv[2])
assert root.parent==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp') and root.name in ['d2h5-skill-validator-vfh47ty2','d2h5-damage-masteries-in_ia_ab']
assert root.is_dir() and not root.is_symlink() and not destination.exists()
files=sorted(root.iterdir());assert all(p.is_file() and not p.is_symlink() for p in files)
ownership=json.loads((root/'ownership.json').read_text());assert all(p['state']=='terminal' for p in ownership['processes'])
destination.mkdir(parents=True)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
archive=destination/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=p.name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(manifest)
 for name,entry in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
(destination/'raw-files.sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['ownership.json','source-provenance.json','source-final-provenance.json','verification.json','browser-summary.json','attachments.sha256.json','benchmark.json','build-provenance.json','attempt-notes.json','next-gameplay-findings.json']:
 if (root/name).exists():shutil.copyfile(root/name,destination/name)
for p in files:p.unlink()
root.rmdir();assert not root.exists()
cleanup={'removedScratchRoot':str(root),'rawFilesArchived':len(files),'rawMembersByteVerified':len(manifest),'allTaskProcessesTerminal':True,'processes':len(ownership['processes']),'buildRemoved':True,'browserStagingRemoved':True,'remainingDisposable':[],'failures':[]}
(destination/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
print(json.dumps(cleanup))
