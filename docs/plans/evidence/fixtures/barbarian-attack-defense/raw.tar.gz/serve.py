from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import os,json
root=Path(__file__).parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(root/'build'),**kwargs)
 def log_message(self,*args):pass
(root/'server-live.json').write_text(json.dumps({'pid':os.getpid(),'port':4503}))
ThreadingHTTPServer(('127.0.0.1',4503),Handler).serve_forever()
