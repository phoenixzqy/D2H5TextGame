from pathlib import Path
import json,hashlib,tarfile,re,subprocess,gzip
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');p=Path(__file__).parent
out=root/'docs/plans/evidence/fixtures/barbarian-attack-defense';out.mkdir(parents=True,exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(file,value):file.write_text(json.dumps(value,indent=2)+'\n')
# Final terminal receipts are mandatory, never inferred from partial logs.
receipts={}
for label in ['engine-final','types-final','lint-final','full-final','browser-final','precache-final','next-attacks']:
 r=json.loads((p/(label+'-result.json')).read_text());assert r['exitCode']==0,(label,r);receipts[label]=r
full=(p/'full-final.log').read_text(errors='replace');m=re.search(r'Test Files\s+(\d+) passed.*?Tests\s+(\d+) passed\s*\|\s*(\d+) skipped',full,re.S);assert m,m
fullFiles,fullTests,skips=map(int,m.groups());assert (fullFiles,fullTests,skips)==(700,15241,2),(fullFiles,fullTests,skips)
f=json.loads((p/'frozen.json').read_text())
for key,base in [('source',root),('build',p/'build')]:
 for name,want in f[key].items():assert sha((base/name).read_bytes())==want,(key,name)
assert sha(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))==f['genuine']
dump(out/'terminal-results.json',{'finalPass':receipts,'fullTests':fullTests,'fullFiles':fullFiles,'existingSkips':skips,'failedOrStopped':{label:json.loads((p/(label+'-result.json')).read_text()) for label in ['full','browser','next-battle-cry']}})
# Keep small diagnostic trace event files; the duplicate asset-resource ZIP is excluded explicitly.
excluded={'browser-en-360/en-360-concentrate-failed-trace.zip'}
files=[file for file in sorted(p.rglob('*')) if file.is_file() and not file.is_symlink() and not file.is_relative_to(p/'build') and str(file.relative_to(p)) not in excluded]
archive=out/'raw.tar.gz';index=[]
with tarfile.open(archive,'w:gz') as tar:
 for file in files:
  name=str(file.relative_to(p));index.append({'path':name,'sha256':sha(file.read_bytes()),'bytes':file.stat().st_size});tar.add(file,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for member in index:
  stream=tar.extractfile(member['path']);assert stream is not None and sha(stream.read())==member['sha256']
dump(out/'packet.json',{'archive':'raw.tar.gz','archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'members':index,'excludedDisposable':{'build':'761 unchanged assets represented by frozen hashes; no duplicate build copy','originalFailedTraceZip':json.loads((p/'failed-browser-trace-events/index.json').read_text())},'receiptNote':'Only finalPass receipts are passes. First failed browser, stopped first full suite and intentional Battle Cry failure remain failures. First focused/lint fixture failures retained as raw logs.','verification':{'archiveMembers':len(index),'allMemberHashesMatch':True,'sourceFiles':len(f['source']),'buildFiles':len(f['build']),'fullFiles':fullFiles,'fullTests':fullTests,'skips':skips}})
print(json.dumps({'archiveMembers':len(index),'archiveBytes':archive.stat().st_size,'fullFiles':fullFiles,'fullTests':fullTests,'skips':skips}))
