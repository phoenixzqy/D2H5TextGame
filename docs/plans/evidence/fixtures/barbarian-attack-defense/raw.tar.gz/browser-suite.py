import os,subprocess,sys
from pathlib import Path
scratch=Path(__file__).parent
for locale,width in [('en','360'),('zh-CN','360'),('en','1280'),('zh-CN','1280')]:
 env={**os.environ,'BROWSER_LOCALE':locale,'BROWSER_WIDTH':width,'BROWSER_RUN':'browser-'+locale+'-'+width}
 code=subprocess.call(['node',str(scratch/'browser.cjs')],env=env)
 if code:sys.exit(code)
