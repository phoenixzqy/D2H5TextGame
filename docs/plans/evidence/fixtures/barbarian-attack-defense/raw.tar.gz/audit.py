from pathlib import Path
import json,hashlib,gzip,os,socket
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path(__file__).parent
out=root/'docs/plans/evidence/fixtures/barbarian-attack-defense';out.mkdir(parents=True,exist_ok=True)
def write(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
def one(folder,pattern):
 files=list(folder.glob(pattern));assert len(files)==1,(folder,pattern,files);return files[0]
def domains(value):return {key:value[key] for key in ['player','inventory','map','mercs','formation']}
pairs=[];cases=[];geometry=[]
for folder in sorted(p.glob('browser-*')):
 if not folder.is_dir():continue
 r=json.loads((folder/'browser-report.json').read_text());assert not r['failures'];assert len(r['cases'])==3
 for c in r['cases']:
  label=c['label'];assert c['pass'] and not c['errors'] and c['pairs']==['rank1','rank2'];assert c['offlineContinue']=={'pass':True,'exactDomains':['player','inventory','map','mercs','formation'],'freshPage':True,'networkOffline':True}
  cases.append(c)
  for rank in ['rank1','rank2']:
   a=one(folder,label+'-'+rank+'-before-*.json');b=one(folder,label+'-'+rank+'-after-*.json');da=json.loads(a.read_text());db=json.loads(b.read_text());assert da['version']==db['version']==22;assert domains(da)==domains(db)
   pairs.append({'label':label,'kind':rank,'before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
  a=one(folder,label+'-rank2-after-*.json');b=one(folder,label+'-offline-continued-*.json');assert domains(json.loads(a.read_text()))==domains(json.loads(b.read_text()))
  pairs.append({'label':label,'kind':'offline-fresh-page','before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
 geometry.extend(r['geometry'])
assert len(cases)==12 and len(geometry)==60 and len(pairs)==36
for g in geometry:assert g['overflow']==0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
write('browser-audit.json',{'cases':cases,'geometry':geometry,'consolePageErrors':[],'screenshots':len(list(p.glob('browser-*/*.png'))),'individuallyInspected':['browser-en-360/en-360-concentrate-current-next.png','browser-en-360/en-360-berserk-current-next.png','browser-zh-CN-360/zh-CN-360-concentrate-cast-visible.png','browser-zh-CN-360/zh-CN-360-stun-current-next.png','browser-en-1280/en-1280-berserk-current-next.png'],'limits':'Synthetic imported L30/resources/helmet and fixed Date.now; no earned campaign or balance claim. Geometry covers selected skill allocation control; no full accessibility audit.'})
write('save-pairs-audit.json',{'ordinaryPairs':24,'offlinePairs':12,'pairs':pairs,'saveVersion':22,'pass':True})
f=json.loads((p/'frozen.json').read_text())
for key,base in [('source',root),('build',p/'build')]:
 drift=[name for name,sha in f[key].items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=sha];assert not drift,(key,drift)
sha=hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest();assert sha==f['genuine']
write('freeze-audit.json',{'sourceCount':len(f['source']),'buildCount':len(f['build']),'sourceDrift':[],'buildDrift':[],'genuine':sha,'pass':True})
write('author-review.json',{'reviewer':'root author only; no independent acceptance','security':{'verdict':'pass','scope':'Current local source/tests and synthetic evidence scripts','findings':[],'constraints':['No external action or new dependency','No persisted combat payload or save migration','Native class/unlock/prerequisite/rank and paid source-bound transient authority checked']},'planReview':{'verdict':'ready','contract':'docs/plans/decisions/D04-barbarian-attack-defense-v1.md','scope':'Three-skill attack/defense batch; preserved full private-v1 objective','requirements':['Paid finite Defense even on miss','Arcane Attack contribution uses existing primitive and magical defenses','Shared on-hit Stun interruption','Native wave/save/playback integration and truthful bilingual current/next/MAX presentation']},'codeReview':{'verdict':'no blocking author finding','axes':{'correctness':'Inspected all five new test files, paid/native concentration match and timing, existing attack-scaled damage, canonical on-hit control, wave authority refresh and no transient save fields. Actual HP/MP and replay assertions accompany marker assertions.','readability':'One bounded paid-status module follows existing Leap/Cloak pattern; tuning remains JSON. Presentation derives Defense/Attack rows from authored metadata.','architecture':'Pure TS engine with existing scheduler/mitigation/typed status playback. Additive Defense bonus; no base-stat mutation or independent simulation.','security':'Source-owned registry shape and native class/allocation authority precede payment. Invalid/foreign potency is stripped on registration; no eval, credentials, network export, schema relaxation or dependency.','performance':'No new unbounded loop; status checks use existing bounded status lists. Full performance budgets not measured; large application/art manifest warnings stay open.'}},'limits':['Independent design/QA and earned balance remain open','30–50-hour campaign, two earned builds per class, full G0–G7/C2–C4 remain unproved','Retained fixture corrections and failed/terminated runs are not counted as passes']})
# Record only descendants of task-owned command PIDs while their trees still exist.
roots=[]
for file in p.glob('*-live.json'):
 try:
  d=json.loads(file.read_text());pid=d.get('pid')
  if isinstance(pid,int):roots.append(pid)
 except (ValueError,KeyError):pass
parents={};records={}
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  parts=proc.joinpath('stat').read_text().rsplit(')',1)[1].split();pid=int(proc.name);parents[pid]=int(parts[1]);records[pid]={'pid':pid,'parent':int(parts[1]),'startTicks':parts[19],'command':proc.joinpath('cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
 except (OSError,ValueError):pass
owned=set(roots)
while True:
 new={pid for pid,parent in parents.items() if parent in owned}-owned
 if not new:break
 owned.update(new)
(p/'recorded-processes.json').write_text(json.dumps({'roots':sorted(roots),'processes':[records[pid] if pid in records else {'pid':pid,'alreadyAbsent':True} for pid in sorted(owned)]},indent=2)+'\n')
print(json.dumps({'browserCases':len(cases),'ordinarySavePairs':24,'offlinePairs':12,'geometry':len(geometry),'sourceFiles':len(f['source']),'buildFiles':len(f['build']),'recordedPids':len(owned)}))
