from pathlib import Path
import csv,io,json,hashlib,collections
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');p=Path(__file__).parent
assert json.loads((p/'full-final-result.json').read_text())['exitCode']==0
f=root/'docs/plans/skill-inventory.csv';before=f.read_bytes();lines=before.splitlines(keepends=True);head=next(csv.reader([lines[0].decode()]));which={'skills-barbarian-concentrate','skills-barbarian-berserk','skills-barbarian-stun'};changed=[];output=[lines[0]]
for raw in lines[1:]:
 row=next(csv.reader([raw.decode()]));values=dict(zip(head,row))
 if values['data_id'] in which:
  assert values['behavior_verification']=='unverified';changed.append(values['data_id']);row[head.index('behavior_verification')]='bounded-functional;independent-acceptance-open';row[head.index('contract_evidence')]='docs/plans/decisions/D04-barbarian-attack-defense-v1.md;docs/plans/evidence/d04-barbarian-attack-defense.md'
  buf=io.StringIO();csv.writer(buf,lineterminator='\r\n' if raw.endswith(b'\r\n') else '\n').writerow(row);output.append(buf.getvalue().encode())
 else: output.append(raw)
assert set(changed)==which and len(changed)==3
value=b''.join(output);rows=list(csv.DictReader(io.StringIO(value.decode())));assert len(rows)==213
counts=collections.Counter(r['behavior_verification'].split(';')[0] for r in rows);assert counts=={'bounded-functional':117,'unverified':94,'bounded-engine-functional':1,'review-needed':1},counts
assert sum(r['class']=='barbarian' and r['behavior_verification'].startswith('bounded-functional;') for r in rows)==19
for a,b in zip(lines[1:],output[1:]):
 if next(csv.reader([a.decode()]))[head.index('data_id')] not in which:assert a==b
(p/'inventory-before.csv').write_bytes(before);f.write_bytes(value)
audit={'changedIds':changed,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(value).hexdigest(),'rows':213,'otherRowsByteExact':210,'idsOrderPreserved':True,'counts':dict(counts),'barbarianBoundedFunctional':19,'independentAcceptance':'open','earnedBalance':'open'}
(root/'docs/plans/evidence/fixtures/barbarian-attack-defense/inventory-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
