import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry();loadDefaultSkills();
const observations=[];
for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Battle Cry','barbarian'),id:'hero',level:30,
  skillLevels:{'skills-barbarian-howl':1,'skills-barbarian-taunt':1,'skills-barbarian-battle-cry':rank},comboOrder:['skills-barbarian-battle-cry']});
 assert.deepEqual(native.skillOrder,['skills-barbarian-battle-cry']);
 const hero:CombatUnit={...native,life:1000000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
  statuses:[{id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:1701}],
  stats:{...native.stats,lifeMax:1000000,manaMax:100,attack:200,attackSpeed:100,defense:100,magicResist:0,
   critChance:0,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,arcane:0,poison:0}}};
 const merc:CombatUnit={...hero,id:'ally',kind:'merc',skillOrder:[],skillLevels:{},statuses:[],stats:{...hero.stats,attackSpeed:50}};
 const enemy:CombatUnit={...merc,id:'enemy',side:'enemy',kind:'monster'};
 const input={seed,playerTeam:[hero,merc],enemyTeam:[enemy]},before=structuredClone(input),out=runBattleRecorded(input);
 assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const cost=Math.max(0,Math.round(6-.1*(rank-1)));
 assert.equal(out.events.filter(e=>e.kind==='mana'&&e.reason==='cast'&&e.target==='hero').length,1);
 assert.equal(out.result.playerTeam[0]?.mana,100-cost);
 const during=out.events.flatMap(e=>e.kind==='damage'&&e.simClockMs>=1700&&e.simClockMs<2700&&!e.dodged?[{at:e.simClockMs,source:e.source,target:e.target,amount:e.amount}]:[]);
 observations.push({rank,seed,cost,applied:out.events.filter(e=>e.kind==='status'&&e.statusId==='battle-cry'),during,
  benefit: during.some(e=>e.source==='enemy'?e.amount<100:e.source==='ally'&&e.amount>100)});
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-attacks-9kb72ug4/battle-cry-observations.json',JSON.stringify({synthetic:true,base:'5d5524b6 plus frozen attack batch; Battle Cry unchanged',observations},null,2));
console.log(JSON.stringify(observations,null,2));
assert.ok(observations.every(o=>o.benefit),'Paid Battle Cry has a marker, but no incoming Attack or outgoing Defense benefit in its active interval');
