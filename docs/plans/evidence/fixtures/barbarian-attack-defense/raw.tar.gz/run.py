import sys,subprocess,time,json,os
from pathlib import Path
scratch=Path(__file__).parent
label=sys.argv[1];command=sys.argv[2:];start=time.monotonic()
with (scratch/(label+'.log')).open('w') as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 (scratch/(label+'-live.json')).write_text(json.dumps({'pid':p.pid,'command':command}))
 code=p.wait()
(scratch/(label+'-result.json')).write_text(json.dumps({'command':command,'pid':p.pid,'exitCode':code,'seconds':time.monotonic()-start}))
sys.exit(code)
