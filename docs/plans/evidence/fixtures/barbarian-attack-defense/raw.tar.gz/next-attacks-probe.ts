import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import rows from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/barbarian.json';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry();loadDefaultSkills();const observations=[];
for(const slug of ['bash','whirlwind','leap-attack','war-cry'])for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const id='skills-barbarian-'+slug,levels:Record<string,number>={};
 function add(key:string){const row=rows.find(s=>s.id===key);assert.ok(row);levels[key]=1;for(const pre of row.prerequisites??[])add(pre);}
 add(id);levels[id]=rank;
 const native=playerToCombatUnit({...createMockPlayer('Synthetic remaining attack probe','barbarian'),id:'hero',level:30,skillLevels:levels,comboOrder:[id]});
 assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:1000000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
 statuses:[{id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:1701}],
 stats:{...native.stats,lifeMax:1000000,manaMax:100,attack:100,attackSpeed:100,defense:100,magicResist:0,critChance:0,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,arcane:0,poison:0}}};
 const enemies=[0,1,2].map((n):CombatUnit=>({...hero,id:'enemy'+n,side:'enemy',kind:'monster',tier:n===2?'boss':'trash',skillOrder:[],skillLevels:{},statuses:[],stats:{...hero.stats,attack:200,attackSpeed:250,defense:0}}));
 const input={seed,playerTeam:[hero],enemyTeam:enemies},before=structuredClone(input),out=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const row=rows.find(s=>s.id===id);assert.ok(row?.damage);const hits=out.events.filter(e=>e.kind==='damage'&&e.source==='hero');
 assert.equal(hits.length,slug==='bash'?1:3);
 assert.equal(new Set(hits.map(e=>e.kind==='damage'?e.target:'')).size,hits.length);
 for(const hit of hits)if(hit.kind==='damage'&&!hit.dodged){assert.ok(hit.amount>=row.damage.min+(row.scaling?.damagePerLevel??0)*(rank-1));assert.ok(hit.amount<=row.damage.max+(row.scaling?.damagePerLevel??0)*(rank-1));}
 const cast=out.events.filter(e=>e.kind==='mana'&&e.reason==='cast');assert.equal(cast.length,1);assert.equal(out.result.playerTeam[0]?.mana,100-row.cost!.mana!);
 observations.push({slug,rank,seed,hits:hits.map(e=>e.kind==='damage'?{target:e.target,amount:e.amount,dodged:e.dodged}:{}),stuns:out.events.filter(e=>e.kind==='status'&&e.statusId==='stun'),interrupted:out.events.filter(e=>e.kind==='stunned'&&e.target.startsWith('enemy')).length,cost:row.cost!.mana});
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-attacks-9kb72ug4/next-attacks-observations.json',JSON.stringify({synthetic:true,base:'5d5524b6 plus frozen attack-defense batch; four probed skills unchanged',observations},null,2));
console.log('48 native remaining-attack rank/seed cases passed; no inventory credit or earned acceptance.');
