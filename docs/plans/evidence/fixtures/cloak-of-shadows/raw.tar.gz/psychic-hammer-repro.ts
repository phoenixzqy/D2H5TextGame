import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { loadDefaultSkills, resetRegistry, getSkill, registerSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { ActiveStatus, CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const id='skills-assassin-psychic-hammer', canonical='assassin.psychic_hammer';
const hold=(at=0):ActiveStatus=>({id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1,appliedAtMs:at});
resetRegistry();loadDefaultSkills();
const original=getSkill(id);assert.ok(original);const observations=[];
for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Hammer','assassin'),id:'hero',level:30,skillLevels:{[id]:rank},comboOrder:[id]});
 assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:2000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,statuses:[hold(1701)],
  stats:{...native.stats,lifeMax:2000,manaMax:100,attack:20,attackSpeed:100,critChance:0,defense:0,magicResist:0}};
 const enemy:CombatUnit={...hero,side:'enemy',kind:'monster',id:'target',skillOrder:[],skillLevels:{},statuses:[hold(2001)],activeBuffIds:[],
  stats:{...hero.stats,attackSpeed:0},basicAttack:{damage:[20,20],damageType:'physical'}};
 const input={seed,playerTeam:[hero],enemyTeam:[enemy]},before=structuredClone(input);
 registerSkill(original);const out=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 registerSkill({...original,effects:original.effects.map(e=>{if(e.kind!=='damage')return e;const {applyStatus,...plain}=e;return plain;})});
 const control=runBattleRecorded(input);assert.deepEqual(input,before);
 const actions=out.events.filter(e=>e.kind==='action'),payments=out.events.filter(e=>e.kind==='mana'&&e.reason==='cast');
 assert.equal(actions.filter(e=>e.kind==='action'&&e.actor==='hero').length,1);assert.equal(payments.length,1);
 const targetActions=out.events.filter(e=>e.kind==='action'&&e.actor==='target').map(e=>e.simClockMs);
 const controlActions=control.events.filter(e=>e.kind==='action'&&e.actor==='target').map(e=>e.simClockMs);
 const knockback=out.events.filter(e=>e.kind==='status'&&e.statusId==='knockback');
 const grid=out.result.enemyTeam[0]?.gridPosition,controlGrid=control.result.enemyTeam[0]?.gridPosition;
 observations.push({rank,seed,actions,payments,knockback,targetActions,controlActions,grid,controlGrid,
  directHits:out.events.filter(e=>e.kind==='damage'&&e.source==='hero'),events:out.events,
  impact:JSON.stringify(targetActions)!==JSON.stringify(controlActions)||JSON.stringify(grid)!==JSON.stringify(controlGrid)});
}
registerSkill(original);
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-cloak-jqdf76h2/psychic-hammer-observations.json',JSON.stringify({synthetic:true,registered:original,observations},null,2));
console.log(JSON.stringify(observations.map(({rank,seed,knockback,targetActions,controlActions,impact})=>({rank,seed,knockback:knockback.length,targetActions,controlActions,impact})),null,2));
const landed=observations.filter(o=>o.knockback.length>0);
assert.ok(landed.length>0);
assert.ok(landed.some(o=>o.impact),'Paid Knockback has no timing or spatial effect in any landed native pair; author adaptation contract required');
