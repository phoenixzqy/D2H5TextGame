from pathlib import Path
import json,hashlib,tarfile,datetime,subprocess
raw=Path(__file__).resolve().parent
work=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');assert Path.cwd()==work
packetpath=work/'docs/plans/evidence/fixtures/p07a05-skeleton-mastery/packet.json'
packet=json.loads(packetpath.read_text());archive=packetpath.parent/packet['archive']['path']
assert packet['rawRoot']==str(raw) and packet['rawCleanup']['status'].startswith('pending')
assert packet['independentDurableReview']['verdict']=='APPROVE' and packet['independentDurableReview']['readersReleased']
head=subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()
for p in [packetpath,archive]:
 subprocess.run(['git','ls-files','--error-unmatch',str(p.relative_to(work))],check=True,stdout=subprocess.DEVNULL)
 assert subprocess.check_output(['git','status','--porcelain','--',str(p.relative_to(work))],text=True)==''
def check(p,row):
 assert not p.is_symlink() and p.resolve()==p
 b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
check(archive,packet['archive'])
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(packet['rawManifest'])
 for member,row in zip(members,packet['rawManifest']):
  assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
for row in packet['currentSources']:check(work/row['path'],row)
files=[];dirs=[]
for p in raw.rglob('*'):
 assert not p.is_symlink()
 if p.is_file():files.append(p)
 elif p.is_dir():dirs.append(p)
 else:raise RuntimeError(str(p))
assert {str(p.relative_to(raw)) for p in files}=={row['path'] for row in packet['rawManifest']}
for row in packet['rawManifest']:check(raw/row['path'],row)
u=json.loads((raw/packet['processUnion']['record']).read_text())['identities']
for row in u:
 try:assert int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])!=row['startTicks']
 except FileNotFoundError:pass
for key in ['stage-e-output-cleanup.json','stage-e-disposable-cleanup.json']:
 result=packet['outputsCleanup'][key];assert not result['remaining'] and not result['failures']
for key in ['stage-e-output-inventory.json','stage-e-disposable-inventory.json']:
 inv=json.loads((raw/key).read_text())
 for row in inv['files']:
  p=Path(row['path']);assert not p.exists() and not p.is_symlink()
 for name in inv.get('rootDirectories',inv.get('roots',[])):
  p=Path(name);assert not p.exists() and not p.is_symlink()
failures=[]
for row in packet['rawManifest']:
 try:(raw/row['path']).unlink()
 except OSError as e:failures.append({'path':row['path'],'error':str(e)})
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):
 try:p.rmdir()
 except OSError as e:failures.append({'path':str(p),'error':str(e)})
remaining=list(raw.rglob('*'))
packet['rawCleanup']={'status':'complete' if not failures and not remaining else 'cleanup-failed','owner':'root','archiveCommit':head,'verifiedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freshChecks':'committed archive/member manifest,current-source hashes,exact live file set,all observed PID/startTicks absent,all disposable inventory files/roots absent','removedFiles':len(files)-sum(p.exists() for p in files),'removedBytes':sum(row['bytes'] for row in packet['rawManifest']),'removedEmptyChildDirectories':len(dirs),'remainingFiles':len(remaining),'retainedEmptyRoot':str(raw),'failures':failures}
packetpath.write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps(packet['rawCleanup']));assert not failures and not remaining
