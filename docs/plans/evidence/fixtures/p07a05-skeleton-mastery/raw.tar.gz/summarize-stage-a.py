from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parent
names=['focused-skeleton-schema-red','focused-skeleton-schema-green','focused-skeleton-missing-helper','focused-skeleton-helper-green','engine-skeleton-stage-a','types-skeleton-stage-a','unit-skeleton-stage-a-serial','lint-skeleton-stage-a-serial','build-skeleton-stage-a']
rows=[]
for name in names:
 m=json.loads((r/(name+'.meta.json')).read_text()); row={'name':name,**m}
 report=r/(name+'-report.json')
 if report.exists():
  p=json.loads(report.read_text()); row['tests']={k:p.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']}; row['actualFiles']=len(p['testResults'])
  if p['testResults']: row['testRuntimeSeconds']=(max(t['endTime'] for t in p['testResults'])-p['startTime'])/1000
 rows.append(row)
for e in json.loads((r/'stage-a-source-freeze.json').read_text()):
 b=Path(e['path']).read_bytes(); assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
for x in rows:
 expected=1 if x['name'] in ['focused-skeleton-schema-red','focused-skeleton-missing-helper'] else 0
 assert x['exitCode']==expected and x['stopReason'] is None and x['signals']==[], x['name']
(r/'stage-a-final-gates.json').write_text(json.dumps({'sourceFreezeUnchanged':True,'finalAcceptedGates':rows,'excludedRuns':['unit-skeleton-stage-a (overlap)','lint-skeleton-stage-a (stopped overlap)'],'limits':'engine3s and full15s targets exceeded; no runtime/native/UI/browser/fullprivatev1 acceptance'},indent=2)+'\n')
print(json.dumps([{'name':x['name'],'wrapperSeconds':x['seconds'],'tests':x.get('tests'),'actualFiles':x.get('actualFiles'),'testRuntimeSeconds':x.get('testRuntimeSeconds')} for x in rows],indent=2))
