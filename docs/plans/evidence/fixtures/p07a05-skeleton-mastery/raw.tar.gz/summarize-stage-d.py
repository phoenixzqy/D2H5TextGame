from pathlib import Path
import json,hashlib
raw=Path(__file__).resolve().parent
names=['focused-stage-d-red','focused-stage-d-green','lint-stage-d-final','lint-stage-d-v3','focused-stage-d-v3','types-stage-d-final','unit-stage-d-final','build-stage-d-final']
rows=[]
for name in names:
 m=json.loads((raw/(name+'.meta.json')).read_text());p=raw/(name+'-report.json')
 if p.exists():
  d=json.loads(p.read_text());m['tests']={k:d[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']};m['actualFiles']=len(d['testResults']);m['testRuntimeSeconds']=(max(t['endTime'] for t in d['testResults'])-d['startTime'])/1000 if d['testResults'] else None
 rows.append({'name':name,**m})
for group in ['stage-b-source-freeze.json','stage-c-source-freeze-v3.json','stage-d-source-freeze.json']:
 for f in json.loads((raw/group).read_text())['files']:
  b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
(raw/'stage-d-final-gates.json').write_text(json.dumps({'finalSourceFreezesUnchanged':True,'historicalV2Failure':'UI RED20=12 intended failures8controls; GREEN52/3; lint1 unnecessary optional chain, only token removed for v3','gates':rows},indent=2)+'\n')
for r in rows:print(r['name'],r['exitCode'],r['seconds'],r.get('tests'),r.get('actualFiles'),r.get('testRuntimeSeconds'))
