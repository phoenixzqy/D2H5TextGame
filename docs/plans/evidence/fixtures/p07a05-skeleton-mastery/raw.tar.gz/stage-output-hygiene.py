from pathlib import Path
import sys,json,hashlib,stat,subprocess,datetime
raw=Path(__file__).resolve().parent
stage,mode=sys.argv[1:]
assert stage in ['c','d','e'] and mode in ['inventory','cleanup']
work=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd()==work
prefix='stage-'+stage

def record(path):
 assert not path.is_symlink() and path.resolve()==path
 data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def sources():
 freezes=['stage-b-source-freeze.json','stage-c-source-freeze-v3.json']
 if stage in ['d','e']: freezes.append('stage-d-source-freeze.json')
 if stage=='e': freezes.append('stage-e-source-freeze.json')
 for name in freezes:
  for entry in json.loads((raw/name).read_text())['files']:
   path=Path(entry['path']);path=path if path.is_absolute() else work/path
   assert record(path)=={**entry,'path':str(path)}, str(path)

def birth_absent(identity):
 p=Path('/proc')/str(identity['pid'])/'stat'
 try: return int(p.read_text().rsplit(')',1)[1].split()[19])!=identity['startTicks']
 except FileNotFoundError: return True

sources()
if mode=='inventory':
 names=sorted(raw.glob('*stage-'+stage+'*.processes.json'))
 identities={}
 for p in names:
  for row in json.loads(p.read_text())['observations']:
   identities[(row['pid'],row['startTicks'])]=row
 union=list(identities.values());assert all(birth_absent(row) for row in union)
 (raw/(prefix+'-process-union.json')).write_text(json.dumps({'identities':union,'absentCount':len(union),'matchingNonZombie':0,'inputs':[p.name for p in names]},indent=2)+'\n')
 dist=work/'dist';assert dist.is_dir() and not dist.is_symlink()
 files=[];directories=[]
 for path in sorted(dist.rglob('*')):
  assert not path.is_symlink()
  if path.is_file(): files.append(record(path))
  elif path.is_dir(): directories.append(str(path))
  else: raise RuntimeError(str(path))
 result=work/'node_modules/.vite/vitest/results.json'
 if result.exists(): files.append(record(result))
 inventory={'files':files,'directories':directories,'rootDirectories':[str(dist)],'retainParents':[str(result.parent),str(result.parent.parent)],'owner':'root; fresh dist and results after prior exact cleanup, retain RAW until durable packet; cleanup after commit and reader release'}
 (raw/(prefix+'-output-inventory.json')).write_text(json.dumps(inventory,indent=2)+'\n')
 print('inventory',len(files),'files',sum(row['bytes'] for row in files),'bytes',len(union),'absent birth identities')
else:
 inventory=json.loads((raw/(prefix+'-output-inventory.json')).read_text());union=json.loads((raw/(prefix+'-process-union.json')).read_text())['identities']
 assert all(birth_absent(row) for row in union)
 for entry in inventory['files']:
  path=Path(entry['path']);assert path.is_relative_to(work/'dist') or path==work/'node_modules/.vite/vitest/results.json'
  assert record(path)==entry
 failures=[]
 for entry in inventory['files']:
  try: Path(entry['path']).unlink()
  except OSError as e: failures.append({'path':entry['path'],'error':str(e)})
 for name in sorted(inventory['directories'],key=lambda x:len(Path(x).parts),reverse=True)+inventory['rootDirectories']:
  path=Path(name);assert path==work/'dist' or path.is_relative_to(work/'dist')
  try: path.rmdir()
  except OSError as e: failures.append({'path':name,'error':str(e)})
 allpaths=[row['path'] for row in inventory['files']]+inventory['directories']+inventory['rootDirectories']
 remaining=[name for name in allpaths if Path(name).exists() or Path(name).is_symlink()]
 result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip(),'freshSourceHashesMatch':True,'freshAbsentBirthIdentityCount':len(union),'freshOutputHashesMatch':True,'removedFiles':len(inventory['files'])-sum(Path(row['path']).exists() for row in inventory['files']),'removedBytes':sum(row['bytes'] for row in inventory['files']),'removedEmptyChildDirs':len(inventory['directories']),'removedRoots':inventory['rootDirectories'],'remaining':remaining,'failures':failures,'retainedParents':inventory['retainParents'],'RAW':'root-owned; retained until durable packet verification and exact cleanup'}
 (raw/(prefix+'-output-cleanup.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['retainedParents','RAW']}));assert not remaining and not failures
