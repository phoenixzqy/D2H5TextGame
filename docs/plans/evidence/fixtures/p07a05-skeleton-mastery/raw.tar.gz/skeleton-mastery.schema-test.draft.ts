import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import necromancerSkills from '../../data/skills/necromancer.json';
import skillSchema from '../../data/schema/skill.schema.json';
import sorceressSkills from '../../data/skills/sorceress.json';
import paladinSkills from '../../data/skills/paladin.json';
import barbarianSkills from '../../data/skills/barbarian.json';

const authored = () => {
  const row = necromancerSkills.find(row => row.id === 'skills-necromancer-skeleton-mastery');
  if (!row) throw new Error('Missing authored Skeleton Mastery');
  return structuredClone(row);
};
const validate = new Ajv2020({ strict: true, allErrors: true }).compile(skillSchema);

const coefficients = { summonLifePct: 0.04, summonAttackPct: 0.02, summonDefensePct: 0.01 };
const coefficientKeys = ['summonLifePct', 'summonAttackPct', 'summonDefensePct'] as const;
const malformedRows = [
  { requiredLevel: undefined },
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '18', null].map(requiredLevel => ({ requiredLevel })),
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '20', null].map(maxLevel => ({ maxLevel })),
  { scaling: undefined }, { scaling: {} }, { scaling: { passiveStatsPerLevel: {} } },
  ...coefficientKeys.flatMap(key => [
    { scaling: { passiveStatsPerLevel: Object.fromEntries(Object.entries(coefficients).filter(([name]) => name !== key)) } },
    ...[-0.01, NaN, Infinity, -Infinity, '0.04', null].map(value =>
      ({ scaling: { passiveStatsPerLevel: { ...coefficients, [key]: value } } }))
  ]),
  { trigger: 'active' }, { target: 'single-enemy' }, { passive: false },
  { aura: true }, { summon: true },
  ...[1, -1, NaN, Infinity, -Infinity, '0', null].map(cooldown => ({ cooldown })),
  { cost: {} }, { cost: { mana: 0 } }, { cost: { life: 0 } },
  { damage: { min: 1, max: 1, breakdown: { physical: 1 } } }, { damageType: 'physical' },
  { appliesStatus: [] }, { appliesStatus: ['burn'] }, { statusEffect: { chance: 1 } },
  { additionalStatusEffects: { freeze: { chance: 1 } } },
  { appliesTags: [] }, { appliesTags: ['fire'] }, { synergies: {} }, { synergies: { fire: 1.2 } },
  { heal: { min: 1, max: 1, target: 'self' } }, { summonId: 'skeleton' },
  { aoeShape: 'single' }, { requires: {} }, { requires: { weaponType: ['staff'] } },
  { scaling: { passiveStatsPerLevel: { ...coefficients, coldDamagePct: 0.1 } } },
  { scaling: { passiveStatsPerLevel: { ...coefficients, typo: 0.1 } } },
  ...['damagePerLevel', 'cooldownPerLevel', 'costPerLevel'].map(key =>
    ({ scaling: { passiveStatsPerLevel: { ...coefficients }, [key]: 0 } })),
  { scaling: { passiveStatsPerLevel: { ...coefficients }, summonStatsPerLevel: { attack: 1 } } },
  { scaling: { passiveStatsPerLevel: { ...coefficients }, summonMaxCount: { kind: 'first-three-then-every-three' } } },
  { scaling: { passiveStatsPerLevel: { ...coefficients }, typo: 1 } },
  { typo: 1 }
];

describe('P07a05A exact Skeleton Mastery schema', () => {
  it('preserves authored passive/self tuning and authored unlock1 and cap20', () => {
    const row = authored();
    expect(validate(row)).toBe(true);
    expect(row).toMatchObject({ id: 'skills-necromancer-skeleton-mastery', trigger: 'passive',
      target: 'self', requiredLevel: 1, minLevel: 1, maxLevel: 20, cooldown: 0,
      scaling: { passiveStatsPerLevel: { ...coefficients } } });
    expect(row).not.toHaveProperty('cost');
    expect(row).not.toHaveProperty('damage');
  });

  it.each([
    { summonLifePct: 0, summonAttackPct: 0, summonDefensePct: 0 },
    { summonLifePct: 0.125, summonAttackPct: 0.375, summonDefensePct: 0.625 },
    { summonLifePct: 3, summonAttackPct: 4, summonDefensePct: 5 }
  ])('accepts alternate finite nonnegative coefficients without a balance ceiling %j', values => {
    expect(validate({ ...authored(), scaling: { passiveStatsPerLevel: values } })).toBe(true);
  });

  it('permits alternative positive integer unlock/cap and explicit passive classification', () => {
    expect(validate({ ...authored(), requiredLevel: 9, maxLevel: 31,
      passive: true, aura: false, summon: false })).toBe(true);
  });

  it.each(malformedRows)('rejects malformed exact Skeleton Mastery row %j', fields => {
    expect(validate({ ...authored(), ...fields })).toBe(false);
  });

  it('preserves every other currently authored Necromancer skill', () => {
    for (const row of necromancerSkills.filter(row => row.id !== 'skills-necromancer-skeleton-mastery')) {
      expect(validate(row), row.id).toBe(true);
    }
  });

  it('preserves neighboring exact player contracts and all authored Sorceress/Paladin/Barbarian rows', () => {
    for (const row of [...sorceressSkills, ...paladinSkills, ...barbarianSkills]) expect(validate(row), row.id).toBe(true);
  });

  it('does not impose the exact-player contract on a distinct passive identity', () => {
    expect(validate({ ...authored(), id: 'skills-other-summon-mastery', requiredLevel: undefined,
      scaling: undefined, cooldown: 1, cost: { mana: 1 } })).toBe(true);
  });
});

