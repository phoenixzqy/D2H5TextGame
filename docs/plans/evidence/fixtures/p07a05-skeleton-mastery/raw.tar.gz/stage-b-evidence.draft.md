
## P07a05B — creation-only runtime integration

Scope: exactly five paths: engine/skills/skeleton-mastery.ts, engine/combat/combat.ts,
stores/combatHelpers.ts, new engine/combat/skeleton-mastery.test.ts and new
stores/skeleton-mastery-composition.test.ts. No authored tuning, shared-type,
save, UI or browser change. Source commit pending whole-evidence review.

The authoritative Player composer accepts only exact Necromancer at finite level
at least authored unlock and allocated exact-alias rank. It freezes primitive
source ID/rank/cap/three total bonuses; battle entry independently copies/freezes
them before any summon factory. A single post-build/pre-runtime-ID decorator
boosts only normalized fresh living-player-hero-owned skeleton warriors/mages.
It preserves existing scalePerRank rounding and summoning-rank floor, retains
new fractions, sets fresh top-level/stats life to lifeMax and leaves all other
fields alone. Existing damaged summons are untouched; no projection is attached
to units or Player. Within-snapshot provenance guards cannot authenticate an
arbitrarily forged entire snapshot. Next-wave/replay/save acceptance remains C.

### Frozen oracles and actual failures

RAW root remains root-owned at
`/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-skeleton-mastery-wy4010oo`.
`stage-b-plan-v3.proposal.json` was independently GD/TD approved before drafts.
The six draft artifacts were frozen and reviewed, then four non-null assertions
were corrected before execution. An unexecuted `draw`-string expectation was
corrected to the documented null/60000ms end event. Old versions/freezes remain.

Before runtime edits, an approved capture-only test passed one case on baseline
47023e1 with all three production hashes unchanged. Its complete input/recording
is `stage-b-prepatch-literal.json` (16,230B SHA256
7df688562e359362b8210adfecede70172b0429db41620eae29daa593537c875), embedded
unchanged in final native tests. QA/producer/GD/TD independently reviewed the
literal and new exact IDs/times/grid/cost/cooldown/mana/cap controls before RED.

Actual first native v6 RED: 57 = eight failed / 49 passed. Seven cases are intended
missing Mastery behavior; one is a test-oracle error: expected cooldown0 from
DEFAULT_SKILLS, but loadDefaultSkills then installs PLAYABLE_CLASS_DATA_SKILLS
and authored Raise Skeleton cooldown1. Root and reviewers missed that override.
Preserve report, classifications and original tests; no product defect is claimed
for this oracle. Final native v7 changes only that expectation 0→1, frozen and
independently re-reviewed before rerun against unchanged production. Corrected
RED: 57 = seven intended failed / 50 passed. Complete baseline/explicit rank0
recording and cooldown tail now pass. The rank1 fractional-Defense hard failure
still blocks later positive-life checks until GREEN; do not count them as RED.

Separate approved composition tests executed before production: 55 = 54 failed /
one passed. Every failure is `composeSkeletonMastery is not a function`; the
ineligible Sorceress wave passes. This is capability failure, not behavioral RED
or a zero-test collection failure. The sequence ran this independent test while
corrected native review was pending, with gates serial and production unchanged.

Seven intended native cases cover four skeleton/mage rank1/20 stat literals,
consumed Attack49 vs35, fractional Defense19.19 causing neutral100→80 vs81,
and factory-time caller mutation proving copied entry primitives. Final GREEN
also executes full-life→real-loss/no-heal tails and preserves whole inputs,
plain-vs-recorded equivalence/repeat determinism. No-projection/explicitrank0
full recording equals the prepatch literal. Durable stunned-target tests at
Mastery0/1/20 enforce two rank6 summons, exact IDs/0+1700ms/positions/two15MP
charges through60000ms, while all15 excluded summon templates preserve complete
recordings. Distinct alternate coefficients detect swaps/hardcoding. Actual
Necromancer/Sorceress store waves exercise real combat with only disk I/O mocked;
importedL24/gear/custom finisher are explicit scaffolding, not earned progression.

### Serial final gates

| Gate | Result | Vitest / wrapper seconds |
| --- | --- | --- |
| Prepatch capture | 1 / 1 file | 1.398 / 2.373 |
| Original native v6 RED | 57 = 8 fail / 49 pass | 2.046 / 3.092 |
| Missing composer | 55 = 54 capability failures / 1 pass | 3.977 / 5.119 |
| Corrected native v7 RED | 57 = 7 intended fail / 50 pass | 2.055 / 3.021 |
| Focused GREEN | 301 / 3 files | 3.720 / 4.706 |
| Engine | 2549 / 79 files | 11.839 / 13.043 |
| Types | pass | — / 12.158 |
| Full unit | 5056 / 194 files | 83.788 / 85.104 |
| Lint / engine purity | pass | — / 32.360 |
| Fresh production bridge/build | pass; bridge absent | — / 9.338 |

Installed sources match `stage-b-source-freeze.json` throughout final
GREEN/engine/types/full/lint/build gates; historical capture/RED use baseline production. actual files count uses
len(testResults), not describe-suite counts. No pending/todo tests, stops or signals
in any B run. All final gates ran serially, with no source edits during gates.
Engine3s/full15s targets remain exceeded; existing Browserslist/chunk-size/large
manifest precache warnings remain. No coverage/performance/balance/campaign or
private-v1/C0–C4/G0–G7 acceptance is claimed.

GD/TD exact-source review approves all five files and releases readers. QA/producer
whole-evidence review and source commit remain pending. Root inventory identifies
761 task-owned build/test-cache output files,40,969,612B,nine empty-after-delete
childdirs plus fresh dist root; fresh1202 PID/birth identities absent. Cleanup
must occur only after commit, all readers release and fresh source/output/process
checks. RAW remains until later durable packet verification/exact cleanup by root.
Shared caches/parents/tools/font/source/history and original checkout preserved;
umbrella worktree claim continues, no push/PR/merge/deploy. StageC native allocation,
respec,nextwave,replay/resources/all3carry/save and truthful bilingual UI/browser
remain; full umbrella objective stays open.
