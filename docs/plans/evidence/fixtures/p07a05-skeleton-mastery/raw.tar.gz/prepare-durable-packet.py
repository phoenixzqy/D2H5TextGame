from pathlib import Path
import json,hashlib,tarfile,datetime,subprocess
raw=Path(__file__).resolve().parent
work=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd()==work
out=work/'docs/plans/evidence/fixtures/p07a05-skeleton-mastery'
assert not out.exists()
def rec(p,path):
 assert not p.is_symlink() and p.resolve()==p
 b=p.read_bytes();return {'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def absent(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])!=row['startTicks']
 except FileNotFoundError:return True
processfiles=sorted(raw.glob('*.processes.json'));union={}
for p in processfiles:
 for row in json.loads(p.read_text())['observations']:union[(row['pid'],row['startTicks'])]=row
assert all(absent(row) for row in union.values())
(raw/'skeleton-all-process-union.json').write_text(json.dumps({'inputs':[p.name for p in processfiles],'identities':list(union.values()),'absentCount':len(union)},indent=2)+'\n')
sources={}
a=json.loads((raw/'stage-a-source-freeze.json').read_text())
for entry in a:sources[entry['path']]=entry
for name in ['stage-b-source-freeze.json','stage-c-source-freeze-v3.json','stage-d-source-freeze.json','stage-e-source-freeze.json']:
 for entry in json.loads((raw/name).read_text())['files']:sources[entry['path']]=entry
for entry in sources.values():assert rec(work/entry['path'],entry['path'])==entry
for name in ['src/data/skills/necromancer.json','production/bugs/BUG-067-skeleton-mastery-details.md']:sources[name]=rec(work/name,name)
for name in ['stage-e-output-cleanup.json','stage-e-disposable-cleanup.json']:
 d=json.loads((raw/name).read_text());assert not d['remaining'] and not d['failures']
manifest=[]
for p in sorted(raw.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():manifest.append(rec(p,str(p.relative_to(raw))))
 elif not p.is_dir():raise RuntimeError(str(p))
out.mkdir(parents=True)
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for row in manifest:tar.add(raw/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member,row in zip(members,manifest):
  assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
  b=tar.extractfile(member).read();assert hashlib.sha256(b).hexdigest()==row['sha256']
head=subprocess.check_output(['git','rev-parse','--short','HEAD'],text=True).strip()
packet={'task':'P07a05 Skeleton Mastery + BUG067','runtimeHead':'7740f2e','sourceHead':head,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':{**rec(archive,'raw.tar.gz'),'files':len(manifest),'originalBytes':sum(row['bytes'] for row in manifest),'roundtripVerified':True},'rawRoot':str(raw),'rawManifest':manifest,'currentSources':list(sources.values()),'processUnion':{'record':'skeleton-all-process-union.json','uniqueAbsent':len(union)},'outputsCleanup':{name:json.loads((raw/name).read_text()) for name in ['stage-e-output-cleanup.json','stage-e-disposable-cleanup.json']},'independentReview':'GD/TD exact source and QA/producer whole E evidence APPROVE; root transcriptions in archive','rawCleanup':{'status':'pending independent durable review and commit','owner':'root','path':str(raw),'method':'fresh archive/member/live-manifest/source/process verification; unlink only exact manifest files then rmdir empty child directories; retain empty RAW root'},'scopeLimit':'Bounded authored/runtime/native/bilingual finite Chromium CSS viewport and explicit same-context save acceptance; no full private-v1/C0-C4/G0-G7/touch/allbrowser/accessibility/earnedcampaign/balance/performance acceptance'}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'archive':packet['archive'],'sources':len(sources),'processes':len(union)}))
