import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
// Only disk I/O is mocked. Imported L24, ranks, gear and finisher are scaffolding.
vi.mock('./save-adapter', () => ({ hasSave: vi.fn(), loadSave: vi.fn(),
  saveSave: vi.fn(() => Promise.resolve(undefined)), deleteSave: vi.fn() }));
import * as engine from '@/engine/combat/combat';
import { createMockPlayer } from '@/features/character/createMockPlayer';
import { loadDefaultSkills, registerSkill, resetRegistry } from '@/engine/skills/registry';
import type { Player } from '@/engine/types/entities';
import type { Item } from '@/engine/types/items';
import { abortSubAreaRun, advanceWaveOrFinish, playerToCombatUnit,
  resetIdleElitePity, startSubAreaRun } from './combatHelpers';
import { __resetPersistenceForTests } from './persistence';
import { useCombatStore } from './combatStore';
import { usePlayerStore } from './playerStore';
import { useInventoryStore } from './inventoryStore';
import { useMapStore } from './mapStore';
import { useMercStore } from './mercStore';
import { useFormationStore } from './formationStore';
import { useMetaStore } from './metaStore';
const AUTHORED = 'skills-necromancer-skeleton-mastery';
const CANONICAL = 'necromancer.skeleton_mastery';
const ACTIVE = 'necromancer.raise_skeleton';
const FINISHER = 'fixture.skeleton-native-finisher';
const stores = [useCombatStore, usePlayerStore, useInventoryStore, useMapStore,
  useMercStore, useFormationStore, useMetaStore] as const;
function reset(): void {
  __resetPersistenceForTests(); abortSubAreaRun(); resetIdleElitePity();
  for (const store of stores) store.getState().reset();
}
function player(): Player {
  const current = usePlayerStore.getState().player;
  if (!current) throw new Error('Missing Skeleton Mastery native fixture player');
  return current;
}
function configure(fields: Partial<Player>): void {
  usePlayerStore.getState().setPlayer({ ...player(), ...fields });
}
function arrange(rank = 20): Item {
  const fresh = createMockPlayer('SkeletonNative', 'necromancer');
  usePlayerStore.getState().setPlayer({ ...fresh, level: 24, skillPoints: 2,
    skillLevels: { [ACTIVE]: 6, ...(rank > 0 ? { [CANONICAL]: rank } : {}) },
    comboOrder: [ACTIVE, FINISHER] });
  // Necromancer L24: life314/mana179/defense89. Cap base defense7.
  const cap: Item = { id: 'fixture-skeleton-native-cap', baseId: 'items/base/helm-cap', rarity: 'rare',
    level: 1, identified: true, equipped: false, affixes: [{ affixId: 'fixture-imported',
      values: new Map([['statMods.life', 999686], ['statMods.mana', 821], ['statMods.defense', 99904]]) }] };
  useInventoryStore.getState().addItem(cap);
  expect(useInventoryStore.getState().equipItem(cap)).toEqual({ ok: true });
  configure({ derivedStats: { ...player().derivedStats, life: 900000, mana: 300 } });
  const converted = playerToCombatUnit(player());
  expect([converted.stats.lifeMax, converted.stats.manaMax, converted.stats.defense]).toEqual([1000000, 1000, 100000]);
  expect(converted.manaRegenPerSecond).toBe(5);
  useMapStore.getState().setCurrentLocation(1, 'areas/act1-blood-moor');
  registerSkill({ id: FINISHER, archetype: 'fixture', target: 'all-enemies', minLevel: 1,
    cooldown: 1, manaCost: 8, effects: [{ kind: 'damage', damageType: 'physical', base: [100000, 100000] }] });
  return cap;
}
function start(): void {
  expect(startSubAreaRun({ runSeed: 7, challengeOrdinal: 0 })?.totalWaves).toBeGreaterThan(2);
  expect(useCombatStore.getState().outcome?.winner).toBe('player');
}
function drain(): void {
  const count = useCombatStore.getState().recordedEvents.length;
  for (let i = 0; i < count; i++) useCombatStore.getState().advanceEvent();
  expect(useCombatStore.getState().playbackComplete).toBe(true);
}
function recording() {
  const s = useCombatStore.getState();
  return structuredClone({ team: s.playerTeam, events: s.recordedEvents, outcome: s.outcome,
    rewards: s.runRewards, cursor: s.eventCursor, complete: s.playbackComplete, paused: s.isPaused });
}
function currentHero() {
  const hero = useCombatStore.getState().playerTeam[0];
  if (!hero) throw new Error('Missing native wave input');
  return hero;
}
function finalHero() {
  const hero = useCombatStore.getState().outcome?.finalPlayerTeam[0];
  if (!hero) throw new Error('Missing native wave outcome');
  return hero;
}
const pools = (hero: ReturnType<typeof currentHero>) => [hero.life, hero.mana,
  hero.manaRegenCarry, hero.manaRegenCompensation, hero.manaRegenExactCarry];
beforeEach(() => { reset(); resetRegistry(); loadDefaultSkills();
  vi.spyOn(Date, 'now').mockReturnValue(1792454400000); });
afterEach(() => { reset(); resetRegistry(); loadDefaultSkills(); vi.restoreAllMocks(); });

describe('P07a05C native fixture pre-capture', () => {
  it('captures real first and second wave inputs, recordings and original resource/carry baselines', () => {
    const snapshots: engine.CombatSnapshot[] = [];
    const original = engine.runBattleRecorded;
    vi.spyOn(engine, 'runBattleRecorded').mockImplementation(input => {
      snapshots.push(structuredClone(input)); return original(input);
    });
    arrange(); start();
    expect(pools(currentHero())).toEqual([900000, 300, 0, 0, '0']);
    const first = recording(); const firstFinal = structuredClone(finalHero());
    drain(); expect(advanceWaveOrFinish()).toBe('next-wave');
    const second = recording();
    expect(pools(currentHero())).toEqual(pools(firstFinal));
    expect(useCombatStore.getState().playerTeam.filter(u => u.kind === 'summon' || u.summon)).toEqual([]);
    const spawned = second.events.find(e => e.kind === 'summon');
    if (spawned?.kind !== 'summon') throw new Error('Missing newly created skeleton');
    expect([spawned.unit.life, spawned.unit.stats.life, spawned.unit.stats.lifeMax,
      spawned.unit.stats.attack, spawned.unit.stats.defense]).toEqual([291.6, 291.6, 291.6, 49, 22.8]);
    console.log('SKELETON_NATIVE_PRECAPTURE=' + JSON.stringify({ snapshots, first, firstFinal, second,
      firstInputPools: pools(first.team[0] ?? currentHero()), secondInputPools: pools(currentHero()),
      secondFinalPools: pools(finalHero()) }));
  });
});
