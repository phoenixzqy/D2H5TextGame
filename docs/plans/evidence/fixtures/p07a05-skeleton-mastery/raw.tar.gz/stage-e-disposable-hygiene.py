from pathlib import Path
import sys,json,hashlib,datetime
raw=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode in ['inventory','cleanup']
roots=[raw/'font-cache',raw/'stage-e-review-images',raw/'attachments'/'stage-e-browser']
def record(p):
 assert not p.is_symlink() and p.resolve()==p
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
if mode=='inventory':
 files=[];dirs=[]
 for root in roots:
  assert root.is_dir() and not root.is_symlink()
  for p in sorted(root.rglob('*')):
   assert not p.is_symlink()
   if p.is_file():files.append(record(p))
   elif p.is_dir():dirs.append(str(p))
   else:raise RuntimeError(str(p))
 result={'roots':[str(p) for p in roots],'files':files,'directories':dirs,'reason':'Task font cache, Playwright last-run metadata and duplicate PNGs decoded losslessly from retained original browser report; all readers must release before cleanup.'}
 (raw/'stage-e-disposable-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(len(files),sum(x['bytes'] for x in files))
else:
 inv=json.loads((raw/'stage-e-disposable-inventory.json').read_text());assert inv['roots']==[str(p) for p in roots]
 for row in inv['files']:
  p=Path(row['path']);assert any(p.is_relative_to(root) for root in roots);assert record(p)==row
 failures=[]
 for row in inv['files']:
  try:Path(row['path']).unlink()
  except OSError as e:failures.append({'path':row['path'],'error':str(e)})
 for name in sorted(inv['directories']+inv['roots'],key=lambda s:len(Path(s).parts),reverse=True):
  p=Path(name);assert p in roots or any(p.is_relative_to(root) for root in roots)
  try:p.rmdir()
  except OSError as e:failures.append({'path':name,'error':str(e)})
 names=[x['path'] for x in inv['files']]+inv['directories']+inv['roots'];remaining=[n for n in names if Path(n).exists() or Path(n).is_symlink()]
 result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':len(inv['files']),'bytes':sum(x['bytes'] for x in inv['files']),'removedRoots':inv['roots'],'remaining':remaining,'failures':failures,'preserved':'Original report with all screenshot bodies/metrics/keyboard/save data, XML/environment evidence, installed fonts/tools/dependencies/shared caches; RAW retained for archive.'}
 (raw/'stage-e-disposable-cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert not remaining and not failures
