from pathlib import Path
import json,hashlib
raw=Path(__file__).resolve().parent
names=['focused-stage-b-prepatch-capture','focused-stage-b-native-red','focused-stage-b-missing-composer','focused-stage-b-native-red-corrected','focused-stage-b-green','engine-stage-b-final','types-stage-b-final','unit-stage-b-final','lint-stage-b-final','build-stage-b-final']
rows=[]
for name in names:
 m=json.loads((raw/(name+'.meta.json')).read_text())
 p=raw/(name+'-report.json')
 if p.exists():
  d=json.loads(p.read_text());m['tests']={k:d[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']};m['actualFiles']=len(d['testResults']);m['testRuntimeSeconds']=(max(t['endTime'] for t in d['testResults'])-d['startTime'])/1000 if d['testResults'] else None
 rows.append({'name':name,**m})
freeze=json.loads((raw/'stage-b-source-freeze.json').read_text())
for f in freeze['files']:
 b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
record={'sourceFreezeUnchanged':True,'gates':rows,'classification':'Initial nativev6 includes one CD oracleerror; correctedv7 has7intendedfail50controls. Missingcomposer54TypeErrors separate. Final gates serial.'}
(raw/'stage-b-final-gates.json').write_text(json.dumps(record,indent=2)+'\n')
for row in rows:print(row['name'],row['exitCode'],row['seconds'],row.get('tests'),row.get('actualFiles'),row.get('testRuntimeSeconds'))
