import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { loadDefaultSkills, resetRegistry } from '../skills/registry';
import { runBattle, runBattleRecorded, type CombatSnapshot, type BattleEvent } from './combat';
import type { CombatUnit } from './types';

interface ProjectedSnapshot extends CombatSnapshot {
  readonly skeletonMastery?: { readonly sourceHeroId: string; readonly rank: number; readonly maxRank: number;
    readonly summonLifePct: number; readonly summonAttackPct: number; readonly summonDefensePct: number };
}
const projection = (rank: number): NonNullable<ProjectedSnapshot['skeletonMastery']> =>
  ({ sourceHeroId: 'hero', rank, maxRank: 20, summonLifePct: rank * .04,
    summonAttackPct: rank * .02, summonDefensePct: rank * .01 });
function unit(id: string, side: CombatUnit['side']): CombatUnit {
  return { id, name: id, side, kind: side === 'player' ? 'hero' : 'monster', level: 24, tier: 'trash',
    life: 10000, mana: 60, stats: { life: 10000, lifeMax: 10000, mana: 60, manaMax: 60,
      attack: 1, defense: 0, magicResist: 0, attackSpeed: 100, critChance: 0, critDamage: 1.5,
      physDodge: 0, magicDodge: 0, magicFind: 0, goldFind: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } },
    statuses: [], cooldowns: {}, skillOrder: [], activeBuffIds: [], enraged: false };
}
function snapshot(rank = 0, template = 'skeleton'): ProjectedSnapshot {
  const skill = template === 'skeletal_mage' ? 'necromancer.raise_skeletal_mage' : 'necromancer.raise_skeleton';
  return { seed: 7, playerTeam: [{ ...unit('hero', 'player'), skillOrder: [skill], skillLevels: { [skill]: 6 },
    gridPosition: { row: 0, col: 0 }, summonGridPositions: [{ row: 1, col: 0 }, { row: 1, col: 1 }] }],
    enemyTeam: [{ ...unit('target', 'enemy'), life: 1000000,
      stats: { ...unit('target', 'enemy').stats, life: 1000000, lifeMax: 1000000 },
      statuses: [{ id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1 }] }],
    ...(rank > 0 ? { skeletonMastery: projection(rank) } : {}) };
}
function record(input: ProjectedSnapshot) {
  const before = structuredClone(input);
  const result = runBattleRecorded(input);
  expect(input).toEqual(before);
  expect(runBattle(input)).toEqual(result.result);
  expect(runBattleRecorded(input)).toEqual(result);
  for (const out of [...result.result.playerTeam, ...result.result.enemyTeam]) {
    expect(out).not.toHaveProperty('skeletonMastery');
  }
  return result;
}
function summons(result: ReturnType<typeof record>) {
  return result.events.filter((event): event is Extract<BattleEvent, { kind: 'summon' }> &
    { readonly simClockMs: number; readonly uiDelayMs: number } => event.kind === 'summon');
}
beforeEach(() => { resetRegistry(); loadDefaultSkills(); });
afterEach(() => { resetRegistry(); loadDefaultSkills(); });

describe('P07a05B captured prepatch control', () => {
  it('captures a complete unprojected two-summon recording before runtime implementation', () => {
    const base = snapshot();
    const input = { ...base, enemyTeam: base.enemyTeam.map(target => ({ ...target, life: 1,
      stats: { ...target.stats, life: 1, lifeMax: 1 } })) };
    const actual = record(input);
    expect(summons(actual).map(e => e.unit.id)).toEqual(['hero-summon-skeleton-1', 'hero-summon-skeleton-2']);
    expect(actual.result.winner).toBe('player');
    console.log('SKELETON_PREPATCH=' + JSON.stringify({ input, actual }));
  });
});
