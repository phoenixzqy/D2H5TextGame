from pathlib import Path
import tarfile,gzip,io,hashlib,json,stat,shutil
raw=Path(__file__).resolve().parent
root=Path.cwd()
target=root/'docs/plans/evidence/fixtures/p02b05c-earned-moor-idle'
target.mkdir(parents=True,exist_ok=True)
shutil.copyfile(root/'docs/plans/evidence/p02b05c-earned-moor-idle.md',raw/'evidence-draft.md')
records=[]
for p in sorted(raw.rglob('*')):
 if p.is_dir(): continue
 assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink(),p
 b=p.read_bytes();records.append({'path':p.relative_to(raw).as_posix(),'byteLength':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=target/'raw.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for rec in records:
    b=(raw/rec['path']).read_bytes();info=tarfile.TarInfo(rec['path']);info.size=len(b);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(b))
b=archive.read_bytes()
packet={'checkpoint':'P02b05c','sourceParent':'0107455261e3f783de30f63ef407d9d26667b0da',
 'scope':'One frozen fresh earned production desktop/en pilot; failed manual W3 draw, no idle/reopen acceptance',
 'archive':{'path':'raw.tar.gz','byteLength':len(b),'sha256':hashlib.sha256(b).hexdigest()},'records':records}
(target/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(records)
 for m,rec in zip(t.getmembers(),records):
  assert m.isfile() and m.name==rec['path'] and m.size==rec['byteLength']
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==rec['sha256']
print(json.dumps({'records':len(records),'uncompressedBytes':sum(x['byteLength'] for x in records),'archiveBytes':len(b),'archiveSha256':packet['archive']['sha256'],'packetSha256':hashlib.sha256((target/'packet.json').read_bytes()).hexdigest()},indent=2))
