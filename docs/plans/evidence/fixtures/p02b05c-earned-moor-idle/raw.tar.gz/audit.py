from pathlib import Path
import json,base64,hashlib,subprocess
raw=Path(__file__).resolve().parent
root=Path.cwd()
r=json.loads((raw/'pilot-report.json').read_text())
def specs(suite):
 yield from suite.get('specs',[])
 for s in suite.get('suites',[]): yield from specs(s)
results=[result for suite in r['suites'] for spec in specs(suite) for test in spec['tests'] for result in test['results']]
assert len(results)==1
result=results[0]
attachments={}
for a in result['attachments']:
 if a.get('contentType')=='application/json':
  b=base64.b64decode(a['body']) if 'body' in a else Path(a['path']).read_bytes()
  attachments[a['name']]=json.loads(b)
position=attachments['pilot-position-and-counts']
preps=[attachments['prep-'+str(i)] for i in range(40)]
prep_rosters=[attachments['prep-result-'+str(i)] for i in range(40)]
assert all(x['liveEnemies']==0 and x['heroHPPercent']>0 and x['log'][-1]=='Victory! All enemies are defeated.' for x in prep_rosters)
manual=[]
for i in range(1,4):
 t=attachments['manual-terminal-'+str(i)]
 manual.append({'wave':i,'mode':'manual','kind':t['waveKind'],'heroPresent':t['heroPresent'],'heroDead':t['heroDead'],
  'displayedHeroHPPercent':t['heroHPPercent'],'liveEnemyCards':t['liveEnemies'],'displayedEnemyCards':len(t['enemyRoster']),
  'lastLog':t['log'][-1],'skipDisabled':t['skipDisabled'],'defeatPanels':t['defeatPanels'],'deadMerc':t['deadMerc']})
assert manual[0]['liveEnemyCards']==manual[1]['liveEnemyCards']==0 and manual[2]['liveEnemyCards']==1
assert position['counts']=={'starts':41,'computedWaves':83,'skipClicks':43,'observedSettlements':42}
assert position['errors']==[]
journal=position['lastJournal']
record={'status':result['status'],'durationMs':result['duration'],'attachmentCount':len(result['attachments']),
 'phase':position['phase'],'counts':position['counts'],'countPrecision':position['accountingPrecision'],'consolePageWarningsErrors':position['errors'],
 'prepWinCount':len(preps),'prepared':{'hero':attachments['prepared-same40A']['player'],'backpack':len(attachments['prepared-same40A']['inventory']['backpack']),
 'shards':attachments['prepared-same40A']['inventory']['currencies']},'manual':manual,
 'lastCommitted':{'playerLevel':journal['player']['level'],'playerXP':journal['player']['experience'],'backpack':len(journal['inventory']['backpack']),
 'shards':journal['inventory']['currencies'],'clears':journal['map']['clearedSubAreas'],'idleTarget':journal['meta']['idleState'].get('idleTarget')},
 'targetJournals':[n for n in attachments if '-settled-' in n],
 'unreached':['genuine canonical clear','Farm Here eligibility','idle start/clear','automatic repeat','Stop/no-late-award','same-context reopen'],
 'preparation': [{'ordinal':i,'level':s['player']['level'],'xp':s['player']['experience'],'bag':len(s['inventory']['backpack']),
 'shards':s['inventory']['currencies']['rune-shard']} for i,s in enumerate(preps)]}
initial=json.loads((raw/'initial-source-tools.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in initial['paths'].items())
assert subprocess.check_output(['git','diff','--name-only'],text=True)==''
for n in ['unit','types','lint','list','build','pilot']:
 m=json.loads((raw/(n+'.meta.json')).read_text());p=json.loads((raw/(n+'.processes.json')).read_text())
 assert not m['signals'] and not m['stopReason'] and not p['remainingNonZombie']
record['preservedSourceHashes']=len(initial['paths']);record['trackedDiffEmpty']=True
record['commandsNoSignalsNoSurvivors']=True
(raw/'audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['prepared','preparation']},indent=2))
