# Amplify Damage production browser contract V1

Separate2path config/spec only after committed accepted4path source fix; no bridge.
Two locales, clean production preview, fixed Date/native simulation timers.
FreshNecromancerL1/1point then explicit importedL1/2points/Teeth1/Teethcombo scaffolding
(not earned progression). Unlearned detail exact50physical-resistance percentagepoints/
3s/everyrank; all9comboslots exclude unlearnedcurse; readonlyexport player unchanged.
Native Moor entry→Pause finite DOMsnapshot then skill Allocate+Enter0→1→2. Entire
exportedplayer exactly prepared except skillpoints2−rank and canonicalrank; current
MP15/CD3/bilingualstatus and nextMP15/CD3 or2.9. No hidden recordingidentity claim,
only current pausedDOM log/cards/resourcebars equality; exactwhole recording unit-only.
ExplicitFlee before nativecombo edits; readoptionindex then Home/ArrowDown/Enter adds
curse slot2, native remove/readd retainsTeethslot1. Explicit Save→Saved→close/newPage/
Continue under sameDate entireSaveCurrent/meta equality, persisted detail/comboslots.
NinefiniteCSSsizes perlocale matching Meteor matrix,18screenshots/14pxprose/44px
controls/hitgrid/nohorizontaloverflow/CDPactualNotoChinese glyphuse/consolearrays[].
This is finiteChromium/CSS/samecontextdisk acceptance; no nativecast/earnedcampaign/
mercenary/balance/performance/nativetouch/fullaccessibility/allbrowser acceptance.
Do not change comboeditreplay or apply this copyfix to authorize another Moor sample.
