const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const { spawn } = require('node:child_process');
const { createRequire } = require('node:module');
const assert = require('node:assert/strict');
const root = '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const raw = __dirname;
const { chromium, expect } = createRequire(path.join(root, 'package.json'))('@playwright/test');
const profiles = [[360,640],[412,915],[640,360],[1280,800],[1920,1080],[320,640],[768,1024],[1024,768],[1440,900]];
const result = { productionBridgeAbsent: true, console: [], requestsFailed: [], cases: [], persistence: [], screenshots: [], scope: 'Ordinary UI, fresh real L1 Paladin and its initial skill point; no injected store state/import or earned campaign claim. Chromium only; no full application accessibility/performance certification.' };
const report = path.join(raw, 'browser-ui-production-report.json');
const shots = path.join(raw, 'ui-browser-screenshots');
assert(!fs.existsSync(report)); assert(!fs.existsSync(shots)); fs.mkdirSync(shots);
let server, serverBirth, browser;
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const birth = pid => { try { return fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(') ').at(-1).split(' ')[19]; } catch { return null; } };
(async () => {
  const port = await new Promise(resolve => { const probe = net.createServer(); probe.listen(0, '127.0.0.1', () => { const value = probe.address().port; probe.close(() => resolve(value)); }); });
  const url = `http://127.0.0.1:${port}`;
  const env = { ...process.env }; delete env.VITE_E2E;
  const log = fs.openSync(path.join(raw, 'ui-browser-server.log'), 'wx');
  server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--strictPort', '--port', String(port)], { cwd: root, env, stdio: ['ignore', log, log] });
  fs.closeSync(log); serverBirth = birth(server.pid);
  result.server = { pid: server.pid, startTicks: serverBirth, port, command: 'vite preview production build; VITE_E2E unset' };
  const started = Date.now();
  while (true) {
    try { if ((await fetch(url)).ok) break; } catch {}
    assert(server.exitCode === null, 'Owned preview exited before ready');
    assert(Date.now() - started < 10000, 'Preview ready timeout'); await delay(100);
  }
  browser = await chromium.launch({ headless: true });
  for (const locale of ['zh-CN', 'en']) {
    const context = await browser.newContext({ viewport: { width: 360, height: 640 }, acceptDownloads: true });
    const page = await context.newPage(); page.setDefaultTimeout(5000); page.setDefaultNavigationTimeout(10000);
    page.on('console', message => { if (['error','warning'].includes(message.type())) result.console.push({ locale, type: message.type(), text: message.text() }); });
    page.on('pageerror', error => result.console.push({ locale, type: 'pageerror', text: error.message }));
    page.on('requestfailed', request => result.requestsFailed.push({ locale, url: request.url(), error: request.failure()?.errorText }));
    await page.goto(url); await expect(page.getByTestId('home-screen')).toBeVisible();
    assert(await page.evaluate(() => typeof window.__GAME__ === 'undefined'), 'Production test bridge present');
    await page.getByTestId('home-new-game').click(); await page.getByTestId('class-paladin').click();
    await page.getByTestId('character-name-input').fill(`Aura-${locale}`); await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    if (locale === 'en') {
      await page.locator('a[href="/settings"]').first().click(); await page.getByRole('button', { name: 'English', exact: true }).click();
    }
    await page.locator('a[href="/skills"]').first().click();
    const legend = locale === 'en' ? 'Aura for next wave' : '下一波光环';
    const group = page.getByRole('group', { name: legend });
    const none = group.getByRole('radio', { name: locale === 'en' ? 'None' : '无', exact: true });
    const might = group.getByRole('radio', { name: locale === 'en' ? 'Might' : '力量', exact: true });
    await expect(none).toBeChecked(); await expect(might).toBeDisabled();
    await page.getByTestId('skill-node-skills-paladin-might').click();
    await page.getByTestId('skill-detail-panel').getByRole('button').click();
    await expect(might).toBeEnabled(); await expect(none).toBeChecked();
    for (const [width,height] of profiles) {
      await page.setViewportSize({ width,height });
      await none.check(); await expect(none).toBeChecked();
      // Enter the radio group with actual Tab events, bounded through native page focus order.
      await page.getByRole('heading', { name: locale === 'en' ? 'Skills' : '技能', exact: true }).click();
      let tabCount = 0;
      while (!await none.evaluate(el => el === document.activeElement) && tabCount < 40) { await page.keyboard.press('Tab'); tabCount++; }
      assert(tabCount < 40, 'Native Tab did not reach None');
      await page.keyboard.press('ArrowRight'); await expect(might).toBeChecked(); await expect(might).toBeFocused();
      const focus = await might.evaluate(el => ({ visible: el.matches(':focus-visible'), width: getComputedStyle(el).outlineWidth, style: getComputedStyle(el).outlineStyle }));
      assert(focus.visible && parseFloat(focus.width) >= 2 && focus.style !== 'none', 'Missing visible native keyboard focus');
      await expect(group.getByRole('status')).toContainText(locale === 'en' ? 'Selected: Might' : '已选择：力量');
      await page.keyboard.press('ArrowLeft'); await expect(none).toBeChecked(); await expect(none).toBeFocused();
      const geometry = await group.evaluate(el => {
        const labels = [...el.querySelectorAll('label')].map(label => { const r = label.getBoundingClientRect(); return { width: r.width, height: r.height, left: r.left, right: r.right }; });
        return { bodyOverflow: document.body.scrollWidth - document.body.clientWidth, documentOverflow: document.documentElement.scrollWidth - document.documentElement.clientWidth, groupOverflow: el.scrollWidth - el.clientWidth, labels, font: getComputedStyle(el.querySelector('label')).fontSize, text: el.textContent };
      });
      assert(geometry.bodyOverflow <= 0 && geometry.documentOverflow <= 0 && geometry.groupOverflow <= 0, 'Horizontal overflow');
      for (const box of geometry.labels) assert(box.width >= 44 && box.height >= 44 && box.left >= 0 && box.right <= width, 'Label target/clipping');
      assert(parseFloat(geometry.font) >= 16, 'Radio label text too small');
      assert(!geometry.text.includes('{{'), 'Unresolved localized placeholders');
      await group.scrollIntoViewIfNeeded();
      const file = `aura-${locale}-${width}x${height}.png`; await page.screenshot({ path: path.join(shots,file) }); result.screenshots.push(file);
      result.cases.push({ locale, width,height, tabCount, focus, geometry });
    }
    await page.setViewportSize({ width:360,height:640 }); await might.check();
    await page.locator('a[href="/settings"]').first().click();
    const downloadEvent = page.waitForEvent('download'); await page.getByTestId('export-save-button').click(); const download = await downloadEvent;
    const stream = await download.createReadStream(); let content = ''; for await (const chunk of stream) content += chunk.toString();
    assert(content.length < 1024 * 1024, 'Unexpected save size'); const save = JSON.parse(content);
    assert.equal(save.player.selectedAuraId,'paladin.might');
    await page.reload(); await page.locator('a[href="/skills"]').first().click(); await expect(might).toBeChecked();
    await none.check(); await page.locator('a[href="/settings"]').first().click();
    const clearedEvent = page.waitForEvent('download'); await page.getByTestId('export-save-button').click(); const cleared = await clearedEvent;
    const clearedStream = await cleared.createReadStream(); let clearedContent = ''; for await (const chunk of clearedStream) clearedContent += chunk.toString();
    assert(!Object.hasOwn(JSON.parse(clearedContent).player,'selectedAuraId'));
    await page.reload(); await page.locator('a[href="/skills"]').first().click(); await expect(none).toBeChecked();
    result.persistence.push({ locale, selectedExportCanonical: true, selectedReloadChecked: true, clearedExportPropertyOmitted: true, clearedReloadNone: true });
    await context.close();
  }
  assert.equal(result.console.length,0,'Production console errors/warnings'); assert.equal(result.requestsFailed.length,0,'Failed requests');
  result.pass = true;
})().catch(error => { result.pass = false; result.error = error.stack; process.exitCode = 1; }).finally(async () => {
  if (browser) await browser.close();
  if (server && server.exitCode === null && birth(server.pid) === serverBirth) {
    const exited = new Promise(resolve => server.once('exit', resolve)); server.kill('SIGTERM'); await exited;
  }
  fs.writeFileSync(report,JSON.stringify(result,null,2)+'\n',{flag:'wx'}); console.log(JSON.stringify({ pass:result.pass,cases:result.cases.length,persistence:result.persistence,error:result.error }));
});
