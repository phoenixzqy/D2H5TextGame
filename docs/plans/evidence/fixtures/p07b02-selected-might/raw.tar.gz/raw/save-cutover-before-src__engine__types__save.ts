/**
 * Save system types
 * @module engine/types/save
 */

import { migrateLegacyStarter } from '../save/legacyStarter';
import type { Player, Mercenary } from './entities';
import type { DerivedStats } from './attributes';
import type { EquipmentSlot, Inventory, Item } from './items';
import type { MapProgress } from './maps';
import type { GridPosition } from '../combat/types';

/**
 * Current save format version. Bump this and add an entry to {@link MIGRATIONS}
 * whenever the on-disk shape changes.
 */
export const CURRENT_SAVE_VERSION = 9;

/**
 * Save file version (most recent).
 */
export type SaveVersion = typeof CURRENT_SAVE_VERSION;

/**
 * Settings
 */
export interface Settings {
  readonly locale: 'zh-CN' | 'en';
  readonly stealthMode: boolean;
  readonly soundEnabled: boolean;
  readonly musicEnabled: boolean;
  readonly combatSpeed: number; // 1 = normal, 2 = 2x, etc.
  readonly autoCombat: boolean;
}

/**
 * Idle state - tracks offline time and multipliers
 */
export interface IdleState {
  /** Last online timestamp (ms since epoch) */
  readonly lastOnline: number;
  
  /** Offline time accumulated (ms) */
  readonly offlineTime: number;
  
  /** Multiplier pool remaining (in seconds of boosted play) */
  readonly multiplierSecondsRemaining: number;
  
  /** Active multiplier (1.0 = none, 2.0 = 2x XP/MF) */
  readonly activeMultiplier: number;
  
  /** Idle farming target (sub-area ID) */
  readonly idleTarget?: string;
}

/**
 * Gacha state
 */
export interface GachaState {
  /** Gacha currency (e.g. "prayer stones") */
  readonly currency: number;
  
  /** Owned mercenary IDs (before recruiting) */
  readonly ownedMercIds: readonly string[];
  
  /** Pity counter (for SSR mercy) */
  readonly pityCounter: number;
}

/**
 * Quest progress entry (persisted in {@link SaveV2.map}).
 */
export interface QuestProgressData {
  readonly id: string;
  readonly status: 'locked' | 'available' | 'inProgress' | 'completed';
  readonly objectives: Readonly<Record<string, boolean>>;
  readonly rewardClaimed?: boolean;
}

/** Historical derived stats permit a validated MR extension but never require it. */
export type LegacyDerivedStats = Omit<DerivedStats, 'magicResist'> & {
  readonly magicResist?: number;
};
export type LegacyPlayer = Omit<Player, 'derivedStats' | 'selectedAuraId'> & {
  readonly derivedStats: LegacyDerivedStats;
};
export type LegacyMercenary = Omit<Mercenary, 'derivedStats'> & {
  readonly derivedStats: LegacyDerivedStats;
};

/**
 * Save file v1 (legacy — engine-shape, never deployed to users).
 *
 * Retained for migration only. New code should target {@link SaveV2}.
 */
export interface SaveV1 {
  readonly version: 1;
  readonly player: LegacyPlayer;
  readonly inventory: Inventory;
  readonly mercenaries: readonly LegacyMercenary[];
  readonly activeMercId?: string;
  readonly mapProgress: MapProgress;
  readonly idleState: IdleState;
  readonly gachaState: GachaState;
  readonly settings: Settings;
  readonly timestamp: number;
}

/**
 * Persisted inventory snapshot. Mirrors `useInventoryStore` shape so save/load
 * is a near-direct copy with no lossy conversion.
 */
export interface InventorySaveData {
  readonly backpack: readonly Item[];
  readonly stash: readonly Item[];
  readonly equipped: Readonly<Record<string, Item | null>>;
  readonly currencies: Readonly<Record<string, number>>;
}

/** Persisted mercenary progression snapshot. */
export interface MercProgressSaveData {
  readonly experience: number;
  readonly experienceToNextLevel: number;
  readonly level?: number;
}

/** Persisted mercenary snapshot. */
export interface MercSaveData {
  readonly ownedMercs: readonly Mercenary[];
  readonly fieldedMercId: string | null;
  readonly mercEquipment: Readonly<Record<string, Partial<Record<EquipmentSlot, Item | null>>>>;
  readonly mercProgress: Readonly<Record<string, MercProgressSaveData>>;
}

/** Historical roster shape; current entities require the MR field. */
export interface LegacyMercSaveData extends Omit<MercSaveData, 'ownedMercs'> {
  readonly ownedMercs: readonly LegacyMercenary[];
}

/** Persisted map snapshot. */
export interface MapSaveData {
  readonly currentAct: number;
  readonly currentSubAreaId: string | null;
  readonly discoveredAreas: readonly string[];
  readonly clearedSubAreas: readonly string[];
  readonly questProgress: Readonly<Record<string, QuestProgressData>>;
}

/** Persisted meta (settings + idle + gacha) snapshot. */
export interface MetaSaveData {
  readonly settings: Settings;
  readonly idleState: IdleState;
  readonly gachaState: GachaState;
}

/**
 * Save file v2. Slices map 1:1 to Zustand stores
 * to avoid translation logic on every mutation.
 */
export interface SaveV2 {
  readonly version: 2;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: Omit<LegacyMercSaveData, 'mercEquipment' | 'mercProgress'>;
  readonly map: Omit<MapSaveData, 'clearedSubAreas'>;
  readonly meta: MetaSaveData;
}

/** Save file v3 — folds legacy gold into rune-shards. */
export interface SaveV3 {
  readonly version: 3;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: Omit<LegacyMercSaveData, 'mercEquipment' | 'mercProgress'>;
  readonly map: Omit<MapSaveData, 'clearedSubAreas'>;
  readonly meta: MetaSaveData;
}

/** Save file v4 — persists map clears and merc equipment/progression. */
export interface SaveV4 {
  readonly version: 4;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: LegacyMercSaveData;
  readonly map: MapSaveData;
  readonly meta: MetaSaveData;
}

/** Alias to whichever version is current; bump along with {@link CURRENT_SAVE_VERSION}. */
export interface SaveV5 {
  readonly version: 5;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: LegacyMercSaveData;
  readonly map: MapSaveData;
  readonly meta: MetaSaveData;
}

/** Save file v6 — persists definition-backed item stat rolls and set-piece ids. */
export interface SaveV6 {
  readonly version: 6;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: LegacyMercSaveData;
  readonly map: MapSaveData;
  readonly meta: MetaSaveData;
}

/** Persisted player-side battle formation. */
export interface FormationPreferences {
  readonly playerPosition: GridPosition;
  readonly mercPosition: GridPosition;
  readonly summonPositions: readonly GridPosition[];
}

/** Save file v7 - persists player-side battle formation preferences. */
export interface SaveV7 {
  readonly version: 7;
  readonly timestamp: number;
  readonly player: LegacyPlayer;
  readonly inventory: InventorySaveData;
  readonly mercs: LegacyMercSaveData;
  readonly map: MapSaveData;
  readonly meta: MetaSaveData;
  readonly formation: FormationPreferences;
}

/** Save file v8 — canonical ownership of the two proven legacy Amazon starters. */
export interface SaveV8 extends Omit<SaveV7, 'version'> {
  readonly version: 8;
}

/** Save file v9 — explicit independent magical mitigation for every saved actor. */
export interface SaveV9 extends Omit<SaveV8, 'version' | 'player' | 'mercs'> {
  readonly version: 9;
  readonly player: Omit<Player, 'selectedAuraId'>;
  readonly mercs: MercSaveData;
}

export type SaveCurrent = SaveV9;

/**
 * Migration function type. Each entry receives the previous version's shape
 * (typed `unknown` because old data may be arbitrary JSON) and returns the next.
 */
export type Migration<From = unknown, To = unknown> = (oldSave: From) => To;

/**
 * Migrations keyed by **target** version. To upgrade an N-versioned save to
 * N+1, call `MIGRATIONS[N+1](save)`. {@link runMigrations} handles chaining.
 */
export const MIGRATIONS: Record<number, Migration> = {
  /** v1 (legacy engine-shape) → v2 (store-shape). */
  2: (raw: unknown): SaveV2 => {
    const v1 = raw as SaveV1;
    const equipped: Record<string, Item | null> = {};
    const eq: unknown = v1.inventory.equipment;
    if (eq instanceof Map) {
      for (const [slot, item] of eq) equipped[slot as string] = item as Item;
    } else if (Array.isArray(eq)) {
      // Already JSON-serialized via toJsonSafe: [[slot, item], ...]
      for (const entry of eq as readonly (readonly [string, Item])[]) {
        equipped[entry[0]] = entry[1];
      }
    }
    return {
      version: 2,
      timestamp: v1.timestamp,
      player: v1.player,
      inventory: {
        backpack: v1.inventory.backpack,
        stash: v1.inventory.stash,
        equipped,
        currencies: {}
      },
      mercs: {
        ownedMercs: v1.mercenaries,
        fieldedMercId: v1.activeMercId ?? null
      },
      map: {
        currentAct: v1.mapProgress.currentAct,
        currentSubAreaId: v1.mapProgress.currentSubArea,
        discoveredAreas: v1.mapProgress.completedSubAreas,
        questProgress: {}
      },
      meta: {
        settings: v1.settings,
        idleState: v1.idleState,
        gachaState: v1.gachaState
      }
    };
  },
  /** v2 → v3: fold legacy gold into rune-shards. */
  3: (raw: unknown): SaveV3 => {
    const v2 = raw as SaveV2;
    const { gold, ...restCurrencies } = v2.inventory.currencies;
    const runeShardTotal = (restCurrencies['rune-shard'] ?? 0) + (gold ?? 0);
    return {
      ...v2,
      version: 3,
      inventory: {
        ...v2.inventory,
        currencies: {
          ...restCurrencies,
          ...(runeShardTotal > 0 ? { 'rune-shard': runeShardTotal } : {})
        }
      }
    };
  },
  /** v3 → v4: add newly persisted map and merc slices with safe defaults. */
  4: (raw: unknown): SaveV4 => {
    const v3 = raw as SaveV3;
    const questProgress = Object.fromEntries(
      Object.entries(v3.map.questProgress).map(([id, progress]) => [
        id,
        { ...progress, rewardClaimed: progress.rewardClaimed ?? false }
      ])
    );
    return {
      ...v3,
      version: 4,
      mercs: {
        ...v3.mercs,
        mercEquipment: {},
        mercProgress: {}
      },
      map: {
        ...v3.map,
        clearedSubAreas: [],
        questProgress
      }
    };
  },
  /** v4 to v5: ensure legacy items have rolled-instance containers. */
  5: (raw: unknown): SaveV5 => {
    const v4 = raw as SaveV4;
    const migrateItem = (item: Item): Item => ({
      ...item,
      ilvl: item.ilvl ?? item.level,
      baseRolls: item.baseRolls ?? {},
      affixes: item.affixes ?? []
    });
    const migrateItemOrNull = (item: Item | null): Item | null => item ? migrateItem(item) : null;
    return {
      ...v4,
      version: 5,
      inventory: {
        ...v4.inventory,
        backpack: v4.inventory.backpack.map(migrateItem),
        stash: v4.inventory.stash.map(migrateItem),
        equipped: Object.fromEntries(Object.entries(v4.inventory.equipped).map(([slot, item]) => [slot, migrateItemOrNull(item)]))
      },
      mercs: {
        ...v4.mercs,
        mercEquipment: Object.fromEntries(Object.entries(v4.mercs.mercEquipment).map(([mercId, equipment]) => [mercId, Object.fromEntries(Object.entries(equipment).map(([slot, item]) => [slot, migrateItemOrNull(item ?? null)]))]))
      }
    };
  },
  /** v5 to v6: ensure definition-backed item fields have JSON-safe defaults. */
  6: (raw: unknown): SaveV6 => {
    const v5 = raw as SaveV5;
    const migrateItem = (item: Item): Item => ({
      ...item,
      statRolls: item.statRolls ?? {},
      affixes: item.affixes ?? []
    });
    const migrateItemOrNull = (item: Item | null): Item | null => item ? migrateItem(item) : null;
    return {
      ...v5,
      version: 6,
      inventory: {
        ...v5.inventory,
        backpack: v5.inventory.backpack.map(migrateItem),
        stash: v5.inventory.stash.map(migrateItem),
        equipped: Object.fromEntries(Object.entries(v5.inventory.equipped).map(([slot, item]) => [slot, migrateItemOrNull(item)]))
      },
      mercs: {
        ...v5.mercs,
        mercEquipment: Object.fromEntries(Object.entries(v5.mercs.mercEquipment).map(([mercId, equipment]) => [mercId, Object.fromEntries(Object.entries(equipment).map(([slot, item]) => [slot, migrateItemOrNull(item ?? null)]))]))
      }
    };
  },
  /** v6 to v7: add persistent player-side battle formation preferences. */
  7: (raw: unknown): SaveV7 => {
    const v6 = raw as SaveV6;
    return {
      ...v6,
      version: 7,
      formation: {
        playerPosition: { row: 1, col: 1 },
        mercPosition: { row: 0, col: 0 },
        summonPositions: [
          { row: 2, col: 0 },
          { row: 2, col: 1 },
          { row: 2, col: 2 },
          { row: 0, col: 1 },
          { row: 0, col: 2 },
          { row: 1, col: 0 },
          { row: 1, col: 2 },
          { row: 0, col: 0 }
        ]
      }
    };
  },
  /** v7 to v8: conservatively transfer a proven legacy starter to canonical gear. */
  8: (raw: unknown): SaveV8 => migrateLegacyStarter(raw as SaveV7),
  /** v8 to v9: add only missing MR; decode validates historical fields first. */
  9: (raw: unknown): SaveV9 => {
    const v8 = raw as SaveV8;
    const addMagicResist = <T extends LegacyPlayer | LegacyMercenary>(unit: T) => ({
      ...unit,
      derivedStats: { ...unit.derivedStats, magicResist: unit.derivedStats.magicResist ?? 0 }
    });
    return {
      ...v8,
      version: 9,
      player: addMagicResist(v8.player),
      mercs: { ...v8.mercs, ownedMercs: v8.mercs.ownedMercs.map(addMagicResist) }
    };
  }
};
