from pathlib import Path
import subprocess, sys, time, json, datetime, os, signal, stat, ctypes
raw = Path(__file__).resolve().parent
name = sys.argv[1]
limits = {name: {'focused':30,'engine':120,'unit':120,'types':90,'lint':90,'build':210,'browser':240}.get(name.split('-')[0],0)}
if not limits[name] or not sys.argv[2:]:
    raise SystemExit('Unknown bounded command')
command = sys.argv[2:]
report = raw / (name + '-report.json')
if report.exists():
    raise SystemExit('Refusing existing per-command report')
for suffix in ['.log', '.meta.json', '.process.json', '.processes.json']:
    if (raw / (name + suffix)).exists():
        raise SystemExit('Refusing to overwrite evidence')
if name == 'pilot' and (raw / 'attachments').exists():
    raise SystemExit('Pilot attachments must be new')
env = dict(os.environ)
env.pop('VITE_E2E', None)
t0 = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
signals = []
reason = None

def size(path):
    # Browser-owned temporary files can disappear between monitor samples.
    # A single no-follow stat counts each surviving regular file and retains link rejection.
    try:
        info = path.lstat()
    except FileNotFoundError:
        return 0
    if stat.S_ISLNK(info.st_mode):
        raise RuntimeError('Unexpected evidence symlink')
    if stat.S_ISREG(info.st_mode):
        return info.st_size
    total = 0
    for child in path.rglob('*'):
        try:
            info = child.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode):
            # Chrome creates SingletonLock/Socket links in its task-owned profile.
            # Count link metadata only; never resolve/traverse/open a link target.
            if (raw / 'ui-browser-temporary') in child.parents:
                total += info.st_size
                continue
            raise RuntimeError('Unexpected attachment symlink')
        if stat.S_ISREG(info.st_mode):
            total += info.st_size
    return total

# Linux process start ticks prevent PID reuse from authorizing a signal.
def processes():
    result = {}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            result[int(entry.name)] = {'pid': int(entry.name), 'state': fields[0], 'ppid': int(fields[1]),
                'pgid': int(fields[2]), 'startTicks': int(fields[19])}
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return result

# Confine orphan adoption to this dedicated wrapper. It starts only the task command.
# Linux child-subreaper retains detached descendants even if their parent exits between scans.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
    raise OSError(ctypes.get_errno(), 'Cannot establish task child subreaper')
wrapper_pid = os.getpid()
owned = {}
observations = []

def discover():
    snapshot = processes()
    # Only identities already observed from the newly started process authorize ancestry.
    parents = {pid for pid, identity in owned.items() if pid in snapshot and
               snapshot[pid]['startTicks'] == identity['startTicks']}
    parents.add(wrapper_pid)
    safe_groups = {identity['pgid'] for pid, identity in snapshot.items() if pid in parents and
                   pid in owned and pid == identity['pgid'] and identity['startTicks'] == owned[pid]['startTicks']}
    changed = True
    while changed:
        changed = False
        for pid, identity in snapshot.items():
            if pid not in owned and (identity['ppid'] in parents or identity['pgid'] in safe_groups):
                owned[pid] = identity.copy()
                parents.add(pid)
                if pid == identity['pgid']:
                    safe_groups.add(pid)
                observations.append({'elapsed': round(time.monotonic() - t0, 3), **identity})
                changed = True
    return {pid: identity for pid, identity in snapshot.items() if pid in owned and
            identity['startTicks'] == owned[pid]['startTicks'] and identity['state'] != 'Z'}

def send(pid, sig):
    # Revalidate the exact birth identity immediately before signaling one task-owned PID.
    identity = processes().get(pid)
    if identity and identity['startTicks'] == owned[pid]['startTicks'] and identity['state'] != 'Z':
        try:
            os.kill(pid, sig)
            signals.append({'signal': signal.Signals(sig).name, **identity})
        except ProcessLookupError:
            pass

with (raw / (name + '.log')).open('x') as out:
    proc = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT, start_new_session=True, env=env)
    root_identity = processes().get(proc.pid)
    if root_identity:
        owned[proc.pid] = root_identity
        observations.append({'elapsed': round(time.monotonic() - t0, 3), **root_identity})
    (raw / (name + '.process.json')).write_text(json.dumps({'pid': proc.pid, 'pgid': proc.pid, 'command': command, 'owner': 'root'}) + '\n')
    while proc.poll() is None:
        discover()
        try:
            if time.monotonic() - t0 >= limits[name]:
                reason = 'deadline'
            elif size(raw / (name + '.log')) > 32 * 1024**2 or size(report) > 32 * 1024**2:
                reason = 'report-cap'
            elif size(raw) + size(Path.cwd() / 'dist') + size(Path.cwd() / 'node_modules/.vite') > 64 * 1024**2:
                reason = 'total-task-artifact-cap'
        except Exception as error:
            reason = str(error)
        if reason:
            break
        time.sleep(0.05)
    # Playwright normally closes all resources. Track detached browser/server children too.
    survivors = discover()
    cleanup_started = time.monotonic()
    term_sent = set()
    while survivors and time.monotonic() - cleanup_started < 1.5:
        for pid in survivors:
            if pid not in term_sent:
                send(pid, signal.SIGTERM)
                term_sent.add(pid)
        time.sleep(0.05)
        proc.poll()
        survivors = discover()
    for pid in survivors:
        send(pid, signal.SIGKILL)
    proc.wait(timeout=0.5)
    remaining = discover()
    for pid in owned:
        if pid != proc.pid:
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
    if remaining:
        reason = reason or 'owned-process-survived-cleanup'
    (raw / (name + '.processes.json')).write_text(json.dumps({'observations': observations,
        'remainingNonZombie': list(remaining.values()), 'signals': signals}, indent=2) + '\n')
# Final caps also cover a child exiting between monitor ticks.
sizes = {'log': size(raw / (name + '.log')), 'report': size(report), 'attachments': size(raw / 'attachments'),
         'totalTaskArtifacts': size(raw) + size(Path.cwd() / 'dist') + size(Path.cwd() / 'node_modules/.vite')}
if not reason and (sizes['log'] > 32 * 1024**2 or sizes['report'] > 32 * 1024**2 or sizes['totalTaskArtifacts'] > 64 * 1024**2):
    reason = 'final-cap'
meta = {'command': command, 'cwd': str(Path.cwd()), 'started': started, 'seconds': round(time.monotonic() - t0, 3),
        'exitCode': proc.returncode, 'pid': proc.pid, 'deadlineSeconds': limits[name], 'cleanupGraceSeconds': 2,
        'stopReason': reason, 'signals': signals, 'sizes': sizes}
(raw / (name + '.meta.json')).write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
sys.exit(124 if reason else proc.returncode)
