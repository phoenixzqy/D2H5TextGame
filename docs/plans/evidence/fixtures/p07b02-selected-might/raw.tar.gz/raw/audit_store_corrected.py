from pathlib import Path
import json,sys,hashlib,datetime,stat
r=Path(__file__).resolve().parent;w=Path.cwd();stage=sys.argv[1];proposal=json.loads((r/sys.argv[2]).read_text())
paths=proposal['paths'];freeze={}
for name in paths:
 p=w/name;data=p.read_bytes();freeze[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if isinstance(paths,dict): assert freeze[name]['sha256']==paths[name]['sha256'],name
 (r/(stage+'-accepted-'+name.replace('/','__'))).write_bytes(data)
(r/(stage+'-source-freeze.json')).write_text(json.dumps(freeze,indent=2)+'\n')
commands=[];lastEnd=None
for name in ['focused-store-selection','engine-store-selection','unit-store-selection','focused-store-selection-corrected','types-store-selection-corrected','lint-store-selection-corrected','build-store-selection-corrected']:
 meta=json.loads((r/(name+'.meta.json')).read_text());assert meta['exitCode']==0 and not meta['stopReason'] and not meta['signals'],name
 start=datetime.datetime.fromisoformat(meta['started']);end=start+datetime.timedelta(seconds=meta['seconds'])
 if lastEnd: assert start>=lastEnd,name
 lastEnd=end
 report=r/(name+'-report.json')
 if report.exists():
  data=json.loads(report.read_text());assert data['numTotalTests']==data['numPassedTests'] and data['numFailedTests']==0 and data['numPendingTests']==0,name
  meta['tests']={key:data[key] for key in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']};meta['files']=len(data['testResults'])
 commands.append(meta)
identities={}
for p in r.glob('*.processes.json'):
 data=json.loads(p.read_text());assert not data['remainingNonZombie'] and not data['signals'],p
 for row in data['observations']:identities[(row['pid'],row['startTicks'])]=row
for pid,birth in identities:
 p=Path('/proc')/str(pid)/'stat'
 if p.exists():
  fields=p.read_text().rsplit(')',1)[1].split();assert int(fields[19])!=birth,(pid,birth)
inventory=[]
for relative in ['dist','node_modules/.vite']:
 root=w/relative;assert root.resolve().is_relative_to(w.resolve()) and not root.is_symlink(),relative
 if not root.exists():continue
 for p in sorted(root.rglob('*')):
  st=p.lstat();assert not stat.S_ISLNK(st.st_mode),p
  if stat.S_ISREG(st.st_mode):
   data=p.read_bytes();inventory.append({'path':str(p.relative_to(w)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(r/(stage+'-owned-output.json')).write_text(json.dumps({'root':str(w),'files':inventory},indent=2)+'\n')
summary={'sourceFreeze':stage+'-source-freeze.json','proposal':sys.argv[2],'commands':commands,'sequenceVerified':True,'processAudit':{'uniqueIdentities':len(identities),'allAbsent':True,'signals':[]},'ownedOutputFiles':len(inventory),'ownedOutputBytes':sum(p['bytes'] for p in inventory),'limits':'existing3sengine/15sunit timing targets missed; retain buildwarnings. No runtime/UI/browser/coverage/earnedcampaign/balance/fullv1 acceptance.'}
(r/(stage+'-final-gates.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='commands'},indent=2))
for command in commands:print(command['command'][0],command['seconds'],command.get('tests',{}))
