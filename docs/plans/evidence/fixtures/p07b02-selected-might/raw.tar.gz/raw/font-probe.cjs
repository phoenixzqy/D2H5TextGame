const {createRequire}=require('node:module');
const fs=require('node:fs'); const path=require('node:path');
const assert=require('node:assert/strict'); const temporary=path.join(__dirname,'ui-browser-temporary'); assert(!fs.existsSync(temporary)); fs.mkdirSync(temporary); process.env.TMPDIR=temporary; for(const name of ['font-probe.json','font-probe.png'])assert(!fs.existsSync(path.join(__dirname,name)));
const {chromium}=createRequire('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/package.json')('@playwright/test');
(async()=> {let browser;try {
browser=await chromium.launch({headless:true,env:{...process.env,FONTCONFIG_FILE:path.join(__dirname,'ui-browser-fontconfig.xml')}});
const page=await browser.newPage();await page.setContent('<p id="serif" style="font-family:serif;font-size:24px">下一波光环中文</p><p id="noto" style="font-family:Noto Sans CJK SC;font-size:24px">下一波光环中文</p>');
await page.evaluate(()=>document.fonts.ready);
const cdp=await page.context().newCDPSession(page);await cdp.send('DOM.enable');await cdp.send('CSS.enable');const doc=await cdp.send('DOM.getDocument');const result={};
for(const selector of ['#serif','#noto']) {const node=await cdp.send('DOM.querySelector',{nodeId:doc.root.nodeId,selector});result[selector]=await cdp.send('CSS.getPlatformFontsForNode',{nodeId:node.nodeId});}
fs.writeFileSync(path.join(__dirname,'font-probe.json'),JSON.stringify(result,null,2),{flag:'wx'});await page.screenshot({path:path.join(__dirname,'font-probe.png')});
}finally{if(browser)await browser.close(); function clean(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name);assert(p.startsWith(temporary+path.sep));if(e.isDirectory())clean(p);else fs.unlinkSync(p);}fs.rmdirSync(dir);}clean(temporary);assert(!fs.existsSync(temporary));}})().catch(e=>{console.error(e);process.exitCode=1;});
