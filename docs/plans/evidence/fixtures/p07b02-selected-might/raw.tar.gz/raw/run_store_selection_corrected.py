from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
commands=[('focused',['node','node_modules/vitest/vitest.mjs','run','src/stores/playerStore.aura.test.ts']),('types',['npm','run','typecheck']),('lint',['npm','run','lint']),('build',['npm','run','check:test-bridge-shake'])]
for tier,command in commands:
 name=tier+'-store-selection-corrected'
 if tier=='focused': command+=['--reporter=json','--outputFile='+str(r/(name+'-report.json'))]
 subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*command],check=True)
