from pathlib import Path
import json,hashlib,tarfile,gzip,io,sys,stat
r=Path(__file__).resolve().parent;target=Path(sys.argv[1]);assert not target.exists();assert target.parent.is_dir();assert not target.parent.is_symlink()
records=[]
for p in sorted(r.rglob('*')):
 st=p.lstat();assert not stat.S_ISLNK(st.st_mode),p
 if stat.S_ISREG(st.st_mode):
  b=p.read_bytes();records.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert sum(x['bytes'] for x in records)<32*1024**2
with target.open('xb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for row in records:
    b=(r/row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];info=tarfile.TarInfo('raw/'+row['path']);info.size=len(b);tar.addfile(info,io.BytesIO(b))
   b=(json.dumps({'rawRoot':str(r),'records':records},indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
with tarfile.open(target,'r:gz') as tar:
 manifest=json.load(tar.extractfile('manifest.json'));assert manifest['records']==records
 assert len(tar.getmembers())==len(records)+1
 for row in records:
  member=tar.getmember('raw/'+row['path']);assert member.isfile();b=tar.extractfile(member).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
assert target.stat().st_size<32*1024**2
print(json.dumps({'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'records':len(records),'rawBytes':sum(x['bytes'] for x in records),'allArchiveMembersVerified':True}))
