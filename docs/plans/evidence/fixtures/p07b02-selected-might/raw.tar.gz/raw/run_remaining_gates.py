from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
stage=sys.argv[1]
commands=[('engine',['node','node_modules/vitest/vitest.mjs','run','--project','engine']),('unit',['node','node_modules/vitest/vitest.mjs','run']),('types',['npm','run','typecheck']),('lint',['npm','run','lint']),('build',['npm','run','check:test-bridge-shake'])]
for tier,command in commands:
 name=tier+'-'+stage
 if tier in ['engine','unit']:
  command += ['--reporter=json','--outputFile='+str(r/(name+'-report.json'))]
 subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*command],check=True)
