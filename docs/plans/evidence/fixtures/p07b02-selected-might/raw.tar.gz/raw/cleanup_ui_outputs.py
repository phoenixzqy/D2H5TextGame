from pathlib import Path
import json,hashlib,stat,datetime
r=Path(__file__).resolve().parent;w=Path.cwd();out=r/'ui-output-cleanup.json';assert not out.exists()
d=json.loads((r/'ui-corrected-owned-output.json').read_text());assert Path(d['root'])==w
files=[];dirs=set()
for row in d['files']:
 p=w/row['path'];assert p.is_relative_to(w/'dist') or p.is_relative_to(w/'node_modules/.vite');assert p.resolve()==p and not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];files.append(p)
 for parent in p.parents:
  if parent in [w,w/'node_modules',w/'node_modules/.vite']:break
  dirs.add(parent)
for p in files:p.unlink()
removed=[]
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):
 if not any(p.iterdir()):p.rmdir();removed.append(str(p.relative_to(w)))
assert all(not p.exists() for p in files)
assert not (r/'ui-browser-temporary').exists()
out.write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inventory':'ui-corrected-owned-output.json','removedFiles':len(files),'removedBytes':sum(x['bytes'] for x in d['files']),'removedEmptyDirectories':removed,'verifiedAllAbsent':True,'sharedCachesPreserved':True,'sourceHistoryEvidencePreserved':True},indent=2)+'\n');print(out.read_text())
