
import { MIGHT_DEFINITION, resolveMightDefinition, resolveMightRank } from './might';

describe('P07b02A independent immutable player Might definition', () => {
  it('copies authored two-coefficient tuning and leaves the full source unchanged', () => {
    const before = structuredClone(paladinSkills);
    expect(MIGHT_DEFINITION).toEqual({ requiredLevel: 1, maxRank: 20,
      physicalDamagePctPerRank: 0.03, attackPctPerRank: 0.01 });
    expect(Object.isFrozen(MIGHT_DEFINITION)).toBe(true);
    expect(resolveMightDefinition(paladinSkills)).toEqual(MIGHT_DEFINITION);
    expect(paladinSkills).toEqual(before);
  });

  it('returns independent frozen primitives without retaining or freezing caller rows', () => {
    const row = authored();
    const before = structuredClone(row);
    const result = resolveMightDefinition([row]);
    expect(result).not.toBe(resolveMightDefinition([row]));
    expect(Object.isFrozen(result)).toBe(true);
    expect(row).toEqual(before);
    expect(Object.isFrozen(row)).toBe(false);
    expect(Object.isFrozen(row.scaling.passiveStatsPerLevel)).toBe(false);
    row.requiredLevel = 9;
    row.maxLevel = 31;
    row.scaling.passiveStatsPerLevel = { physicalDamagePct: 99, attackPct: 99 };
    expect(result).toEqual(MIGHT_DEFINITION);
    for (const key of ['requiredLevel', 'maxRank', 'physicalDamagePctPerRank', 'attackPctPerRank']) {
      expect(Reflect.set(result, key, 99)).toBe(false);
    }
  });

  it.each([0, 0.125, 3])('copies each alternate valid coefficient %s, unlock and cap independently', value => {
    for (const key of ['physicalDamagePct', 'attackPct']) {
      const values = { ...coefficients, [key]: value };
      const definition = resolveMightDefinition([{ ...authored(), requiredLevel: 9, maxLevel: 31,
        scaling: { passiveStatsPerLevel: values } }]);
      expect(definition).toEqual({ requiredLevel: 9, maxRank: 31,
        physicalDamagePctPerRank: values.physicalDamagePct, attackPctPerRank: values.attackPct });
      expect(resolveMightRank({ 'paladin.might': 99 }, definition)).toBe(31);
    }
  });

  it('selects exactly one authored player identity, never canonical-only or mercenary identities', () => {
    for (const rows of [[], [null, 7, {}], [{ ...authored(), id: 'paladin.might' }],
      [{ ...authored(), id: 'aura-might' }], [authored(), authored()]]) {
      expect(() => resolveMightDefinition(rows)).toThrow(/exactly one/);
    }
    expect(resolveMightDefinition([null, 7, {}, { id: 'other' }, authored()])).toEqual(MIGHT_DEFINITION);
  });

  it.each(malformedRows)('rejects malformed selected Might definition %j', fields => {
    expect(() => resolveMightDefinition([{ ...authored(), ...fields }])).toThrow(/Might/);
  });
});

const invalidRanks: readonly unknown[] = [0, -1, 1.5, NaN, Infinity, -Infinity, '20', null, undefined, true];
const levels = (value: unknown): Readonly<Record<string, number>> => value as Readonly<Record<string, number>>;

describe('P07b02A allocation-only Might rank independent of selection and eligibility', () => {
  it.each(['skills-paladin-might', 'paladin.might'])('resolves exact alias %s and clamps once', alias => {
    for (const rank of [1, 10, 20]) expect(resolveMightRank({ [alias]: rank })).toBe(rank);
    expect(resolveMightRank({ [alias]: 99 })).toBe(20);
  });

  it('takes the maximum valid alias once regardless of insertion order or duplicate allocations', () => {
    expect(resolveMightRank({ 'skills-paladin-might': 2, 'paladin.might': 7 })).toBe(7);
    expect(resolveMightRank({ 'paladin.might': 2, 'skills-paladin-might': 7 })).toBe(7);
    expect(resolveMightRank({ 'skills-paladin-might': 20, 'paladin.might': 20 })).toBe(20);
    expect(resolveMightRank({ 'skills-paladin-might': 99, 'paladin.might': 1 })).toBe(20);
  });

  it.each(invalidRanks)('ignores invalid allocation %s while preserving a valid alternate alias', invalid => {
    expect(resolveMightRank(levels({ 'skills-paladin-might': invalid, 'paladin.might': 3 }))).toBe(3);
    expect(resolveMightRank(levels({ 'paladin.might': invalid, 'skills-paladin-might': 3 }))).toBe(3);
    expect(resolveMightRank(levels({ 'skills-paladin-might': invalid }))).toBe(0);
    expect(resolveMightRank(levels({ 'paladin.might': invalid }))).toBe(0);
  });

  it('never infers rank1 or accepts a mercenary, marker, selected field or similar alias', () => {
    expect(resolveMightRank()).toBe(0);
    expect(resolveMightRank({})).toBe(0);
    expect(resolveMightRank({ 'paladin-might': 20, 'skills-paladin.might': 20,
      'aura-might': 20, 'might': 20, 'selectedAuraId': 20, 'skills-paladin-holy-fire': 20 })).toBe(0);
  });
});
