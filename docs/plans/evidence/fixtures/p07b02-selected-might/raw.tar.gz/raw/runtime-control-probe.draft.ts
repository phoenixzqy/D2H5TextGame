import { expect, it } from 'vitest';
import { runBattle, runBattleRecorded } from './combat';
import type { CombatUnit } from './types';

function unit(id: string, side: CombatUnit['side']): CombatUnit {
  return { id, name: id, side, kind: side === 'player' ? 'hero' : 'monster', level: 24, tier: 'trash',
    life: 100, mana: 50,
    stats: { life: 100, lifeMax: 100, mana: 100, manaMax: 100, attack: 100, defense: 0, magicResist: 0,
      attackSpeed: 100, critChance: 0, critDamage: 2, physDodge: 0, magicDodge: 0,
      magicFind: 0, goldFind: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } },
    statuses: [], cooldowns: {}, skillOrder: [], activeBuffIds: [], enraged: false };
}
it('captures the complete unaffected seed7 recording before any Might runtime patch', () => {
  const input = { seed: 7, playerTeam: [unit('hero', 'player')],
    enemyTeam: [{ ...unit('target', 'enemy'), life: 1,
      statuses: [{ id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1 }] }] };
  const before = structuredClone(input);
  const actual = runBattleRecorded(input);
  expect(input).toEqual(before);
  expect(runBattle(input)).toEqual(actual.result);
  expect(runBattleRecorded(input)).toEqual(actual);
  console.log('MIGHT_PREPATCH_CONTROL=' + JSON.stringify({ input, actual }));
});
