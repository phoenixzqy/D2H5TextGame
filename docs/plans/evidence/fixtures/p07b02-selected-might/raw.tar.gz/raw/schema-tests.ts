import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import paladinSkills from '../../data/skills/paladin.json';
import skillSchema from '../../data/schema/skill.schema.json';

const authored = () => {
  const row = paladinSkills.find(row => row.id === 'skills-paladin-might');
  if (!row) throw new Error('Missing authored Might');
  return structuredClone(row);
};
const validate = new Ajv2020({ strict: true, allErrors: true }).compile(skillSchema);
const coefficients = { physicalDamagePct: 0.03, attackPct: 0.01 };
const malformedRows = [
  { requiredLevel: undefined },
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '1', null].map(requiredLevel => ({ requiredLevel })),
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '20', null].map(maxLevel => ({ maxLevel })),
  { scaling: undefined }, { scaling: {} }, { scaling: { passiveStatsPerLevel: {} } },
  { scaling: { passiveStatsPerLevel: { attackPct: 0.01 } } },
  { scaling: { passiveStatsPerLevel: { physicalDamagePct: 0.03 } } },
  ...['physicalDamagePct', 'attackPct'].flatMap(key =>
    [-0.01, NaN, Infinity, -Infinity, '0.03', null].map(value =>
      ({ scaling: { passiveStatsPerLevel: { ...coefficients, [key]: value } } }))),
  { trigger: 'active' }, { target: 'all-allies' }, { passive: false },
  { aura: undefined }, { aura: false }, { summon: true },
  ...[1, -1, NaN, Infinity, -Infinity, '0', null].map(cooldown => ({ cooldown })),
  { cost: {} }, { cost: { mana: 0 } }, { cost: { life: 0 } },
  { damage: { min: 1, max: 1, breakdown: { physical: 1 } } }, { damageType: 'physical' },
  { appliesStatus: [] }, { appliesStatus: ['stun'] }, { statusEffect: { chance: 1 } },
  { additionalStatusEffects: { freeze: { chance: 1 } } },
  { appliesTags: ['physical'] }, { synergies: { physical: 1.2 } },
  { heal: { min: 1, max: 1, target: 'self' } }, { summonId: 'skeleton' },
  { aoeShape: 'single' }, { requires: {} }, { requires: { weaponType: ['sword'] } },
  { scaling: { passiveStatsPerLevel: { ...coefficients, fireDamagePct: 0.1 } } },
  { scaling: { passiveStatsPerLevel: { ...coefficients, typo: 0.1 } } },
  ...['damagePerLevel', 'cooldownPerLevel', 'costPerLevel'].map(key =>
    ({ scaling: { passiveStatsPerLevel: coefficients, [key]: 0 } })),
  { scaling: { passiveStatsPerLevel: coefficients, summonStatsPerLevel: { attack: 1 } } },
  { scaling: { passiveStatsPerLevel: coefficients, summonMaxCount: { kind: 'first-three-then-every-three' } } },
  { scaling: { passiveStatsPerLevel: coefficients, typo: 1 } }, { typo: 1 }
];

describe('P07b02A exact player Might schema', () => {
  it('preserves authored unlock1/cap20 and both distinct coefficients without selecting an aura', () => {
    const row = authored();
    expect(validate(row)).toBe(true);
    expect(row).toMatchObject({ id: 'skills-paladin-might', requiredLevel: 1, minLevel: 1,
      maxLevel: 20, trigger: 'passive', aura: true, target: 'self', cooldown: 0,
      scaling: { passiveStatsPerLevel: coefficients } });
    expect(row).not.toHaveProperty('cost');
    expect(row).not.toHaveProperty('damage');
  });

  it.each([0, 0.125, 3])('accepts each finite nonnegative coefficient %s independently without a tuning ceiling', value => {
    for (const key of ['physicalDamagePct', 'attackPct']) {
      expect(validate({ ...authored(), scaling: { passiveStatsPerLevel: { ...coefficients, [key]: value } } })).toBe(true);
    }
  });

  it('accepts alternate positive integer unlock/cap with explicit passive and nonsummon classification', () => {
    expect(validate({ ...authored(), requiredLevel: 9, maxLevel: 31,
      passive: true, summon: false })).toBe(true);
  });

  it.each(malformedRows)('rejects malformed exact player Might row %j', fields => {
    expect(validate({ ...authored(), ...fields })).toBe(false);
  });

  it('preserves every other authored Paladin skill including distinct aura metadata', () => {
    for (const row of paladinSkills.filter(row => row.id !== 'skills-paladin-might')) {
      expect(validate(row), row.id).toBe(true);
    }
  });

  it('does not impose player Might restrictions on a distinct mercenary identity', () => {
    expect(validate({ ...authored(), id: 'aura-might', aura: false, requiredLevel: undefined,
      scaling: undefined, cooldown: 1, cost: { mana: 1 } })).toBe(true);
  });
});
