from pathlib import Path
import json,hashlib,stat,datetime
r=Path(__file__).resolve().parent;w=Path.cwd();out=r/'ui-final-browser-audit.json';assert not out.exists()
freeze=json.loads((r/'ui-corrected-source-freeze.json').read_text())
for p,v in freeze.items():
 b=(w/p).read_bytes();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256'],p
ids={};signals=[]
for p in r.glob('*.processes.json'):
 d=json.loads(p.read_text());assert not d['remainingNonZombie'],p
 signals.extend(d['signals'])
 for row in d['observations']:ids[(row['pid'],row['startTicks'])]=row
for pid,birth in ids:
 p=Path('/proc')/str(pid)/'stat'
 if p.exists():assert int(p.read_text().rsplit(')',1)[1].split()[19])!=int(birth),(pid,birth)
inventory=json.loads((r/'ui-corrected-owned-output.json').read_text())
for row in inventory['files']:
 p=w/row['path'];assert not p.is_symlink();b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],p
browser=json.loads((r/'browser-ui-production-v5-report.json').read_text());assert browser['pass'] and len(browser['cases'])==18 and len(browser['persistence'])==2 and not browser['console'] and not browser['requestsFailed'] and browser['temporaryCleanupVerified']
meta=json.loads((r/'browser-ui-production-v5.meta.json').read_text());assert meta['exitCode']==0 and not meta['stopReason'] and not meta['signals']
assert not (r/'ui-browser-temporary').exists()
files=[]
for p in sorted(r.rglob('*')):
 st=p.lstat();assert not stat.S_ISLNK(st.st_mode),p
 if stat.S_ISREG(st.st_mode):
  b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
d={'checked':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFreeze':freeze,'browserMeta':meta,'browserCases':len(browser['cases']),'explicitSaveLocales':[x['locale'] for x in browser['persistence']],'cumulativeProcessIdentities':len(ids),'allProcessIdentitiesAbsent':True,'wrapperSignals':signals,'outputInventory':'ui-corrected-owned-output.json','outputFilesVerified':len(inventory['files']),'outputBytes':sum(x['bytes'] for x in inventory['files']),'rawFiles':files,'rawBytes':sum(x['bytes'] for x in files),'temporaryAbsent':True}
out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ['sourceFreeze','rawFiles']}))
