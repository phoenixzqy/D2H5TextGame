from pathlib import Path
import json,subprocess,os,signal
root=Path(__file__).resolve().parent
started=json.loads((root/'pulse-preview-final.process.json').read_text())['pid']
def children(pid):
 data=subprocess.check_output(['ps','--ppid',str(pid),'-o','pid=,args='],text=True) if subprocess.run(['pgrep','-P',str(pid)],capture_output=True).returncode==0 else ''
 out=[]
 for line in data.splitlines():
  p,command=line.strip().split(None,1);out.append((int(p),command));out+=children(int(p))
 return out
owned=children(started)
servers=[(pid,cmd) for pid,cmd in owned if 'node ' in cmd and 'vite preview' in cmd and '--port 4464' in cmd and str(root/'build-final') in cmd]
assert len(servers)==1,owned
pid,command=servers[0]
(root/'preview-final-stop.json').write_text(json.dumps({'npmPid':started,'serverPid':pid,'command':command,'signal':'SIGTERM'},indent=2))
os.kill(pid,signal.SIGTERM)
print('Stopped exact task-owned preview PID',pid)
