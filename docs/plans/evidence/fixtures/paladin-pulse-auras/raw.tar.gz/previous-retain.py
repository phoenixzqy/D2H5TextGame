"""Retain this task's evidence, verify bytes, then remove its exact scratch tree."""
from pathlib import Path
import hashlib
import json
import socket
import tarfile

root = Path(__file__).resolve().parent
expected = Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-enemy-auras-d3niygby')
assert root == expected and not root.is_symlink()
draft = (root / 'evidence-draft.md').read_text()
owner = json.loads((root / 'ownership.json').read_text())
assert owner['owner'] == 'root' and owner['task'] == 'Paladin Holy Freeze and Conviction'
worktree = Path(owner['worktree'])
target = worktree / 'docs/plans/evidence/fixtures/paladin-enemy-auras'
assert not target.exists(), 'Never overwrite retained evidence'
assert json.loads((root / 'enemy-auras-full.result.json').read_text())['exit'] == 0
assert json.loads((root / 'full-before.json').read_text()) == json.loads((root / 'full-after.json').read_text())
assert json.loads((root / 'browser-domain-audit.json').read_text())['pass'] is True
processes = list(root.glob('*.process.json'))
for process in processes:
    assert process.with_name(process.name.replace('.process.json', '.result.json')).is_file(), process
connection = socket.socket()
assert connection.connect_ex(('127.0.0.1', 4463)) != 0, 'Preview must stop before retention'
connection.close()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

owned = sorted(root.rglob('*'))
assert not any(path.is_symlink() for path in owned), 'Resolve unexpected links before cleanup'
files = [path for path in owned if path.is_file() and
         path.relative_to(root).parts[0] != 'build' and
         'downloads' not in path.relative_to(root).parts]
target.mkdir(parents=True)
records = []
retained = {}
with tarfile.open(target / 'raw.tar.gz', 'w:gz', compresslevel=6) as archive:
    for path in files:
        relative, size, sha = str(path.relative_to(root)), path.stat().st_size, digest(path)
        record = {'path': relative, 'bytes': size, 'sha256': sha}
        if sha in retained:
            record.update(retained[sha])
        elif path.suffix == '.zip' and size > 20 * 1024 * 1024:
            traces = target / 'traces'
            traces.mkdir(exist_ok=True)
            parts = []
            with path.open('rb') as stream:
                index = 0
                while chunk := stream.read(20 * 1024 * 1024):
                    index += 1
                    part = traces / f'{sha[:12]}.zip.part{index:02d}'
                    part.write_bytes(chunk)
                    parts.append(str(part.relative_to(target)))
            record.update({'artifacts': parts, 'reassemble': 'concatenate parts in listed order'})
            retained[sha] = {key: record[key] for key in ['artifacts', 'reassemble']}
        else:
            archive.add(path, arcname=relative, recursive=False)
            record.update({'artifact': 'raw.tar.gz', 'member': relative})
            retained[sha] = {key: record[key] for key in ['artifact', 'member']}
        records.append(record)

with tarfile.open(target / 'raw.tar.gz', 'r:gz') as archive:
    for record in records:
        value = hashlib.sha256()
        count = 0
        if 'artifacts' in record:
            streams = [(target / part).open('rb') for part in record['artifacts']]
        else:
            streams = [archive.extractfile(record['member'])]
        for stream in streams:
            assert stream is not None
            with stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    value.update(chunk)
                    count += len(chunk)
        assert count == record['bytes'] and value.hexdigest() == record['sha256'], record['path']

manifest = {'scratchRoot': str(root), 'rawFiles': len(records),
            'terminalProcessRecords': len(processes), 'byteVerified': True,
            'archiveSha256': digest(target / 'raw.tar.gz'), 'files': records}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

receipt = {'scratchRoot': str(root), 'removedFiles': [], 'removedDirectories': [],
           'remainingPaths': [], 'failures': []}
for path in sorted(owned, key=lambda path: len(path.parts), reverse=True):
    relative = str(path.relative_to(root))
    try:
        if path.is_file():
            path.unlink()
            receipt['removedFiles'].append(relative)
        elif path.is_dir():
            path.rmdir()
            receipt['removedDirectories'].append(relative)
    except OSError as error:
        receipt['failures'].append({'path': relative, 'error': str(error)})
try:
    root.rmdir()
except OSError as error:
    receipt['failures'].append({'path': str(root), 'error': str(error)})
receipt['scratchAbsent'] = not root.exists()
if root.exists():
    receipt['remainingPaths'] = [str(path) for path in root.rglob('*')]
connection = socket.socket()
receipt['preview4463Closed'] = connection.connect_ex(('127.0.0.1', 4463)) != 0
connection.close()
(target / 'cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'retainedFiles': len(records), 'terminalProcesses': len(processes),
                  'removedFiles': len(receipt['removedFiles']),
                  'scratchAbsent': receipt['scratchAbsent'],
                  'preview4463Closed': receipt['preview4463Closed'],
                  'failures': receipt['failures']}))
assert receipt['scratchAbsent'] and not receipt['failures'] and receipt['preview4463Closed']

full_result = "Full current-source run: **12,261 passed /517 files**, two existing skips; 533.89s Vitest/535.156s process. All1,231 source/test/config hashes,760 build hashes, HEAD/Git state and genuine save digest stayed exact through the run. Commit bee0cd8 has the identical validated source hashes."
retention_result = f"The manifest retains {len(records)} original files and {len(processes)} terminal process records, all byte-verified."
cleanup_result = f"Cleanup removed {len(receipt['removedFiles'])} exact task-owned files, confirms scratch-root absence and preview4463 closure, and reports no failures or remaining paths. Shared caches and older campaign evidence remain."
report = draft.replace('FULL_RESULT', full_result).replace('RETENTION_RESULT', retention_result).replace('CLEANUP_RESULT', cleanup_result)
report = report.replace('baseline bc9750f.', 'baseline bc9750f; implementation bee0cd8.')
assert all(marker not in report for marker in ['FULL_RESULT','RETENTION_RESULT','CLEANUP_RESULT'])
(worktree / 'docs/plans/evidence/d05-paladin-enemy-auras.md').write_text(report)
