# D05 — Selected Holy Fire and Holy Shock / BUG181

Local implementation on feat/playable-foundations, baseline9a6afe1. Root sole writer and self-review;
independent design/QA and earned class/build balance remain open. The [family contract](../decisions/D05-paladin-aura-family-v1.md)
records the provisional local defaults: Fire preserves advertised20 base damage, Shock newly receives20,
both on a JSON-owned1000ms simulation interval. This is not earned balance approval.

Both selected living-hero auras now pulse every living enemy in registration order, first at one full
interval after native wave entry. They persist through source stun/freeze, use no mana/cast/cooldown/action
slot, and consume no hit/dodge/crit/proc RNG. Existing increases, combos, resistance penalties/clamps,
flat mitigation, minimum damage and exact-once death consequences use the normal damage commit path.
Fire's guaranteed canonical Burn uses10% of mitigated pulse damage per stack per second, floored with
minimum1,3000ms duration and canonical five-stack refresh/expiry. Existing periodic deaths settle first;
a due pulse precedes surviving tied actions, includes60000ms, and never catches up after battle/action cap.

Strict schema confines required auraPulse metadata to exact Fire/Shock rows, matching elements and Fire-only
finite nested Burn tuning. Definition/native/direct-engine projections copy/freeze nested metadata and
reject invalid or foreign potency. Existing authored+3%matching-element damage/rank, unlock6/24,
prerequisites and cap20 remain; only eligible hero/original living fielded merc gain these rank bonuses.
Dream item-granted Holy Shock retains its separate D10 contract. Savev22 already permits selection IDs;
no transient timer/potency is persisted. Native changes apply next wave; replay uses original inputs and
never repeats income. Both locales explain timing, base damage, source eligibility, rank bonuses and Burn.

## Verification

Original combat RED7failed/3controls (including an incorrect AS188 tied-action fixture) is retained.
The corrected2000ms/AS0 tie and real combo fixtures still produce7causal failures; a later cap case gives
8failed/3controls. Original boundary/native/UI RED8failed/33passes is retained. After metadata, four new
boundary cases pass; one existing assertion still expects Holy Fire unsupported and is corrected alongside
an explicit unsupported Sanctuary control. UI count RED records two13-versus15 failures and two missing
pulse descriptions. Their counts update to15 while retaining exclusivity/resource checks. The uncommitted
UI expectation is clarified from "dealt" to "mitigated" pulse damage to match the accepted contract and
existing before-shield canonical DoT calculation; rounding/minimum are visible in both languages.

FOCUSED_RESULT
ENGINE_RESULT
The first complete run records 12,283 passes / one stale store assertion failure / two existing skips across 519 files. All 1,233 inputs, 760 build hashes, HEAD/Git state and genuine save digest stayed exact. The old unsupported Holy Fire fixture now uses still-unsupported Sanctuary; new Fire/Shock cases verify unlearned and under-level rejection with no mutation/publication. Historical save-version rejection tests remain untouched.
FULL_RESULT
Initial lint reports six errors: redundant literal guards on typed metadata, redundant discriminant branches, a matcher any-return and implicit numeric interpolation. The metadata boundary now accepts unknown before explicit validation; tests retain exact assertions without those lint errors. The original output is retained. Final types, standard lint/engine purity, explicit-VITE_E2E=false production build and four-chunk/five-pattern
bridge scan pass. Existing suite-time, bundle/PWA warning budgets and intermittent BUG180 remain open.

Production browser en/zh-CN at1280x800 and360x640 uses an explicitly constructed L30 prerequisite fixture,
publicly allocates both skills, selects each and clears to None. BROWSER_RESULT
The first independent attachment audit incorrectly expected Shock to be learned during the earlier Fire-only allocation step; its original failure/script are retained. The corrected audit checks rank0 before Shock allocation and rank1 afterward, preserving full-domain equality.
These fixtures do not prove earned acquisition, paid town respec, pacing or class balance. The pointer
moves away from detail panels before screenshots, avoiding the previous unrelated hover overlay. The mobile capture is a scrolled detail view with existing fixed navigation; whole-screen accessibility acceptance is not claimed.

## Retention and remaining scope

The first retention attempt stopped before archive creation or deletion because its exact owner-task assertion omitted the trailing word "pulses". The original script/failure and exact-name correction are retained.
RETENTION_RESULT
CLEANUP_RESULT

Only these two inventory rows gain bounded-functional dispositions:213IDs remain,162unverified,
49bounded-functional,one bounded-engine-functional (Ice Arrow),one review-needed (Cold Mastery).
The50 bounded records have different proof scopes; no engine-only record is promoted. BUG181 remains
open for Sanctuary, Cleansing, Redemption, Prayer, Vigor and Concentration. No stat-only substitute counts
as a promised distinct mechanic.

The genuine claimed Ancients401/Rite save remains decompressedSHA256
c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577,
L33/XP149261/23682gear/nextNormal402; no genuine campaign action or diagnostic-save promotion.
Baal, seven-class/two-build acceptance, economy/endgame/pacing/offline/PWA/accessibility/performance,
independent C2-C4 and fullG0-G7 acceptance remain open. Local only; umbrella goal/branch/worktree stay active.
