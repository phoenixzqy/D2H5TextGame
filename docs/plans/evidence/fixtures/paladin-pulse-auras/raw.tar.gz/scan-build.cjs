const fs=require('node:fs');const path=require('node:path');const assert=require('node:assert/strict');
const assets=path.join(__dirname,'build-final/assets');const patterns=[/__GAME__/,/\bseedItem\b/,/\bseedMerc\b/,/\binstallTestBridge\b/,/[,{]flushSave:/];
const chunks=fs.readdirSync(assets).filter(n=>n.endsWith('.js'));
assert.ok(chunks.length>0);
for(const chunk of chunks){const text=fs.readFileSync(path.join(assets,chunk),'utf8');for(const pattern of patterns)assert.equal(pattern.test(text),false,chunk+' '+pattern);}
console.log(JSON.stringify({chunks,patterns:patterns.map(String),pass:true}));
