const start = performance.now();
const registry = await import("/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry.ts");
console.log(JSON.stringify({ phase: process.env.BENCH_PHASE, importMs: performance.now() - start,
  registered: registry.listSkills().length, node: process.version }));
