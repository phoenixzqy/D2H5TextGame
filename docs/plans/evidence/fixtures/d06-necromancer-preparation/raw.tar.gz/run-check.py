import datetime, json, pathlib, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1]; argv=sys.argv[2:]
assert name.replace('-', '').isalnum()
log=root/(name+'.log'); meta=root/(name+'.json')
assert not log.exists() and not meta.exists()
p=root/'ownership.json'; d=json.loads(p.read_text()); d['artifacts']=sorted(set(d['artifacts']+[log.name,meta.name])); p.write_text(json.dumps(d,indent=2)+'\n')
t=time.monotonic(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('w') as out:
 proc=subprocess.Popen(argv,stdout=out,stderr=subprocess.STDOUT)
 record={'argv':argv,'pid':proc.pid,'startUtc':start,'log':log.name}
 meta.write_text(json.dumps(record,indent=2)+'\n')
 code=proc.wait()
record.update(seconds=time.monotonic()-t,exitCode=code)
meta.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
print('\n'.join(log.read_text().splitlines()[-12:]))
sys.exit(code)
