import base64, hashlib, json, pathlib
root = pathlib.Path(__file__).resolve().parent
image_root = root / 'browser-original-images'
assert not image_root.exists()
image_root.mkdir()
reports = {}
images = []
def specs(suite):
    yield from suite.get('specs', [])
    for child in suite.get('suites', []):
        yield from specs(child)
for report_name in ['necromancer-browser-report.json', 'necromancer-browser-final-report.json', 'raven-final-browser-report.json']:
    report = json.loads((root / report_name).read_text())
    tests = []
    for suite in report['suites']:
        for spec in specs(suite):
            for test in spec['tests']:
                for result in test['results']:
                    attachments = []
                    for index, attachment in enumerate(result['attachments']):
                        body = base64.b64decode(attachment['body']) if 'body' in attachment else pathlib.Path(attachment['path']).read_bytes()
                        entry = {k: attachment[k] for k in ['name', 'contentType']}
                        entry.update(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
                        if attachment['contentType'] == 'image/png':
                            name = f"{report_name.removesuffix('.json')}-{len(tests):02d}-{index:02d}.png"
                            destination = image_root / name
                            assert not destination.exists()
                            destination.write_bytes(body)
                            entry['originalPng'] = str(destination.relative_to(root))
                            images.append({'test': spec['title'], **entry})
                        elif attachment['contentType'] == 'application/json':
                            entry['value'] = json.loads(body)
                        attachments.append(entry)
                    tests.append({'title': spec['title'], 'status': result['status'], 'retry': result['retry'], 'durationMs': result['duration'], 'attachments': attachments})
    reports[report_name] = {'stats': report['stats'], 'errors': report['errors'], 'tests': tests}
summary = {'reports': reports, 'originalPngs': images, 'limits': 'Imported eligibility/survival fixture and finite DOM/layout checks only; not earned progression, balance, full D06/P09/P10, offline, full a11y, performance or private-v1 acceptance.'}
(root / 'browser-evidence-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
outputs = {}
for leaf in ['necromancer-browser-output', 'necromancer-browser-final-output', 'raven-final-browser-output', 'browser-original-images']:
    directory = root / leaf
    entries = {}
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            body = path.read_bytes()
            entries[str(path.relative_to(directory))] = {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
        else:
            assert path.is_dir(), path
    outputs[leaf] = entries
(root / 'browser-output-inventory.json').write_text(json.dumps(outputs, indent=2) + '\n')
print(json.dumps({'reports': {name: report['stats'] for name, report in reports.items()}, 'originalPngs': len(images), 'outputs': {name: len(entries) for name, entries in outputs.items()}}, indent=2))
