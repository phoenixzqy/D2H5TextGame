# D06 v1c truthful descriptions — proposed next increment

After the reviewed five-path runtime commit and separate BUG072/ledger increment,
root owns exactly five paths: SkillsScreen.tsx, existing canonical corpse-summon
UI suite, en/zh-CN skills.json and execution-ledger.md. No other source changes.

Use existing skill.description and tDataKey only for the three canonical D06 v1c
preparation identities; prepend it to unchanged shared preparation prose. Preserve
all thirteen prior preparation/legacy Iron/synthetic behavior. No new UI control,
business logic, save shape or data tuning.

Proposed exact descriptions:
- Skeleton en: Prepare skeleton warriors; no corpse is required.
- Skeleton zh-CN: 准备骷髅战士，无需尸体。
- Mage en: Prepare skeletal mages that fight with physical basic attacks; no corpse is required.
- Mage zh-CN: 准备以物理普通攻击作战的骷髅法师，无需尸体。
- Revive en: Prepare Revived Minions whose strength grows with skill rank. No corpse or fallen enemy is required. They last until they or their summoner die, or the wave ends.
- Revive zh-CN: 准备实力随技能等级成长的复生仆从，无需尸体或倒下的敌人。仆从持续作战，直到自身或召唤者死亡，或本波结束。

Shared prose already supplies learned/unlocked/combo, one whole-batch payment,
full/poor/no-retry, no ordinary action/replacement/refund and paid fresh waves.

Before production edits add independent literal full paragraph assertions to all
canonical-rank/authored-alias cases; add unlearned preview and concrete rank6
current/next Mastery-derived summon stat checks (including Revive exclusion).
Establish genuine RED for missing displayed identity; preserve all current cap/
cost/CD assertions. Then make the smallest locale and presentation change.
Focused canonical + generic preparation + Mastery suites, full units, types and
lint serially; build plus production browser follows in separate increment.
Freeze source and exact command records, QA and design review then producer.

Browser follow-up plan: separate normal production spec/config modeled on existing
paid Raven proof; all3skills×2locales, target allocations1→2 via real controls,
imported L30/points/prerequisites/gear/resources disclosed, exact own-template
startup cap and single payment from300MP, no bridge, combo replay, explicit disk
save/close/newpage/reload equality, finite mobile/desktop/landscape layouts and
actual Chinese font/screenshot inspection. Shared preparation sentence + each
skill identity visible in both locales. Store engine suites remain evidence for
next-wave carry/respec/death/refund/replay details; no browser scaffold proves
earned progression, full Mage elemental identity, enemy inheritance, full D06/P09/
P10, corpse consumers, selected-item Iron or private-v1. Task-owned outputs
registered before creation, exact files inventoried, cleanup after all readers
and durable retention; original checkout stays read-only; no remote action.
