# D06 v1c durable closure plan
Root remains sole writer/executor. All browser/source readers have released.
1. Browser commit 4cc41f0 is complete. Preserve original failures, RED snapshots,
   reports (including inline base64), decoded original PNGs, command metadata,
   review transcriptions and source/build inventories. Do not change older v1b.
2. Create root-owned cleanup/archive scripts in registered RAW before capture.
   Verify all metadata command PIDs absent and no live Node/Chromium processes
   belonging to this worktree/task; ports4375/4376 closed. Never kill processes.
   Verify exact current dist against accepted 760-file inventory; inventory exact
   task-only fontconfig-cache/browser-tmp. Unlink verified regular files and rmdir
   exact empty directories only, never RAW/worktree/shared parents. Keep receipt.
3. Archive all remaining RAW regular files losslessly, refusing symlinks,
   unsafe/duplicate members or unregistered root files/child output directories.
   Packet binds every member size/SHA256, archive size/hash, source HEAD/current
   fingerprints, metadata results, original failures and scope/provenance limits.
   Roundtrip every member against live bytes. Cleanup script is included.
4. Exactly five repository paths: new archive and packet under fixtures/
   d06-necromancer-preparation, new evidence document, BUG073 and ledger.
   BUG073 closure cites accepted foundation/UI/browser proof; foundation RED
   source is reconstructed, corrected UI RED snapshot is actual. Explicitly
   retain fixture-name failure and visual/time/balance/full-game limitations.
   Scoped regression report maps BUG072/073 to existing tests; no new global
   regression manifest or project-wide coverage claim.
5. Freeze and independently review archive/closure; source unchanged while read.
   All readers release, exact five-path commit before RAW deletion. Then guarded
   cleanup rechecks committed archive and every member, exact live RAW set,
   current source fingerprints, absent command PIDs/processes/ports/outputs and
   original checkout clean. Unlink only exact members; remove exact empty child
   directories; preserve empty RAW root. Failures/remaining paths are reported.
6. Following <=5-path docs increment persists actual cleanup receipt and bounded
   delivery notes. Verify cleanup before bounded closure. Keep umbrella claim;
   full D06/private-v1 not complete. Next: reviewed Iron Golem contract.
No push/PR/merge/deploy or shared cache/font/tool cleanup.
