# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: necromancer-preparation.spec.ts >> paid raise-skeleton native allocation, startup, disk reload and layouts en
- Location: tests/pwa/necromancer-preparation.spec.ts:77:3

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 1
Received length: 0
Received array:  []
```

# Test source

```ts
  70  |   return points;
  71  | }
  72  | function section(panel: Locator, page: Page, name: string): Locator {
  73  |   return panel.locator('section').filter({ has: page.getByRole('heading', { name,exact: true }) });
  74  | }
  75  | for (const item of CASES) for (const locale of ['en','zh-CN'] as const) {
  76  |   const SKILL = `necromancer.${item.slug.replace(/-/g, '_')}`, NODE = `skills-necromancer-${item.slug}`, NAME = `Paid ${item.slug}`;
  77  |   test(`paid ${item.slug} native allocation, startup, disk reload and layouts ${locale}`, async ({ page: initial, context }, info) => {
  78  |     const english = locale === 'en', name = english ? item.en : item.zh,
  79  |       descriptionText = `${item.identity[locale]} ${copy[locale].prose(english ? item.en : item.zh, item.cap, item.cost)}`,
  80  |       text = copy[locale], errors: string[] = [];
  81  |     const watch = (p: Page): void => {
  82  |       p.on('pageerror', error => errors.push(error.message));
  83  |       p.on('console', message => { if (['warning','error'].includes(message.type())) errors.push(`${message.type()}: ${message.text()}`); });
  84  |     };
  85  |     let page = initial; watch(page); await page.clock.setFixedTime(fixedTime); // Date only, native timers.
  86  |     try {
  87  |       await page.goto('/'); await createCharacter(page,{ class: 'necromancer',name: NAME });
  88  |       await navTo(page,'settings');
  89  |       await page.getByRole('button',{ name: english ? 'English' : '简体中文',exact: true }).click();
  90  |       const fresh = await backup(page);
  91  |       expect(fresh.player).toMatchObject({ class: 'necromancer',level: 1,skillPoints: 1 });
  92  |       const cap: Item = { id: 'fixture-paid-necromancer-cap',baseId: 'items/base/helm-cap',
  93  |         rarity: 'rare',level: 1,identified: true,equipped: true,equipSlot: 'head',
  94  |         affixes: [{ affixId: 'fixture-imported-survival-mana',values: new Map([
  95  |           ['statMods.life',999638],['statMods.mana',796.5],['statMods.defense',999000]
  96  |         ]) }] };
  97  |       // Explicitly imported eligibility/survival scaffold; no earned progression or balance claim.
  98  |       const eligible: SaveCurrent = { ...fresh,player: { ...fresh.player,level: 30,skillPoints: 2,
  99  |         skillLevels: { ...item.prerequisites, 'necromancer.skeleton_mastery': 20 },comboOrder: [],derivedStats: { ...fresh.player.derivedStats,
  100 |           life: 900000,lifeMax: 1000000,mana: 300,manaMax: 1000,attack: 30,defense: 100000,attackSpeed: 120 } },
  101 |         inventory: { ...fresh.inventory,equipped: { ...fresh.inventory.equipped,head: cap } } };
  102 |       const importLabel = english ? 'Import Save' : '导入存档';
  103 |       await page.getByRole('button',{ name: importLabel,exact: true }).click();
  104 |       const dialog = page.getByRole('dialog');
  105 |       await dialog.getByRole('textbox').fill(JSON.stringify(eligible, (_key,value: unknown) => value instanceof Map ? [...value] : value));
  106 |       await dialog.getByRole('button',{ name: importLabel,exact: true }).click(); await expect(dialog).toHaveCount(0);
  107 |       const prepared = await backup(page); expect(prepared.player).toEqual(eligible.player);
  108 |       await attach(info,'01-imported-eligibility-and-gear',{ fresh,prepared });
  109 |       await navTo(page,'map');
  110 |       await page.getByTestId('sub-area-row-a1-blood-moor').getByRole('button',{ name: english ? 'Enter' : '进入',exact: true }).click();
  111 |       await expect(page.getByTestId('combat-screen')).toBeVisible(); await pause(page,english);
  112 |       const before = await combatSnapshot(page); expect(before.cards.length).toBeGreaterThan(1);
  113 |       expect(await page.locator('[data-kind="summon"]').count()).toBe(0);
  114 |       await attach(info,'02-paused-wave-before-allocation',before);
  115 |       for (const rank of [1,2]) {
  116 |         const panel = await detail(page,NODE), allocate = panel.getByRole('button',{ name: text.allocate,exact: true });
  117 |         await allocate.focus(); await expect(allocate).toBeFocused(); await page.keyboard.press('Enter');
  118 |         const current = section(panel,page,text.current), next = section(panel,page,text.next);
  119 |         await expect(current.getByText(text.cap,{ exact: true }).locator('+ dd')).toHaveText(String(item.slug === 'raise-skeleton' ? 1 : rank));
  120 |         await expect(current.getByText(text.mana,{ exact: true }).locator('+ dd')).toHaveText(String(item.cost));
  121 |         await expect(next.getByText(text.cap,{ exact: true }).locator('+ dd')).toHaveText(item.slug === 'raise-skeleton' ? english ? '1(no change)' : '1（无变化）' : `${String(rank+1)}(+1)`);
  122 |         await expect(next.getByText(text.mana,{ exact: true }).locator('+ dd')).toHaveText(String(item.cost));
  123 |         if (rank === 2) {
  124 |           await expect(panel).toContainText(descriptionText);
  125 |           for (const [index,label] of (english ? ['Life','Attack','Defense'] : ['生命','攻击','防御']).entries()) {
  126 |             await expect(current.getByText(label,{ exact: true }).locator('+ dd')).toHaveText(item.unit[index] ?? 'missing literal');
  127 |           }
  128 |         }
  129 |         const allocated = await backup(page);
  130 |         expect(allocated.player).toEqual({ ...prepared.player,skillPoints: 2-rank,skillLevels: { ...prepared.player.skillLevels, [SKILL]: rank } });
  131 |         await navTo(page,'combat');
  132 |         await expect(page.getByRole('button',{ name: english ? 'Resume' : '继续',exact: true })).toHaveAttribute('aria-pressed','true');
  133 |         const after = await combatSnapshot(page); expect(after).toEqual(before);
  134 |         await attach(info,`03-native-allocation-${String(rank)}`,{ allocated,after });
  135 |       }
  136 |       await navTo(page,'skills'); await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  137 |       const slot = page.getByRole('combobox',{ name: english ? 'Slot 1' : '槽位 1',exact: true });
  138 |       await expect(slot).toHaveValue(''); await expect(slot.locator(`option[value="${NODE}"]`)).toHaveCount(1);
  139 |       await slot.selectOption(NODE); await expect(slot).toHaveValue(NODE); // Explicit native combo replay.
  140 |       const observer = await page.evaluateHandle(({mpLabel,template}) => {
  141 |         const frames: Frame[] = []; let previous = '', overflow = false;
  142 |         const sample = (): void => {
  143 |           const root = document.querySelector('[data-testid="combat-screen"]'); if (!root) return;
  144 |           const bar = root.querySelector(`[role="group"][aria-label="${mpLabel}"] [role="progressbar"]`);
  145 |           const frame: Frame = { mp: Number(bar?.getAttribute('aria-valuenow')),max: Number(bar?.getAttribute('aria-valuemax')),
  146 |             summons: Array.from(root.querySelectorAll<HTMLElement>(`[data-testid^="unit-card-"][data-testid*="-summon-${template}-"]`),node => ({
  147 |               id: node.dataset.testid ?? '',lifeWidth: node.querySelector<HTMLElement>('.bg-red-600')?.style.width ?? '' })),
  148 |             logs: Array.from(root.querySelectorAll('[data-testid="combat-log"] > div > span:last-child'),node => node.textContent ?? '').slice(-8) };
  149 |           const serialized = JSON.stringify(frame); if (serialized === previous) return; previous = serialized;
  150 |           if (frames.length === 128) { overflow = true; return; } frames.push(frame);
  151 |         };
  152 |         const changes = new MutationObserver(sample);
  153 |         changes.observe(document.body,{ childList: true,subtree: true,attributes: true,characterData: true });
  154 |         return { read: () => ({ frames,overflow }),disconnect: () => changes.disconnect() };
  155 |       },{ mpLabel: text.mp,template: item.template });
  156 |       try {
  157 |         await navTo(page,'combat');
  158 |         const summons = page.locator(`[data-testid^="unit-card-"][data-testid*="-summon-${item.template}-"]`);
  159 |         await expect(summons).toHaveCount(item.cap,{ timeout: 1500 }); await pause(page,english);
  160 |         const observation = await observer.evaluate(handle => handle.read());
  161 |         await attach(info,'04-ordinary-DOM-paid-batch-startup',observation);
  162 |         expect(observation.overflow).toBe(false);
  163 |         expect(observation.frames.some(frame => frame.mp === 300 && frame.max === 1000 && frame.summons.length === 0)).toBe(true);
  164 |         const batch = observation.frames.find(frame => frame.summons.length === item.cap);
  165 |         expect(batch).toBeDefined(); expect(batch).toMatchObject({ mp: 300-item.cost,max: 1000 });
  166 |         expect(new Set(batch?.summons.map(summon => summon.id)).size).toBe(item.cap);
  167 |         expect(batch?.summons.map(summon => summon.lifeWidth)).toEqual(Array.from({ length: item.cap },() => '100%'));
  168 |         const cast = english ? `${NAME} casts ${name}.` : `${NAME} 施放了 ${name}。`;
  169 |         const summon = english ? `${NAME} summons ${item.template === 'skeleton' ? 'Skeleton Warrior' : item.template === 'skeletal_mage' ? 'Skeletal Mage' : 'Revived Minion'}.` : `${NAME} 召唤了 ${item.template === 'skeleton' ? '骷髅战士' : item.template === 'skeletal_mage' ? '骷髅法师' : '复生仆从'}。`;
> 170 |         expect(batch?.logs.filter(line => line === cast)).toHaveLength(1);
      |                                                           ^ Error: expect(received).toHaveLength(expected)
  171 |         expect(batch?.logs.filter(line => line === summon)).toHaveLength(item.cap);
  172 |         expect(batch?.logs[0]).toBe(english ? 'Turn 1 begins' : '第 1 回合开始');
  173 |         await production(page);
  174 |       } finally { await observer.evaluate(handle => handle.disconnect()); await observer.dispose(); }
  175 |       await page.getByRole('button',{ name: english ? 'Flee' : '逃跑',exact: true }).click();
  176 |       const panel = await detail(page,NODE), metrics = [];
  177 |       await expect(panel).toContainText(descriptionText);
  178 |       for (const [width,height] of sizes) {
  179 |         await page.setViewportSize({ width,height }); const controls = [];
  180 |         for (const target of [page.getByTestId(`skill-node-${NODE}`),panel.getByRole('button')]) {
  181 |           await target.scrollIntoViewIfNeeded(); const bounds = await target.boundingBox(); expect(bounds).not.toBeNull();
  182 |           expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  183 |           controls.push({ bounds,hits: await hitGrid(target) });
  184 |         }
  185 |         const description = panel.getByText(descriptionText,{ exact: true });
  186 |         await description.scrollIntoViewIfNeeded(); await expect(description).toBeVisible();
  187 |         const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  188 |         expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14); await production(page);
  189 |         const headingHits = await hitGrid(panel.getByRole('heading',{ name: name,exact: true }));
  190 |         if (!english && width === 360) {
  191 |           const cdp = await context.newCDPSession(page);
  192 |           try {
  193 |             await cdp.send('DOM.enable'); await cdp.send('CSS.enable'); const doc = await cdp.send('DOM.getDocument');
  194 |             const node = await cdp.send('DOM.querySelector',{ nodeId: doc.root.nodeId,
  195 |               selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  196 |             const fonts = await cdp.send('CSS.getPlatformFontsForNode',{ nodeId: node.nodeId });
  197 |             await attach(info,'05-actual-Chinese-fonts',fonts);
  198 |             expect(fonts.fonts.some(f => f.familyName === 'Noto Sans CJK SC' && f.glyphCount > 0)).toBe(true);
  199 |           } finally { await cdp.detach(); }
  200 |         }
  201 |         if (width === 360 || width === 1280) await info.attach(`detail-${String(width)}x${String(height)}`,{ body: await page.screenshot(),contentType: 'image/png' });
  202 |         metrics.push({ width,height,font,controls,headingHits });
  203 |       }
  204 |       await attach(info,'05-finite-layout-metrics',metrics); await page.setViewportSize({ width: 1280,height: 800 });
  205 |       const saved = await backup(page);
  206 |       expect(saved.player).toEqual({ ...prepared.player,skillPoints: 0,skillLevels: { ...prepared.player.skillLevels, [SKILL]: 2 },comboOrder: [NODE] });
  207 |       await page.getByRole('button',{ name: english ? 'Save' : '保存',exact: true }).click();
  208 |       await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  209 |       await page.close(); page = await context.newPage(); watch(page); await page.clock.setFixedTime(fixedTime);
  210 |       await page.goto('/'); await page.getByTestId('home-continue').click(); await expect(page.getByTestId('town-screen')).toBeVisible();
  211 |       const loaded = await backup(page); expect(loaded).toEqual(saved);
  212 |       await attach(info,'06-explicit-save-close-newpage-continue',{ saved,loaded });
  213 |       await expect(await detail(page,NODE)).toContainText(descriptionText);
  214 |       await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  215 |       await expect(page.getByRole('combobox',{ name: english ? 'Slot 1' : '槽位 1',exact: true })).toHaveValue(NODE);
  216 |       await attach(info,'07-console-errors',errors); expect(errors).toEqual([]); await production(page);
  217 |     } finally { await page.close(); }
  218 |   });
  219 | }
  220 | 
  221 | 
  222 | for (const locale of ['en','zh-CN'] as const) {
  223 |   test(`Mastery20 corrects rank6/7 production details with Revive excluded ${locale}`, async ({page},info) => {
  224 |     const english = locale === 'en', errors: string[] = [];
  225 |     page.on('pageerror', error => errors.push(error.message));
  226 |     page.on('console', message => {
  227 |       if (['warning','error'].includes(message.type())) errors.push(`${message.type()}: ${message.text()}`);
  228 |     });
  229 |     await page.goto('/'); await createCharacter(page,{ class: 'necromancer',name: 'Mastery Correction' });
  230 |     await navTo(page,'settings');
  231 |     await page.getByRole('button',{ name: english ? 'English' : '简体中文',exact: true }).click();
  232 |     const fresh = await backup(page);
  233 |     const scaffold: SaveCurrent = { ...fresh,player: { ...fresh.player,level: 30,skillPoints: 0,comboOrder: [],
  234 |       skillLevels: { 'necromancer.raise_skeleton': 6,'necromancer.raise_skeletal_mage': 6,
  235 |         'necromancer.revive': 6,'necromancer.skeleton_mastery': 20 } } };
  236 |     const label = english ? 'Import Save' : '导入存档';
  237 |     await page.getByRole('button',{ name: label,exact: true }).click();
  238 |     const dialog = page.getByRole('dialog'); await dialog.getByRole('textbox').fill(JSON.stringify(scaffold));
  239 |     await dialog.getByRole('button',{ name: label,exact: true }).click(); await expect(dialog).toHaveCount(0);
  240 |     const rows = [];
  241 |     for (const item of [
  242 |       { slug: 'raise-skeleton',current: ['291.6','49','22.8'],next: ['309.6(+18)','51.8(+2.8)','24(+1.2)'] },
  243 |       { slug: 'raise-skeletal-mage',current: ['221.4','63','12'],next: ['234(+12.6)','67.2(+4.2)','12'] },
  244 |       { slug: 'revive',current: ['210','38','23'],next: ['222(+12)','40(+2)','24(+1)'] }
  245 |     ]) {
  246 |       const panel = await detail(page,`skills-necromancer-${item.slug}`), values = [];
  247 |       for (const [index,title] of (english ? ['Current','Next Level'] : ['当前','下一级']).entries()) {
  248 |         const stats = section(panel,page,title), actual = [];
  249 |         for (const stat of english ? ['Life','Attack','Defense'] : ['生命','攻击','防御']) {
  250 |           actual.push(await stats.getByText(stat,{ exact: true }).locator('+ dd').textContent());
  251 |         }
  252 |         expect(actual).toEqual(index === 0 ? item.current : item.next); values.push(actual);
  253 |       }
  254 |       rows.push({ slug: item.slug,actual: values });
  255 |       if (item.slug === 'raise-skeleton') for (const [width,height] of [[360,640],[1280,800]]) {
  256 |         if (!width || !height) throw new Error('Missing display evidence viewport');
  257 |         await page.setViewportSize({ width,height }); await panel.scrollIntoViewIfNeeded();
  258 |         await info.attach(`corrected-detail-${String(width)}x${String(height)}`,{ body: await page.screenshot(),contentType: 'image/png' });
  259 |       }
  260 |       await production(page);
  261 |     }
  262 |     expect(errors).toEqual([]);
  263 |     await attach(info,'Mastery20-corrected-production-literals',{ locale,importedScaffold: true,rows,errors });
  264 |   });
  265 | }
  266 | 
```