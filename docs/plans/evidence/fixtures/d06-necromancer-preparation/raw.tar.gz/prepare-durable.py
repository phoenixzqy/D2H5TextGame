from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, io, json, stat, subprocess, tarfile
R=Path(__file__).resolve().parent
ns={'__name__':'archive_helpers'}
exec(compile((R/'cleanup-durable.py').read_text(),str(R/'cleanup-durable.py'),'exec'),ns)
W=ns['W']; digest=ns['digest']; inventory=ns['inventory']; audit=ns['audit']
assert Path.cwd()==W
fixture=W/'docs/plans/evidence/fixtures/d06-necromancer-preparation'
assert not fixture.exists()
expected_dirty={'docs/plans/execution-ledger.md','production/bugs/BUG-073-summon-mastery-detail.md','docs/plans/evidence/d06-necromancer-preparation.md'}
actual_dirty={x[3:] for x in subprocess.check_output(['git','status','--porcelain','-uall'],text=True).splitlines()}
assert actual_dirty==expected_dirty,actual_dirty
process=audit()
absent=[str(W/'dist')]+[str(R/n) for n in ('runtime-build','mastery-foundation-build','fontconfig-cache','browser-tmp')]
for n in absent: assert not Path(n).exists() and not Path(n).is_symlink(),n
registry=json.loads((R/'ownership.json').read_text())
registered=set(registry['artifacts'])
allowed_dirs={Path(v['path']).name for v in registry['disposableDirectories'] if Path(v['path']).parent==R}
for q in R.iterdir():
 assert not q.is_symlink(),q
 assert (q.is_file() and q.name in registered) or (q.is_dir() and q.name in allowed_dirs),q
files,dirs=inventory(R)
names=set(subprocess.check_output(['git','diff','--no-renames','--diff-filter=ACMRT','--name-only','db861b0..HEAD'],text=True).splitlines())
names|=expected_dirty|{'docs/plans/decisions/D06-summon-corpses-v1.md','docs/plans/decisions/D06-summon-preparation-v1.md','docs/design/skills-spec.md'}
sources={}
for n in sorted(names):
 q=W/n;assert q.is_file() and not q.is_symlink(),n
 sources[n]=digest(q.read_bytes())
fixture.mkdir()
archive=fixture/'raw.tar.gz'
with archive.open('xb') as output:
 with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for name,v in files.items():
    n=PurePosixPath(name);assert str(n)==name and not n.is_absolute() and '..' not in n.parts
    b=(R/name).read_bytes();assert digest(b)==v
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;info.mtime=0
    tf.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(files) and len({m.name for m in members})==len(files)
 for m in members:
  assert m.isfile() and m.name in files
  b=tf.extractfile(m).read();assert m.size==len(b) and digest(b)==files[m.name] and b==(R/m.name).read_bytes()
assert inventory(R)==(files,dirs)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
p={'task':'D06 v1c Necromancer prepared retinues, BUG072 cooldown initialization and BUG073 display',
'sourceHead':head,'sourceCommits':subprocess.check_output(['git','log','--reverse','--format=%H','db861b0..HEAD'],text=True).splitlines(),
'rawRoot':str(R),'owner':'root','createdUtc':ns['stamp'](),
'archive':{'path':'raw.tar.gz',**digest(archive.read_bytes()),'files':len(files),'originalBytes':sum(v['bytes'] for v in files.values()),'roundtripVerified':True},
'rawManifest':files,'rawDirectories':dirs,
'finalClosureVerification':{'files':sources,'note':'Current final source/document bytes before archive/closure commit. Original per-step freezes remain historical and are not relabeled as current.'},
'processAudit':process,'disposableOutputsAbsent':absent,
'validation':{'runtime':{'focused':212,'engine':3101,'full':5981,'fullFiles':209,'fullSeconds':95.44,'typesSeconds':13.517,'lintSeconds':35.211,'buildSeconds':9.680},
'foundation':{'focused':355,'engine':3141,'full':6021,'fullFiles':209,'fullSeconds':94.36,'typesSeconds':13.460,'lintSeconds':35.286,'buildSeconds':9.537},
'screen':{'focused':104,'full':6031,'fullFiles':209,'fullSeconds':94.26,'typesSeconds':13.321,'lintSeconds':34.144,'buildSeconds':9.567},
'browser':{'necromancerPassed':8,'necromancerReportSeconds':75.421,'necromancerWrapperSeconds':76.385,'unchangedRavenPassed':2,'ravenReportSeconds':24.024,'ravenWrapperSeconds':25.210,'typesSeconds':14.148,'lintSeconds':38.069,'originalPngsViewedByRoot':20,'layoutsPerNativeFlow':9,'retries':0,'errors':[],'sourceBasis':'Exact same accepted screen production build and app/unit bytes. No rebuild/full-unit rerun for browser-only increment.'}},
'provenanceLimits':[
'Foundation RED original-test snapshot was reconstructed later by inverse of two fixture corrections; not captured at RED execution. Actual corrected UI RED snapshot captured and identical to GREEN.',
'Initial browser failure was a native maxlength16 fixture name; original 19-character name/source/config/report/error context retained. Correct startup itself observed. Narrow QA-approved short names and exported-name guard preserve numerical oracles.',
'Original reproduction default-font tofu and task-only CJK cache recovery are retained; installed fonts/shared caches/CSS unchanged.',
'Historical command wrappers lack startTicks/all-descendant observations; current absent-PID and consumer checks are not comprehensive historical birth telemetry.',
'Original failures, failed full/type attempts, controls and corrections remain distinct; no all-passing-history claim.'],
'visualLimits':['All20 original PNGs viewed by root; incomplete mobile numeric framing, exact DOM assertions separately cover values.','Navigation pictograph boxes observed in this Linux environment, including unchanged Raven; cross-platform cause/impact unproven.','Finite Chromium layouts/CJK checks do not establish all-glyph/platform/native-touch/a11y acceptance.'],
'scope':'Bounded three-skill preparation, shared cooldown correction, Mastery display and truthful bilingual copy/browser/save. Imported scaffolds are not earned progression/balance. FullD06/P09/P10, other corpse consumers, selected-itemIron, Mage elemental identity, private-v1/C0-C4/G0-G7 remain open. Engine3s/full15s and existing build warnings remain unresolved.',
'preserved':'Lossless all remaining RAW files: original RED/failing/successful logs and command metadata, source snapshots and parks, reports with base64 attachments, decoded original PNGs, error contexts, reviews, inventories, scripts, ownership and verified output-cleanup receipts. Original v1b packet untouched.',
'rawCleanup':{'status':'pending','owner':'root','requires':'Independent reviewed five-path archive/closure commit, readers released, guarded committed packet/archive and exact live/member/source/process/port/output/original checks. Exact files/empty children only; retain empty RAW root and shared parents/fonts/tools/source/history.'},
'independentDurableReview':{'verdict':'pending'},'independentDesignReview':{'verdict':'pending'}}
(fixture/'packet.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':p['archive'],'rawDirectories':len(dirs),'sources':len(sources),'commandPidsAbsent':process['uniqueCommandPids']}))
