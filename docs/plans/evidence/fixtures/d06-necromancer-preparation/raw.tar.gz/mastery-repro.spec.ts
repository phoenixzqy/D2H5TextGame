import { test, expect } from "/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs";
import { readFile } from 'node:fs/promises';
import { createCharacter, navTo } from "/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/tests/e2e/_helpers.ts";
import type { SaveCurrent } from "/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/types/save.ts";
for (const locale of ['en','zh-CN'] as const) {
 test(`reproduce missing Mastery-derived summon detail ${locale}`, async ({page}, info) => {
  const errors:string[]=[];
  page.on('pageerror', e=>errors.push(e.message));
  page.on('console',m=>{if(['error','warning'].includes(m.type())) errors.push(m.text());});
  await page.goto('/'); await page.waitForLoadState('networkidle');
  await createCharacter(page,{class:'necromancer',name:'Mastery Detail'});
  await navTo(page,'settings'); await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
  const pending=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const download=await pending;
  let fresh:SaveCurrent;
  try{fresh=JSON.parse(await readFile(await download.path(),'utf8')) as SaveCurrent;}finally{await download.delete();}
  const imported:SaveCurrent={...fresh,player:{...fresh.player,level:30,skillPoints:0,comboOrder:[],skillLevels:{
   'necromancer.raise_skeleton':6,'necromancer.raise_skeletal_mage':6,'necromancer.revive':6,'necromancer.skeleton_mastery':20
  }}};
  const label=locale==='en'?'Import Save':'导入存档';await page.getByRole('button',{name:label,exact:true}).click();
  const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(imported));
  await dialog.getByRole('button',{name:label,exact:true}).click();await expect(dialog).toHaveCount(0);
  await navTo(page,'skills');await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  const rows=[];
  for(const item of [
   {slug:'raise-skeleton',base:[162,35,19],next:[172,37,20],expected:[291.6,49,22.8],expectedNext:[309.6,51.8,24]},
   {slug:'raise-skeletal-mage',base:[123,45,10],next:[130,48,10],expected:[221.4,63,12],expectedNext:[234,67.2,12]},
   {slug:'revive',base:[210,38,23],next:[222,40,24],expected:[210,38,23],expectedNext:[222,40,24]}
  ]){
   await page.getByTestId(`skill-node-skills-necromancer-${item.slug}`).click();await page.mouse.move(1,1);
   const panel=page.getByTestId('skill-detail-panel');
   const values=[];
   for(const title of locale==='en'?['Current','Next Level']:['当前','下一级']){
    const section=panel.locator('section').filter({has:page.getByRole('heading',{name:title,exact:true})});
    const numbers=[];
    for(const stat of locale==='en'?['Life','Attack','Defense']:['生命','攻击','防御']){
     const value=await section.getByText(stat,{exact:true}).locator('+ dd').evaluate(node=>node.childNodes[0]?.textContent??'');
     numbers.push(Number(value));
    }values.push(numbers);
   }
   expect(values).toEqual([item.base,item.next]);
   if(item.slug!=='revive')expect(values).not.toEqual([item.expected,item.expectedNext]);
   rows.push({slug:item.slug,actual:values,required:[item.expected,item.expectedNext]});
   if(item.slug==='raise-skeleton'){
    if(locale==='zh-CN'){
     const cdp=await page.context().newCDPSession(page);
     try{
      await cdp.send('DOM.enable');await cdp.send('CSS.enable');const doc=await cdp.send('DOM.getDocument');
      const node=await cdp.send('DOM.querySelector',{nodeId:doc.root.nodeId,selector:'[data-testid="skill-detail-panel"] #skill-detail-panel > p'});
      const fonts=await cdp.send('CSS.getPlatformFontsForNode',{nodeId:node.nodeId});
      await info.attach('actual-Chinese-fonts',{body:JSON.stringify(fonts),contentType:'application/json'});
      expect(fonts.fonts.some(f=>f.familyName==='Noto Sans CJK SC'&&f.glyphCount>0)).toBe(true);
     }finally{await cdp.detach();}
    }
    await panel.scrollIntoViewIfNeeded();await info.attach('actual-unempowered-skeleton-detail',{body:await page.screenshot(),contentType:'image/png'});}
  }
  expect(await page.evaluate(()=>'__GAME__' in window)).toBe(false);
  expect(errors).toEqual([]);
  await info.attach('reproduction',{body:JSON.stringify({locale,viewport:{width:360,height:640},importedScaffold:true,rows,errors},null,2),contentType:'application/json'});
 });
}
