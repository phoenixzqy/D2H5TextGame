from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, socket, stat, subprocess, sys, tarfile
W = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
R = Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-necromancer-preparation-edsqysz8')
P = W / 'docs/plans/evidence/fixtures/d06-necromancer-preparation/packet.json'
ORIGINAL = Path('/home/felixzhao/workspace/D2H5TextGame')
assert Path.cwd() == W and R.is_dir() and not R.is_symlink()
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b): return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def inventory(root):
    assert root.resolve() == root and root.is_dir() and not root.is_symlink(), root
    files, dirs = {}, []
    for q in sorted(root.rglob('*')):
        mode = q.lstat().st_mode
        assert not stat.S_ISLNK(mode), q
        name = str(q.relative_to(root))
        if stat.S_ISREG(mode): files[name] = digest(q.read_bytes())
        elif stat.S_ISDIR(mode): dirs.append(name)
        else: raise RuntimeError('Unexpected file type: ' + str(q))
    return files, dirs

def audit():
    records = []
    def visit(v, path):
        if isinstance(v, dict):
            if isinstance(v.get('pid'), int) and isinstance(v.get('argv'), list):
                records.append({'record': path, 'pid': v['pid'], 'startUtc': v.get('startUtc')})
            for x in v.values(): visit(x, path)
        elif isinstance(v, list):
            for x in v: visit(x, path)
    for q in sorted(R.glob('*.json')): visit(json.loads(q.read_text()), q.name)
    pids = sorted({v['pid'] for v in records})
    assert pids
    for pid in pids: assert not Path('/proc', str(pid)).exists(), ('Observed PID occupied; no historical birth identity inferred', pid)
    consumers = []
    for q in Path('/proc').iterdir():
        if not q.name.isdigit(): continue
        try:
            exe = Path(os.readlink(q/'exe')).name
            comm = (q/'comm').read_text().strip().lower()
            if not any(s in exe.lower() or s in comm for s in ('node', 'chrome', 'chromium', 'npm', 'playwright', 'vitest')): continue
            args = (q/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            cwd = Path(os.readlink(q/'cwd'))
            if cwd.is_relative_to(W) or cwd.is_relative_to(R) or str(W) in args or str(R) in args:
                consumers.append({'pid': int(q.name), 'executable': exe, 'cwd': str(cwd)})
        except (FileNotFoundError, ProcessLookupError, PermissionError): continue
    assert not consumers, consumers
    for port in (4375, 4376):
        with socket.socket() as s:
            s.settimeout(0.25)
            assert s.connect_ex(('127.0.0.1', port)) != 0, port
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ORIGINAL, text=True) == ''
    return {'verifiedUtc': stamp(), 'records': records, 'uniqueCommandPids': len(pids),
            'remainingObservedPids': [], 'remainingTaskNodeChromiumConsumers': [], 'closedPorts': [4375,4376],
            'limitation': 'Original wrappers record PID/startUtc, not historical startTicks or all descendant births. Every observed PID is absent including zombies; no reused identity was inferred. Live executable/cwd/argv scan is a current-state consumer check.'}

def remove_exact(root, files, dirs):
    assert inventory(root) == (files, dirs), root
    for name in sorted(files): (root/name).unlink()
    for name in sorted(dirs, key=lambda n: (len(Path(n).parts), n), reverse=True): (root/name).rmdir()
    assert root.is_dir() and not list(root.iterdir()), root

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == '--outputs':
        target = R/'disposable-cleanup-receipt.json'
        assert not target.exists()
        process = audit()
        registry = json.loads((R/'ownership.json').read_text())
        allowed = {Path(v['path']) for v in registry['disposableDirectories'] if v['initiallyAbsent']}
        roots = [W/'dist', R/'fontconfig-cache', R/'browser-tmp']
        staged = []
        for root in roots:
            assert root in allowed
            files, dirs = inventory(root)
            if root == W/'dist':
                accepted = json.loads((R/'mastery-ui-dist-inventory.json').read_text())
                assert accepted['root'] == str(root) and files == accepted['files']
            staged.append({'root': str(root), 'files': files, 'directories': dirs})
        for entry in staged:
            root = Path(entry['root'])
            remove_exact(root, entry['files'], entry['directories'])
            root.rmdir()
            assert not root.exists() and not root.is_symlink()
        for name in ('runtime-build', 'mastery-foundation-build'):
            assert not (R/name).exists() and not (R/name).is_symlink()
        receipt = {'status': 'complete', 'owner': 'root', 'verifiedUtc': stamp(), 'processAudit': process,
                   'removedOutputs': staged, 'remainingPaths': [], 'failures': [],
                   'retained': 'RAW evidence, browser outputs/original PNGs, inventories, empty shared parents, installed fonts/tools/dependencies and source/history'}
        target.write_text(json.dumps(receipt, indent=2)+'\n')
        print(json.dumps({'status': 'complete', 'removedRoots': [x['root'] for x in staged],
                          'files': sum(len(x['files']) for x in staged), 'bytes': sum(v['bytes'] for x in staged for v in x['files'].values()),
                          'commandPidsAbsent': process['uniqueCommandPids']}))
    elif mode in ('--raw', '--verify-raw'):
        assert subprocess.check_output(['git','status','--porcelain'],text=True) == ''
        head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
        packet = json.loads(P.read_text())
        assert packet['rawRoot'] == str(R) and packet['rawCleanup']['status'] == 'pending'
        assert packet['independentDurableReview']['verdict'] == 'APPROVE'
        assert packet['independentDesignReview']['verdict'] == 'APPROVE'
        archive = P.parent/packet['archive']['path']
        for q in (P, archive):
            assert subprocess.check_output(['git','show',head+':'+str(q.relative_to(W))]) == q.read_bytes()
        assert digest(archive.read_bytes()) == {k: packet['archive'][k] for k in ('bytes','sha256')}
        for name, value in packet['finalClosureVerification']['files'].items():
            q = W/name
            assert q.is_file() and not q.is_symlink() and digest(q.read_bytes()) == value, name
        process = audit()
        for name in packet['disposableOutputsAbsent']:
            q = Path(name); assert not q.exists() and not q.is_symlink(), q
        files, dirs = inventory(R)
        assert files == packet['rawManifest'] and dirs == packet['rawDirectories']
        with tarfile.open(archive, 'r:gz') as tf:
            members = tf.getmembers()
            assert len(members) == len(files) and len({m.name for m in members}) == len(members)
            for member in members:
                name = PurePosixPath(member.name)
                assert member.isfile() and str(name) == member.name and not name.is_absolute() and '..' not in name.parts
                assert member.name in files
                b = tf.extractfile(member).read()
                assert member.size == len(b) and digest(b) == files[member.name] and b == (R/member.name).read_bytes()
        if mode == '--verify-raw': print('All committed-archive and exact RAW guards passed; no deletion.'); sys.exit(0)
        failures = []
        try: remove_exact(R, files, dirs)
        except Exception as exc: failures.append(repr(exc))
        remaining, remaining_dirs = inventory(R)
        packet['rawCleanup'] = {'status': 'complete' if not failures and not remaining and not remaining_dirs else 'incomplete',
            'owner': 'root', 'archiveCommit': head, 'verifiedUtc': stamp(), 'processAudit': process,
            'removedFiles': len(files)-len(remaining), 'removedBytes': sum(v['bytes'] for n,v in files.items() if n not in remaining),
            'removedEmptyChildDirectories': len(dirs)-len(remaining_dirs), 'remainingPaths': sorted(remaining)+remaining_dirs,
            'retainedEmptyRoot': str(R), 'failures': failures,
            'guards': 'Committed packet/archive, all archive/live bytes and exact sets, all current fingerprints, absent observed PIDs/task consumers/ports/outputs, clean original checkout, readers released'}
        P.write_text(json.dumps(packet, ensure_ascii=False, indent=2)+'\n')
        print(json.dumps(packet['rawCleanup']))
        assert packet['rawCleanup']['status'] == 'complete'
    else: raise RuntimeError(mode)
