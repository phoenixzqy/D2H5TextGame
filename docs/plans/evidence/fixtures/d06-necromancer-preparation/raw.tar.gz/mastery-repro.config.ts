import { defineConfig } from "/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test/index.mjs";
export default defineConfig({
 testDir: "/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-necromancer-preparation-edsqysz8", testMatch: 'mastery-repro.spec.ts', workers: 1, retries: 0,
 timeout: 45000, outputDir: "/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-necromancer-preparation-edsqysz8/mastery-repro-output",
 reporter: [['line'], ['json', { outputFile: "/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-necromancer-preparation-edsqysz8/mastery-repro-report.json" }]],
 use: { baseURL: 'http://127.0.0.1:4374', viewport: {width:360,height:640}, trace:'off', video:'off', screenshot:'only-on-failure' },
 webServer: { cwd:"/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2", command:"node_modules/.bin/vite preview --outDir /home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-necromancer-preparation-edsqysz8/runtime-build --port 4374 --host 127.0.0.1 --strictPort", url:'http://127.0.0.1:4374', reuseExistingServer:false, timeout:20000 }
});
