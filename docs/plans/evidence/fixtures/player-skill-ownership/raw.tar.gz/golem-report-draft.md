# D05 — Reconcile the historical Golem Mastery record

This corrects one stale `unverified` inventory entry. No new runtime implementation or new earned skill acceptance is claimed. The historical implementation already applies the JSON-authored Golem Mastery life and flat Attack Speed bonuses to fresh owner-bound Clay/Blood/Iron/Fire Golems after rank and Iron item scaling; inherited preloads are not decorated again. Exact allocation aliases/MAX/cap, actual Necromancer/unlock/Clay prerequisite, copied immutable tuning and resource/original-input replay boundaries remain. Runtime/native/display/Skills/Iron presentation are integrated at current head.

| Historical implementation | Scope |
| --- | --- |
|44376bc|Pure engine definition/projection and fresh golem empowerment|
|d542275|Native current-wave/next-wave/replay/import integration|
|2f3f5bc|Current/next summon preview arithmetic|
|a615431|Bilingual Skills values/allocation/eligibility|
|1760c4d|Iron Golem item-adjusted preview integration|

A targeted hash audit verifies all five implementation commits are ancestors, every publication scope matches its committed bytes, and all five review-manifest/support-manifest hashes are intact.899 support-file entries and58 command receipts/output hashes match retained originals. Historical source and QA/test-evidence/TD/five-axis approvals remain historical; all review readers had released and each cleanup receipt has remaining[]/failures[]. The audit does not promote those approvals to independent acceptance of today's integrated head.

Current source review: `golem-mastery.ts` differs from its display implementation only by the separately reviewed shared schema-validator refactor. Its engine tests and Skills tests remain byte-identical to the corresponding published implementations. The native tests add the existing synthetic-entry-pools fixture. The current source still captures the Player projection per wave and sends it through fresh preparation/corpse/Iron creation, and current Skills/Iron previews consume the same arithmetic. Current full-suite results and exact source hashes are supplied by the accompanying ownership batch evidence; no new test run is needed for this documentation-only correction.

The original raw root remains `/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-iron-golem-bc3r0les`, owned by root for the ongoing umbrella goal. It contains source/failure/review evidence still needed by full-v1 consumers; root will retain/archive then remove exact originals once those consumers finish. This correction neither removes that evidence nor reruns historical browser fixtures. Browser labels golem-skills-browser2/browser3 and golem-iron-browser2 are imported functional proof, not earned acquisition or viable builds.

Only `necromancer.golem_mastery` changes to `bounded-functional;independent-acceptance-open`.213 identities/order remain, with153 unverified/58 bounded-functional/one bounded-engine-functional/one review-needed. Differing evidence scopes remain explicit. Genuine Ancients401 save and L33/nextNormal402 state remain unchanged; Baal, all-class builds, economy/pacing/endgame/PWA/performance and independent C2-C4/fullG0-G7/private-v1 acceptance remain open.
