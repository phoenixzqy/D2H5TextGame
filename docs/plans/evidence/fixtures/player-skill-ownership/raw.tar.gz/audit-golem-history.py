from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent
history=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-iron-golem-bc3r0les')
impl={'engine':'44376bc','native':'d542275','display':'2f3f5bc','skills':'a615431','iron':'1760c4d'}
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
for part,commit in impl.items():
 p=history/f'golem-{part}-publication.json';pub=json.loads(p.read_text())
 review=history/pub['reviewManifest'];assert sha(review.read_bytes())==pub['reviewManifestSha256']
 sup=Path(pub['support']['path']);assert sha(sup.read_bytes())==pub['support']['sha256']
 support=json.loads(sup.read_text())
 for file in support['files']:
  path=history/file['path'];assert path.resolve().is_relative_to(history.resolve())
  raw=path.read_bytes();assert len(raw)==file['bytes'] and sha(raw)==file['sha256'],(part,file['path'])
 commands=[]
 for command in pub['commands']:
  p=Path(command['receipt']);raw=p.read_bytes();d=json.loads(raw)
  assert sha(raw)==command['receiptSha256']
  assert d['exitCode']==command['exitCode']
  output=(p.parent/'output.log').read_bytes()
  assert sha(output)==command['outputSha256']==d['outputSha256']
  commands.append({'label':command['label'],'receiptSha256':sha(raw),'outputSha256':sha(output),'exitCode':d['exitCode']})
 scopes=[]
 for file in pub['scope']:
  raw=subprocess.check_output(['git','show',commit+':'+file['path']]);assert sha(raw)==file['sha256']
  scopes.append({'path':file['path'],'historicalSha256':file['sha256'],'committedExact':True,'currentSha256':sha(Path(file['path']).read_bytes())})
 assert subprocess.run(['git','merge-base','--is-ancestor',commit,'HEAD']).returncode==0
 cleanup=json.loads((history/f'golem-{part}-cleanup.json').read_text())
 assert cleanup['remaining']==[] and cleanup['failures']==[]
 assert pub['reviewReadersReleased']
 checks.append({'part':part,'implementation':commit,'scope':scopes,'supportFilesVerified':len(support['files']),'commands':commands,'historicalReviews':pub['reviews'],'readersReleased':True,'cleanupEmpty':True,'publicationSha256':sha((history/f'golem-{part}-publication.json').read_bytes()),'reviewManifestSha256':pub['reviewManifestSha256'],'supportManifestSha256':pub['support']['sha256']})
result={'pass':True,'historicalOnly':True,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'historyRoot':str(history),'parts':checks,'currentDiffReview':['Golem Mastery module differs from its display implementation only by the reviewed shared skill-validator refactor.','Native test adds the existing synthetic-entry-pools fixture.','Current combat/native/display/Skills/Iron consumers still use the same explicit source projection; current tests must pass separately.'],'acceptanceLimit':'Historical independent approvals are not current integrated independent acceptance. Synthetic imported eligibility is not earned build viability. No new implementation credit.'}
(root/'golem-history-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':True,'parts':len(checks),'supportFilesVerified':sum(r['supportFilesVerified'] for r in checks),'commandsVerified':sum(len(r['commands']) for r in checks)}))
