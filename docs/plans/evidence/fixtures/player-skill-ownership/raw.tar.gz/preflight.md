# Player class-skill ownership preflight

Previous goal turn: no progress toward implementation (requested status report); earlier committed and verified Shout/Orders; no remaining
task processes or scratch. Current65b6b85clean; exact existing human claim in_use
owned by session01a1577a-5af4-70e3-8699-50a906877d8f. Root sole writer/no agents;
original read-only; preserve branch/claim, no remote or genuine campaign actions.

Security check: pass. Scope is local deterministic class/allocation validation
before player combat projection. No dependency/network/credential/permission/save
version change. Restricting invalid class-skill casts, preserving item grants.

Root-cause plan: causal native RED first; shared fresh Player boundary validates
all known authored class actives, exact aliases/MAX/cap, finite integral unlock,
transitive prerequisites. Filter only combat configuration, never persisted
priorities/allocations or earned state. Preserve generic fixtures/non-class and
existing D10 equipped-source governance. Passive/aura priorities cannot cast.
Copy immutable JSON metadata; normalize selected eligible active rank once.
Standalone engine remains a deterministic trusted-snapshot API, not a security
authenticator for forged snapshots. No new action/damage/mana/RNG/save fields.

Plan-review pending causal evidence and native/UI/item/summon lifecycle consumers.
Validation: rank1/20 valid controls; every class/alias/invalid/missing/foreign/
prerequisite/unlock failure; original resources/replay/no income/import; existing
item and summon boundaries. Production public priority/learning Save/Continue,
full/types/lint/build and exact fingerprints before source/evidence commits.
Port4472. Track all disposable outputs under this root; shared caches preserved.

Plan review: ready after corrected causal RED21/two valid controls. Preserve the existing D06 direct-prerequisite validator unchanged, then filter ordinary actives with copied engine metadata; D10 stays downstream. Nonstandard registry aliases cannot bypass known class ownership. Native/UI/persistence consumers and item/summon regressions included. No delegated agents or remote actions.

Integration review refinement: CE/PE already enforce complete Player-derived source/rank/prerequisite ownership at engine selection/commit; preserve their accepted priority metadata and specialized validators rather than duplicating the authority. Their existing negative tests prove no unauthorized cast. D06 direct summon semantics remain unchanged. Two old native fixtures need lawful Fire Ball unlock/Fire Bolt prerequisite and expected Firestorm canonical rank normalization. Browser Python package unavailable; use installed Playwright Node API, no installation or bridge; public UI interactions only, synthetic imports. Existing preview lifecycle scripts retain exact process receipts beyond the generic with_server helper.

Final review refinement: unknown registered class stubs were a second ownership route; native amazon.piercing_strike rank20 paid20MP on Amazon and Barbarian without an authored definition. Five causal RED /309 controls retained; namespace rejection yields314 focused GREEN, with non-class fixture path preserved. Final engine6585/224, lint/typecheck and explicit-false production build pass. No independent acceptance is inferred. Final browser/full/fingerprint review still required.

Final validation: full standard npm test12822/540 plus two existing skips,515.519s normal completion; source1257/build760/HEAD/Git/genuine exact before-after. Final production browser4/4, separate eight-pair five-domain audit20geometry/8individually inspected screenshots; final bridge4chunks/5patterns absent. All final gates pass; no new skips, weakened checks or unrelated source edits. Source commit 70be381240aed745897271964448d1dbb950ca3b has all1257 committed source blobs byte-equal to validated snapshot and working files. Root self-review only; independent whole-head/earned acceptance remains open.
