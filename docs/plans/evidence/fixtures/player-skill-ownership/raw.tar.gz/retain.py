from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent
out=Path('docs/plans/evidence/fixtures/player-skill-ownership')
assert json.loads((root/'owner.json').read_text())['baseline']=='65b6b85846d7c4f8b7535d3dc07918bcaf977417'
assert not out.exists(), 'Do not overwrite retained evidence'
processes=sorted(root.glob('*.process.json'))
for record in processes:
 label=record.name.removesuffix('.process.json')
 assert (root/(label+'.result.json')).is_file(),label
 pid=json.loads(record.read_text())['pid']
 proc=Path('/proc')/str(pid)/'cmdline'
 assert not proc.exists() or proc.read_bytes()==b'',(label,pid,'process still alive or PID reused; inspect before cleanup')
files=sorted(f for f in root.rglob('*') if f.is_file() and 'build-final' not in f.relative_to(root).parts)
assert not any(f.is_symlink() for f in root.rglob('*'))
out.mkdir()
archive=out/'raw.tar.gz'
entries=[]
with tarfile.open(archive,'w:gz') as tar:
 for f in files:
  relative=str(f.relative_to(root));content=f.read_bytes()
  entries.append({'path':relative,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'artifact':'raw.tar.gz','member':relative})
  tar.add(f,arcname=relative,recursive=False)
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for e in entries:
  data=tar.extractfile(e['member']).read()
  assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
manifest={'scratchRoot':str(root),'rawFiles':len(entries),'terminalProcessRecords':len(processes),'byteVerified':True,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
