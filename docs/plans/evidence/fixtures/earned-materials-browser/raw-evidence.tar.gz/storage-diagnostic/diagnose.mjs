import { chromium } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/playwright/index.mjs';
import { readFile, writeFile } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
const root = '/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-earned-materials-_gkzh9u6';
const out = root + '/storage-diagnostic';
const repo = '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const origin = 'http://127.0.0.1:4413';
const bytes = await readFile(root + '/earned-export.json.gz');
const raw = gunzipSync(bytes).toString('utf8');
const input = JSON.parse(raw);
assert.equal(createHash('sha256').update(bytes).digest('hex'), '1de7b2371224cd09d2b1baad532416bad2e4ac19f0719e2dcf64fec9c05c0c8c');
const server = spawn(process.execPath, [repo + '/node_modules/vite/bin/vite.js','preview','--outDir',root+'/dist','--port','4413','--host','127.0.0.1','--strictPort'], { cwd: repo, stdio: ['ignore','pipe','pipe'] });
let serverLog=''; server.stdout.on('data',b=>serverLog+=b);server.stderr.on('data',b=>serverLog+=b);
let browser;
const errors=[], marks=[];
const record=async(name,value)=>writeFile(out+'/'+name+'.json', JSON.stringify(value,null,2));
try {
 await record('ownership',{scriptPid:process.pid,serverPid:server.pid});
 const deadline=Date.now()+20000;
 while(Date.now()<deadline) { try { if((await fetch(origin)).ok)break; }catch{} await new Promise(r=>setTimeout(r,100)); }
 browser=await chromium.launch();
 const context=await browser.newContext({viewport:{width:360,height:640},permissions:['clipboard-read','clipboard-write']});
 const page=await context.newPage();
 page.on('pageerror',e=>errors.push(e.message)); page.on('console',m=>{if(['warning','error'].includes(m.type()))errors.push(m.text());});
 const nav=async route=>page.locator('a[href="/'+route+'"]').first().click();
 await page.goto(origin); await page.getByTestId('home-new-game').click(); await page.getByTestId('class-sorceress').click();
 await page.getByTestId('character-name-input').fill('Diagnostic only');await page.getByTestId('character-start-btn').click();
 await page.getByTestId('town-screen').waitFor();await nav('settings');
 await page.getByRole('button',{name:'导入存档',exact:true}).click();
 await page.evaluate(value=>navigator.clipboard.writeText(value),raw);
 const dialog=page.getByRole('dialog'),textbox=dialog.getByRole('textbox');
 await textbox.click();await textbox.press('ControlOrMeta+V'); assert.equal(await textbox.inputValue(),raw);
 await dialog.getByRole('button',{name:'导入存档',exact:true}).click();await dialog.waitFor({state:'hidden'});
 const pending=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const download=await pending;
 const exported=await readFile(await download.path(),'utf8');await download.saveAs(out+'/import-check-native.json');await download.delete();
 const actual=JSON.parse(exported);
 for(const key of ['version','player','inventory','map','mercs','formation'])assert.deepEqual(actual[key],input[key],key);
 const cdp=await context.newCDPSession(page);await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:10000});await cdp.send('Profiler.start');
 const start=performance.now();marks.push({phase:'before-inventory',at:start,url:page.url()});
 await nav('inventory'); marks.push({phase:'click-returned',elapsed:performance.now()-start,url:page.url()});
 // Passive diagnostic bound only: this does not pass the original 5s UI gate.
 let mountError;try {await page.getByTestId('materials-panel').waitFor({state:'visible',timeout:30000});}catch(e){mountError=String(e);}
 const profile=(await cdp.send('Profiler.stop')).profile;await record('profile',profile);
 await record('mount-observation',{mountError,elapsed:performance.now()-start,url:page.url(),inventory:await page.getByTestId('inventory-screen').count(),panels:await page.getByTestId('materials-panel').count(),rows:await page.getByTestId(/^material-/).count()});
 const state=await page.evaluate(()=>({url:location.href,inventory:document.querySelectorAll('[data-testid="inventory-screen"]').length,panels:document.querySelectorAll('[data-testid="materials-panel"]').length,rows:[...document.querySelectorAll('[data-testid^="material-"]')].map(n=>({id:n.getAttribute('data-testid'),text:n.textContent})),overflow:document.documentElement.scrollWidth-innerWidth}));
 marks.push({phase:'panel-visible',elapsed:performance.now()-start,...state});
 await page.screenshot({path:out+'/inventory.png',timeout:10000});
 assert.equal(state.rows.length,Object.keys(input.inventory.materials).length);
 await record('diagnosis',{inputGzipSha:createHash('sha256').update(bytes).digest('hex'),inputRawSha:createHash('sha256').update(raw).digest('hex'),marks,errors,acceptance:'diagnostic only; no combat, no new Save/Continue acceptance'});
} catch(e) { await record('failure',{error:String(e),marks,errors});process.exitCode=1; }
finally {if(browser)await browser.close();server.kill('SIGTERM');await new Promise(r=>{if(server.exitCode!==null)r();else server.once('exit',r);});await writeFile(out+'/server.log',serverLog);}
