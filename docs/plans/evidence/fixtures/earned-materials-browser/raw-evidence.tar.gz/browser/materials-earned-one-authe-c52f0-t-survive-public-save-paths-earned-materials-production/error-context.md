# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: materials-earned.spec.ts >> one authentic Catacombs challenge earns concrete materials that survive public save paths
- Location: tests/pwa/materials-earned.spec.ts:149:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByTestId('materials-panel').getByTestId(/^material-/)
Expected: 5
Received: 0
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByTestId('materials-panel').getByTestId(/^material-/)
    - locator resolved to 0 elements
    - unexpected value "0"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "Main navigation" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "Town" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: Town
      - listitem [ref=e10]:
        - link "Map" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: Map
      - listitem [ref=e14]:
        - link "Combat" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: Combat
      - listitem [ref=e18]:
        - link "Inventory" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: Inventory
      - listitem [ref=e22]:
        - link "Skills" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: Skills
      - listitem [ref=e26]:
        - link "Mercs" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: Mercs
      - listitem [ref=e30]:
        - link "Quests" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: Quests
      - listitem [ref=e34]:
        - link "Settings" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: Settings
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e40]: Settings
      - button "Earned Act I · Level 24. Open character sheet." [ref=e42] [cursor=pointer]:
        - generic [ref=e44]: "24"
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: Earned Act I
            - generic [ref=e48]: Level 24
          - generic [ref=e49]:
            - generic [ref=e50]: HP
            - progressbar "HP" [ref=e51]
          - generic [ref=e53]:
            - generic [ref=e54]: MP
            - progressbar "MP" [ref=e55]
          - generic [ref=e57]:
            - generic [ref=e58]: XP
            - progressbar "XP" [ref=e59]
    - main [ref=e61]:
      - generic [ref=e62]:
        - generic [ref=e63]:
          - heading "Language" [level=2] [ref=e64]
          - generic [ref=e65]:
            - button "简体中文" [ref=e66] [cursor=pointer]
            - button "English" [pressed] [ref=e67] [cursor=pointer]
        - generic [ref=e68]:
          - generic [ref=e69] [cursor=pointer]:
            - generic [ref=e70]:
              - generic [ref=e71]: Stealth Mode
              - generic [ref=e72]: Hide icons and colors for workplace discretion
            - checkbox "Stealth Mode" [ref=e73]
          - generic [ref=e75] [cursor=pointer]:
            - generic [ref=e77]: Sound
            - checkbox "Sound" [checked] [ref=e78]
          - generic [ref=e80] [cursor=pointer]:
            - generic [ref=e82]: Music
            - checkbox "Music" [checked] [ref=e83]
        - generic [ref=e84]:
          - heading "Save Management" [level=2] [ref=e85]
          - generic [ref=e86]:
            - button "Save" [ref=e87] [cursor=pointer]
            - button "Export Save" [active] [ref=e88] [cursor=pointer]
            - button "Import Save" [ref=e89] [cursor=pointer]
            - button "Delete Save" [ref=e90] [cursor=pointer]
        - generic [ref=e91]:
          - link "☕ Buy me a coffee" [ref=e92] [cursor=pointer]:
            - /url: https://www.buymeacoffee.com/
          - generic [ref=e93]: "Version: 0.1.0"
      - status [ref=e94]: Save exported
```

# Test source

```ts
  23  |   const pending = page.waitForEvent('download');
  24  |   await page.getByTestId('export-save-button').click();
  25  |   const download = await pending;
  26  |   try {
  27  |     const raw = await readFile(await download.path(), 'utf8');
  28  |     return { save: JSON.parse(raw) as SaveCurrent, raw };
  29  |   } finally { await download.delete(); }
  30  | }
  31  | 
  32  | async function importRaw(page: Page, raw: string, english: boolean): Promise<void> {
  33  |   const label = english ? 'Import Save' : '导入存档';
  34  |   await page.getByRole('button', { name: label, exact: true }).click();
  35  |   const dialog = page.getByRole('dialog'), textbox = dialog.getByRole('textbox');
  36  |   // BUG-111: multiline CDP insertText stalls; paste the exact native export.
  37  |   await page.context().grantPermissions(['clipboard-read', 'clipboard-write'], { origin: new URL(page.url()).origin });
  38  |   await page.evaluate(async value => navigator.clipboard.writeText(value), raw);
  39  |   await textbox.click();
  40  |   await textbox.press('ControlOrMeta+V');
  41  |   await expect(textbox).toHaveValue(raw);
  42  |   await dialog.getByRole('button', { name: label, exact: true }).click();
  43  |   await expect(dialog).toHaveCount(0);
  44  | }
  45  | 
  46  | /** Read only the application's non-sensitive single-player save; no storage writes. */
  47  | async function stored(page: Page): Promise<SaveCurrent> {
  48  |   return page.evaluate(() => new Promise<SaveCurrent>((resolve, reject) => {
  49  |     const open = indexedDB.open('D2H5TextGame');
  50  |     open.onerror = () => { reject(new Error('Cannot read game save database')); };
  51  |     open.onsuccess = () => {
  52  |       const db = open.result;
  53  |       const get = db.transaction('saves', 'readonly').objectStore('saves').get('current');
  54  |       get.onerror = () => { db.close(); reject(new Error('Cannot read game save record')); };
  55  |       get.onsuccess = () => {
  56  |         db.close();
  57  |         const row = get.result as { data: SaveCurrent } | undefined;
  58  |         if (!row) { reject(new Error('No game save record')); return; }
  59  |         resolve(JSON.parse(JSON.stringify(row.data, (_key, value: unknown) => {
  60  |           if (value instanceof Map) return [...(value as Map<unknown, unknown>).entries()];
  61  |           if (value instanceof Set) return [...(value as Set<unknown>).values()];
  62  |           return value;
  63  |         })) as SaveCurrent);
  64  |       };
  65  |     };
  66  |   }));
  67  | }
  68  | 
  69  | function owned(save: SaveCurrent | SaveV17): Map<string, Item> {
  70  |   const items = [...save.inventory.backpack, ...save.inventory.stash,
  71  |     ...Object.values(save.inventory.equipped),
  72  |     ...Object.values(save.mercs.mercEquipment).flatMap(equipment => Object.values(equipment))]
  73  |     .filter((item): item is Item => item !== null);
  74  |   const result = new Map(items.map(item => [item.id, item]));
  75  |   expect(result.size).toBe(items.length);
  76  |   return result;
  77  | }
  78  | 
  79  | function conserved(actual: SaveCurrent, expected: SaveCurrent): void {
  80  |   for (const field of ['version', 'player', 'inventory', 'mercs', 'map', 'formation'] as const) {
  81  |     expect(actual[field], field).toEqual(expected[field]);
  82  |   }
  83  |   expect(actual.meta.settings).toEqual(expected.meta.settings);
  84  |   expect(actual.meta.gachaState).toEqual(expected.meta.gachaState);
  85  |   // A real Continue samples real elapsed offline time. Only this separate bonus/time
  86  |   // metadata and timestamp may differ; it must never manufacture inventory rewards.
  87  |   expect(actual.meta.idleState.idleTarget).toEqual(expected.meta.idleState.idleTarget);
  88  | }
  89  | 
  90  | async function terminal(page: Page) {
  91  |   return page.evaluate(() => ({
  92  |     wave: document.querySelector('[data-testid="wave-counter"]')?.textContent,
  93  |     skipDisabled: document.querySelector<HTMLButtonElement>('[data-testid="skip-button"]')?.disabled,
  94  |     log: [...document.querySelectorAll('[data-testid="combat-log"] > div > span:last-child')].map(n => n.textContent),
  95  |     liveEnemies: document.querySelectorAll('[data-testid="enemies-grid"] [data-testid^="unit-card-"]:not([data-dead="true"])').length,
  96  |     hero: [...document.querySelectorAll('[data-testid^="unit-card-"]')]
  97  |       .filter(n => n.getAttribute('data-testid') === 'unit-card-player-1792497600000')
  98  |       .map(n => ({ dead: n.getAttribute('data-dead'), text: n.textContent })),
  99  |     defeat: document.querySelector('[data-testid="defeat-panel"]')?.textContent ?? null
  100 |   }));
  101 | }
  102 | 
  103 | async function setLocale(page: Page, locale: 'en' | 'zh-CN') {
  104 |   await navTo(page, 'settings');
  105 |   await page.getByRole('button', { name: locale === 'en' ? 'English' : '简体中文', exact: true }).click();
  106 | }
  107 | 
  108 | function materialName(translations: unknown, nameKey: string): string {
  109 |   let translated: unknown = translations;
  110 |   for (const key of nameKey.split('.').slice(1)) translated = (translated as Record<string, unknown>)[key];
  111 |   expect(typeof translated).toBe('string');
  112 |   return String(translated);
  113 | }
  114 | 
  115 | async function panelEvidence(page: Page, expected: SaveCurrent, label: string, assertClean: () => void): Promise<void> {
  116 |   const catalog = JSON.parse(await readFile('src/data/items/materials.json', 'utf8')) as { id: string; nameKey: string }[];
  117 |   for (const locale of ['en', 'zh-CN'] as const) {
  118 |     assertClean();
  119 |     await setLocale(page, locale);
  120 |     const translations: unknown = JSON.parse(await readFile(`src/i18n/locales/${locale}/items.json`, 'utf8'));
  121 |     await navTo(page, 'inventory');
  122 |     const panel = page.getByTestId('materials-panel');
> 123 |     await expect(panel.getByTestId(/^material-/)).toHaveCount(Object.keys(expected.inventory.materials).length);
      |                                                   ^ Error: expect(locator).toHaveCount(expected) failed
  124 |     for (const [id, quantity] of Object.entries(expected.inventory.materials)) {
  125 |       const definition = catalog.find(material => material.id === id);
  126 |       expect(definition).toBeDefined();
  127 |       const row = panel.getByTestId(`material-${id}`);
  128 |       await expect(row.locator(':scope > span').first()).toHaveText(materialName(translations, definition?.nameKey ?? ''));
  129 |       await expect(row.locator(':scope > span').last()).toHaveText(
  130 |         `${locale === 'en' ? 'Owned: ' : '持有：'}${new Intl.NumberFormat(locale).format(quantity)}`);
  131 |     }
  132 |     for (const [width, height] of [[360, 640], [1280, 800]]) {
  133 |       assertClean();
  134 |       await page.setViewportSize({ width: width ?? 360, height: height ?? 640 });
  135 |       await panel.scrollIntoViewIfNeeded();
  136 |       const geometry = await panel.evaluate(node => ({
  137 |         documentOverflow: document.documentElement.scrollWidth - innerWidth,
  138 |         rowsFit: [...node.querySelectorAll('li')].every(row => row.scrollWidth <= row.clientWidth),
  139 |         text: node.textContent
  140 |       }));
  141 |       expect(geometry.documentOverflow).toBeLessThanOrEqual(0);
  142 |       expect(geometry.rowsFit).toBe(true);
  143 |       await record(`${label}-${locale}-${String(width)}`, geometry);
  144 |       await page.screenshot({ path: join(root, `${label}-${locale}-${String(width)}.png`), fullPage: false });
  145 |     }
  146 |   }
  147 | }
  148 | 
  149 | test('one authentic Catacombs challenge earns concrete materials that survive public save paths', async ({ page, context }) => {
  150 |   expect(root).not.toBe('');
  151 |   const freeze = JSON.parse(await readFile(join(root, 'freeze.json'), 'utf8')) as {
  152 |     approved: boolean; files: { path: string; sha256: string }[];
  153 |   };
  154 |   expect(freeze.approved).toBe(true);
  155 |   expect(freeze.files.length).toBeGreaterThan(100);
  156 |   for (const file of freeze.files) expect(hash(await readFile(file.path)), file.path).toBe(file.sha256);
  157 |   const bytes = await readFile(input), raw = gunzipSync(bytes).toString('utf8');
  158 |   expect(hash(bytes)).toBe(gzipSha);
  159 |   expect(hash(Buffer.from(raw))).toBe(rawSha);
  160 |   const historical = JSON.parse(raw) as SaveV17;
  161 |   expect(historical.version).toBe(17);
  162 |   expect(historical.map.challengeOrdinals).toEqual({ normal: 252, nightmare: 0 });
  163 |   expect(owned(historical).size).toBe(5680);
  164 |   const errors: string[] = [], consoleErrors: string[] = [];
  165 |   context.on('page', next => {
  166 |     next.on('pageerror', error => errors.push(error.message));
  167 |     next.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') consoleErrors.push(message.text()); });
  168 |   });
  169 |   page.on('pageerror', error => errors.push(error.message));
  170 |   page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') consoleErrors.push(message.text()); });
  171 |   const assertClean = () => { expect(errors).toEqual([]); expect(consoleErrors).toEqual([]); };
  172 |   let latest: SaveCurrent | undefined;
  173 |   let active = page;
  174 |   try {
  175 |     await page.goto('/');
  176 |     await createCharacter(page, { class: 'sorceress', name: 'Import screen only' });
  177 |     await setLocale(page, 'zh-CN');
  178 |     await importRaw(page, raw, false);
  179 |     const baseline = (await backup(page)).save;
  180 |     await record('import-baseline', baseline);
  181 |     expect(baseline.version).toBe(18);
  182 |     expect(baseline.inventory).toEqual({ ...historical.inventory, materials: {} });
  183 |     for (const field of ['player', 'mercs', 'map', 'formation'] as const) expect(baseline[field]).toEqual(historical[field]);
  184 |     expect(baseline.meta.settings).toEqual(historical.meta.settings);
  185 |     expect(baseline.meta.gachaState).toEqual(historical.meta.gachaState);
  186 |     expect(baseline.meta.idleState.idleTarget).toEqual(historical.meta.idleState.idleTarget);
  187 |     expect(baseline.meta.idleState.activeMultiplier).toBe(1);
  188 |     expect(baseline.meta.idleState.multiplierSecondsRemaining).toBe(0);
  189 |     expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  190 |     await setLocale(page, 'en');
  191 |     const before = (await backup(page)).save;
  192 |     expect(before).toEqual({ ...baseline, timestamp: before.timestamp, meta: { ...baseline.meta, settings: { ...baseline.meta.settings, locale: 'en' }, idleState: before.meta.idleState } });
  193 |     expect(before.meta.idleState.activeMultiplier).toBe(1);
  194 |     expect(before.meta.idleState.multiplierSecondsRemaining).toBe(0);
  195 |     expect(before.meta.idleState.idleTarget).toEqual(baseline.meta.idleState.idleTarget);
  196 |     await record('before-challenge', before);
  197 |     latest = before;
  198 |     assertClean();
  199 |     // Atomic exclusive marker makes a second invocation at this root refuse BEFORE Enter.
  200 |     await writeFile(join(root, 'challenge-start.json'), JSON.stringify({ at: new Date().toISOString(), ordinal: 252, area: 'a1-catacombs' }), { flag: 'wx' });
  201 |     await navTo(page, 'map');
  202 |     const act = page.getByRole('button', { name: /^Act 1 ·/ });
  203 |     if (await act.getAttribute('aria-expanded') !== 'true') await act.click();
  204 |     assertClean();
  205 |     await page.getByTestId('sub-area-row-a1-catacombs').getByRole('button', { name: 'Enter', exact: true }).click();
  206 |     await expect(page.getByTestId('combat-screen')).toBeVisible();
  207 |     const waveResults = [];
  208 |     for (let wave = 1; wave <= 6; wave += 1) {
  209 |       assertClean();
  210 |       if (wave > 1) await page.getByRole('button', { name: 'Resume', exact: true }).click();
  211 |       // Node-side observation checks runtime errors on every poll. A missed
  212 |       // expected terminal also returns immediately, and the catch pauses playback.
  213 |       const deadline = Date.now() + 90_000;
  214 |       let observed = await terminal(page);
  215 |       while (Date.now() <= deadline) {
  216 |         assertClean();
  217 |         const actual = Number(/^\D*(\d+)/.exec(observed.wave ?? '')?.[1]);
  218 |         if (actual > wave || observed.defeat !== null || (actual === wave && observed.skipDisabled)) break;
  219 |         await page.waitForTimeout(50);
  220 |         observed = await terminal(page);
  221 |       }
  222 |       if (Date.now() > deadline) throw new Error(`Native wave ${String(wave)} observation timed out`);
  223 |       await record(`wave-${String(wave)}-terminal`, observed);
```