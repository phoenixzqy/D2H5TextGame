import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills, getSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry();loadDefaultSkills();
const id='skills-barbarian-double-throw',registered=getSkill(id);assert.ok(registered);const observations=[];
const hold:ActiveStatus={id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1,appliedAtMs:1701};
for(const rank of [1,2,20])for(const seed of [7,19,41,97])for(const count of [1,4]){
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Double Throw','barbarian'),id:'hero',level:30,
  skillLevels:{[id]:rank,'skills-barbarian-bash':1,'skills-barbarian-double-swing':1},comboOrder:[id]});
 assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:100000,mana:100,statuses:[hold],manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
  stats:{...native.stats,lifeMax:100000,manaMax:100,attackSpeed:100,critChance:0,defense:0,magicResist:0,physDodge:0,magicDodge:0}};
 const enemyTeam:CombatUnit[]=Array.from({length:count},(_,i)=>({...hero,id:'target-'+i,kind:'monster',side:'enemy',skillOrder:[],skillLevels:{},
  statuses:[{...hold,appliedAtMs:2001}],gridPosition:{row:Math.floor(i/3),col:i%3},stats:{...hero.stats,attackSpeed:0},basicAttack:{damage:[1,1],damageType:'physical'}}));
 const input={seed,playerTeam:[hero],enemyTeam},before=structuredClone(input),actual=runBattleRecorded(input);
 assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),actual);
 const actions=actual.events.filter(e=>e.kind==='action'&&e.actor==='hero'),payments=actual.events.filter(e=>e.kind==='mana'&&e.reason==='cast');
 const attempts=actual.events.flatMap(e=>e.kind==='damage'&&e.source==='hero'?[e]:[]);
 assert.equal(actions.length,1);assert.equal(payments.length,1);assert.equal(actual.result.playerTeam[0]?.mana,90);
 observations.push({rank,seed,enemies:count,actions,payments,attempts,attemptCounts:Object.fromEntries(enemyTeam.map(u=>[u.id,attempts.filter(e=>e.target===u.id).length])),
  heroFinalMana:actual.result.playerTeam[0]?.mana,events:actual.events,finalEnemyLife:actual.result.enemyTeam.map(u=>({id:u.id,life:u.life})),
  doubleThrowObserved:count===1&&attempts.length===2});
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-double-swing-5ov3u07v/double-throw-observations-corrected.json',JSON.stringify({synthetic:true,registered,observations},null,2));
console.log(JSON.stringify(observations.map(({rank,seed,enemies,attemptCounts,doubleThrowObserved})=>({rank,seed,enemies,attemptCounts,doubleThrowObserved})),null,2));
assert.ok(observations.filter(o=>o.enemies===1).every(o=>o.doubleThrowObserved),'Double Throw promises two throws, but each isolated single-target cast resolves only one attempt');
