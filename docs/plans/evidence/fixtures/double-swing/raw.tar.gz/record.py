import sys,subprocess,time,json,os
from pathlib import Path
root=Path(__file__).parent
name=sys.argv[1]; argv=sys.argv[2:]; started=time.time()
with root.joinpath(name+'.log').open('w') as log:
 proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
 live={'name':name,'argv':argv,'pid':proc.pid,'wrapperPid':os.getpid(),'started':started,'cwd':os.getcwd()}
 root.joinpath(name+'-live.json').write_text(json.dumps(live,indent=2))
 print(json.dumps(live),flush=True)
 code=proc.wait()
 receipt={**live,'exit':code,'seconds':time.time()-started}
 root.joinpath(name+'.json').write_text(json.dumps(receipt,indent=2))
print(root.joinpath(name+'.log').read_text()[-7000:],flush=True)
print(json.dumps(receipt),flush=True)
sys.exit(code)
