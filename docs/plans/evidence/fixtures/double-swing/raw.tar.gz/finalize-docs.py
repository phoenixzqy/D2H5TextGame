from pathlib import Path
import collections
import csv
import hashlib
import io
import json
import re
import subprocess

scratch = Path(__file__).resolve().parent
repo = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
required = ['full', 'engine', 'focused-final', 'types', 'lint', 'build', 'browser', 'compatibility', 'loader']
receipts = {n: json.loads((scratch / (n + '.json')).read_text()) for n in required}
assert all(r['exit'] == 0 for r in receipts.values())
log = (scratch / 'full.log').read_text()
assert re.search(r'Test Files\s+683 passed', log)
assert re.search(r'Tests\s+15063 passed\s*\|\s*2 skipped', log)
duration = re.search(r'Duration\s+([\d.]+)s', log).group(1)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head != json.loads((scratch / 'freeze.json').read_text())['head']
short = head[:8]
(scratch / 'final-validation-summary.json').write_text(json.dumps({
    'sourceCommit': head, 'fullTests': 15063, 'fullFiles': 683, 'existingSkips': 2,
    'vitestSeconds': float(duration), 'receipts': receipts}, indent=2) + '\n')

inventory = repo / 'docs/plans/skill-inventory.csv'
before = (scratch / 'inventory-before.csv').read_bytes()
assert inventory.read_bytes() == before
lines = before.splitlines(keepends=True)
index = next(i for i, line in enumerate(lines) if line.startswith(b'barbarian,skills-barbarian-double-swing,'))
fields = next(csv.reader([lines[0].decode()]))
row = dict(zip(fields, next(csv.reader([lines[index].decode()]))))
row.update(risk_flags='provisional-targeting-adaptation|independent-acceptance-open|earned-balance-open',
    behavior_verification='bounded-functional;independent-acceptance-open',
    contract_evidence='docs/plans/decisions/D04-double-swing-v1.md;docs/plans/evidence/d04-double-swing.md')
out = io.StringIO(newline='')
csv.writer(out, lineterminator='\r\n' if lines[index].endswith(b'\r\n') else '\n').writerow([row[k] for k in fields])
updated = list(lines)
updated[index] = out.getvalue().encode()
assert all(a == b for i, (a, b) in enumerate(zip(lines, updated)) if i != index)
inventory.write_bytes(b''.join(updated))
rows = list(csv.DictReader(io.StringIO(inventory.read_text())))
assert len(rows) == 213
counts = dict(collections.Counter(r['behavior_verification'] for r in rows))
assert sum(n for k, n in counts.items() if k.startswith('bounded-functional;')) == 112
assert counts['unverified'] == 99
audit = {'creditedOnly': 'skills-barbarian-double-swing', 'rows': len(rows),
    'otherRowsByteExact': 212, 'orderPreserved': True, 'counts': counts,
    'barbarianBounded': 14, 'beforeSha256': hashlib.sha256(before).hexdigest(),
    'afterSha256': hashlib.sha256(inventory.read_bytes()).hexdigest()}
(scratch / 'inventory-audit.json').write_text(json.dumps(audit, indent=2) + '\n')

evidence = f'''# D04 — Double Swing's actual original-pool cleaves

2026-10-25; author verification under
[contract](../decisions/D04-double-swing-v1.md) and
[BUG214](../../../production/bugs/BUG-214-double-swing-single-attempt.md).
Independent design/QA, earned balance and complete privatev1 remain open.

## Change

Implement two independent passes across the same up to three original living
enemies. Use the existing densest cross and its lowest-row/column anchor tie
rule; cap the row/column ordered result before attacking. Cross is an explicit
provisional author spatial adaptation. The existing prose promised two cleaves
and up to three targets, but did not choose a footprint or resolve every
death/miss rule. No earned balance or independent design approval is implied.

The optional typed hitSequence.targetMode=each-original preserves default total
rotated-attempt semantics for Fury/Jab/Talon/Claw. Double Swing alone authors
strikes2/cross/cap3. Closed schema ownership and actual-row identity reject
contradictory payloads; the adapter copies the mode and11shared combat lines
iterate the fixed original pool. Each attempt uses ordinary hit/base/critical,
mitigation, personal absorption, reflection and death settlement. Dead originals
lose their slot; no replacement or redistribution. Caster death stops both passes.

Preserve Physical40–60/+4rank per attempt,10MP/CD1 paid once, unlock6/cap20,
Bash1 prerequisite and existing equipment eligibility. No weapon Attack bonus,
new stat, saved combat field, version bump, resource grant or dependency.
Pure and actual bilingual UI expose attempts per target, per-attempt damage,
cross/cap/order, misses/death and one paid cast. A variable-size pool is never
advertised as a fixed six-attempt cast.

## Causal and native proof

38new cases/four files:10schema/adapter/display,18causal,2native lifecycle/save
and8bilingual actual UI. The rank cases include60actual scenarios: ranks1/2/20
×seeds7/19/41/97 ×one/two/three/four/nine enemies. Literal target pools and order
prove deterministic cross/cap and two passes, with immutable seeded replay,
ordinary runBattle equality, actual HP loss, one1700ms action/10MP payment and
final90MP. All HP/MP and living active-status playback match engine results.
Future/dead raw status markers remain outside the staged active view.

Seed41 consumes a missed first attempt and resolves the second; seed7 with50%
critical chance yields independent false/true outcomes. With nine enemies, a
one-HP first original dies once, producing one corpse and two boss orbs; the
remaining sequence is1,3,4,3,4 with no new target0. Lethal reflection ends the
cast after one41HP hit/reflection, before any other original is attacked.
Reflected Bone Armor absorbs41then9, leaving41HP damage from the second hit.
Shield/corpse probes explicitly supply synthetic shared-consumer state.
Physical50% resistance gives20/25damage; ordinary Defense reduces both hits.

Two500ms actions at500/1500ms pay once each at the exact1s cooldown boundary.
Without the intervening hold,1000ms uses an ordinary attack and1500ms resumes
the full paid sequence. Insufficient MP/CD prevents every skill attempt/payment.
Native class/unlock/Bash/rank/alias/MAX checks preserve legal authority. Learning
mid-recording leaves that recording frozen, changes next wave and preserves
resources/base stats. Save/import restores allocation/priority without combat
teams/statuses or pool refill. Synthetic mechanics do not establish earned builds.

## Production browser proof

Public create/export/import/allocate rank1→2/priority/cast/save/reopen succeeds
for en/zh-CN ×360×640/1280×800. Each first cast has six actual positive damage
events: the same three original enemies appear twice in the same order. Native
enemy mitigation reduces these hits to1HP each; this is mechanical browser
proof, not damage viability. Visible MP decreases and the hero survives.

Eight Save-close-new-page-Continue pairs preserve player/inventory/map/mercs/
formation exactly. Meta idle clocks may advance on real reopen and are outside
these five exact domains.20geometry checks cover360×640,412×915,640×360,
1280×800,1920×1080 with no horizontal overflow and allocation controls≥44px.
Sixteen screenshots/four individually inspected show readable bilingual copy,
current/next per-attempt damage, target cap, per-target attempts and actual logs.
Browser4/4, no page errors. Synthetic L30/resources/imported helmet/fixed combat
Date.now, ordinary timers and public controls are explicit; no store/test bridge.
Existing navigation glyphs, full device/a11y/offline acceptance remain open.

## Validation and corrections

Final focused38/4, compatibility129/6 and real shared-loader1/1 PASS. Earlier
engine7787/289 PASS covers the first9new engine cases; final focused and full
include the tenth negative preview case. Runtime semantics remain unchanged
since that engine run; one schema description was clarified to include shared
cap ownership. Types/lint/build PASS. Final full15063/683/two existing skips
PASS in{duration}s Vitest ({receipts['full']['seconds']:.3f}s wrapper), against the
frozen final source/test/build. All1180source/config/contracts and760build
hashes are checked through delivery. Four bridge-free chunks and all756present
precache URLs pass; existing test/bundle/PWA/performance budgets remain open.

Original native RED11failed/1passed and bilingual UI RED8failed are retained.
The expanded fixture initially used.5as50% resistance; the shared resolver uses
percentage points and produced40/49. It now uses50, retaining literal20/25
expectations without changing damage code. The first compatibility command
included a nonexistent skills.test.ts pattern; its actual129/6results are
reported as six files only. The real shared-skill-validator1/1ran separately.
No test was skipped, weakened or disabled, and no full run was restarted.

Author five-axis/security review has no required finding. Additive optional
API capability, boundary validation and existing per-hit pipeline keep the
change bounded at two passes ×three targets. Independent review/earned balance
remain open; no genuine campaign, remote, CI, permission or credential action.

## Delivery and remaining scope

Source/tests/contract committed as `{short}`; actual committed blobs for all1180
frozen source/config/contracts,760build hashes and genuine save are audited.
Only Double Swing gains credit:112bounded-functional/99unverified/one engine-only/
one review-needed; Barbarian14/30. Other212inventory rows remain byte-exact,
with213IDs/order unchanged. Double Throw remains uncredited and separately
[reproduced](d04-double-throw-repro.md).

RETENTION-CLEANUP-PENDING

[Raw archive](fixtures/double-swing/raw.tar.gz),
[member manifest](fixtures/double-swing/packet.json),
[source audit](fixtures/double-swing/source-delivered.json),
[browser audit](fixtures/double-swing/browser-audit.json) and
[cleanup receipt](fixtures/double-swing/cleanup.json) retain the evidence.

Genuine Ancients/Rite remainsL33/XP149261/nextNormal402/Nightmare0/Baal uncleared,
decompressed SHA256
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`.
C0/C1 retain narrow exits; C2–C4/fullG0–G7/all-class earned builds/30–50hour
pacing/economy/endgame/independent acceptance and complete privatev1 remain
unfinished. Root sole writer/reviewer; umbrella goal/branch/worktree/claim active.
'''
(repo / 'docs/plans/evidence/d04-double-swing.md').write_text(evidence)
bug = repo / 'production/bugs/BUG-214-double-swing-single-attempt.md'
s = bug.read_text().replace('- Status: reproduced; repeated-attempt/targeting contract and repair open.',
    f'- Status: locally fixed in `{short}`; independent and earned acceptance open.')
bug.write_text(s + f'''

## Local repair

`{short}` implements the [author contract](../../docs/plans/decisions/D04-double-swing-v1.md):
two independently settled passes across a fixed capped cross, no dead-target
replacement/redistribution and one payment/CD.38new cases/four files cover
schema/adapter/pure display, actual combat/playback, native save/wave lifecycle
and bilingual UI. Focused38/4, compatibility129/6, loader1/1, types/lint/build,
production4/4 and full15063/683/two existing skips pass.
[Delivery evidence](../../docs/plans/evidence/d04-double-swing.md) retains original
REDs, synthetic fixture limits, hashes and exact task-owned cleanup. Independent
design/QA/earned balance stay open; the historical reproduction above remains.
''')
repro = repo / 'docs/plans/evidence/d04-double-swing-repro.md'
repro.write_text(repro.read_text() + f'''

## Subsequent local repair

`{short}` implements the explicit [author contract](../decisions/D04-double-swing-v1.md).
[Delivery verification](d04-double-swing.md) records actual original-pool passes,
death/payment/cooldown/mitigation, native save/wave proof and production browser
checks. Historical prepatch evidence above is preserved; independent/earned
acceptance remains open.
''')
ledger = repo / 'docs/plans/execution-ledger.md'
lines = ledger.read_text().splitlines(keepends=True)
i = next(i for i, line in enumerate(lines) if line.startswith('| D04 Double Swing / BUG214 |'))
lines[i] = f'| D04 Double Swing / BUG214 | locally fixed/verified; independent and earned acceptance open | Source/tests/contract `{short}`: two fixed-original passes across densest cross/cap3, no replacement/redistribution, one10MP/CD1 and truthful per-target previews.38new cases; earlier engine7787/289, focused38/4, compatibility129/6, loader1/1, full15063/683/two existing skips/types/lint/build PASS. Production4/4/eight exact five-domain Continue pairs/20geometry/16screenshots/four inspected, six first-cast attempts each. [Evidence](evidence/d04-double-swing.md). All1180source committed blobs/760build/genuine audited. Only Swing credited:112bounded/99unverified/one engine-only/one review-needed; Barbarian14/30. Cross adaptation/provisional balance, independent gates/C2-C4/fullG0-G7/privatev1 open; genuineL33/next402/Baal uncleared unchanged. |\n'
lines.insert(i + 1, '| D04 Double Throw / BUG215 | singleton second throw missing; contract/repair open |24native rank1/2/20 ×four seeds ×one/four enemies cases pay12MP once. Singleton gets one attempt; four enemies get one attempt on each of first two. Complete corrected observations precede intentional exit1. [Reproduction](evidence/d04-double-throw-repro.md). No Throw repair/credit. |\n')
ledger.write_text(''.join(lines) + f'''

## 2026-10-25 — Double Swing original-pool cleaves verified; Double Throw reproduced

Source/tests/contract `{short}` fixes BUG214 with actual two-pass capped cross,
independent per-hit settlement and truthful bilingual attempts-per-target copy.
60native rank/seed/layout scenarios prove exact original membership/order,
actual HP loss and one10MP debit. Dead originals skip without redistribution;
lethal reflection stops the caster. Miss/crit/Defense/resistance/shield, exact
cooldown, native authority/current-wave isolation/next-wave/save and immutable
resource/living-status playback are covered. [Evidence](evidence/d04-double-swing.md).

Focused38/4, compatibility129/6, real loader1/1, earlier engine7787/289 and
types/lint/build PASS; final full15063/683/two existing skips, Vitest{duration}s,
wrapper{receipts['full']['seconds']:.3f}s. Final full includes tenth new engine
preview case added after earlier engine run. Frozen1180source/config/contracts,
760build/genuine hashes audited. Production4/4/eight exact five-domain Continue
pairs/20geometry/16screenshots/four inspected: six real attempts on same three
targets twice,1HP each after actual enemy mitigation. Synthetic browser pools/
level/helmet/fixed combat Date.now establish no earned balance. Original REDs,
resistance-unit fixture correction and the separate real-loader receipt remain.

Only Swing credited;213IDs/order and212other rows byte-exact:112bounded-functional/
99unverified/one engine-only/one review-needed, Barbarian14/30. Retention/cleanup
terminal details are in the linked delivery packet. Double Throw is separately
reproduced:12singleton cases have one attempt instead of two throws,12four-enemy
cases have one attempt on each of first two. Initial copied90MP expectation was
corrected to native12MP/88remaining; both scripts/receipts retained. BUG215
contract/repair remains open with no Throw credit.

Genuine Ancients/Rite L33/XP149261/nextNormal402/Nightmare0/Baal uncleared and exact
hash remain unchanged. C0/C1 retain narrow exits; C2 underway,C3/C4/fullG0-G7/
all-class earned builds/30–50hour pacing/economy/endgame/independent acceptance
and complete privatev1 unfinished. No genuine campaign or remote action. Root
sole writer/reviewer; umbrella goal/branch/worktree/claim remains active.
''')
print(json.dumps({'sourceCommit': head, 'inventory': audit, 'fullVitestSeconds': duration}))
