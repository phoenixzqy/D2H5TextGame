# Next-slice draft — two total Double Throw attempts

Draft only; BUG215 contract/repair pending. Unlike two cleaving Swing passes,
Throw promises two weapons, not two attempts per enemy. Proposed contract:
existing first-two original area pool, two total independent attempts rotating
within that pool. A lone survivor may receive both. This fits the existing
shared default sequence semantics with strikes2; no each-original mode, shape
or three-target cap. Preserve Physical50–75/+5rank,12MP/CD1, unlock12/cap20 and
Bash→Double Swing prerequisites/current equipment eligibility. One cast/payment/
CD; misses consume attempts, stop on caster/pool death, no outside replacement.
Use strict actual-row schema ownership and truthful bilingual per-cast display.
Prove singleton/two/four-enemy behavior, independent rolls, death/reflection/
shields/mitigation, no leaks into Swing's different mode, legal native allocation,
current/next-wave isolation, save/import, immutable playback/replay and production
public browser checks with exactly two total Throw attempts, one12MP debit, both
locales/mobile/desktop and exact five-domain reopen. No genuine campaign/remote
operation. Independent design/earned balance stay open. Review and record the
actual contract before writing REDs/production changes.
