import { afterEach, beforeEach, expect, it } from 'vitest';
import { runBattleRecorded, runBattle, type CombatSnapshot } from './combat';
import { loadDefaultSkills, resetRegistry } from '../skills/registry';
import type { CombatUnit } from './types';
function unit(id: string, side: CombatUnit['side']): CombatUnit {
  return { id, side, name: id, kind: side === 'player' ? 'hero' : 'monster', level: 30, tier: 'trash',
    life: 100000, mana: 9, stats: { life: 100000, lifeMax: 100000, mana: 9, manaMax: 100,
      attack: 1, attackSpeed: 100, defense: 0, magicResist: 0, critChance: 0, critDamage: 2,
      physDodge: 0, magicDodge: 0, magicFind: 0, goldFind: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } },
    statuses: [], cooldowns: {}, activeBuffIds: [], skillOrder: [], enraged: false };
}
function scene(): CombatSnapshot {
  return { seed: 7, playerTeam: [Object.assign(unit('hero', 'player'), { burstOfSpeedRank: 20,
    skillLevels: { 'assassin.burst_of_speed': 20 }, skillOrder: ['assassin.burst_of_speed'] })],
    enemyTeam: [{ ...unit('target', 'enemy'), statuses: [{ id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1 }] }] };
}
beforeEach(() => { resetRegistry(); loadDefaultSkills(); });
afterEach(() => { resetRegistry(); loadDefaultSkills(); });
it('actual paid rank20 Burst changes the next attack time without changing base stats or refilling resources', () => {
  const input=scene(), before=structuredClone(input), result=runBattleRecorded(input);
  const actions=result.events.filter(e => e.kind==='action' && e.actor==='hero');
  expect(actions.slice(0,2).map(e=>e.simClockMs)).toEqual([1700,3080]);
  expect(result.result.playerTeam[0]?.stats).toEqual(input.playerTeam[0]?.stats);
  expect(result.result.playerTeam[0]?.mana).toBe(0);
  expect(input).toEqual(before);expect(runBattleRecorded(input)).toEqual(result);expect(runBattle(input)).toEqual(result.result);
});
it('observes a finite ten-second paid effect and its expiry rather than a permanent marker', () => {
  const result=runBattleRecorded(scene());
  expect(result.events.some(e=>e.kind==='status-state' && e.target==='hero' && e.simClockMs===1700 &&
    e.statuses.some(s=>s.id==='burst-of-speed' && s.expiresAtMs===11700))).toBe(true);
  expect(result.events.some(e=>e.kind==='status-state' && e.target==='hero' && e.simClockMs===11700 &&
    e.statuses.every(s=>s.id!=='burst-of-speed'))).toBe(true);
  expect(result.result.playerTeam[0]?.activeBuffIds).not.toContain('burst-of-speed');
});
it('can pay for a later recast after expiry, but never refreshes an active effect', () => {
  const input=scene();const result=runBattleRecorded({ ...input,playerTeam:input.playerTeam.map(u=>({...u,mana:100})) });
  const casts=result.events.filter(e=>e.kind==='action' && e.actor==='hero' && e.skillId==='assassin.burst_of_speed');
  expect(casts.length).toBeGreaterThan(1);
  for(let i=1;i<casts.length;i++) expect((casts[i]?.simClockMs??0)-(casts[i-1]?.simClockMs??0)).toBeGreaterThanOrEqual(10000);
});
