import assert from 'node:assert/strict';
import { activeBurstOfSpeed, paidBurstOfSpeed, copyBurstOfSpeedStatuses } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/burst-of-speed';
import { rebaseStatusClock } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/status';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const unit={id:'hero',side:'player',kind:'hero',level:30,life:100,statuses:[{
 id:'burst-of-speed',sourceId:'hero',stacks:1,remaining:10,appliedAtMs:59999.99,
 expiresAtMs:59999.99+10000,statBuff:paidBurstOfSpeed(20)}]} as unknown as CombatUnit;
const rebased=rebaseStatusClock(unit,60000),s=rebased.statuses[0];assert.ok(s);
const actualDuration=s.expiresAtMs!-s.appliedAtMs!;
assert.notEqual(actualDuration,10000,'Fixture must expose real floating cancellation');
assert.deepEqual(activeBurstOfSpeed(rebased,0),paidBurstOfSpeed(20));
const copied=copyBurstOfSpeedStatuses(rebased);assert.deepEqual(copied,rebased);
assert.notEqual(copied.statuses[0]?.statBuff,s.statBuff);assert.ok(Object.isFrozen(copied.statuses[0]?.statBuff));
assert.equal(activeBurstOfSpeed(rebased,s.expiresAtMs!),undefined);
assert.equal(activeBurstOfSpeed({...rebased,statuses:[{...s,expiresAtMs:s.expiresAtMs!+.00001}]},0),undefined);
console.log(JSON.stringify({lateCast:59999.99,rebaseAt:60000,actualDuration,strictEqualityWouldReject:true,validPotencyRetained:true,expiryAndExtendedIntervalRejected:true}));
