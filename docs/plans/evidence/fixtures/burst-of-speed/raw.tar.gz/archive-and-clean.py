import sys,json,tarfile,hashlib,socket,os
from pathlib import Path
scratch=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
fixtures=repo/'docs/plans/evidence/fixtures/burst-of-speed'
assert scratch.name=='d2h5-burst-speed-9gsu8yoe' and not scratch.is_symlink()
full=json.loads((scratch/'full-verification.json').read_text())
assert full['exit']==0 and not full['drift'] and full['headUnchanged'] and full['statusUnchanged']
processes=[]
for p in sorted(scratch.glob('*.process.json')):
 name=p.name.removesuffix('.process.json')
 receipt=scratch/('full-verification.json' if name=='full-npm' else name+'.result.json')
 assert receipt.is_file(),str(receipt)
 processes.append({'process':p.name,'terminal':receipt.name,**json.loads(receipt.read_text())})
with socket.socket() as s: assert s.connect_ex(('127.0.0.1',4460))!=0
fixtures.mkdir(exist_ok=False)
# Generated build output is disposable; retain every build hash rather than duplicating assets.
raw=[]
for p in sorted(scratch.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file() and p.relative_to(scratch).parts[0]!='dist':raw.append(p)
manifest={str(p.relative_to(scratch)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in raw}
archive=fixtures/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in raw:tar.add(p,arcname=str(p.relative_to(scratch)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for m in members:
  assert m.isfile() and m.name in manifest
  f=tar.extractfile(m);assert f is not None
  data=f.read();assert len(data)==manifest[m.name]['size'] and hashlib.sha256(data).hexdigest()==manifest[m.name]['sha256']
packet={'baselineHead':full.get('head','f2de6a0'),'archive':archive.name,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'rawCount':len(raw),'rawFiles':manifest,'terminalProcesses':processes,'buildRetained':'All generated build-file hashes retained in raw/build-files.json; built assets are disposable','genuineCampaignActions':0,'cleanupOwner':'root'}
(fixtures/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
# Exact file inventory, validated before deletion; never traverse links or a shared parent.
files=[p for p in sorted(scratch.rglob('*')) if p.is_file()]
cleanupManifest={str(p.relative_to(scratch)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for p in files}
for p in files:
 assert not p.is_symlink() and p.resolve().is_relative_to(scratch.resolve())
 expected=cleanupManifest[str(p.relative_to(scratch))]
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256']
(fixtures/'cleanup-inventory.json').write_text(json.dumps(cleanupManifest,indent=2)+'\n')
failures=[]
for p in files:
 try:p.unlink()
 except OSError as error:failures.append({'path':str(p),'error':str(error)})
for p in sorted([p for p in scratch.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):
 try:p.rmdir()
 except OSError as error:failures.append({'path':str(p),'error':str(error)})
try:scratch.rmdir()
except OSError as error:failures.append({'path':str(scratch),'error':str(error)})
remaining=[str(p) for p in files if p.exists()]
if scratch.exists():remaining.append(str(scratch))
with socket.socket() as s:portClosed=s.connect_ex(('127.0.0.1',4460))!=0
receipt={'scratch':str(scratch),'deletedFiles':len(files),'rawFilesArchived':len(raw),'remainingPaths':remaining,'failures':failures,'port4460Closed':portClosed,'sharedCachesPreserved':True,'worktreeClaimPreserved':True}
(fixtures/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
assert not remaining and not failures and portClosed
