from pathlib import Path
import json,gzip,hashlib
r=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
def j(p):return json.loads(Path(p).read_text())
def z(p):return json.load(gzip.open(p))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def own(s):
 a=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[v for eq in s['mercs']['mercEquipment'].values() for v in eq.values()]
 a=[i for i in a if i is not None];d={i['id']:i for i in a};assert len(d)==len(a);return d
def totalxp(s):return s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))
screen=j(r/'diamond-v2-screen.json');assert screen['status']=='complete' and screen['qualified'];assert len(screen['rows'])==32 and screen['wins']==32 and screen['secondHalfWins']==16
for row in screen['rows']:assert row['won'] and len(row['waves'])==row['totalWaves']==6 and all(w['winner']=='player' for w in row['waves'])
for name in ['screen.json','gear-screen.json']:
 d=j(r/name);assert d['status']=='complete' and len(d['rows'])==32 and d['wins']==0 and not d['qualified']
input=z(screen['policy']['input']);assert hashlib.sha256(gzip.decompress(Path(screen['policy']['input']).read_bytes())).hexdigest()==screen['policy']['inputRawSHA256']
expected=z(r/'diamond-v2-prepared.diagnostic-only.json.gz');prepared=z(r/'native-diamond-preparation/final.json.gz');assert prepared==expected
prep=j(r/'native-diamond-preparation/report.json');combat=j(r/'earned-frigid393/report.json');rescue=j(r/'native-rescue-claim/report.json')
for report in [prep,combat,rescue]:assert report['status']=='observed' and not report['errors'] and not report['console'] and not report.get('cleanupErrors')
assert len(prep['actions'])==13 and len(combat['launches'])==1 and combat['launches'][0]['ordinal']==393 and combat['outcome']=='earned-act5-area-victory'
assert len(rescue['actions'])==4 and [a['kind'] for a in rescue['actions']]==['cage','cage','cage','claim']
before,after=own(input),own(prepared);assert before.keys()==after.keys()
crafted={c['id']:c['count'] for c in screen['policy']['crafts']}
for id,item in before.items():
 a,b=dict(item),dict(after[id]);a.pop('equipped',None);b.pop('equipped',None)
 if id in crafted:
  old=a.pop('socketContents',[]);new=b.pop('socketContents',[]);assert new==old+[{'kind':'gem','id':'gems/diamond/flawless'}]*crafted[id]
 assert a==b,id
assert prepared['inventory']['materials']=={**input['inventory']['materials'],'gems/diamond/flawless':input['inventory']['materials']['gems/diamond/flawless']-5}
assert prepared['inventory']['materialActionOrdinal']==input['inventory']['materialActionOrdinal']+5
for k in ['currencies','questItems','questServices']:assert prepared['inventory'][k]==input['inventory'][k]
for k in ['map','mercs','formation','meta','endgame']:assert prepared[k]==input[k]
for k in ['level','experience','coreStats','skillLevels','skillPoints','statPoints','respecsRemaining','comboOrder']:assert prepared['player'][k]==input['player'][k]
assert prepared['player']['derivedStats']['magicResist']==40
pairs=[];snapshots=0
for folder,report in [('native-diamond-preparation',prep),('earned-frigid393',combat),('native-rescue-claim',rescue)]:
 states=report['states']
 for n,label in enumerate(states):
  path=r/folder/(label if label.endswith('.json.gz') else label+'.json.gz');value=z(path)
  if isinstance(value,dict) and 'player' in value:
   snapshots+=1;assert set(before)<=set(own(value))
  if label.removesuffix('.json.gz').endswith('-saved'):
   nextlabel=states[n+1];assert nextlabel.removesuffix('.json.gz').endswith('-continued');nextpath=r/folder/(nextlabel if nextlabel.endswith('.json.gz') else nextlabel+'.json.gz');assert value==z(nextpath);pairs.append([str(path.relative_to(r)),str(nextpath.relative_to(r))])
for wave in range(1,7):
 initial=z(r/f'earned-frigid393/393-w{wave}-initial.json.gz');terminal=z(r/f'earned-frigid393/393-w{wave}-terminal.json.gz');assert terminal['skipDisabled'] and terminal['liveEnemies']==0 and terminal['defeat'] is None;assert terminal['log'][-1]=='Victory! All enemies are defeated.';assert next(c for c in terminal['cards'] if c['id']=='unit-card-'+input['player']['id'])['dead'] is None;assert set(initial['enemyIds'])<=set(terminal['enemyIds'])
combatfinal=z(r/'earned-frigid393/final.json.gz');final=z(r/'native-rescue-claim/final.json.gz');ancestor=own(prepared);now=own(final)
for id,i in ancestor.items():assert now[id]==i,id
qid='quests/act5-rescue-on-mount-arreat';assert combatfinal['map']['questProgress'][qid]['objectives']['obj-free-15']==False
for n in range(1,4):assert qid+'#action:release-cage-'+str(n) not in combatfinal['map']['questReceipts'];assert final['map']['questReceipts'][qid+'#action:release-cage-'+str(n)] is True
assert final['map']['questProgress'][qid]['rewardClaimed'] and final['map']['questProgress'][qid]['status']=='completed'
assert totalxp(final)-totalxp(combatfinal)==8000 and final['player']['skillPoints']==combatfinal['player']['skillPoints']+1
for k,v in combatfinal['player']['derivedStats']['resistances'].items():assert final['player']['derivedStats']['resistances'][k]==v+5
assert final['inventory']==combatfinal['inventory'];assert final['map']['challengeOrdinals']=={'normal':394,'nightmare':0};assert final['player']['derivedStats']['magicResist']==40
assert final['inventory']['questServices']['quests/act5-siege-on-harrogath#reward:service']=={'serviceId':'socket_item','state':'available'}
for merc in input['mercs']['ownedMercs']:
 if merc['id']!=input['mercs']['fieldedMercId']:assert next(m for m in final['mercs']['ownedMercs'] if m['id']==merc['id'])==merc
freeze=j(r/'source-freeze.json');drift=[p for p,h in freeze.items() if not (repo/p).is_file() or sha(repo/p)!=h];assert not drift
summary={'status':'pass','sourceFiles':len(freeze),'sourceDrift':drift,'diagnostics':{'baselineWins':0,'resistanceOnlyWins':0,'diamondWins':32,'diamondSecondHalfWins':16,'nEach':32,'diagnosticPromotions':0},'nativePreparationActions':len(prep['actions']),'diamondCost':5,'genuineLaunches':combat['launches'],'nativeCageActions':3,'separateClaim':True,'saveContinuePairs':pairs,'nativeSavedSnapshots':snapshots,'ownedBefore':len(before),'ownedPrepared':len(ancestor),'ownedFinal':len(now),'allPreparedPayloadsExactAtFinal':True,'totalXPEarned':totalxp(final)-totalxp(input),'combatXP':totalxp(combatfinal)-totalxp(prepared),'claimXP':8000,'finalLevel':final['player']['level'],'finalXP':final['player']['experience'],'finalSkillPoints':final['player']['skillPoints'],'finalStatPoints':final['player']['statPoints'],'finalMagicResist':40,'finalNextNormal':394,'finalRawSHA256':hashlib.sha256(gzip.decompress((r/'native-rescue-claim/final.json.gz').read_bytes())).hexdigest(),'noBrowserErrors':True,'limitations':'one English/mobile earned pilot; no C2/full-v1 or pacing acceptance; source unchanged'}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='saveContinuePairs'},indent=2))
