from pathlib import Path
import gzip,json,hashlib,re,math
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
task=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/merc-picker380')
root=task/'earned-river-through391'
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
source=repo/'docs/plans/evidence/fixtures/earned-tyrael-and-river-through379/retained-final.json.gz'
original=load(source);report=json.loads((root/'report.json').read_text());assert report['status']=='observed' and not report['errors'] and not report['console'] and report['retries']==0
assert hashlib.sha256(gzip.decompress(source.read_bytes())).hexdigest()=='b0972bad81133bba925939ed6c412307e2338df2e65795a2f6b48fa70735a64f'
def owned(s):
 rows=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[i for gear in s['mercs']['mercEquipment'].values()for i in gear.values()]
 rows=[i for i in rows if i is not None];d={i['id']:i for i in rows};assert len(rows)==len(d);return d
def xp(s):return s['player']['experience']+sum(math.floor(100*l**2.5)for l in range(1,s['player']['level']))
ancestor=owned(original);final=load(root/'final.json.gz');new=owned(final);saves={};states={}
for p in sorted(root.glob('*.json.gz')):
 s=load(p);states[p.name[:-8]]=s
 if isinstance(s,dict) and all(k in s for k in ['player','inventory','map','mercs','meta','formation']):
  saves[p.name[:-8]]=s;items=owned(s)
  for key,item in ancestor.items():assert items.get(key)==item,(p.name,key)
  for key in ['coreStats','skillLevels','comboOrder','respecsRemaining']:assert s['player'][key]==original['player'][key]
  assert s['inventory']['equipped']==original['inventory']['equipped'];assert s['mercs']['mercEquipment']==original['mercs']['mercEquipment'];assert s['mercs']['fieldedMercId']==original['mercs']['fieldedMercId'];assert s['formation']==original['formation'];assert s['endgame']==original['endgame'];assert s['map']['questProgress']==original['map']['questProgress'];assert s['map']['questReceipts']==original['map']['questReceipts']
  assert s['map']['challengeOrdinals']['nightmare']==original['map']['challengeOrdinals']['nightmare']
  for key,n in original['inventory']['materials'].items():assert s['inventory']['materials'].get(key,0)>=n
  for key,n in original['inventory']['currencies'].items():assert s['inventory']['currencies'].get(key,0)>=n
  assert [m['id']for m in s['mercs']['ownedMercs']]==[m['id']for m in original['mercs']['ownedMercs']]
  for merc in original['mercs']['ownedMercs']:
   if merc['id']!=original['mercs']['fieldedMercId']:assert next(m for m in s['mercs']['ownedMercs']if m['id']==merc['id'])==merc
pairs=[];normalized={re.sub(r'^\d+-','',k):s for k,s in saves.items()}
for key,s in normalized.items():
 if key.endswith('-saved'):
  other=key[:-6]+'-continued';assert s==normalized[other];pairs.append([key,other])
assert len(report['areas'])==len(report['launches'])
ordinals=[a['ordinal']for a in report['areas']];assert ordinals==list(range(380,380+len(ordinals)));assert len(ordinals)<=12
wins=[]
for area in report['areas']:
 assert area['outcome']=='victory' and area['alias']=='river-of-flame' and len(area['waves'])==6
 for wave in area['waves']:
  ordinal,w=area['ordinal'],wave['wave'];assert wave['outcome']=='victory'
  before=states[f'{ordinal}-w{w}-initial'];terminal=states[f'{ordinal}-w{w}-terminal'];assert before['enemyIds'] and all(i in terminal['enemyIds']for i in before['enemyIds']);assert terminal['liveEnemies']==0 and terminal['skipDisabled'] is True and terminal['log'][-1]=='Victory! All enemies are defeated.'
  assert next(c for c in terminal['cards']if c['id']=='unit-card-'+original['player']['id'])['dead'] is None
  wins.append(wave)
assert len(pairs)==len(ordinals)+1
assert final['map']['challengeOrdinals']['normal']==380+len(ordinals)==report['finalOrdinal']
assert xp(final)-xp(original)==report['totalXP']==sum(w['delta']['xp']for w in wins)
assert len(new)-len(ancestor)==sum(len(w['delta']['newItems'])for w in wins)
levelDelta=final['player']['level']-original['player']['level'];assert final['player']['statPoints']==original['player']['statPoints']+5*levelDelta;assert final['player']['skillPoints']==original['player']['skillPoints']+levelDelta
assert final['player']['level']==32 and report['stopReason']=='target-level32'
audit={'kind':'genuine ordinary UI earned continuation; root self-audit, independent acceptance pending','sourceCommit':report['runtime'],'inputRawSHA256':report['inputSHA256'],'finalRawSHA256':hashlib.sha256(gzip.decompress((root/'final.json.gz').read_bytes())).hexdigest(),'firstOrdinal':ordinals[0],'lastOrdinal':ordinals[-1],'nextNormal':final['map']['challengeOrdinals']['normal'],'challenges':len(ordinals),'nativeWaveVictories':len(wins),'nativeNonwins':0,'saveExports':len(saves),'saveCloseContinuePairs':len(pairs),'ancestralFullItemsPreserved':len(ancestor),'ownedItemsFinal':len(new),'newItems':len(new)-len(ancestor),'heroLevel':final['player']['level'],'heroXP':final['player']['experience'],'earnedHeroXP':report['totalXP'],'unspentStatPoints':final['player']['statPoints'],'unspentSkillPoints':final['player']['skillPoints'],'rosterCount':len(final['mercs']['ownedMercs']),'fieldedMerc':final['mercs']['fieldedMercId'],'consoleErrors':report['errors'],'consoleWarnings':report['console'],'scriptWallMs':report['executionWallMs'],'requestedClockAdvanceMs':report['requestedClockAdvanceMs'],'pacing':'transport measurements only; no30-50active-hour acceptance','metadataCorrection':'Original report kind string retains stale through375/next376 descriptive text from cloned runner. Its actual inputPath/inputSHA256, plan, guards, launch ledger, exports and this audit all prove through379/next380. Original report/script preserved unchanged; no action was replayed.'}
(task/'river-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
