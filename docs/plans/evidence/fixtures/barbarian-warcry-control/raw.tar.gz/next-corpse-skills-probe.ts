import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import skills from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/barbarian.json';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const observations = [];
for (const slug of ['find-potion', 'find-item', 'grim-ward']) for (const rank of [1, 2, 20]) for (const seed of [7, 19, 41, 97]) {
 const id='skills-barbarian-'+slug, levels:Record<string,number>={};
 function add(key:string){const row=skills.find(s=>s.id===key);assert.ok(row);for(const required of row.prerequisites??[])add(required);levels[key]=1;}
 add(id);levels[id]=rank;
 const native=playerToCombatUnit({...createMockPlayer('Synthetic corpse-skill probe','barbarian'),id:'hero',level:30,skillLevels:levels,comboOrder:[id]});assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:1000000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
 statuses:[{id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:2701}],
 stats:{...native.stats,lifeMax:1000000,manaMax:100,attack:200,attackSpeed:100,defense:100,magicResist:0,critChance:0,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,arcane:0,poison:0}}};
 const enemy:CombatUnit={...hero,id:'enemy',side:'enemy',kind:'monster',skillOrder:[],skillLevels:{},statuses:[],stats:{...hero.stats,attackSpeed:50}};
 const input={seed,playerTeam:[hero],enemyTeam:[enemy]},before=structuredClone(input),out=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const paid=out.events.filter(e=>e.kind==='mana'&&e.reason==='cast'),casts=out.events.filter(e=>e.kind==='action'&&e.skillId==='barbarian.'+slug.replaceAll('-','_'));
 assert.equal(paid.length,1);assert.equal(casts.length,1);assert.equal(casts[0]?.simClockMs,1700);assert.equal(out.events.some(e=>e.kind==='death'),false);
 const during=out.events.filter(e=>e.simClockMs>=1700&&e.simClockMs<2700&&(e.kind==='action'||e.kind==='damage'||e.kind==='summon'||e.kind==='status'||e.kind==='buff'));
 observations.push({slug,rank,seed,paid,casts,noDeathOrCorpseAvailable:true,during});
}
const output={synthetic:true,base:'98ad7970 plus frozen warcry-control implementation; these three skills unchanged',observations};
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-warcry-control-qoc34jvq/next-corpse-skills-observations.json',JSON.stringify(output,null,2));
console.log(JSON.stringify(output,null,2));
assert.ok(observations.every(o=>o.casts.length===0),'Corpse-search/ward skills cast and pay before any corpse exists.');
