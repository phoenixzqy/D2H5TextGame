from pathlib import Path
import json,hashlib,gzip,os,socket
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path(__file__).parent
out=root/'docs/plans/evidence/fixtures/barbarian-warcry-control';out.mkdir(parents=True,exist_ok=True)
def write(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
def one(folder,pattern):
 files=list(folder.glob(pattern));assert len(files)==1,(folder,pattern,files);return files[0]
def domains(value):return {key:value[key] for key in ['player','inventory','map','mercs','formation']}
pairs=[];cases=[];geometry=[]
for folder in sorted(p.glob('browser-*')):
 if not folder.is_dir():continue
 r=json.loads((folder/'browser-report.json').read_text());assert not r['failures'];assert len(r['cases'])==3
 for c in r['cases']:
  label=c['label'];assert c['pass'] and not c['errors'] and c['pairs']==['rank1','rank2'];assert c['offlineContinue']=={'pass':True,'exactDomains':['player','inventory','map','mercs','formation'],'freshPage':True,'networkOffline':True}
  cases.append(c)
  for rank in ['rank1','rank2']:
   a=one(folder,label+'-'+rank+'-before-*.json');b=one(folder,label+'-'+rank+'-after-*.json');da=json.loads(a.read_text());db=json.loads(b.read_text());assert da['version']==db['version']==22;assert domains(da)==domains(db)
   pairs.append({'label':label,'kind':rank,'before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
  a=one(folder,label+'-rank2-after-*.json');b=one(folder,label+'-offline-continued-*.json');assert domains(json.loads(a.read_text()))==domains(json.loads(b.read_text()))
  pairs.append({'label':label,'kind':'offline-fresh-page','before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
 geometry.extend(r['geometry'])
assert len(cases)==12 and len(geometry)==60 and len(pairs)==36
for g in geometry:assert g['overflow']==0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
write('browser-audit.json',{'cases':cases,'geometry':geometry,'consolePageErrors':[],'screenshots':len(list(p.glob('browser-*/*.png'))),'individuallyInspected':['browser-en-360/en-360-howl-current-next.png','browser-en-360/en-360-taunt-current-next.png','browser-zh-CN-360/zh-CN-360-battle-cry-current-next.png','browser-en-1280/en-1280-battle-cry-current-next.png'],'limits':'Synthetic imported L30/resources/helmet and fixed Date.now; no earned campaign or balance claim. Geometry covers selected skill allocation control; no full accessibility audit.'})
write('save-pairs-audit.json',{'ordinaryPairs':24,'offlinePairs':12,'pairs':pairs,'saveVersion':22,'pass':True})
f=json.loads((p/'frozen.json').read_text())
for key,base in [('source',root),('build',p/'build')]:
 drift=[name for name,sha in f[key].items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=sha];assert not drift,(key,drift)
sha=hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest();assert sha==f['genuine']
write('freeze-audit.json',{'sourceCount':len(f['source']),'buildCount':len(f['build']),'sourceDrift':[],'buildDrift':[],'genuine':sha,'pass':True})
print('Verified 12cases /24ordinary pairs /12offline pairs /60geometry; source/build/genuine exact.')
