import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import skills from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/sorceress.json';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';

const observations = [];
for (const rank of [1, 2, 20]) for (const seed of [7, 19, 41, 97]) {
  const id = 'skills-sorceress-frozen-orb', levels: Record<string, number> = {};
  function add(key: string) {
    const row = skills.find(s => s.id === key);
    assert.ok(row);
    for (const required of row.prerequisites ?? []) add(required);
    levels[key] = 1;
  }
  add(id); levels[id] = rank;
  const native = playerToCombatUnit({ ...createMockPlayer('Synthetic Frozen Orb geometry', 'sorceress'),
    id: 'hero', level: 30, skillLevels: levels, comboOrder: [id] });
  assert.deepEqual(native.skillOrder, [id]);
  const hero: CombatUnit = { ...native, life: 1000000, mana: 100,
    manaRegenPerSecond: 0, manaRegenBaselinePerSecond: 0,
    statuses: [{ id: 'stun', sourceId: 'synthetic-hold', stacks: 1, remaining: -1, appliedAtMs: 1701 }],
    stats: { ...native.stats, lifeMax: 1000000, manaMax: 100, attack: 200, attackSpeed: 100,
      defense: 0, magicResist: 0, critChance: 0, physDodge: 0, magicDodge: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } } };
  const enemies: CombatUnit[] = [];
  for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) enemies.push({
    ...hero, id: `enemy-${String(row)}-${String(col)}`, side: 'enemy', kind: 'monster',
    skillOrder: [], skillLevels: {}, gridPosition: { row, col },
    statuses: [{ id: 'stun', sourceId: 'synthetic-hold', stacks: 1, remaining: -1, appliedAtMs: 0 }]
  });
  const input = { seed, playerTeam: [hero], enemyTeam: enemies }, before = structuredClone(input);
  const out = runBattleRecorded(input);
  assert.deepEqual(input, before); assert.deepEqual(runBattleRecorded(input), out);
  const casts = out.events.filter(e => e.kind === 'action' && e.skillId === 'sorceress.frozen_orb');
  const paid = out.events.filter(e => e.kind === 'mana' && e.reason === 'cast');
  const hits = out.events.filter(e => e.kind === 'damage' && e.source === 'hero' && e.simClockMs === 1700);
  assert.equal(casts.length, 1); assert.equal(casts[0]?.simClockMs, 1700);
  assert.equal(paid.length, 1); assert.equal(out.result.playerTeam[0]?.mana, 70);
  const targets = hits.flatMap(e => e.kind === 'damage' ? [e.target] : []);
  const loss = out.result.enemyTeam.reduce((n, e) => n + 1000000 - e.life, 0);
  assert.equal(loss, hits.reduce((n, e) => n + (e.kind === 'damage' ? e.amount : 0), 0));
  observations.push({ rank, seed, legalAllocations: levels, casts, paid, hits, targets, actualHpLoss: loss,
    existingCone2Targets: ['enemy-0-1', 'enemy-1-0', 'enemy-1-1', 'enemy-1-2'],
    inputsImmutable: true, exactReplay: true });
}
const output = { synthetic: true, source: '98ad7970 plus warcry-control; Frozen Orb unchanged',
  promise: 'skills-spec and both locales say cone; authored/legacy data select box-3x3', observations };
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-warcry-control-qoc34jvq/next-frozen-orb-observations.json', JSON.stringify(output, null, 2));
console.log(JSON.stringify(output, null, 2));
assert.ok(observations.every(o => JSON.stringify(o.targets) === JSON.stringify(o.existingCone2Targets)),
  'Frozen Orb selects a nine-cell box instead of the existing cone geometry promised by its design/copy.');
