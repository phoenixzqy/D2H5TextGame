import sys,subprocess,time,json
from pathlib import Path
p=Path(__file__).parent
label=sys.argv[1];command=sys.argv[2:];start=time.monotonic()
with (p/(label+'.log')).open('w') as log:
 child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
 (p/(label+'-live.json')).write_text(json.dumps({'pid':child.pid,'command':command}))
 code=child.wait()
(p/(label+'-result.json')).write_text(json.dumps({'command':command,'pid':child.pid,'exitCode':code,'seconds':time.monotonic()-start}))
sys.exit(code)
