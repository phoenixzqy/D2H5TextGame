from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,json
p=Path(__file__).parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(p/'build'),**kwargs)
 def log_message(self,format,*args):pass
port=int(os.environ.get('BROWSER_PORT','4504'))
(p/('server-'+str(port)+'-live.json')).write_text(json.dumps({'pid':os.getpid(),'port':port}))
ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
