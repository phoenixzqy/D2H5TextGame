from pathlib import Path
import json
p=Path(__file__).parent
f=p/'recorded-processes.json';record=json.loads(f.read_text()) if f.exists() else {'roots':[],'processes':[]};byid={r['pid']:r for r in record['processes']};roots=set(record['roots'])
for q in [*p.glob('*-live.json'),*p.glob('*-result.json')]:
 try:
  r=json.loads(q.read_text());pid=r.get('pid')
  if isinstance(pid,int):roots.add(pid)
 except (OSError,ValueError):pass
procs={}
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:
  raw=(q/'stat').read_text().rsplit(')',1)[1].split();pid=int(q.name)
  procs[pid]={'pid':pid,'parent':int(raw[1]),'startTicks':raw[19],'command':(q/'cmdline').read_bytes().replace(bytes([0]),b' ').decode(errors='replace')}
 except (OSError,IndexError,ValueError):pass
owned=roots|set(byid)
while True:
 more={pid for pid,r in procs.items() if r['parent'] in owned}
 if more<=owned:break
 owned|=more
for pid in owned:
 if pid not in byid:byid[pid]=procs.get(pid,{'pid':pid,'alreadyAbsent':True})
record['roots']=sorted(roots);record['processes']=[byid[pid] for pid in sorted(byid)];f.write_text(json.dumps(record,indent=2)+'\n');print('Recorded',len(byid),'PIDs,',sum(pid in procs for pid in byid),'currently present')
