from pathlib import Path
import subprocess,os
root=Path(__file__).parent
for locale in ['en','zh-CN']:
 for width in ['360','1280']:
  env={**os.environ,'BROWSER_RUN':'final-browser-'+locale+'-'+width,'BROWSER_LOCALE':locale,'BROWSER_WIDTH':width}
  subprocess.run(['node',str(root/'browser.cjs')],env=env,check=True)
