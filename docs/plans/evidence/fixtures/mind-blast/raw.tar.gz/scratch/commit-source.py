from pathlib import Path
import hashlib,io,json,re,subprocess,tarfile
root=Path(__file__).parent
assert not (root/'source-delivered.json').exists(), 'Already delivered; inspect state instead of repeating'
required=['full-final','engine-final','types-frozen','lint-final','build-final','browser-final','compatibility']
receipts={name:json.loads((root/(name+'.json')).read_text()) for name in required}
assert all(r['exit_code']==0 for r in receipts.values())
log=(root/'full-final.log').read_text()
assert re.search(r'Tests\s+14875 passed\s*\|\s*2 skipped',log),log[-1000:]
assert re.search(r'Test Files\s+666 passed',log),log[-1000:]
freeze=json.loads((root/'source-freeze.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in freeze.items())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','diff','--check'],check=True)
changed=subprocess.check_output(['git','diff','--name-only','--','src'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],text=True).splitlines()
files=sorted(set(changed+new+['docs/plans/decisions/D04-mind-blast-mana-burn-v1.md']))
assert len(files)==22,files
subprocess.run(['git','add','--',*files],check=True)
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@openai.com','commit','-m','fix(combat): implement Mind Blast Stun and shared Mana Burn'],check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
archive=subprocess.check_output(['git','archive','--format=tar',commit,'--','src','docs/plans/decisions/D04-mind-blast-mana-burn-v1.md'])
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert actual==freeze,{'extra':set(actual)-set(freeze),'missing':set(freeze)-set(actual),'drift':[p for p in actual if actual[p]!=freeze.get(p)]}
report={'commit':commit,'changed_files':files,'frozen_source_files':len(actual),'actual_committed_blobs_exact':True,'required_receipts':receipts,'full_tests':14875,'full_files':666,'existing_skips':2}
(root/'source-delivered.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['changed_files','required_receipts']},indent=2))
