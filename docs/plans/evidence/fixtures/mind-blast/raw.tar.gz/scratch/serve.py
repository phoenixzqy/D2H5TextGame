from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
import os,json
root=Path(__file__).parent
class QuietHandler(SimpleHTTPRequestHandler):
 def log_message(self,*args): pass
(root/('server-'+str(os.getpid())+'.json')).write_text(json.dumps({'pid':os.getpid(),'port':4496})+'\n')
ThreadingHTTPServer(('127.0.0.1',4496),partial(QuietHandler,directory=str(root/'dist-final'))).serve_forever()
