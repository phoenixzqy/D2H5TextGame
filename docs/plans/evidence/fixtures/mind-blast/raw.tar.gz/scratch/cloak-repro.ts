import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { getSkill, loadDefaultSkills, resetRegistry } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import skills from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/assassin.json';
import type { ActiveStatus, CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const id='skills-assassin-cloak-of-shadows', canonical='assassin.cloak_of_shadows';
const hold=(at=0):ActiveStatus=>({id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1,appliedAtMs:at});
resetRegistry();loadDefaultSkills();const observations=[];
for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const levels:Record<string,number>={};
 const add=(key:string)=>{const row=skills.find(s=>s.id===key);assert.ok(row);levels[key]=key===id?rank:1;for(const child of row.prerequisites??[])add(child);};add(id);
 const player={...createMockPlayer('Synthetic Cloak','assassin'),id:'hero',level:30,skillLevels:levels,comboOrder:[id]};
 const native=playerToCombatUnit(player);assert.deepEqual(native.skillOrder,[id]);
 const noCloak=playerToCombatUnit({...player,skillLevels:{...levels,[id]:0}});
 const hero:CombatUnit={...native,life:2000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,statuses:[hold(1701)],
  stats:{...native.stats,lifeMax:2000,manaMax:100,attackSpeed:100,critChance:0}};
 const enemy:CombatUnit={...hero,side:'enemy',kind:'monster',id:'target',skillOrder:[],skillLevels:{},statuses:[hold()],activeBuffIds:[]};
 const input={seed,playerTeam:[hero],enemyTeam:[enemy]},before=structuredClone(input),out=runBattleRecorded(input);
 assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const actions=out.events.filter(e=>e.kind==='action'),statuses=out.events.filter(e=>e.kind==='status'),payments=out.events.filter(e=>e.kind==='mana'&&e.reason==='cast');
 assert.equal(actions.length,1);assert.equal(actions[0]?.kind==='action'&&actions[0].skillId,canonical);assert.equal(payments.length,1);
 assert.equal(out.result.enemyTeam[0]?.life,2000);assert.equal(out.result.playerTeam[0]?.life,2000);
 observations.push({rank,seed,registered:getSkill(id),nativeDefense:native.stats.defense,withoutCloakDefense:noCloak.stats.defense,
  nativeMagicDodge:native.stats.magicDodge,withoutCloakMagicDodge:noCloak.stats.magicDodge,
  actions,payments,statuses,events:out.events,final:{hero:out.result.playerTeam[0],target:out.result.enemyTeam[0]},
  blindEvents:statuses.filter(e=>e.kind==='status'&&e.statusId==='blind').length});
}
writeFileSync('/tmp/d2h5-mind-blast-t1fuehnc/cloak-observations.json',JSON.stringify({synthetic:true,observations},null,2));
console.log(observations.map(({rank,seed,payments,statuses,blindEvents,nativeDefense,withoutCloakDefense})=>({rank,seed,payments,statuses,blindEvents,nativeDefense,withoutCloakDefense})));
assert.ok(observations.every(row=>row.blindEvents>0),'Every real paid Cloak should apply its authored Blind');
