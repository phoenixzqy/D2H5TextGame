from pathlib import Path
import json,hashlib
p=Path(__file__).parent
names=['browser15-en-desktop','browser15-zh-mobile','browser15-zh-desktop','browser15-en-mobile'];pairs=[];geometry=[];screens=[]
for name in names:
 d=p/name;r=json.loads((d/'browser-report.json').read_text());assert len(r['cases'])==1 and not r['failures'];c=r['cases'][0];assert c['pass'] and not c['errors'];assert c['combat'][0]['localizedFreezeChip'] and c['combat'][0]['actualFreezeLog']
 for stage,rank in [('rank1',1),('rank2',2)]:
  b=list(d.glob('*-'+stage+'-before-*.json'));a=list(d.glob('*-'+stage+'-after-*.json'));assert len(b)==len(a)==1
  before=json.loads(b[0].read_text());after=json.loads(a[0].read_text());assert before['version']==after['version']==22
  for domain in ['player','inventory','map','mercs','formation']:assert before[domain]==after[domain],(name,stage,domain)
  assert after['player']['skillLevels']['amazon.freezing_arrow']==rank and after['player']['skillPoints']==2-rank
  assert after['player']['comboOrder']==['skills-amazon-freezing-arrow']
  pairs.append({'case':name,'stage':stage,'exact_domains':['player','inventory','map','mercs','formation'],'before_sha256':hashlib.sha256(b[0].read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(a[0].read_bytes()).hexdigest()})
 assert len(r['geometry'])==5
 for g in r['geometry']:assert g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
 geometry.extend(r['geometry']);screens.extend(str(x.relative_to(p)) for x in sorted(d.glob('*.png')))
result={'cases':4,'pairs':pairs,'geometry':geometry,'screenshots':screens,'synthetic_imports':True,'fixed_combat_Date_now':'2026-10-25T12:30:00Z','probability':0.15,'bridge':'absent','all_exact':True}
out=p/'browser-audit15.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':4,'pairs':len(pairs),'geometry':len(geometry),'screenshots':len(screens),'all_exact':True}))
