from pathlib import Path
import hashlib,json,subprocess,gzip
p=Path(__file__).parent;wd=Path.cwd();frozen=json.loads((p/'frozen-inputs15.json').read_text());expected={**frozen['source'],**frozen['design']}
assert json.loads((p/'full15.json').read_text())['exit_code']==0
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();names=sorted(expected)
r=subprocess.run(['git','cat-file','--batch'],input=''.join(head+':'+n+'\n' for n in names).encode(),capture_output=True,check=True).stdout
index=0
for name in names:
 end=r.index(b'\n',index);header=r[index:end].split();assert len(header)==3 and header[1]==b'blob',name;size=int(header[2]);start=end+1;data=r[start:start+size];assert r[start+size:start+size+1]==b'\n';index=start+size+1
 assert hashlib.sha256(data).hexdigest()==expected[name],('committed blob',name)
 assert hashlib.sha256((wd/name).read_bytes()).hexdigest()==expected[name],('disk',name)
assert index==len(r)
for name,sha in frozen['build'].items():assert hashlib.sha256((p/'production-dist15'/name).read_bytes()).hexdigest()==sha
assert hashlib.sha256(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()==frozen['genuine']
next_source=json.loads((p/'next-impale-final15-source-audit.json').read_text())
for name,sha in next_source['files'].items():assert hashlib.sha256((wd/name).read_bytes()).hexdigest()==sha
out={'head':head,'source_files':len(frozen['source']),'design_files':len(frozen['design']),'build_files':len(frozen['build']),'genuine':frozen['genuine'],'actual_git_blobs_and_disk_exact':True,'next_impale_repro_sources_exact':True}
f=p/'committed-source-audit.json';assert not f.exists();f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
