import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { getSkill, loadDefaultSkills, resetRegistry } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import skills from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/amazon.json';
import type { ActiveStatus, CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const hold=(at=0):ActiveStatus=>({id:'stun',sourceId:'fixture',stacks:1,remaining:-1,appliedAtMs:at});
resetRegistry();loadDefaultSkills();
const cases=[];
const registered=getSkill('amazon.impale');assert.ok(registered);
const declared=skills.find(s=>s.id==='skills-amazon-impale')?.appliesStatus??[];
const represented=registered.effects.flatMap(e=>e.kind==='damage'?(e.applyStatuses??(e.applyStatus?[e.applyStatus]:[])).map(s=>s.id):[]);
for(const rank of [1,20])for(const seed of [7,19,41,97]){
 const levels:Record<string,number>={};
 const add=(id:string)=>{const row=skills.find(s=>s.id===id);if(!row)throw Error('Missing authored prerequisite');levels[id]=id==='skills-amazon-impale'?rank:1;for(const child of row.prerequisites??[])add(child);};
 add('skills-amazon-impale');
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Impale','amazon'),id:'impale-hero',level:30,comboOrder:['skills-amazon-impale'],skillLevels:levels});
 assert.deepEqual(native.skillOrder,['skills-amazon-impale']);
 const hero:CombatUnit={...native,life:2000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,statuses:[hold(1701)],stats:{...native.stats,lifeMax:2000,manaMax:100,attack:100,defense:0,magicResist:0,attackSpeed:100,physDodge:0,magicDodge:0,critChance:0,resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}}};
 const monster:CombatUnit={...hero,id:'impaled-monster',side:'enemy',kind:'monster',tier:'trash',skillOrder:[],skillLevels:{},activeBuffIds:[],statuses:[hold()],stats:{...hero.stats,attackSpeed:80}};
 
 const input={seed,playerTeam:[hero],enemyTeam:[monster]},before=structuredClone(input),r=runBattleRecorded(input);
 assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),r);
 const hits=r.events.filter(e=>e.kind==='damage'&&e.source===hero.id);
 const statuses=r.events.filter(e=>e.kind==='status'&&e.target===monster.id);
 const dots=r.events.filter(e=>e.kind==='dot'&&e.target===monster.id);
 const targetFinalHP=r.result.enemyTeam[0]?.life;
 assert.equal(hits.length,1);assert.ok(hits[0]&&hits[0].kind==='damage');
 assert.equal(r.result.playerTeam[0]?.mana,90);
 cases.push({rank,seed,nativeOrder:native.skillOrder,nativeLevels:levels,hits,statuses,dots,targetFinalHP,finalMana:r.result.playerTeam[0]?.mana});
}
writeFileSync("/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-freezing-arrow-uxt9vj2q/impale-native-observed.json",JSON.stringify({synthetic:true,declared,represented,registered,cases},null,2)+'\n');
assert.ok(cases.some(c=>c.hits.some(h=>h.kind==='damage'&&h.amount>0)),'At least one actual landed native hit');
assert.ok(cases.filter(c=>c.hits.some(h=>h.kind==='damage'&&h.amount>0)).every(c=>c.dots.some(d=>d.kind==='dot'&&d.damage>0)),'Impale advertised Bleed must remove real periodic HP after a landed hit');
