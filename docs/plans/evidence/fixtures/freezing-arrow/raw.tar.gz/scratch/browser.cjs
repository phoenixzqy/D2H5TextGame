const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises'), path = require('node:path'), assert = require('node:assert/strict');
const root=path.join(__dirname,process.env.BROWSER_RUN||'browser-verified'), baseURL='http://127.0.0.1:4487', report={cases:[],geometry:[],failures:[]};let serial=0;
async function nav(page,route){await page.locator(`a[href="/${route}"]`).first().click();await expect(page.getByTestId(`${route}-screen`)).toBeVisible();}
async function exported(page,label){const pending=page.waitForEvent('download');await page.getByTestId('export-save-button').click();const download=await pending,target=path.join(root,`${label}-${++serial}.json`);await download.saveAs(target);return JSON.parse(await fs.readFile(target,'utf8'));}
function domains(save){return Object.fromEntries(['player','inventory','map','mercs','formation'].map(key=>[key,save[key]]));}
async function pair(page,context,locale,label){await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');const before=await exported(page,label+'-before');assert.equal(before.version,22);await page.close();page=await context.newPage();await page.goto(baseURL,{waitUntil:'networkidle'});await expect(page.getByTestId('home-continue')).toBeEnabled();await page.getByTestId('home-continue').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');const after=await exported(page,label+'-after');assert.deepEqual(domains(before),domains(after));return {page,save:after};}
async function geometry(page,label){const original=page.viewportSize();for(const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]){await page.mouse.move(1,1);await page.setViewportSize({width,height});const button=page.getByTestId('skill-detail-panel').getByRole('button');await button.scrollIntoViewIfNeeded();const box=await button.boundingBox();const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);assert.ok(overflow<=0);assert.ok(box&&box.width>=44&&box.height>=44);report.geometry.push({label,width,height,overflow,allocate:box});}await page.mouse.move(1,1);await page.setViewportSize(original);await page.mouse.move(1,1);}
async function fight(page,locale,label,heroId){
 await page.clock.setFixedTime(new Date('2026-10-25T12:30:00Z'));
 await nav(page,'map');await page.getByTestId('sub-area-row-a1-catacombs').getByRole('button',{name:locale==='en'?'Enter':'进入',exact:true}).click();await expect(page.getByTestId('combat-screen')).toBeVisible();
 const auto=page.getByRole('checkbox');if(await auto.isChecked())await auto.uncheck();
 const name=locale==='en'?'Freeze':'冻结';
 await expect(page.getByTestId('combat-log')).toContainText(name,{timeout:20000});
 const chip=page.locator('[data-testid^="unit-card-"]').filter({has:page.getByTestId('unit-effect-chips').getByText(name,{exact:true})}).first();
 await expect(chip).toBeVisible();
 await page.getByRole('button',{name:locale==='en'?'Pause':'暂停',exact:true}).click();
 const text=await page.getByTestId('combat-log').innerText();
 const lifePercent=await page.getByTestId('unit-card-'+heroId).locator('div.bg-red-600').evaluate(el=>Number.parseFloat(el.style.width));
 assert.ok(lifePercent>0);
 await fs.writeFile(path.join(root,label+'-combat.json'),JSON.stringify({text,lifePercent,localizedFreezeChip:true},null,2));
 await page.mouse.move(1,1);await page.screenshot({path:path.join(root,label+'-combat.png'),fullPage:true});
 await chip.scrollIntoViewIfNeeded();await page.mouse.move(1,1);await page.screenshot({path:path.join(root,label+'-freeze-visible.png')});
 await page.getByRole('button',{name:locale==='en'?'Flee':'逃跑',exact:true}).click();await expect(page.getByTestId('map-screen')).toBeVisible();
 return {lifePercent,localizedFreezeChip:true,actualFreezeLog:true};
}
(async()=>{await fs.mkdir(root,{recursive:true});const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});try{
for(const locale of [process.env.BROWSER_LOCALE])for(const viewport of [{width:Number(process.env.BROWSER_WIDTH),height:process.env.BROWSER_WIDTH==='360'?640:800}]){
 const label=`${locale}-${viewport.width}`,context=await browser.newContext({viewport,locale,acceptDownloads:true}),errors=[];context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));let page=await context.newPage();const result={label,errors,pairs:[],combat:[]};await context.tracing.start({screenshots:true,snapshots:true,sources:false});
 try{
 await page.goto(baseURL,{waitUntil:'networkidle'});assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');await page.getByTestId('home-new-game').click();await page.getByTestId('class-amazon').click();await page.getByTestId('character-name-input').fill('FreezeCheck');await page.getByTestId('character-start-btn').click();await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();const fresh=await exported(page,label+'-fresh');
 const cap={id:'synthetic-freezing-arrow-browser-cap',baseId:'items/base/helm-cap',rarity:'rare',level:1,socketCapacity:0,identified:true,equipped:true,affixes:[{affixId:'fixture-imported',values:[['statMods.life',50000],['statMods.mana',50000],['statMods.attack',0],['statMods.defense',-1000],['statMods.attackSpeed',0]]}]};
 const levels={'amazon.cold_arrow':1,'amazon.ice_arrow':1,'amazon.freezing_arrow':1};
 const constructed={...fresh,player:{...fresh.player,level:30,skillPoints:1,skillLevels:levels,comboOrder:['skills-amazon-freezing-arrow']},inventory:{...fresh.inventory,equipped:{helm:cap}}};
 await fs.writeFile(path.join(root,label+'-synthetic-input.json'),JSON.stringify(constructed,null,2));await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(constructed));await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();await expect(dialog).toHaveCount(0);const imported=await exported(page,label+'-imported');assert.deepEqual(imported.player.skillLevels,levels);
 let continued=await pair(page,context,locale,label+'-rank1');page=continued.page;assert.deepEqual(continued.save.player.skillLevels,levels);result.pairs.push('rank1');
 await nav(page,'skills');await page.mouse.move(1,1);await page.getByTestId('skill-node-skills-amazon-freezing-arrow').click();const panel=page.getByTestId('skill-detail-panel');
 await expect(panel.getByRole('heading',{level:2})).toHaveText(locale==='en'?'Freezing Arrow':'冰冻箭');
 for(const text of ['3×3','15%',locale==='en'?'Chill for 2 seconds':'冰冷持续2秒',locale==='en'?'Freeze for 1 second':'冰冻持续1秒','0.5'])await expect(panel).toContainText(text);
 await expect(panel).not.toContainText(locale==='en'?'cone':'锥形');
 await expect(panel).toContainText('50 ~ 70');await expect(panel).toContainText('55 ~ 75');await expect(panel).not.toContainText('{{');
 await geometry(page,label);await panel.getByRole('button').click();await expect(panel.getByRole('button')).toBeDisabled();await panel.scrollIntoViewIfNeeded();await page.mouse.move(1,1);await page.screenshot({path:path.join(root,label+'-details.png')});await panel.locator('p').first().scrollIntoViewIfNeeded();await page.screenshot({path:path.join(root,label+'-description.png')});
 await panel.getByText(locale==='en'?'Prerequisites':'前置技能',{exact:true}).scrollIntoViewIfNeeded();await page.mouse.move(1,1);await page.screenshot({path:path.join(root,label+'-details-lower.png')});
 await page.getByRole('tab',{name:locale==='en'?'Active Skills':'主动技能',exact:true}).click();
 await page.getByTestId('skills-active-panel').getByRole('combobox').first().selectOption({label:locale==='en'?'Freezing Arrow':'冰冻箭'});
 result.combat.push(await fight(page,locale,label,constructed.player.id));
 continued=await pair(page,context,locale,label+'-rank2');page=continued.page;assert.equal(continued.save.player.skillPoints,0);assert.deepEqual(continued.save.player.skillLevels,{'amazon.cold_arrow':1,'amazon.ice_arrow':1,'amazon.freezing_arrow':2});assert.deepEqual(continued.save.player.comboOrder,['skills-amazon-freezing-arrow']);assert.ok(!JSON.stringify(continued.save).includes('freezingArrowRank'));result.pairs.push('rank2');assert.deepEqual(errors,[]);result.pass=true;await context.tracing.stop();console.log(label+' PASS');
 }catch(error){result.pass=false;result.error=String(error.stack||error);report.failures.push(label);await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});throw error;}finally{report.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(report,null,2));await context.close();}
}
}finally{await browser.close();}assert.equal(report.cases.length,1);assert.deepEqual(report.failures,[]);console.log('One terminal browser case passes.');})().catch(error=>{console.error(error);process.exitCode=1;});
