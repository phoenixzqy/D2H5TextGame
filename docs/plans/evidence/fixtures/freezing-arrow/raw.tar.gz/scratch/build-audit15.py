import re,json,pathlib,hashlib
from urllib.parse import unquote
p=pathlib.Path(__file__).parent
d=p/'production-dist15'
patterns=[r'__GAME__',r'\bseedItem\b',r'\bseedMerc\b',r'\binstallTestBridge\b',r'[,{]flushSave:']
chunks=list((d/'assets').glob('*.js'))
violations=[{'chunk':f.name,'pattern':pattern} for f in chunks for pattern in patterns if re.search(pattern,f.read_text())]
assert chunks and not violations,violations
refs=re.findall(r'\{url:"([^"]+)"', (d/'sw.js').read_text())
missing=[x for x in refs if not (d/unquote(x)).is_file()]
assert len(refs)==756 and not missing,missing
result={'chunks':[{'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in chunks],
        'forbidden_patterns':patterns,'violations':violations,'precache_references':len(refs),'missing':missing}
out=p/'build-audit15.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
