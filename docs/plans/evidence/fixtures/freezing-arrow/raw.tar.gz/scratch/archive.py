from pathlib import Path
import tarfile,hashlib,json
p=Path(__file__).parent;wd=Path.cwd();out=wd/'docs/plans/evidence/fixtures/freezing-arrow';assert not out.exists()
assert json.loads((p/'full15.json').read_text())['exit_code']==0
assert json.loads((p/'committed-source-audit.json').read_text())['actual_git_blobs_and_disk_exact']
# Full asset bytes are reproducible from frozen source and retained complete hash maps.
files=[f for f in sorted(p.rglob('*')) if f.is_file() and f.relative_to(p).parts[0] not in ['production-dist','production-dist15']]
assert all(not f.is_symlink() and f.resolve().is_relative_to(p.resolve()) for f in files)
receipts=[];members=[]
for f in files:
 rel=str(f.relative_to(p));data=f.read_bytes();members.append({'path':'scratch/'+rel,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 if f.suffix=='.json':
  try:r=json.loads(data)
  except (ValueError,UnicodeDecodeError):continue
  if isinstance(r,dict) and 'command' in r and 'exit_code' in r:receipts.append({'path':'scratch/'+rel,'exit_code':r['exit_code']})
out.mkdir(parents=True)
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in files:t.add(f,arcname='scratch/'+str(f.relative_to(p)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert sorted(t.getnames())==sorted(m['path'] for m in members)
 for m in members:
  f=t.extractfile(m['path']);assert f is not None;data=f.read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
packet={'root':str(p),'members':members,'terminal_receipts':receipts,'member_hashes_verified':True,'raw_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'build_hash_maps':{'production-dist':'scratch/frozen-inputs.json','production-dist15':'scratch/frozen-inputs15.json'},'final_evidence':['browser-audit15.json','visual-review15.json','full15.json','post-full-freeze-audit15.json','committed-source-audit.json'],'superseded_draft10_evidence_retained':True,'next_impale_reproduction_credit':False}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
(out/'committed-source-audit.json').write_bytes((p/'committed-source-audit.json').read_bytes())
(out/'inventory-reconciliation.json').write_bytes((p/'inventory-reconciliation.json').read_bytes())
print(json.dumps({'raw_members':len(members),'terminal_receipts':len(receipts),'hashes_verified':True,'archive_bytes':archive.stat().st_size}))
