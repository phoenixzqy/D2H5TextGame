from pathlib import Path
import csv,json,io,collections,hashlib,subprocess
p=Path(__file__).parent;target=Path('docs/plans/skill-inventory.csv')
assert json.loads((p/'full15.json').read_text())['exit_code']==0
before=target.read_bytes();rows=list(csv.DictReader(io.StringIO(before.decode())));fields=list(rows[0]);old={r['data_id']:dict(r) for r in rows}
assert len(rows)==len(old)==213
for row in rows:
 if row['data_id']=='skills-amazon-freezing-arrow':
  assert row['behavior_verification']=='unverified'
  row.update(adapter_route='damage+explicit-secondary-freeze',risk_flags='independent-design-qa-and-earned-balance-open',behavior_verification='bounded-functional;independent-acceptance-open',contract_evidence='docs/plans/decisions/D04-freezing-arrow-v1.md;docs/plans/evidence/d04-freezing-arrow.md;production/bugs/BUG-201-freezing-arrow-unreachable-freeze.md')
 if row['data_id']=='skills-amazon-impale':
  assert row['behavior_verification']=='unverified'
  row.update(risk_flags='dot-strength-metadata-missing;defense-bypass-description-contradiction',contract_evidence='docs/plans/evidence/d04-impale-repro.md;docs/plans/decisions/D04-impale-v1.md;production/bugs/BUG-202-impale-inert-bleed-and-defense.md')
changed=[r['data_id'] for r in rows if r!=old[r['data_id']]];credits=[r['data_id'] for r in rows if r['behavior_verification']!=old[r['data_id']]['behavior_verification']]
assert changed==['skills-amazon-freezing-arrow','skills-amazon-impale'] and credits==['skills-amazon-freezing-arrow']
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':111,'bounded-functional':100,'bounded-engine-functional':1,'review-needed':1},counts
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);target.write_bytes(out.getvalue().encode())
after=list(csv.DictReader(io.StringIO(target.read_text())));assert [r['data_id'] for r in after]==list(old)
report={'total':len(rows),'ids_and_order_preserved':True,'changed_rows':changed,'credited_rows':credits,'counts':counts,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'independent_earned_acceptance':'open'}
f=p/'inventory-reconciliation.json';assert not f.exists();f.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
