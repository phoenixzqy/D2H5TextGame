import pathlib, subprocess, hashlib, json, sys, gzip
p=pathlib.Path(__file__).parent
wd=pathlib.Path.cwd()
assert wd==pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
def digest(file):return hashlib.sha256(file.read_bytes()).hexdigest()
source={name:digest(wd/name) for name in sorted(set(names)) if name and (wd/name).is_file() and
        (name.startswith(('src/','tests/','scripts/')) or '/' not in name and name.endswith(('.ts','.js','.mjs','.cjs','.json')))}
build={str(f.relative_to(p/'production-dist')):digest(f) for f in sorted((p/'production-dist').rglob('*')) if f.is_file()}
genuine=hashlib.sha256(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
assert genuine=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577'
value={'source':source,'build':build,'genuine':genuine,'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),
       'scope':'source/build/genuine/HEAD; task evidence outputs excluded from Git status equality'}
if sys.argv[1]=='before':
 out=p/'frozen-inputs-verified.json';assert not out.exists();out.write_text(json.dumps(value,indent=2)+'\n')
else:
 before=json.loads((p/'frozen-inputs-verified.json').read_text());assert value==before,'Frozen input drift'
 out=p/'post-full-freeze-audit-verified.json';assert not out.exists();out.write_text(json.dumps({'source_files':len(source),'build_files':len(build),'genuine':genuine,'head':value['head'],'all_exact':True},indent=2)+'\n')
print(json.dumps({'source_files':len(source),'build_files':len(build),'genuine':genuine,'all_exact':True}))
