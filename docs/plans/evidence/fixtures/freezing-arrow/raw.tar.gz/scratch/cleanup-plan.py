from pathlib import Path, PurePosixPath
import hashlib,json,socket,tarfile
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-freezing-arrow-uxt9vj2q')
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=wd/'docs/plans/evidence/fixtures/freezing-arrow'
packet=json.loads((out/'packet.json').read_text())
assert packet['root']==str(root) and root.is_dir() and not root.is_symlink()
assert hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest()==packet['raw_archive_sha256']
expected={}
with tarfile.open(out/'raw.tar.gz','r:gz') as archive:
    assert sorted(archive.getnames())==sorted(m['path'] for m in packet['members'])
    for m in packet['members']:
        rel=PurePosixPath(m['path']);assert rel.parts[0]=='scratch' and '..' not in rel.parts
        data=archive.extractfile(m['path']).read()
        assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
        expected[str(PurePosixPath(*rel.parts[1:]))]=m['sha256']
for build,mapfile in [('production-dist','frozen-inputs.json'),('production-dist15','frozen-inputs15.json')]:
    frozen=json.loads((root/mapfile).read_text())['build']
    for name,digest in frozen.items():
        p=Path(name)
        rel=p.relative_to(root) if p.is_absolute() else Path(build)/p
        # Frozen maps use names relative to their build root.
        if rel.parts[0]!=build: rel=Path(build)/rel
        assert '..' not in rel.parts
        assert str(rel) not in expected
        expected[str(rel)]=digest
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==set(expected),{'unexpected':sorted(actual-set(expected)),'missing':sorted(set(expected)-actual)}
paths=list(root.rglob('*'));assert all(not p.is_symlink() and p.resolve().is_relative_to(root.resolve()) for p in paths)
for rel,digest in expected.items():assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
for pid in (807924,851573):assert not Path(f'/proc/{pid}').exists(),pid
for port in (4487,4488):
    with socket.socket() as s:
        s.settimeout(.2);assert s.connect_ex(('127.0.0.1',port))!=0,port
for rel in sorted(expected):(root/rel).unlink()
for p in sorted([p for p in paths if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
root.rmdir();assert not root.exists()
receipt={'root':str(root),'archive_members_verified':len(packet['members']),'removed_exact_files':len(expected),'root_absent':not root.exists(),'owned_pids_absent':[807924,851573],'owned_ports_closed':[4487,4488],'remaining':[],'failures':[],'older_roots_and_shared_caches':'preserved'}
(out/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
