from pathlib import Path
import subprocess,sys,time,json,datetime,os,signal
raw=Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
t0=time.monotonic(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
signals=[]; timeout=False
with (raw/(name+'.log')).open('w') as out:
    proc=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
    (raw/(name+'.process.json')).write_text(json.dumps({'pid':proc.pid,'pgid':proc.pid,'command':command,'owner':'root'})+'\n')
    try: proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        timeout=True; signals.append({'signal':'SIGTERM','pgid':proc.pid});os.killpg(proc.pid,signal.SIGTERM)
        try: proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            signals.append({'signal':'SIGKILL','pgid':proc.pid});os.killpg(proc.pid,signal.SIGKILL);proc.wait()
meta={'command':command,'cwd':str(Path.cwd()),'started':start,'seconds':round(time.monotonic()-t0,3),'exitCode':proc.returncode,'pid':proc.pid,'deadlineSeconds':30,'cleanupGraceSeconds':2,'timeout':timeout,'signals':signals}
(raw/(name+'.meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta));sys.exit(124 if timeout else proc.returncode)
