import type { RestoredModeAttempt } from './mode-adapter';
export interface ModeWaveComparison {
  readonly position: number;
  readonly firstIndex: number | null;
  readonly secondIndex: number | null;
  readonly combatInputsEqual: boolean | null;
  readonly rawBattleOutputsEqual: boolean | null;
  readonly presentationEqual: boolean | null;
  readonly determinism: 'matched' | 'mismatch' | 'different-inputs' | 'unpaired';
}
type Coverage = 'exercised' | 'unexercised';
export interface RestoredModeComparison {
  readonly sourceIdentityEqual: boolean;
  readonly restoredBaselineEqual: boolean;
  readonly runIdentityEqual: boolean;
  readonly waveComparisons: readonly ModeWaveComparison[];
  readonly rawCombatObservationsEqual: boolean;
  readonly rawPityObservationsEqual: boolean;
  readonly rawRewardsEqual: boolean;
  readonly semanticRewardsIgnoringOnlyTopLevelItemIdEqual: boolean;
  readonly rawDomainObservationsEqual: boolean;
  readonly logicalUiTimingsEqual: boolean;
  readonly fullRawObservationEqual: boolean;
  readonly itemIdentityAssessment: 'equal' | 'different' | 'unexercised';
  readonly battlePathCoverage: { readonly first: Coverage; readonly second: Coverage };
  readonly rewardPathCoverage: { readonly first: Coverage; readonly second: Coverage };
}
/** Compare closed native observations without rerunning or normalizing their inputs. */
export function compareRestoredModes(_first: RestoredModeAttempt, _second: RestoredModeAttempt): RestoredModeComparison {
  throw new Error('P02b05b02a comparator is not implemented');
}
