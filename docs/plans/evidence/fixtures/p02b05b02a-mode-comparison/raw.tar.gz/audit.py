from pathlib import Path
import hashlib,json,collections
raw=Path(__file__).parent
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
hashbytes=lambda b:hashlib.sha256(b).hexdigest()
def tree(manifest, overrides, prefix=''):
 h=hashlib.sha256(b'd2h5-file-entries-v1\0')
 for m in manifest:
  if not m['path'].startswith(prefix):continue
  data=overrides.get(m['path'],(w/m['path']).read_bytes())
  assert len(data)==m['byteLength'] and hashbytes(data)==m['sha256'],m['path']
  h.update(json.dumps([m['path'],len(data)],separators=(',',':')).encode());h.update(data)
 return h.hexdigest()
identity=['sourceSha','sourceTreeHash','dataHash','nodeVersion','vitestVersion','manifest','collectionPolicy']
rows=[]
for name in ['red-boundary','green-first','green-final']:
 v=json.loads((raw/(name+'.observations.json')).read_text())['attempts']
 overrides={}
 if name!='green-final':overrides['tests/sim/production/mode-comparison.test.ts']=(raw/'mode-comparison.test.ts').read_bytes()
 if name=='red-boundary':overrides['tests/sim/production/mode-comparison.ts']=(raw/'boundary.ts').read_bytes()
 first=v[0]['sourceBefore']
 for a in v:
  for key in ['sourceBefore','sourceAfter']:
   s=a[key];assert {k:s[k] for k in identity}=={k:first[k] for k in identity}
   assert tree(s['manifest'],overrides)==s['sourceTreeHash'];assert tree(s['manifest'],overrides,'src/data/')==s['dataHash']
  assert a['options'] in [{'mode':m,'idleEliteMisses':n} for n in [0,11] for m in ['manual','idle']]
  assert [x['advanceResult'] for x in a['waves']]==['next-wave','defeat']
  assert a['terminal']['map']['clearedSubAreas']==[]
 for i,j,expected in [(0,1,[True,True]),(2,3,[False,False])]:
  a,b=v[i],v[j];assert a['baseline']==b['baseline'];assert a['baselineCombat']==b['baselineCombat']
  results=[]
  for x,y in zip(a['waves'],b['waves']):
   seed=lambda attempt,wave:(attempt['handle']['runSeed'] ^ ((wave['index']+1)*0x9e3779b1))&0xffffffff
   inputs=seed(a,x)==seed(b,y) and all(x['opening'][k]==y['opening'][k] for k in ['playerTeam','enemyTeam'])
   outputs=all(x['opening'][k]==y['opening'][k] for k in ['recordedEvents','outcome','log']) and all(x['played'][k]==y['played'][k] for k in ['playerTeam','enemyTeam','eventCursor','playbackComplete','log']) and all(x[k]==y[k] for k in ['advanceResult','terminalSimClockMs'])
   if inputs:assert outputs
   results.append(inputs)
  assert results==expected
 rows.append({'dataset':name,'attempts':4,'playedBattles':8,'manifestEntries':len(first['manifest']),'sourceStates':8,'sourceSha':first['sourceSha'],'sourceTreeHash':first['sourceTreeHash'],'inputEqualities':[[True,True],[False,False]],'clears':0})
for f,h in json.loads((raw/'preserved-baseline.json').read_text()).items():assert hashbytes((w/f).read_bytes())==h
assert hashbytes((w/'tests/sim/production/mode-comparison.test.ts').read_bytes())=='68da6bd46f0cf4b54a5c5f5608c252895f17e295778a31fddcd7e72b81efd7fc'
result={'preservedHashes':27,'observationAudits':rows,'implementationSha256':hashbytes((w/'tests/sim/production/mode-comparison.ts').read_bytes()),'amendedTestSha256':hashbytes((w/'tests/sim/production/mode-comparison.test.ts').read_bytes())}
(raw/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
