# Next family reconnaissance — read-only, not acceptance or a reproduced bug

2026-10-25 at Druid runtime HEAD 06c9f50; no Paladin source edits, tests or gameplay runs.

Inventory has ten unverified Paladin actives and twenty bounded auras. Prioritize one coherent active-family audit rather than assuming all ten need the same repair.

Observed current source:

- `src/engine/skills/dataCatalog.ts:133-175` forwards only the first primary status generally. Its secondary-status whitelist supports specific cold attacks/Freeze metadata/Meteor armor melt, so Vengeance's authored three-status list does not get general preservation. The generic damage adapter emits one `damageType` plus min/max and never reads `damage.breakdown` here. Vengeance JSON authors equal Fire/Cold/Lightning breakdown but `damageType: fire`. Need native causal reproduction of all three actual components and statuses, including payment/rank/mitigation/miss/refresh/kill boundaries; do not infer success from tags.
- `src/data/skills/paladin.json` Holy Shield advertises authored per-rank defensePct .04 and shieldAbsorbPct .02; adapter self-buff branch attaches an ordinary permanent named buff with no Holy Shield mechanics discriminator. Need native reproduction and an explicit contract for absorb meaning/lifecycle before implementation.
- English Holy Bolt copy promises 50% dealt-damage healing; its current JSON lacks `onHitRecovery`. Shared on-hit recovery already exists for Druid sustain and might be reusable after a proper contract/reproduction.
- Blessed Hammer English copy promises ignoring magic resistance; JSON is ordinary Arcane damage. Need verify actual effective mitigation and authored intent rather than only cast existence.
- Sacrifice copy promises caster damage; authored row has ordinary physical damage and no self-damage metadata. Need reproduce and specify actual-HP/payment/lethal/ordering boundaries explicitly in JSON.
- Conversion copy promises temporary allied fighting; JSON applies `converted` on a Physical hit. Source search in combat.ts found no explicit conversion branch; inspect shared status/targeting/AI and reproduce before filing or choosing semantics.
- Zeal copy promises a flurry/up to3 nearby enemies, while JSON targets `area-enemies` with `cross`. Reconcile actual non-spatial formation targeting and number/sequence before credit. Charge/Smite/Fist of Heavens have ordinary authored Stun/Paralyze consumers but are still individually unverified.

No new bug number claimed. These are source-supported investigation leads, not new runtime proof, implementation, design approval or inventory credit. Druid packet completion first. Root sole writer; preserve existing worktree/branch/claim and genuine Ancients save; no agents, remote or genuine campaign actions.
