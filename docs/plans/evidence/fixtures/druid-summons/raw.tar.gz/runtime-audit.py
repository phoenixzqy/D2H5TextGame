import pathlib,subprocess,hashlib,json,gzip,re,sys
w=pathlib.Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
s=pathlib.Path(__file__).parent
build=s/'runtime-dist'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=w)
def maps():
 paths=git('ls-files','--cached','--others','--exclude-standard','-z').decode().split('\0')
 sources={p:sha(w/p) for p in sorted(set(paths)) if p and (w/p).is_file() and (p.startswith(('src/','tests/','scripts/')) or ('/' not in p and pathlib.Path(p).suffix in ['.ts','.js','.mjs','.cjs','.json']))}
 binaries={str(p.relative_to(build)):sha(p)for p in sorted(build.rglob('*'))if p.is_file()}
 genuine=w/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz'
 digest=hashlib.sha256(gzip.decompress(genuine.read_bytes())).hexdigest()
 assert digest=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577'
 return {'sources':sources,'build':binaries,'genuine':{'compressed':sha(genuine),'decompressed':digest},'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain').decode()}
mode=sys.argv[1]
if mode=='freeze':
 p=s/'runtime-freeze.json';assert not p.exists();p.write_text(json.dumps(maps(),indent=2)+'\n')
 chunks=list((build/'assets').glob('*.js'));assert chunks
 forbidden=[r'__GAME__',r'\bseedItem\b',r'\bseedMerc\b',r'\binstallTestBridge\b',r'[,{]flushSave:']
 violations=[{'chunk':p.name,'pattern':pattern}for p in chunks for pattern in forbidden if re.search(pattern,p.read_text())]
 refs=re.findall(r'\{url:"([^"]+)",revision:',(build/'sw.js').read_text())
 missing=[p for p in refs if not (build/p).is_file()]
 assert not violations and not missing and len(refs)==756,(violations,missing,len(refs))
 report={'chunks':[p.name for p in chunks],'bridgeViolations':violations,'precacheReferences':len(refs),'missing':missing,'sourceFiles':len(maps()['sources']),'buildFiles':len(maps()['build'])}
 p=s/'runtime-build-audit.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
elif mode=='verify':
 original=json.loads((s/'runtime-freeze.json').read_text());current=maps();assert original==current
 report={'sources':len(current['sources']),'build':len(current['build']),'genuine':current['genuine'],'head':current['head'],'drift':[]}
 p=s/'runtime-post-full-audit.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
elif mode=='committed':
 original=json.loads((s/'runtime-freeze.json').read_text());mismatches=[]
 for rel,expected in original['sources'].items():
  actual=hashlib.sha256(git('show','HEAD:'+rel)).hexdigest()
  if actual!=expected or sha(w/rel)!=expected:mismatches.append(rel)
 assert not mismatches,mismatches
 report={'head':git('rev-parse','HEAD').decode().strip(),'sourceBlobs':len(original['sources']),'mismatches':mismatches}
 p=s/'runtime-committed-audit.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
else:raise ValueError(mode)
