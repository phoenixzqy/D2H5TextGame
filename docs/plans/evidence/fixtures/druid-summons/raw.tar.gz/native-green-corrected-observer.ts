import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
import { useInventoryStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/inventoryStore';
import { useMapStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/mapStore';
import { useFormationStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/formationStore';
useInventoryStore.getState().reset();useMapStore.getState().reset();useFormationStore.getState().reset();
const cases=[
 {slug:'raven',template:'raven',costs:[6,4],prerequisites:[],promise:'blind'},
 {slug:'poison-creeper',template:'poison_creeper',costs:[8,6],prerequisites:[],promise:'poison'},
 {slug:'carrion-vine',template:'carrion_vine',costs:[14,11],prerequisites:['poison-creeper'],promise:'life'},
 {slug:'solar-creeper',template:'solar_creeper',costs:[18,15],prerequisites:['poison-creeper','carrion-vine'],promise:'mana'}
] as const;
const canonical=(slug:string)=>'druid.'+slug.replaceAll('-','_');
const rows:unknown[]=[],failures:string[]=[];
for(const c of cases)for(const [i,rank]of [1,20].entries()){
 const id=canonical(c.slug),player={...createMockPlayer('Native summon repro','druid'),id:'hero',level:30,
  skillLevels:{...Object.fromEntries(c.prerequisites.map(s=>[canonical(s),1])),[id]:rank},comboOrder:['skills-druid-'+c.slug]};
 const native=playerToCombatUnit(player);
 const hero:CombatUnit={...native,life:500,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,manaRegenCarry:0,manaRegenCompensation:0,manaRegenExactCarry:'0',
  stats:{...native.stats,life:10000,lifeMax:10000,mana:1000,manaMax:1000,attack:1,defense:0,critChance:0},
  statuses:[{id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1}]};
 const targets=[1,1000000].map((life,index):CombatUnit=>({...hero,id:'enemy-'+index,name:'Held target '+index,side:'enemy',kind:'monster',life,mana:0,
  stats:{...hero.stats,life,lifeMax:life,attack:0,defense:0,magicResist:0,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}},skillOrder:[],skillLevels:{},
  statuses:[{id:'stun',sourceId:'synthetic-isolation',stacks:1,remaining:-1}]}));
 const input={seed:7,playerTeam:[hero],enemyTeam:targets},before=structuredClone(input),r=runBattleRecorded(input);
 const spawned=r.events.filter(e=>e.kind==='summon'),paid=r.events.filter(e=>e.kind==='mana'&&e.target===hero.id&&e.reason==='cast');
 const ownHits=r.events.filter(e=>e.kind==='damage'&&e.source.startsWith('hero-summon-')&&e.amount>0);
 const hpOrb=r.events.filter(e=>e.kind==='orb'&&e.target===hero.id&&e.orb.kind==='hp').length*500;
 const mpOrb=r.events.filter(e=>e.kind==='orb'&&e.target===hero.id&&e.orb.kind==='mp').length*50;
 const final=r.result.playerTeam.find(u=>u.id===hero.id);assert.ok(final);
 assert.deepEqual(native.skillOrder,['skills-druid-'+c.slug]);
 assert.equal(spawned.length,c.slug==='raven'&&rank===20?8:1);
 assert.equal(paid.length,1);assert.deepEqual(paid[0],{kind:'mana',target:hero.id,mana:100-(c.costs[i]??0),reason:'cast',simClockMs:0,uiDelayMs:50});
 assert.ok(ownHits.length>0,'Actual summon must deal positive damage');
 assert.ok(r.events.some(e=>e.kind==='death'&&e.target==='enemy-0'),'An actual primary monster death supplies a body');
 assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),r);
 const netLife=final.life-hero.life-hpOrb,netMana=final.mana-(hero.mana-(c.costs[i]??0))-mpOrb;
 const blind=r.events.filter(e=>e.kind==='status'&&(e.statusId==='blind'||e.statusId==='dim-vision'));
 const poison=r.events.filter(e=>e.kind==='dot'&&e.target==='enemy-1'&&e.amount>0);
 const typedPoison=r.events.some(e=>e.kind==='status-state'&&e.target==='enemy-1'&&e.statuses.some(s=>s.id==='poison'&&s.damageType==='poison'&&(s.dotPerStack??0)>0));
 if(c.promise==='poison'){assert.ok(typedPoison);const direct=r.events.reduce((sum,e)=>sum+(e.kind==='damage'&&e.target==='enemy-1'?e.amount:0),0),periodic=poison.reduce((sum,e)=>sum+(e.kind==='dot'?e.amount:0),0);assert.ok(periodic>0);assert.equal(r.result.enemyTeam.find(u=>u.id==='enemy-1')?.life,1000000-direct-periodic);}
 const consumed=r.events.filter(e=>e.kind==='message'&&e.messageKey.startsWith('combat:corpses.consumed'));
 const actual=c.promise==='blind'?blind.length>0:c.promise==='poison'?poison.length>0:c.promise==='life'?netLife>0&&consumed.length>0:netMana>0&&consumed.length>0;
 rows.push({slug:c.slug,rank,nativeSkillOrder:native.skillOrder,spawns:spawned.length,payment:paid,positiveSummonHits:ownHits.length,blindEvents:blind.length,positivePoisonEvents:poison.length,consumedCorpseEvents:consumed.length,initialHero:{life:hero.life,mana:hero.mana},finalHero:{life:final.life,mana:final.mana},hpFromOrbs:hpOrb,mpFromOrbs:mpOrb,netLifeBeyondOrbs:netLife,netManaBeyondOrbs:netMana,promisedEffectPass:actual,events:r.events});
 if(!actual)failures.push(c.slug+' rank'+rank+' promised '+c.promise+' effect absent');
}
writeFileSync(new URL('./native-green-corrected-observer-result.json',import.meta.url),JSON.stringify({seed:7,scope:'Synthetic L30 native eligibility, ordinary one paid preparation, held hero/enemies, one actual primary monster death, immutable replay; ordinary orb HP/MP explicitly subtracted; no earned campaign proof.',rows,failures},null,2)+'\n');
console.log(JSON.stringify(rows.map((r)=>{const {events,...summary}=r as {events:unknown};return summary}),null,2));
assert.deepEqual(failures,[],failures.join('; '));
