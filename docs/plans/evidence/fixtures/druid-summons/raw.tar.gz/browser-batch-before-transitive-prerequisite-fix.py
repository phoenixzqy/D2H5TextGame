import subprocess,pathlib,sys
s=pathlib.Path(__file__).parent
for locale,width in [('en','1280'),('en','360'),('zh-CN','1280'),('zh-CN','360')]:
 label='browser-observed-'+locale+'-'+width
 print('Running '+label,flush=True)
 subprocess.run(['python3',str(s/'run.py'),label,'env','BROWSER_RUN='+label,'BROWSER_LOCALE='+locale,'BROWSER_WIDTH='+width,'python3','.github/skills/webapp-testing/scripts/with_server.py','--server','exec python3 '+str(s/'serve.py'),'--port','4481','--','node',str(s/'browser-current.cjs')],check=True)
 print('Finished '+label,flush=True)
