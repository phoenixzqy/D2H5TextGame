from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import functools
root=Path(__file__).parent/'presentation-dist'
class Handler(SimpleHTTPRequestHandler):
 def do_GET(self):
  if not (root/self.path.split('?')[0].lstrip('/')).is_file(): self.path='/index.html'
  super().do_GET()
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  super().end_headers()
ThreadingHTTPServer(('127.0.0.1',4481),functools.partial(Handler,directory=str(root))).serve_forever()
