from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
s=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for p in sorted(s.rglob('*-failed-trace.zip')):
 output=p.with_name(p.stem+'-diagnostics.zip');assert not output.exists()
 with ZipFile(p)as source:
  names=source.namelist();last={}
  for n in names:
   if n.startswith('resources/page@')and n.endswith('.jpeg'):
    page=n.rsplit('-',1)[0]
    if page not in last or n>last[page]:last[page]=n
  retained={'trace.trace','trace.network','trace.stacks',*last.values()}
  assert retained.issubset(set(names))
  members=[]
  with ZipFile(output,'w',compression=ZIP_DEFLATED,compresslevel=9)as target:
   for n in names:
    data=source.read(n)
    members.append({'name':n,'bytes':len(data),'sha256':sha(data),'retained':n in retained})
    if n in retained:target.writestr(n,data)
 with ZipFile(output)as z:
  assert set(z.namelist())==retained
  for row in members:
   if row['retained']:assert sha(z.read(row['name']))==row['sha256']
 manifest={'original':str(p.relative_to(s)),'originalBytes':p.stat().st_size,'originalSha256':sha(p.read_bytes()),'diagnostics':str(output.relative_to(s)),'diagnosticsBytes':output.stat().st_size,'diagnosticsSha256':sha(output.read_bytes()),'members':members,'retained':len(retained),'omitted':len(names)-len(retained),'reason':'Preserve exact action/network/stack diagnostics and last screenshot per page, plus separate original failure PNG/log/source/receipt. Omit other trace JPEG frames from the retained packet. Original ZIP will be removed with verified task scratch cleanup; compact packet does not retain original ZIP bytes or full screenshot replay.'}
 mp=p.with_name(p.stem+'-retention.json');assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n')
 results.append({k:v for k,v in manifest.items()if k!='members'})
out=s/'trace-retention-summary.json';assert not out.exists();out.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
