from pathlib import Path
import json,hashlib,tarfile,shutil,re,socket
s=Path(__file__).parent.resolve()
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
d=w/'docs/plans/evidence/fixtures/druid-summons'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not d.exists()
for n in ['presentation-full','final-engine','final-types','previews-lint-repaired','previews-rebuilt']:
 assert json.loads((s/(n+'.json')).read_text())['exit']==0,n
full=(s/'presentation-full.log').read_text()
assert re.search(r'Tests\s+13865 passed \| 2 skipped',full),full[-1200:]
assert re.search(r'Test Files\s+605 passed',full),full[-1200:]
for n in ['presentation-post-full-audit.json','presentation-committed-audit.json','runtime-committed-audit.json','browser-audit.json']:
 assert (s/n).is_file()
committed=json.loads((s/'presentation-committed-audit.json').read_text());assert committed['sourceBlobs']==1334 and not committed['mismatches']
assert len(json.loads((s/'browser-audit.json').read_text())['cases'])==4
owners=[]
for p in s.glob('*server-owner.json'):
 r=json.loads(p.read_text());assert not Path('/proc',str(r['pid'])).exists(),r
 owners.append({'receipt':p.name,**r,'stopped':True})
with socket.socket()as sock:assert sock.connect_ex(('127.0.0.1',4481))!=0
allpaths=list(s.rglob('*'));assert not any(p.is_symlink()for p in allpaths)
files=sorted(p for p in allpaths if p.is_file())
keep=[];disposable=[]
for p in files:
 rel=p.relative_to(s)
 reason='build output'if rel.parts[0]in ['runtime-dist','presentation-dist']else 'full trace JPEG replay; exact text diagnostics, selected final frames, original error PNG/log/receipt and complete member hashes retained'if p.name.endswith('-failed-trace.zip')else None
 row={'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)}
 (disposable if reason else keep).append({**row,**({'reason':reason}if reason else {})})
d.mkdir()
archive=d/'raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
 for row in keep:tar.add(s/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 members={m.name:m for m in tar.getmembers()};assert len(members)==len(keep)
 for row in keep:
  assert members[row['path']].isfile()
  with tar.extractfile(members[row['path']])as source:assert hashlib.sha256(source.read()).hexdigest()==row['sha256'],row['path']
(d/'raw-files.sha256.json').write_text(json.dumps(keep,indent=2)+'\n')
(d/'disposable-files.sha256.json').write_text(json.dumps(disposable,indent=2)+'\n')
for n in ['browser-audit.json','presentation-post-full-audit.json','presentation-committed-audit.json','trace-retention-summary.json']:
 shutil.copyfile(s/n,d/n)
for src,dst in [('browser-verified-en-360/en-360-raven-details.png','raven-en-mobile.png'),('browser-verified-zh-CN-360/zh-CN-360-solar-creeper-combat.png','solar-zh-mobile.png')]:
 shutil.copyfile(s/src,d/dst);assert sha(s/src)==sha(d/dst)
receipts=[]
for row in keep:
 if row['path'].endswith('.json'):
  try:r=json.loads((s/row['path']).read_text())
  except (ValueError,UnicodeError):continue
  if isinstance(r,dict)and all(k in r for k in ['argv','cwd','exit','seconds','finished']):receipts.append({'path':row['path'],**r})
(d/'terminal-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
report={'scope':'D06/BUG195 seven Druid summons; bounded local functionality, independent design/QA and earned balance open','scratch':str(s),'archive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'rawFiles':len(keep),'rawBytes':sum(r['bytes']for r in keep),'disposableFiles':len(disposable),'disposableBytes':sum(r['bytes']for r in disposable),'terminalReceipts':len(receipts),'allArchivedBytesVerified':True,'finalFull':json.loads((s/'presentation-full.json').read_text()),'finalFullTests':13865,'finalFullFiles':605,'existingSkipped':2,'committedSource':committed,'serverOwners':owners,'port4481Closed':True,'tracePolicy':'Original failed ZIP SHA/member maps retained, exact action/network/stack diagnostics and final frame per page retained in compact ZIPs. Other JPEG frames and original ZIP bytes omitted. Separate original failure screenshots, source variants, logs and terminal receipts retained. Original full ZIPs are disposable after byte-verified archive.'}
(d/'packet.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['serverOwners','finalFull','committedSource']},indent=2))
