from pathlib import Path
import json,hashlib,os,socket,re
s=Path(__file__).parent
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
slugs=['raven','poison-creeper','summon-spirit-wolf','summon-dire-wolf','carrion-vine','solar-creeper','summon-grizzly']
prereq={'druid.lycanthropy':1,'druid.werebear':1,'druid.werewolf_maul':1}
domains=['player','inventory','map','mercs','formation']
rows=[];pairs=[];screens=[]
for locale,width in [('en',1280),('en',360),('zh-CN',1280),('zh-CN',360)]:
 label=f'{locale}-{width}';base=s/f'browser-verified-{label}'
 receipt=json.loads((s/f'browser-verified-{label}.json').read_text());assert receipt['exit']==0
 report=json.loads((base/'browser-report.json').read_text());assert not report['failures']
 assert len(report['cases'])==1
 case=report['cases'][0];assert case['label']==label and case['pass'] is True and not case['errors']
 assert case['pairs']==['rank1','rank2'] and [r['slug'] for r in case['combat']]==slugs
 assert len(report['geometry'])==5
 for point,(vw,vh) in zip(report['geometry'],[(360,640),(412,915),(640,360),(1280,800),(1920,1080)]):
  assert (point['width'],point['height'])==(vw,vh)
  assert point['overflow']==0 and point['allocate']['width']>=44 and point['allocate']['height']>=44
 copy=json.loads((w/f'src/i18n/locales/{locale}/combat.json').read_text())
 skillcopy=json.loads((w/f'src/i18n/locales/{locale}/skills.json').read_text())
 for entry in case['combat']:
  slug=entry['slug'];assert entry['positiveAttacks']>0
  path=base/f'{label}-{slug}-combat.json';assert json.loads(path.read_text())==entry
  minion=entry['minion'];log=entry['log']
  pattern=r'(?:attacks|hits) .+ for [1-9]\d* ' if locale=='en' else r'(?:普攻|对) .+造成 [1-9]\d* 点'
  assert sum(minion in m and bool(re.search(pattern,m)) for m in log)==entry['positiveAttacks']
  if slug=='raven':assert any(copy['effect']['status']['blind'] in m for m in log)
  if slug=='poison-creeper':assert any(re.search(r'takes [1-9]\d* damage over time' if locale=='en' else r'因持续伤害受到 [1-9]\d* 点伤害',m)for m in log)
  if slug in ['carrion-vine','solar-creeper']:
   key='consumedCarrion' if slug=='carrion-vine' else 'consumedSolar'
   assert any(copy['corpses'][key].split('{{')[0] in m for m in log)
  if slug=='carrion-vine':assert any(re.search(r'SummonCheck recovers [1-9]\d* HP' if locale=='en' else r'SummonCheck 恢复了 [1-9]\d* 点生命',m)for m in log)
  if slug=='solar-creeper':
   assert any('SummonCheck'in m and skillcopy['druid']['werewolf-maul']['name']in m and ('casts'if locale=='en'else'施放了')in m for m in log)
   samples=entry['manaSamples'];before=[p for p in samples if p['consumed']==0][-1]
   after=next(p for p in samples if p['consumed']>0 and p['mp']>before['mp'])
   assert 0<before['mp']<before['max'] and after['mp']<=after['max']
   mana={'before':before,'after':after,'increase':after['mp']-before['mp']}
  for suffix in ['details.png','combat.png']:
   p=base/f'{label}-{slug}-{suffix}';assert p.is_file();screens.append(str(p.relative_to(s)))
 for rank,b,a in [(1,3,4),(2,5,6)]:
  before=json.loads((base/f'{label}-rank{rank}-before-{b}.json').read_text())
  after=json.loads((base/f'{label}-rank{rank}-after-{a}.json').read_text())
  assert before['version']==after['version']==22
  assert {k:before[k]for k in domains}=={k:after[k]for k in domains}
  assert after['player']['skillLevels']=={**prereq,**{'druid.'+slug.replace('-','_'):rank for slug in slugs}}
  assert after['player']['skillPoints']==(7 if rank==1 else 0)
  assert after['player']['comboOrder']==(['druid.raven']if rank==1 else ['skills-druid-summon-grizzly'])
  assert 'druidSummonRanks'not in json.dumps(after)
  pairs.append({'case':label,'rank':rank,'domains':domains,'version':22,'exact':True})
 owner=json.loads((s/f'browser-verified-{label}-server-owner.json').read_text())
 assert owner['root']==str(s/'presentation-dist')
 assert not Path('/proc',str(owner['pid'])).exists(),owner
 rows.append({'case':label,'combatEntries':7,'geometry':5,'pageErrors':[],'solarMana':mana,'serverPID':owner['pid'],'serverStopped':True})
with socket.socket()as sock: assert sock.connect_ex(('127.0.0.1',4481))!=0
out={'cases':rows,'positiveSummonEntries':28,'exactFiveDomainPairs':pairs,'geometrySamples':20,'screenshots':screens,'inspectedScreenshots':[f'browser-verified-{locale}-{width}/{locale}-{width}-{kind}.png'for locale,width in [('en',1280),('en',360),('zh-CN',1280),('zh-CN',360)]for kind in ['raven-details','solar-creeper-combat']],'visualReview':'Author inspection: readable wrapping, reachable >=44px Allocate, no page overflow; descriptions scroll vertically and combat viewport captures are not stand-alone proof of offscreen logs/effects. DOM logs and MP samples provide those checks. Existing font/icon/navigation presentation and independent UX acceptance remain open.','fixture':'Disclosed synthetic L30, 50000 HP/MP gear, -80 attackSpeed, learned transitive Maul prerequisites. Public creation/import/allocation/selection/combat/export/Continue. Not earned campaign or balance.','port4481Closed':True}
p=s/'browser-audit.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'positiveSummonEntries':28,'exactFiveDomainPairs':len(pairs),'geometrySamples':20,'screenshots':len(screens),'inspected':len(out['inspectedScreenshots']),'solarManaIncreases':{r['case']:r['solarMana']['increase']for r in rows},'portClosed':True}))
