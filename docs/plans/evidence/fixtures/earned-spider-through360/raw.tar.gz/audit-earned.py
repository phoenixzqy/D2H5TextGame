from pathlib import Path
import gzip,json,hashlib,re,sys,subprocess,urllib.request
base=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=base/sys.argv[1]
input_path=Path(sys.argv[2])
read=lambda p:json.loads(gzip.decompress(p.read_bytes()))
before=read(input_path);report=json.loads((root/'report.json').read_text());after=read(root/'final.json.gz')
assert report['status']=='observed',report.get('failure')
assert report['errors']==[] and report['console']==[] and report['retries']==0
start_input=before['map']['challengeOrdinals']['normal']
expected_preparation={272:'unchanged genuine next272 recruitment final',282:'unchanged genuine L26 next282 final',359:'unchanged genuine L29 next359 saved final after observed watchdog'}
assert report['policy']['preparation']==expected_preparation[start_input]
assert report['inputSHA256']==hashlib.sha256(gzip.decompress(input_path.read_bytes())).hexdigest()
frozen=json.loads((base/('earned-policy.json' if start_input==272 else f'earned-{start_input}-policy.json')).read_text())
assert frozen['inputRawSHA256']==report['inputSHA256']
assert frozen['targetLevel']==report['policy']['targetLevel']
assert frozen['maxRuns']==report['policy']['maxFarmRuns']
def owned(s):
    a=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[i for eq in s['mercs']['mercEquipment'].values() for i in eq.values()]
    a=[i for i in a if i];m={i['id']:i for i in a};assert len(m)==len(a);return m
old=owned(before);new=owned(after)
for ident,item in old.items():assert new[ident]==item,ident
for k in ['coreStats','skillLevels','comboOrder','respecsRemaining','skills','name','id','class']:
    assert after['player'][k]==before['player'][k],k
for k in ['endgame','formation']:assert after[k]==before[k],k
for k in ['equipped','questItems']:assert after['inventory'][k]==before['inventory'][k],k
for k in ['mercEquipment','fieldedMercId']:assert after['mercs'][k]==before['mercs'][k],k
for k in ['questProgress','questReceipts','clearedSubAreas','currentAct','discoveredAreas']:
    assert after['map'][k]==before['map'][k],k
assert after['meta']==before['meta']
for merc in before['mercs']['ownedMercs']:
    if merc['id']!=before['mercs']['fieldedMercId']:
        assert merc==next(m for m in after['mercs']['ownedMercs'] if m['id']==merc['id'])
assert [m['id'] for m in before['mercs']['ownedMercs']]==[m['id'] for m in after['mercs']['ownedMercs']]
xp=lambda s:s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))
dxp=xp(after)-xp(before);gear=len(new)-len(old)
assert dxp==report['totalXP']==sum(w['delta']['xp'] for a in report['areas'] for w in a['waves'])
assert gear==sum(len(w['delta']['newItems']) for a in report['areas'] for w in a['waves'])
start=before['map']['challengeOrdinals']['normal'];end=after['map']['challengeOrdinals']['normal']
assert end==start+len(report['launches']);assert after['map']['challengeOrdinals']['nightmare']==before['map']['challengeOrdinals']['nightmare']
for i,launch in enumerate(report['launches']):
    assert launch['ordinal']==start+i and launch['alias']=='spider-forest'
    assert read(root/('prelaunch-'+str(start+i)+'.json.gz'))['map']['challengeOrdinals']['normal']==start+i
round_trips=[]
for name in sorted(root.glob('*-saved.json.gz')):
    n=int(name.name.split('-')[0]);other=root/re.sub(r'^\d+',f'{n+1:03}',name.name.replace('-saved.json.gz','-continued.json.gz'))
    assert read(name)==read(other);round_trips.append([name.name,other.name])
assert len(round_trips)==len(report['launches'])+1
levels=after['player']['level']-before['player']['level']
assert after['player']['statPoints']-before['player']['statPoints']==5*levels
assert after['player']['skillPoints']-before['player']['skillPoints']==levels+sum(1 for l in range(before['player']['level']+1,after['player']['level']+1) if l%12==0)
assert after['player']['level']>=report['policy']['targetLevel'] or len(report['launches'])==report['policy']['maxFarmRuns'] or report['areas'][-1]['outcome']=='nonwin'
source=json.loads((base.parent/'merc-holy-freeze/source-hashes-final.json').read_text())
freeze=json.loads((base/'runtime-freeze-before-amazon.json').read_text())
assert freeze['runtimeCommit']=='6faa46f' and freeze['sourceFiles']==len(source)
assert freeze['immutableGitSourceDrift']==[] and freeze['workingTreeDriftBeforeAmazonFix']==[]
requests=''.join('6faa46f:'+name+'\n' for name in source)
git=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=requests.encode(),stdout=subprocess.PIPE,check=True).stdout
cursor=0
for name,sha in source.items():
    newline=git.index(b'\n',cursor);header=git[cursor:newline].split();assert header[1]==b'blob'
    size=int(header[2]);payload=git[newline+1:newline+1+size];cursor=newline+size+2
    assert hashlib.sha256(payload).hexdigest()==sha,name
assert cursor==len(git)
allowed={'src/data/schema/skill.schema.json','src/stores/combatHelpers.ts',
         'src/i18n/locales/en/skills.json','src/i18n/locales/zh-CN/skills.json',
         'src/features/skills/SkillsScreen.tsx'}
drift={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name,sha in source.items()
       if hashlib.sha256((repo/name).read_bytes()).hexdigest()!=sha}
assert set(drift)<=allowed,drift
actual={str(p.relative_to(base/'dist')):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (base/'dist').rglob('*') if p.is_file()}
assert actual==freeze['distManifest'],'Frozen production dist changed'
for name,sha in freeze['servedChunks'].items():
    with urllib.request.urlopen('http://127.0.0.1:4422/assets/'+name) as response:
        assert hashlib.sha256(response.read()).hexdigest()==sha,name

for area in report['areas']:
    for wave in area['waves']:
        terminal=read(root/f"{area['ordinal']}-w{wave['wave']}-terminal.json.gz")
        if wave['outcome']=='victory':
            assert terminal['liveEnemies']==0 and terminal['log'][-1]=='Victory! All enemies are defeated.'
            assert next(c for c in terminal['cards'] if c['id']=='unit-card-'+before['player']['id'])['dead'] is None
raw=gzip.decompress((root/'final.json.gz').read_bytes())
result={'kind':'root conservation and original-result audit; no independent acceptance claimed','inputRawSHA256':hashlib.sha256(gzip.decompress(input_path.read_bytes())).hexdigest(),'finalRawSHA256':hashlib.sha256(raw).hexdigest(),'before':{'level':before['player']['level'],'xp':before['player']['experience'],'gear':len(old),'nextOrdinal':start},'after':{'level':after['player']['level'],'xp':after['player']['experience'],'gear':len(new),'nextOrdinal':end,'statPoints':after['player']['statPoints'],'skillPoints':after['player']['skillPoints']},'deltaXP':dxp,'gearGain':gear,'launches':len(report['launches']),'waves':report['areas'],'roundTrips':round_trips,'errors':0,'sourceFiles':len(source),'sourceDrift':drift,'sourceValidationBasis':'immutable git6faa46f + frozen full dist manifest + four served chunks; known Amazon-only current working-tree drift recorded explicitly','distFiles':len(actual),'servedChunks':freeze['servedChunks'],'executionWallMs':report['executionWallMs'],'requestedClockAdvanceMs':report['requestedClockAdvanceMs'],'economicPacing':'not measured by virtual UI or execution wall time'}
out=base/(sys.argv[1]+'-audit.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['waves','roundTrips']}))
