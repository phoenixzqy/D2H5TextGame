import subprocess,sys,time,json,os
from pathlib import Path
root=Path(__file__).resolve().parent
tag=sys.argv[1]
assert tag.replace('-', '').isalnum()
start=time.monotonic()
with (root/(tag+'.log')).open('w') as f:
 p=subprocess.Popen(sys.argv[2:],stdout=f,stderr=subprocess.STDOUT)
 entry={'tag':tag,'pid':p.pid,'command':sys.argv[2:],'state':'running'}
 record=root/'ownership.json'
 data=json.loads(record.read_text()); data['processes'].append(entry); record.write_text(json.dumps(data,indent=2)+'\n')
 code=p.wait()
entry.update(state='terminal',exit=code,seconds=round(time.monotonic()-start,2))
data=json.loads(record.read_text()); data['processes']=[entry if x['pid']==p.pid and x['tag']==tag else x for x in data['processes']]; record.write_text(json.dumps(data,indent=2)+'\n')
print('\n'.join((root/(tag+'.log')).read_text().splitlines()[-35:]))
print(json.dumps(entry))
sys.exit(code)
