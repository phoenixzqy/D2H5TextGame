from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import functools, os, json
root=Path(__file__).parent/'production-dist-final'
label=os.environ['BROWSER_RUN']
access=(Path(__file__).parent/(label+'-server-access.log')).open('w')
(Path(__file__).parent/(label+'-server-owner.json')).write_text(json.dumps({'pid':os.getpid(),'port':4492,'root':str(root)}))
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,fmt,*args):
  access.write(fmt % args + "\n");access.flush()
 def do_GET(self):
  if not (root/self.path.split('?')[0].lstrip('/')).is_file(): self.path='/index.html'
  super().do_GET()
 def end_headers(self):
  self.send_header('Cache-Control','no-store')
  super().end_headers()
ThreadingHTTPServer(('127.0.0.1',4492),functools.partial(Handler,directory=str(root))).serve_forever()
