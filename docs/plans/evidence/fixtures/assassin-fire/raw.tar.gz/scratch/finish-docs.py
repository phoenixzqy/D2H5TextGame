from pathlib import Path
import json,re,sys,subprocess
p=Path(__file__).parent
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
runtime,ui=sys.argv[1:]
receipt=json.loads((p/'full-final.json').read_text());assert receipt['exit_code']==0
log=(p/'full-final.log').read_text()
assert re.search(r'Test Files\s+651 passed',log)
assert re.search(r'Tests\s+14626 passed \| 2 skipped',log)
for name in ['post-full-freeze-audit.json','committed-source-audit.json']:
 assert json.loads((p/name).read_text())['exact']
inv=json.loads((p/'inventory-reconciliation.json').read_text());assert inv['counts']['bounded-functional']==104
vitest=re.search(r'Duration\s+([\d.]+)s',log).group(1)
evidence=f'''# D04 — Assassin Fire potency and Phoenix elemental attribution

Fixed and verified locally: runtime/data `{runtime}`, presentation `{ui}`.
Root sole writer and author reviewer; independent design/QA and earned balance
remain open. [BUG205](../../../production/bugs/BUG-205-assassin-burn-missing-periodic-damage.md),
[original reproduction](d04-assassin-burn-repro.md) and
[contract](../decisions/D04-assassin-fire-v1.md) precede implementation.

## Actual repair and remaining promises

Fire Blast, Fists of Fire, Dragon Tail, Wake of Fire, Wake of Inferno and
Phoenix Strike now author explicit `statusEffect.dotPctOfDamage:0.1`.
The existing Burn/Ignite runtime captures `max(1,floor(mitigatedFireHit*0.1))`
DPS per stack for three seconds, cap5; capture precedes personal absorption,
as in Vengeance. No global missing-potency fallback, new status runtime,
dependency, save field/version or native eligibility change. Existing damage,
growth, target selection, costs, cooldowns and prerequisites are preserved.
The fraction is explicit provisional functional tuning; earned balance is open.

Phoenix opts into the existing weighted-component runtime with equal60/60/60
weights. Its unchanged total120–180/+12rank is now real Fire/Cold/Lightning,
one shared base/hit/critical roll and one action/payment/cooldown, with separate
mitigation and Burn/Chill/Paralyze. Burn derives solely from the mitigated Fire
component. The entire compound strike settles before one death/corpse closure.
Schema ownership remains narrow: only Vengeance and Phoenix can opt in, with
Phoenix's actual L30/Cobra Strike+Blades of Ice identity required. Scalar skill
and Vengeance behavior remain compatible.

Death Sentry remains excluded and broken: its current Fire/Burn conflicts with
the promised lightning trap/corpse explosion. Adding a Burn rate would preserve
the wrong identity. Fire Blast's cone/trap mismatch, Fists charge behavior,
Wake persistent traps and Phoenix charge/build interactions remain open.
Only Dragon Tail gains bounded whole-skill functionality credit; repaired parts
alone do not credit the other five whole skills.

## Causal tests and retained failures

The rebuilt84-case actual native probe covers seven skills at ranks1/2/20 and
seeds7/19/41/97. The six repaired skills have54positive periodic cases; Death
Sentry retains nine positive hits with zero periodic HP loss. All casts prove
one payment/action, immutable replay and actual final HP conservation.

| Skill, rank1 seed7 | Direct HP loss | Periodic HP loss |
| --- | ---: | ---: |
| Fire Blast | 51 | 15 |
| Fists of Fire | 46 | 12 |
| Dragon Tail | 71 | 21 |
| Wake of Fire | 61 | 18 |
| Wake of Inferno | 92 | 27 |
| Phoenix Strike | 123 (41/type) | 12 |
| Death Sentry, still unpowered | 87 | 0 |

The134new cases comprise57native/store,21schema/catalog/pure display and56UI.
They cover exact ranks/aliases/MAX/prerequisites, paid misses, unaffordable and
cooling refusal, every shaped/all/single target's actual HP, immutable captured
allocation, ordinary/recorded replay and weapon Attack independence. Existing
Vengeance regressions cover shared absorption/compound settlement semantics.
Phoenix mitigation control gives Fire20/Cold29/Lightning40, Burn6 and final
HP1905 from2000; guaranteed critical gives82/type, Burn24 and finalHP1730.

Original source RED41failed/19passed and corrected/full-UI RED89failed/19passed
are retained. Fixture corrections use actual applyStatus/applyStatuses fields,
Chill2s and status-state source ownership; DoT events have no source field.
Compound strikes complete before death. The first green2failed/153passed fixed
a stale insertion-order expectation and Fire Defense/MR arithmetic. Four strict
type errors, a stale status-owner list and one lint issue were also corrected.
These explanations and original terminal receipts remain in the archive.

[BUG206](../../../production/bugs/BUG-206-phoenix-summary-omits-components.md)
was found by the initial production visual review: Phoenix's leading summary
showed only Fire although actual rows/combat had all three components. Eight
bilingual rank0/1/2/20 main-paragraph assertions fail before repair and pass
with a generic model-driven composite description. An earlier RED selected
the rank heading; the corrected-selector RED is8failed/48passed. Both are
retained. Vengeance wording is unchanged; original charge promises remain.

Final focused compatibility345/11, data compatibility872/15, engine7574/276,
strict types, lint and production build PASS. Final full passes14626/651files
with two existing skips, {receipt['seconds']:.3f}s wrapper (Vitest{vitest}s).
The first full14618/651 predates the eight summary cases/UI fix and is retained
as historical evidence. Neither full run was interrupted/restarted. Engine,
full-suite, typecheck and lint durations exceed repository budgets; these
results do not close performance gates.

## Production browser and persistence

Initial production build:24cases, six skills ×en/zh-CN×1280×800/360×640,
48exact five-domain Save-close-new-page-Continue pairs. Final summary build:
four Phoenix primary cases and two mobile row-capture supplements,12exact
pairs. Combined30cases/60exact pairs/50geometry samples/96screenshots;16were
individually inspected, including six final passing images, six initial concern
images and four superseded duplicate captures. Final visual verdict is bounded
PASS. No console errors in the audited cases; checked controls meet44px and
geometry has no horizontal overflow across the five sampled viewport sizes.

Fixtures disclose syntheticL30, the real prerequisite chain, imported resource
helmet and fixed Date.now with ordinary timers. Public rank1Continue preserves
empty priority; public Active Skills selection changes it, and rank2Continue
preserves selection. Player, inventory, map, mercs and formation match exactly.
No private store injection or production test bridge; this grants no earned
progression or balance credit. Both builds have four bridge-free JS chunks
and all756precache URLs. Full accessibility/device/PWA/performance remain open.

Four first final-build stats shots failed to move the app's actual scroll
container and duplicate summary captures. The two mobile supplements scroll
the correct DOM ancestor and show complete Current/Next rows. Original captures
and `stat-capture-correction.json` remain; no product patch was needed.

## Provenance and accounting

Final1383source/test/config, two controlling design and760build files remain
hash-exact through the final full suite, along with historical HEAD0e1eecd0
and the genuine-save digest. Actual committed blobs/disk match the tested
snapshot at `{ui}`; historical HEAD is not claimed to contain the patch.
Initial/final snapshots differ only in SkillsScreen, its Assassin Fire UI test
and the two locale files. Other1379source hashes and both design files match;
there was no runtime change between full runs. Both build hash maps are retained.

Inventory preserves213IDs/order, changes exactly seven Burn rows and leaves
206others exact:104bounded-functional/107unverified/one engine-only/one
review-needed. Exactly one new credit, Dragon Tail; Assassin7/30 locally
bounded. Independent/earned class/build acceptance remains open.

The separate [Fire Blast cone reproduction](d04-fire-blast-cone-repro.md)
confirms the five-cell cross despite bilingual/spec cone promises. It is a
retained diagnostic exit1, not a required-suite failure or cone repair/credit.

Genuine claimed Ancients/Rite staysL33/XP149261/nextNormal402/Nightmare0,
Baal uncleared; decompressed SHA256 remains
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`.
C0/C1 retain narrow exits; C2–C4/fullG0–G7, earned builds,30–50hour pacing,
economy/endgame and independent acceptance remain unfinished. No genuine
campaign or remote action. Umbrella goal/branch/worktree/claim remain active.

[Raw archive](fixtures/assassin-fire/raw.tar.gz),
[member manifest](fixtures/assassin-fire/packet.json),
[committed audit](fixtures/assassin-fire/committed-source-audit.json) and
[cleanup receipt](fixtures/assassin-fire/cleanup.json) retain failures and proof.
Archive/cleanup counts are appended after actual verification.
'''
(wd/'docs/plans/evidence/d04-assassin-fire.md').write_text(evidence)
file=wd/'production/bugs/BUG-205-assassin-burn-missing-periodic-damage.md';s=file.read_text();s=s.replace('- Status: reproduced; implementation and functionality credit open.','- Status: six Fire-hit/Burn paths locally repaired; Death Sentry and other whole-skill promises remain open.')
s+='\n## Local repair continuation\n\nSix explicit authored fractions and real Phoenix components are verified in\n[Assassin Fire evidence](../../docs/plans/evidence/d04-assassin-fire.md).\nFinal full14626/651/two existing skips, types/lint/build and bounded production\nchecks pass. Only Dragon Tail gains functionality credit. Death Sentry remains\nunpowered pending lightning/trap/corpse identity repair; cone, charge and\npersistent-trap requirements stay open. This is partial resolution, not closure\nof all seven advertised skills. Original reproduction remains historical.\n';file.write_text(s)
file=wd/'production/bugs/BUG-206-phoenix-summary-omits-components.md';s=file.read_text().replace('- Status: reproduced during BUG205 production visual review; repair pending.','- Status: fixed and verified locally; independent/earned acceptance open.')
s+='\n## Local repair continuation\n\nThe final model-driven composite summary uses shared bilingual prose, with\neight genuine failing main-paragraph assertions before repair. Final56UI cases,\nfull14626/651/two skips, strict types/lint/build and affected production cases\npass. The two final mobile supplements show complete stat rows after a capture\nscroll correction. See [verified evidence](../../docs/plans/evidence/d04-assassin-fire.md).\nThe earlier instruction to wait for the first full run was followed; its terminal\nPASS precedes the UI edit and a separate final full run. Phoenix charge/build\npromises remain open; this issue does not grant whole-skill credit.\n';file.write_text(s)
file=wd/'docs/plans/evidence/d04-assassin-burn-repro.md';s=file.read_text();s+='\n## Repair continuation\n\nThe above records the original reproduction. Six Fire/Burn paths and Phoenix\ncomponents are now locally repaired and verified in\n[Assassin Fire evidence](d04-assassin-fire.md); Death Sentry remains open.\nOnly Dragon Tail gains bounded whole-skill credit. Original charge/trap/corpse\nand earned acceptance requirements are preserved.\n';file.write_text(s)
(wd/'production/bugs/BUG-207-fire-blast-cross-instead-of-cone.md').write_text('''# BUG-207 — Fire Blast selects a cross instead of its promised cone

- Status: reproduced; cone contract/implementation and whole-skill credit open.
- Severity: Medium — paid area targeting differs from the advertised shape.
- Environment: Node24.21.0, real default registry/native L30 Assassin, rank1 seed7.
- Owner: root; independent design/QA and earned balance remain open.

## Reproduction

1. Allocate actual Fire Blast rank1 with native playerToCombatUnit priority.
2. Put nine held2000HP enemies on the explicit3×3 grid, row-major target0–8.
3. Supply synthetic resources, allow one action, then hold the caster.
4. Record all damage/DoT, immutable exact replay, one payment and final HP.

Expected: the targeting honors the cone promised by skills-spec.md and both
locale descriptions. The spec does not define numeric grid cone geometry;
write an explicit faithful contract before patching, without relabeling a cross.

Observed: registered `aoeShape:"cross"`; actual target IDs1,3,4,5,7 form the
five-cell cross. Exactly one25MP payment, directHP295 and periodicHP84. Final
HP conservation/replay pass. A final intended diagnostic assertion exits1
because actual cross contradicts the cone promise.

Root cause: Assassin JSON authors cross; grid/schema lack a cone shape.
English: “Throws an explosive fire trap that bursts in a cone, burning enemies.”
Chinese: “投掷锥形爆裂的火焰陷阱，灼烧敌人。”
skills-spec.md row `assassin.fire_blast` says Cone/Cone fire trap.

See [native reproduction](../../docs/plans/evidence/d04-fire-blast-cone-repro.md).
This report precedes cone code/data repair. The separate Burn patch preserves
cross while repairing potency; it neither waives this defect nor credits the
whole skill. No earned campaign action or remote publication.
''')
(wd/'docs/plans/evidence/d04-fire-blast-cone-repro.md').write_text('''# D04 — Native Fire Blast cone mismatch reproduction

2026-10-25. Reproduced only; no targeting patch or whole-skill credit.
[BUG207](../../../production/bugs/BUG-207-fire-blast-cross-instead-of-cone.md)
records the issue before a cone contract/implementation.

The [Assassin Fire packet](fixtures/assassin-fire/packet.json) retains
`scratch/fire-blast-cone-repro.ts`, `scratch/fire-blast-cone-observed.json`
and `scratch/next-fire-blast-cone-repro.{log,json}`. The diagnostic exits1 after
asserting exact one action/payment, immutable replay and target HP conservation.
Its final assertion identifies the cross/cone promise mismatch, not a unit-suite
failure. It runs against the final frozen1383source snapshot; no source mutation
occurs between probe and the current Assassin Fire committed-blob audit.

Native L30/rank1/seed7 Fire Blast hits row-major3×3 targets1,3,4,5,7. Direct
HP295 plus periodicHP84 equals total final loss379. Final HP by target0–8 is
`[2000,1934,2000,1927,1917,1922,2000,1921,2000]`; mana100→75. Both locale
source descriptions and skills-spec.md promise cone, while data/grid/schema
implement cross. Numeric cone geometry needs an explicit contract before code.

Held enemies, later caster hold and resources are synthetic. This establishes
actual targeting, not earned balance, trap lifecycle or whole-skill acceptance.
Genuine retainedL33/next402/Baal-uncleared state/digest remains unchanged.
''')
file=wd/'docs/plans/execution-ledger.md';lines=file.read_text().splitlines()
for i,line in enumerate(lines):
 if line.startswith('| D04 Assassin Burn / BUG205 |'):
  lines[i]=f'| D04 Assassin Fire / BUG205–206 | six Fire-hit/Burn paths locally repaired; other promises open | Runtime `{runtime}`, presentation `{ui}`; explicit10% Fire-only Burn and real shared-roll Phoenix components, generic bilingual composite summary.134new cases; final full14626/651/two skips ({receipt["seconds"]:.3f}s), engine7574/276, types/lint/build PASS.30production cases/60exact five-domain Continue pairs/50geometry/96screenshots/16inspected. [Evidence](evidence/d04-assassin-fire.md). Exact1383source/two design/760build freeze and committed blobs verified. Only Dragon Tail credited:104bounded/107unverified/one engine-only/one review-needed; Assassin7/30. Cone/charge/persistent traps and Death Sentry identity remain open; genuineL33/next402/Baal uncleared unchanged. Independent/earned acceptance/C2-C4/G0-G7/privatev1 open. |'
  lines.insert(i+1,'| D04 Fire Blast cone / BUG207 | reproduced; targeting repair open | Native rank1/seed7/nine3×3targets selects IDs1,3,4,5,7; one25MP action, direct295/periodic84, exact replay/finalHP. Bilingual/spec cone promise conflicts with actual cross; numeric cone contract required before patch. [Reproduction](evidence/d04-fire-blast-cone-repro.md). No whole-skill credit or genuine campaign action. |')
  break
else:raise AssertionError('Missing ledger row')
file.write_text('\n'.join(lines)+'\n')
review={'review':'root author self-review; independent acceptance remains open','verdict':'PASS within explicit Fire-hit/Burn/composite/summary scope','source_commit':ui,'runtime_commit':runtime,'full_passed':14626,'full_files':651,'existing_skips':2,'new_cases':134,'browser_cases':30,'exact_continue_pairs':60,'final_frozen_source_design_build_and_committed_blobs_exact':True,'credit':['Dragon Tail'],'limits':['Fire Blast cone targeting and trap identity','Fists charge behavior','Wake persistent traps','Phoenix charge/build interactions','Death Sentry lightning/trap/corpse identity','Earned build/balance/campaign/Baal/pacing/endgame','Independent acceptance/full C2-C4/G0-G7/mobile/a11y/PWA/performance'],'security':'First-party local data/UI, no credentials/network/CI/permissions/dependencies/save-version/remote action','failure_evidence_preserved':True,'genuine_unchanged':True}
(p/'author-review-final.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'continuation-state.json').write_text(json.dumps({'stage':'final source committed; inventory/evidence updated; archive cleanup next','runtime_commit':runtime,'presentation_commit':ui,'full_terminal':True,'final_test_counts':{'passed':14626,'files':651,'skipped':2},'BUG205':'six paths repaired; Death Sentry open','BUG206':'fixed locally','BUG207':'reproduced only','goal':'active','worktree_claim':'preserved'},indent=2)+'\n')
print('Wrote evidence, bug continuations, cone report/reproduction, ledger and final author review')
