from pathlib import Path
import json
p=Path(__file__).parent;initial=json.loads((p/'browser-audit-initial.json').read_text());final=[];pairs=[];geometry=[]
for name in ['final-en-desktop','final-en-mobile','final-zh-desktop','final-zh-mobile','visual-en-mobile','visual-zh-mobile']:
 r=p/name;report=json.loads((r/'browser-report.json').read_text());assert not report['failures'] and len(report['cases'])==1
 case=report['cases'][0];assert case['pass'] and not case['errors'] and case['combat'][0]['selectedSkill']=='phoenix-strike';final.append({'run':name,**case});geometry.extend(report['geometry'])
 for before in sorted(r.glob('*-before-*.json')):
  prefix=before.name.split('-before-')[0];after=next(r.glob(prefix+'-after-*.json'));a=json.loads(before.read_text());b=json.loads(after.read_text());keys=['player','inventory','map','mercs','formation'];assert a['version']==b['version']==22 and all(a[k]==b[k] for k in keys)
  if '-rank1-' in before.name:assert a['player']['comboOrder']==[] and a['player']['skillLevels']['assassin.phoenix_strike']==1
  else:assert a['player']['comboOrder']==['skills-assassin-phoenix-strike'] and a['player']['skillLevels']['assassin.phoenix_strike']==2
  pairs.append({'run':name,'before':str(before.relative_to(p)),'after':str(after.relative_to(p)),'domains_exact':keys})
assert len(final)==6 and len(pairs)==12 and len(geometry)==30
assert all(g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44 for g in geometry)
result={'initial_cases':initial['cases'],'final_cases':final,'initial_pairs':initial['pairs'],'final_pairs':pairs,'initial_geometry':initial['geometry'],'final_geometry':geometry,'cases_total':30,'exact_pairs_total':60,'geometry_total':50,'screenshots':len(list(p.glob('browser-*/*.png')))+len(list(p.glob('final-*/*.png')))+len(list(p.glob('visual-*/*.png'))),'initial_visual_concerns':['BUG206 first Fire-only summary; repaired and rerun in final four Phoenix cases'],'provenance':{'initial':'frozen-inputs-initial.json','final':'frozen-inputs.json','runtime_source_unchanged_between_builds':'presentation-delta-audit.json'},'synthetic':True,'earned_progression_credit':False}
(p/'browser-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:result[k] for k in ['cases_total','exact_pairs_total','geometry_total','screenshots']})
