import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { getSkill, loadDefaultSkills, resetRegistry } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import skills from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/assassin.json';
import type { ActiveStatus, CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
const ids=['skills-assassin-fire-blast','skills-assassin-phoenix-strike','skills-assassin-fists-of-fire','skills-assassin-dragon-tail','skills-assassin-wake-of-fire','skills-assassin-wake-of-inferno','skills-assassin-death-sentry'];
const hold=(at=0):ActiveStatus=>({id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:at});
resetRegistry();loadDefaultSkills();const cases=[];
for(const selectedId of ids)for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const source=skills.find(s=>s.id===selectedId);assert.ok(source&&source.appliesStatus?.includes('burn'));
 const levels:Record<string,number>={};const add=(id:string)=>{const row=skills.find(s=>s.id===id);assert.ok(row);levels[id]=id===selectedId?rank:1;for(const child of row.prerequisites??[])add(child);};add(selectedId);
 const registered=getSkill(selectedId);assert.ok(registered);
 const native=playerToCombatUnit({...createMockPlayer('Synthetic Assassin Burn','assassin'),id:'burn-hero',level:30,comboOrder:[selectedId],skillLevels:levels});assert.deepEqual(native.skillOrder,[selectedId]);
 const hero:CombatUnit={...native,life:2000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,statuses:[hold(1701)],stats:{...native.stats,lifeMax:2000,manaMax:100,attack:100,defense:0,magicResist:0,attackSpeed:100,physDodge:0,magicDodge:0,critChance:0,resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}}};
 const monster:CombatUnit={...hero,id:'burn-target',side:'enemy',kind:'monster',tier:'trash',skillOrder:[],skillLevels:{},activeBuffIds:[],statuses:[hold()],stats:{...hero.stats,attackSpeed:80}};
 const input={seed,playerTeam:[hero],enemyTeam:[monster]},before=structuredClone(input),out=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const hits=out.events.filter(e=>e.kind==='damage'&&e.source===hero.id),dots=out.events.filter(e=>e.kind==='dot'&&e.target===monster.id),markers=out.events.filter(e=>e.kind==='status'&&e.target===monster.id&&e.statusId==='burn');
 const directHP=hits.reduce((n,e)=>n+(e.kind==='damage'?e.amount:0),0),periodicHP=dots.reduce((n,e)=>n+(e.kind==='dot'?e.amount:0),0);assert.equal(out.result.enemyTeam[0]?.life,2000-directHP-periodicHP);
 const actions=out.events.filter(e=>e.kind==='action'),payments=out.events.filter(e=>e.kind==='mana'&&e.reason==='cast');assert.equal(actions.length,1);assert.equal(payments.length,1);assert.equal(actions[0]?.kind==='action'&&actions[0].skillId,registered.id);
 cases.push({id:selectedId,rank,seed,nativeOrder:native.skillOrder,nativeLevels:levels,registered,hits,dots,markers,actions,payments,directHP,periodicHP,targetFinalHP:out.result.enemyTeam[0]?.life,finalMana:out.result.playerTeam[0]?.mana});
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-assassin-fire-i8gs6gwc/assassin-burn-native-repaired.json',JSON.stringify({synthetic:true,ids,cases},null,2)+'\n');
assert.equal(cases.length,84);assert.ok(cases.filter(c=>c.directHP>0).every(c=>c.markers.length>0),'Positive hits must actually apply the declared Burn marker');
assert.ok(cases.filter(c=>c.directHP>0&&c.id!=='skills-assassin-death-sentry').every(c=>c.periodicHP>0),'Every landed Fire hit within the six-skill repair must remove periodic HP');
assert.ok(cases.filter(c=>c.id==='skills-assassin-death-sentry').every(c=>c.periodicHP===0),'Unmodified Death Sentry stays explicitly unrepaired under BUG205');
