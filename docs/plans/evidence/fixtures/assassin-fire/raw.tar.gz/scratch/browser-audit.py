from pathlib import Path
import json,re
p=Path(__file__).parent;cases=[];pairs=[];geometry=[]
slugs={'fire-blast','fists-of-fire','dragon-tail','wake-of-fire','wake-of-inferno','phoenix-strike'}
for name in ['browser-en-desktop','browser-en-mobile','browser-zh-desktop','browser-zh-mobile']:
 r=p/name;report=json.loads((r/'browser-report.json').read_text());assert not report['failures'];assert len(report['cases'])==6
 assert {c['combat'][0]['selectedSkill'] for c in report['cases']}==slugs
 for case in report['cases']:
  assert case['pass'] and not case['errors'] and case['combat'][0]['publicCast'];cases.append({'run':name,**case})
 geometry.extend(report['geometry'])
 for before in sorted(r.glob('*-before-*.json')):
  prefix=before.name.split('-before-')[0];after=next(r.glob(prefix+'-after-*.json'));a=json.loads(before.read_text());b=json.loads(after.read_text());keys=['player','inventory','map','mercs','formation'];assert a['version']==b['version']==22 and all(a[k]==b[k] for k in keys)
  label,rank=prefix.rsplit('-rank',1);slug=re.fullmatch(r'(?:en|zh-CN)-(?:1280|360)-(.*)',label).group(1);assert slug in slugs
  source=json.loads((r/(label+'-synthetic-input.json')).read_text());levels=source['player']['skillLevels'];canonical='assassin.'+slug.replace('-','_')
  if rank=='1':assert a['player']['comboOrder']==[] and a['player']['skillLevels']==levels
  else:assert a['player']['comboOrder']==['skills-assassin-'+slug] and a['player']['skillLevels']==levels|{canonical:2}
  pairs.append({'run':name,'skill':slug,'rank':rank,'before':str(before.relative_to(p)),'after':str(after.relative_to(p)),'domains_exact':keys})
assert len(cases)==24 and len(pairs)==48 and len(geometry)==20
assert all(g['overflow']<=0 and g['allocate']['width']>=44 and g['allocate']['height']>=44 for g in geometry)
result={'cases':cases,'pairs':pairs,'geometry':geometry,'screenshots':len(list(p.glob('browser-*/*.png'))),'public_configuration_change':'Every synthetic import starts empty; rank1 Continue proves empty priority, public Active Skills selector chooses the actual skill, rank2 Continue preserves that exact selected priority and prerequisites.'}
(p/'browser-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({'cases':len(cases),'exact_pairs':len(pairs),'geometry':len(geometry),'screenshots':result['screenshots']})
