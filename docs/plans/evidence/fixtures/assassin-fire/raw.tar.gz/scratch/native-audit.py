from pathlib import Path
import json
p=Path(__file__).parent;r=json.loads((p/'assassin-burn-native-repaired.json').read_text());groups=[]
for key in r['ids']:
 rows=[x for x in r['cases'] if x['id']==key];positive=[x for x in rows if x['directHP']>0]
 assert len(rows)==12 and len(positive)==9
 repaired=key!='skills-assassin-death-sentry'
 assert all((x['periodicHP']>0)==repaired for x in positive)
 groups.append({'id':key,'cases':12,'positive_hits':9,'positive_periodic_cases':sum(x['periodicHP']>0 for x in rows),'rank1_seed7':[{k:x[k] for k in ['directHP','periodicHP','targetFinalHP']} for x in rows if x['rank']==1 and x['seed']==7][0],'whole_skill_credit':False})
out={'cases':84,'repaired_fire_skills':6,'positive_periodic_cases':54,'death_sentry_positive_hits_still_without_periodic_HP':9,'groups':groups}
(p/'native-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
