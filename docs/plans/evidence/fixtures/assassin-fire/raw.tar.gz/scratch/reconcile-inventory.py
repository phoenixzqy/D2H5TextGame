from pathlib import Path
import csv,io,json,hashlib,collections
p=Path(__file__).parent;wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');file=wd/'docs/plans/skill-inventory.csv'
assert json.loads((p/'full-final.json').read_text())['exit_code']==0
assert json.loads((p/'committed-source-audit.json').read_text())['exact']
assert json.loads((p/'post-full-freeze-audit.json').read_text())['exact']
old=file.read_bytes();reader=csv.DictReader(io.StringIO(old.decode()));fields=reader.fieldnames;before=list(reader);rows=[dict(r) for r in before]
limits={'fire-blast':'cone-trap-identity-open','fists-of-fire':'charge-runtime-open','dragon-tail':'independent-design-qa-and-earned-balance-open','wake-of-fire':'persistent-trap-runtime-open','wake-of-inferno':'persistent-trap-runtime-open','phoenix-strike':'charge-build-runtime-and-independent-acceptance-open','death-sentry':'lightning-trap-corpse-identity-open-and-burn-still-unpowered'}
for r in rows:
 slug=r['data_id'].removeprefix('skills-assassin-')
 if not r['data_id'].startswith('skills-assassin-') or slug not in limits:continue
 assert r['behavior_verification']=='unverified'
 if slug!='death-sentry':
  r['adapter_route']='shared-roll-typed-components+real-statuses' if slug=='phoenix-strike' else 'damage+explicit-on-hit-burn'
  r['risk_flags']='on-hit-burn-repaired|'+limits[slug]
  if slug=='dragon-tail':r['behavior_verification']='bounded-functional;independent-acceptance-open'
 else:r['risk_flags']=limits[slug]
 links=r['contract_evidence'].replace(';','|').split('|')
 links+=['docs/plans/evidence/d04-assassin-fire.md']
 if slug!='death-sentry':links+=['docs/plans/decisions/D04-assassin-fire-v1.md']
 if slug=='phoenix-strike':links+=['production/bugs/BUG-206-phoenix-summary-omits-components.md']
 r['contract_evidence']='|'.join(dict.fromkeys(x for x in links if x))
assert len(rows)==213 and [r['data_id'] for r in rows]==[r['data_id'] for r in before]
changed=[a['data_id'] for a,b in zip(rows,before) if a!=b];assert set(changed)=={'skills-assassin-'+s for s in limits}
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':107,'bounded-functional':104,'bounded-engine-functional':1,'review-needed':1},counts
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);new=out.getvalue().encode();file.write_bytes(new)
result={'rows':213,'IDs_and_order_unchanged':True,'credited':['skills-assassin-dragon-tail'],'repaired_part_but_whole_skill_unverified':['skills-assassin-'+s for s in limits if s not in ['dragon-tail','death-sentry']],'still_broken_and_unverified':['skills-assassin-death-sentry'],'changed_rows':changed,'other206rows_exact':True,'counts':counts,'baseline_sha256':hashlib.sha256(old).hexdigest(),'final_sha256':hashlib.sha256(new).hexdigest()}
(p/'inventory-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
