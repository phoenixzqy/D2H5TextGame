from pathlib import Path
import hashlib,json,gzip,subprocess,sys
p=Path(__file__).parent
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=lambda data:hashlib.sha256(data).hexdigest()
keys=set(json.loads((p/'baseline-source.json').read_text())['source'])
keys.update(['src/stores/assassin-fire.causal.test.ts','src/engine/skills/assassin-fire.test.ts','src/features/skills/SkillsScreen.assassin-fire.test.tsx'])
def current():
 return {'source':{k:sha((wd/k).read_bytes()) for k in sorted(keys)},
  'design':{k:sha((wd/k).read_bytes()) for k in ['docs/design/skills-spec.md','docs/plans/decisions/D04-assassin-fire-v1.md']},
  'build':{str(f.relative_to(p/'production-dist-final')):sha(f.read_bytes()) for f in sorted((p/'production-dist-final').rglob('*')) if f.is_file()},
  'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wd,text=True).strip(),
  'genuine_decompressed_sha256':sha(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))}
if sys.argv[1]=='snapshot':
 result=current();assert result['genuine_decompressed_sha256']=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577';(p/'frozen-inputs.json').write_text(json.dumps(result,indent=2)+'\n');print({k:len(v) if isinstance(v,dict) else v for k,v in result.items()})
else:
 frozen=json.loads((p/'frozen-inputs.json').read_text());actual=current();assert actual==frozen,'Frozen inputs changed';result={'source_files':len(actual['source']),'design_files':len(actual['design']),'build_files':len(actual['build']),'exact':True,'genuine_unchanged':True,'head':actual['head']};(p/(sys.argv[2]+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(result)
