from pathlib import Path
import json,hashlib,os,socket
p=Path(__file__).parent.resolve();assert p==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-dragon-talon-htannqlu')
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=wd/'docs/plans/evidence/fixtures/dragon-talon';packet=json.loads((dest/'packet.json').read_text());assert packet['root']==str(p) and packet['member_hashes_verified']
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha((dest/'raw.tar.gz').read_bytes())==packet['raw_archive_sha256']
retained={m['path'].removeprefix('scratch/'):m['sha256'] for m in packet['members']}
build=json.loads((p/'frozen-inputs.json').read_text())['build'];pids=set()
for f in p.glob('*owner.json'):
 r=json.loads(f.read_text())
 for key in ['pid','wrapper_pid']:
  if isinstance(r.get(key),int):pids.add(r[key])
live=[pid for pid in sorted(pids) if (Path('/proc')/str(pid)).exists()]
assert not live,live
s=socket.socket();s.settimeout(1);port_closed=s.connect_ex(('127.0.0.1',4491))!=0;s.close();assert port_closed
files=[];directories=[]
for f in p.rglob('*'):
 assert not f.is_symlink(),str(f)
 assert f.resolve().is_relative_to(p),str(f)
 if f.is_file():
  rel=str(f.relative_to(p));digest=sha(f.read_bytes())
  if rel.startswith('production-dist/'):assert digest==build[rel.removeprefix('production-dist/')],rel
  else:assert digest==retained[rel],rel
  files.append(f)
 elif f.is_dir():directories.append(f)
for f in files:f.unlink()
for directory in sorted(directories,key=lambda x:len(x.parts),reverse=True):directory.rmdir()
p.rmdir()
remaining=[str(f) for f in files if f.exists()];assert not remaining and not p.exists()
result={'root':str(p),'verified_retained_members':len(retained),'removed_exact_files':len(files),'recorded_pids_absent':sorted(pids),'port4491_closed':port_closed,'scratch_absent':not p.exists(),'remaining':remaining,'failures':[],'worktree_and_claim':'preserved active','shared_caches':'preserved'}
(dest/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
