from pathlib import Path
import csv,io,json,hashlib,subprocess,collections
p=Path(__file__).parent;wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');file=wd/'docs/plans/skill-inventory.csv'
assert json.loads((p/'full.json').read_text())['exit_code']==0
assert json.loads((p/'committed-source-audit.json').read_text())['exact']
old=file.read_bytes();reader=csv.DictReader(io.StringIO(old.decode()));fields=reader.fieldnames;before=list(reader);rows=[dict(r) for r in before]
for r in rows:
 if r['data_id']=='skills-amazon-jab':
  assert r['behavior_verification']=='unverified'
  r['adapter_route']='damage+three-independent-original-target-attempts';r['risk_flags']='independent-design-qa-and-earned-balance-open';r['behavior_verification']='bounded-functional;independent-acceptance-open'
  r['contract_evidence']='docs/plans/decisions/D04-jab-v1.md;docs/plans/evidence/d04-jab.md;production/bugs/BUG-203-jab-missing-repeated-attacks.md'
 if r['data_id']=='skills-assassin-dragon-talon':
  assert r['behavior_verification']=='unverified'
  r['risk_flags']='repeated-kicks-metadata-missing';r['contract_evidence']='docs/plans/evidence/d04-dragon-talon-repro.md;docs/plans/decisions/D04-dragon-talon-v1.md;production/bugs/BUG-204-dragon-talon-missing-repeated-kicks.md'
assert len(rows)==213 and [r['data_id'] for r in rows]==[r['data_id'] for r in before]
changed=[a['data_id'] for a,b in zip(rows,before) if a!=b];assert set(changed)=={'skills-amazon-jab','skills-assassin-dragon-talon'}
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);new=out.getvalue().encode()
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':109,'bounded-functional':102,'bounded-engine-functional':1,'review-needed':1},counts
file.write_bytes(new)
result={'rows':213,'IDs_and_order_unchanged':True,'credited':['skills-amazon-jab'],'evidence_only_unverified':['skills-assassin-dragon-talon'],'changed_rows':changed,'counts':counts,'baseline_sha256':hashlib.sha256(old).hexdigest(),'final_sha256':hashlib.sha256(new).hexdigest(),'other211rows_exact':True}
(p/'inventory-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
