from pathlib import Path
import json
p=Path(__file__).parent;cases=[];pairs=[];geometry=[]
for name in ['browser-en-desktop','browser-en-mobile','browser-zh-desktop','browser-zh-mobile']:
 r=p/name;report=json.loads((r/'browser-report.json').read_text());assert not report['failures'];assert len(report['cases'])==1 and report['cases'][0]['pass'];case=report['cases'][0];assert not case['errors'] and case['combat'][0]['oneCastThreeAttempts'];cases.append({'run':name,**case});geometry.extend(report['geometry'])
 for before in r.glob('*-before-*.json'):
  prefix=before.name.split('-before-')[0];after=next(r.glob(prefix+'-after-*.json'));a=json.loads(before.read_text());b=json.loads(after.read_text());keys=['player','inventory','map','mercs','formation'];assert all(a[k]==b[k] for k in keys)
  if '-rank1-' in before.name:assert a['player']['comboOrder']==[] and a['player']['skillLevels']=={'assassin.dragon_talon':1}
  else:assert a['player']['comboOrder']==['skills-assassin-dragon-talon'] and a['player']['skillLevels']=={'assassin.dragon_talon':2}
  pairs.append({'run':name,'before':str(before.relative_to(p)),'after':str(after.relative_to(p)),'domains_exact':keys})
assert len(pairs)==8 and len(geometry)==20
result={'cases':cases,'pairs':pairs,'geometry':geometry,'screenshots':len(list(p.glob('browser-*/*.png'))),'public_configuration_change':'Imported empty priority, continued empty, selected Dragon Talon through public Active Skills control, then preserved selected priority after Save-close-new-page-Continue.'};(p/'browser-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({'cases':len(cases),'exact_pairs':len(pairs),'geometry':len(geometry),'screenshots':result['screenshots']})
