from pathlib import Path
import csv,io,json,hashlib,collections
p=Path(__file__).parent;wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');file=wd/'docs/plans/skill-inventory.csv'
assert json.loads((p/'full.json').read_text())['exit_code']==0
assert json.loads((p/'committed-source-audit.json').read_text())['exact']
old=file.read_bytes();reader=csv.DictReader(io.StringIO(old.decode()));fields=reader.fieldnames;before=list(reader);rows=[dict(r) for r in before]
burn={f'skills-assassin-{s}' for s in ['fire-blast','phoenix-strike','fists-of-fire','dragon-tail','wake-of-fire','wake-of-inferno','death-sentry']}
for r in rows:
 if r['data_id']=='skills-assassin-dragon-talon':
  assert r['behavior_verification']=='unverified'
  r['adapter_route']='damage+three-independent-original-target-attempts';r['risk_flags']='independent-design-qa-and-earned-balance-open';r['behavior_verification']='bounded-functional;independent-acceptance-open'
  r['contract_evidence']='docs/plans/decisions/D04-dragon-talon-v1.md;docs/plans/evidence/d04-dragon-talon.md;production/bugs/BUG-204-dragon-talon-missing-repeated-kicks.md'
 if r['data_id'] in burn:
  assert r['behavior_verification']=='unverified'
  r['risk_flags']='|'.join(filter(None,[r['risk_flags'],'native-burn-zero-periodic-hp-reproduced','whole-skill-acceptance-open']))
  r['contract_evidence']='|'.join(filter(None,[r['contract_evidence'],'docs/plans/evidence/d04-assassin-burn-repro.md','production/bugs/BUG-205-assassin-burn-missing-periodic-damage.md']))
assert len(rows)==213 and [r['data_id'] for r in rows]==[r['data_id'] for r in before]
changed=[a['data_id'] for a,b in zip(rows,before) if a!=b];assert set(changed)==burn|{'skills-assassin-dragon-talon'}
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);new=out.getvalue().encode()
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':108,'bounded-functional':103,'bounded-engine-functional':1,'review-needed':1},counts
file.write_bytes(new)
result={'rows':213,'IDs_and_order_unchanged':True,'credited':['skills-assassin-dragon-talon'],'evidence_only_unverified':sorted(burn),'changed_rows':changed,'counts':counts,'baseline_sha256':hashlib.sha256(old).hexdigest(),'final_sha256':hashlib.sha256(new).hexdigest(),'other205rows_exact':True}
(p/'inventory-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
