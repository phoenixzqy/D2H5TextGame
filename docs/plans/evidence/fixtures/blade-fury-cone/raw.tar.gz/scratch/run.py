from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).parent
name,*command=sys.argv[1:]
start=time.monotonic()
with (root/(name+'.log')).open('w') as out:
 proc=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT)
 code=proc.wait()
(root/(name+'.json')).write_text(json.dumps({'command':command,'pid':proc.pid,'exit_code':code,'seconds':time.monotonic()-start})+'\n')
print((root/(name+'.log')).read_text()[-4500:])
print('exit',code)
sys.exit(code)
