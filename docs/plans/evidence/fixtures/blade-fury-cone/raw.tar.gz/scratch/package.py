from pathlib import Path
import json,tarfile,hashlib,socket,os,gzip,subprocess,re
root=Path('/tmp/d2h5-blade-fury-eraq3vei');wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=wd/'docs/plans/evidence/fixtures/blade-fury-cone'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for name in ['focused','focused-final','engine','types-delivery','lint-final','build','browser','native','full']:
 assert json.loads((root/(name+'.json')).read_text())['exit_code']==0,name
assert json.loads((root/'next-mind-blast.json').read_text())['exit_code']==1
log=(root/'full.log').read_text();assert re.search(r'Tests\s+14777 passed\s+\|\s+2 skipped',log);assert re.search(r'Test Files\s+661 passed',log)
frozen=json.loads((root/'frozen-inputs.json').read_text())
for f,h in (frozen['source']|frozen['design']).items():assert sha((wd/f).read_bytes())==h,f
for f,h in frozen['build'].items():assert sha((root/'build'/f).read_bytes())==h,f
assert sha(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))==frozen['genuine_decompressed_sha256']
pids=set(map(int,json.loads((root/'live-owned-processes.json').read_text())))
receipts=[]
for p in sorted(root.glob('*.json')):
 d=json.loads(p.read_text())
 if isinstance(d,dict) and 'command' in d and 'exit_code' in d:
  receipts.append({'path':'scratch/'+p.name,'exit_code':d['exit_code']});
  if 'pid' in d:pids.add(d['pid'])
assert all(not (Path('/proc')/str(pid)).exists() for pid in pids),[pid for pid in pids if (Path('/proc')/str(pid)).exists()]
s=socket.socket();s.settimeout(1);assert s.connect_ex(('127.0.0.1',4495))!=0;s.close()
files=sorted(p for p in root.rglob('*') if p.is_file() or p.is_symlink())
assert all(not p.is_symlink() for p in files)
raw=[p for p in files if p.relative_to(root).parts[0]!='build']
members=[{'path':'scratch/'+str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in raw]
dest.mkdir(parents=True,exist_ok=True)
archive=dest/'raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p,m in zip(raw,members):t.add(p,arcname=m['path'],recursive=False)
with tarfile.open(archive) as t:
 assert t.getnames()==[m['path'] for m in members]
 for m in members:
  data=t.extractfile(m['path']).read();assert len(data)==m['bytes'] and sha(data)==m['sha256']
packet={'raw_archive_sha256':sha(archive.read_bytes()),'members':members,'terminal_receipts':receipts,'disposable_build_files':len(frozen['build'])}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
# Every exact file is either retained byte-for-byte or a verified disposable build output.
assert root.resolve()==root and root.parent==Path('/tmp') and root.name=='d2h5-blade-fury-eraq3vei'
for p in files:p.unlink()
for p in sorted((p for p in root.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.rmdir()
root.rmdir();assert not root.exists()
cleanup={'root':str(root),'verified_raw_members':len(members),'removed_exact_files':len(files),'disposable_build_files':len(frozen['build']),'recorded_pids_absent':sorted(pids),'port4495_closed':True,'scratch_absent':True,'remaining':[],'failures':[],'worktree_and_claim':'preserved active','shared_caches':'preserved'}
(dest/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
print(json.dumps({'archive_sha256':packet['raw_archive_sha256'],'raw_members':len(members),'terminal_receipts':len(receipts),'removed_exact_files':len(files),'recorded_pids_absent':len(pids),'remaining':[],'failures':[]},indent=2))
