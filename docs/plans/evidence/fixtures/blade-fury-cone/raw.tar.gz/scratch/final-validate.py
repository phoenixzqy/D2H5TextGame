from pathlib import Path
import csv,collections,gzip,hashlib,io,json,re,socket,subprocess,tarfile
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');dest=wd/'docs/plans/evidence/fixtures/blade-fury-cone'
sha=lambda raw:hashlib.sha256(raw).hexdigest();packet=json.loads((dest/'packet.json').read_text());cleanup=json.loads((dest/'cleanup.json').read_text())
assert sha((dest/'raw.tar.gz').read_bytes())==packet['raw_archive_sha256']
with tarfile.open(dest/'raw.tar.gz') as t:
 assert t.getnames()==[m['path'] for m in packet['members']]
 for m in packet['members']:
  data=t.extractfile(m['path']).read();assert sha(data)==m['sha256'] and len(data)==m['bytes'],m['path']
 read=lambda name:json.load(t.extractfile('scratch/'+name))
 frozen=read('frozen-inputs.json');committed=read('committed-source-audit.json');reconciliation=read('inventory-reconciliation.json');expected=frozen['source']|frozen['design']
 assert committed['actual_committed_blob_sha256']==expected
 for f,h in expected.items():assert sha((wd/f).read_bytes())==h,f
 batch=''.join(f"{committed['commit']}:{f}\n" for f in expected);output=io.BytesIO(subprocess.check_output(['git','cat-file','--batch'],cwd=wd,input=batch.encode()))
 for f,h in expected.items():
  header=output.readline().decode().split();assert header[1]=='blob';assert sha(output.read(int(header[2])))==h;assert output.read(1)==b'\n'
 assert not output.read()
 for name in ['focused','focused-final','engine','types-delivery','lint-final','build','browser','native','full']:assert read(name+'.json')['exit_code']==0,name
 assert read('next-mind-blast.json')['exit_code']==1
 full=t.extractfile('scratch/full.log').read().decode();assert re.search(r'Tests\s+14777 passed\s+\|\s+2 skipped',full);assert re.search(r'Test Files\s+661 passed',full)
 native=read('native-repaired.json')['cases'];assert len(native)==12
 for c in native:assert c['actualTargets']==['target-1','target-3','target-4','target-5'] and c['finalMana']==85 and c['periodicHP']==0
 browser=read('browser-audit.json');assert browser['cases_total']==4 and browser['exact_save_pairs_total']==8 and browser['geometry_total']==20
 pairs=0
 for case in browser['cases']:
  assert case['pass'] and case['errors']==[] and len(case['first_cast_attempts'])==4
  folder='scratch/browser-'+case['label'].split('-blade-fury')[0]+'/'
  for rank in ['rank1','rank2']:
   saves=[]
   for phase in ['before','after']:
    prefix=folder+case['label']+'-'+rank+'-'+phase+'-';names=[n for n in t.getnames() if n.startswith(prefix) and n.endswith('.json')];assert len(names)==1,names
    saves.append(json.load(t.extractfile(names[0])))
   domains=lambda s:{key:s[key] for key in ['player','inventory','map','mercs','formation']}
   assert domains(saves[0])==domains(saves[1]);pairs+=1
 assert pairs==8
 mind=read('mind-blast-observed.json')['cases'];assert len(mind)==12
 for c in mind:assert c['markers'] and not c['stunEvents'] and c['finalMana']==70 and all(u['mana']==100 for u in c['targetMana'])
 rows=list(csv.DictReader((wd/'docs/plans/skill-inventory.csv').open()));assert len(rows)==213 and sha((wd/'docs/plans/skill-inventory.csv').read_bytes())==reconciliation['final_sha256']
 baseline=list(csv.DictReader(subprocess.check_output(['git','show',committed['commit']+':docs/plans/skill-inventory.csv'],cwd=wd,text=True).splitlines()))
 assert [(r['class'],r['data_id']) for r in rows]==[(r['class'],r['data_id']) for r in baseline]
 changed=[b['data_id'] for a,b in zip(baseline,rows) if a!=b];assert changed==['skills-assassin-blade-fury']
 counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts==reconciliation['counts']
 assert sha(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))==frozen['genuine_decompressed_sha256']
assert cleanup['remaining']==cleanup['failures']==[] and not Path(cleanup['root']).exists()
assert all(not (Path('/proc')/str(pid)).exists() for pid in cleanup['recorded_pids_absent'])
s=socket.socket();s.settimeout(1);assert s.connect_ex(('127.0.0.1',4495))!=0;s.close()
files=['docs/plans/evidence/d04-blade-fury-cone.md','docs/plans/evidence/d04-blade-fury-cone-repro.md','docs/plans/evidence/d04-mind-blast-repro.md','production/bugs/BUG-209-blade-fury-line-instead-of-cone.md','production/bugs/BUG-210-mind-blast-missing-stun-and-mana-loss.md','docs/plans/execution-ledger.md'];links=0
for file in files:
 p=wd/file
 for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  target=match.group(1).split('#')[0]
  if not target or '://' in target or target.startswith('mailto:'):continue
  assert (p.parent/target).exists(),(file,target);links+=1
result={'pass':True,'committed_source':committed['commit'],'source_files':len(frozen['source']),'design_files':len(frozen['design']),'actual_committed_blobs_and_disk_exact':True,'full_provenance_note':committed['note'],'raw_archive_sha256':packet['raw_archive_sha256'],'verified_raw_members':len(packet['members']),'terminal_receipts':len(packet['terminal_receipts']),'removed_exact_files':cleanup['removed_exact_files'],'recorded_pids_absent':len(cleanup['recorded_pids_absent']),'scratch_absent':True,'port4495_closed':True,'remaining':[],'failures':[],'inventory_rows':213,'changed_rows':changed,'counts':counts,'browser_exact_save_pairs':pairs,'full_tests':14777,'full_files':661,'existing_skips':2,'local_document_links_checked':links,'genuine_decompressed_sha256':frozen['genuine_decompressed_sha256'],'independent_and_earned_acceptance_open':True,'umbrella_goal':'active; C2-C4/full G0-G7 unfinished'}
(dest/'final-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
