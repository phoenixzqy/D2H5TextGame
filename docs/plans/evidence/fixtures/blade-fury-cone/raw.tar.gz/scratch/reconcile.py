from pathlib import Path
import csv,io,json,hashlib,collections,subprocess
root=Path(__file__).parent;p=Path('docs/plans/skill-inventory.csv');raw=p.read_bytes();rows=list(csv.DictReader(io.StringIO(raw.decode())));baseline=[dict(r) for r in rows]
row=next(r for r in rows if r['data_id']=='skills-assassin-blade-fury');assert row['behavior_verification']=='unverified'
assert json.loads((root/'full.json').read_text())['exit_code']==0
row.update(adapter_route='physical-shaped-cone-damage',risk_flags='cone-targeting-locally-repaired|independent-design-qa-and-earned-balance-open',behavior_verification='bounded-functional;independent-acceptance-open',contract_evidence='docs/plans/decisions/D04-blade-fury-cone-v1.md|docs/plans/evidence/d04-blade-fury-cone.md|production/bugs/BUG-209-blade-fury-line-instead-of-cone.md')
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows);new=out.getvalue().encode()
assert len(rows)==213 and [(r['class'],r['data_id']) for r in rows]==[(r['class'],r['data_id']) for r in baseline]
changed=[b['data_id'] for a,b in zip(baseline,rows) if a!=b];assert changed==['skills-assassin-blade-fury']
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':104,'bounded-functional':107,'bounded-engine-functional':1,'review-needed':1}
p.write_bytes(new)
result={'baseline_sha256':hashlib.sha256(raw).hexdigest(),'final_sha256':hashlib.sha256(new).hexdigest(),'rows':213,'IDs_order_unchanged':True,'changed_rows':changed,'other_rows_unchanged':212,'counts':counts,'assassin_bounded':sum(r['class']=='assassin' and r['behavior_verification'].startswith('bounded-functional;') for r in rows)}
(root/'inventory-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
