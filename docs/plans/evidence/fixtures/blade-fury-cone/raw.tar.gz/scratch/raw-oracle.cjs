const assert=require('node:assert/strict');
function draws(seed,n){let state=seed>>>0;return Array.from({length:n},()=>{state=(state+0x6d2b79f5)>>>0;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;});}
const raw=draws(7,12),base=[1,4,7,10].map(i=>40+Math.floor(raw[i]*21)),misses=draws(2,4);
assert.deepEqual(base,[41,50,45,45]);assert.ok(misses.every(value=>value>=.05));
console.log(JSON.stringify({scope:'Raw PRNG/math only; no combat or damage resolver import',seed7:{raw,base,resistance50:base.map(value=>Math.floor(value*.5))},seed2HitDraws:misses},null,2));
