from pathlib import Path
import json,gzip,hashlib,math,re
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/cold391')
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
def owned(s):
 rows=[i for i in s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[i for gear in s['mercs']['mercEquipment'].values()for i in gear.values()] if i is not None];d={i['id']:i for i in rows};assert len(rows)==len(d);return d
def xp(s):return s['player']['experience']+sum(math.floor(100*l**2.5)for l in range(1,s['player']['level']))
original=load(repo/'docs/plans/evidence/fixtures/earned-river-idle-through390/retained-final.json.gz');prepared=load(root/'native-preparation-finalized/final.json.gz');combat=load(root/'earned-diablo391/final.json.gz');final=load(root/'diablo-claim/final.json.gz');quest='quests/act4-terrors-end'
assert prepared==load(root/'native-preparation-resume/033-stopped-native.json.gz')==load(root/'canonical-export.diagnostic-only.json.gz')
assert len(owned(prepared))==22003 and set(owned(prepared))==set(owned(original));assert prepared['map']==original['map'];assert prepared['player']['experience']==original['player']['experience'];assert prepared['map']['challengeOrdinals']['normal']==391
assert prepared['player']['statPoints']==5 and prepared['player']['skillPoints']==0;assert prepared['player']['skillLevels']['sorceress.ice_blast']==20;assert prepared['player']['skillLevels']['sorceress.cold_mastery']==20;assert prepared['mercs']['fieldedMercId']=='mercs/act2-holy-freeze';assert len(prepared['mercs']['ownedMercs'])==12
for m in original['mercs']['ownedMercs']:assert next(n for n in prepared['mercs']['ownedMercs'] if n['id']==m['id'])==m
assert original['inventory']['currencies']['wishstone']-prepared['inventory']['currencies']['wishstone']==5
assert prepared['inventory']['materialActionOrdinal']-original['inventory']['materialActionOrdinal']==10
screen=json.loads((root/'screen.json').read_text());assert sum(x['n'] for x in screen['summary'])==96
assert [(x['wins'],x['secondHalfWins']) for x in screen['summary']]==[(0,0),(29,15),(32,16)]
proof=json.loads((root/'canonical-equivalence.json').read_text());assert proof['status']=='pass' and proof['pairedFullRuns']==8 and len(proof['rows'])==4
for row in proof['rows']:assert row['wholeRecordingsAndCanonicalSavesEqual'] and len(row['perWaveWitnesses'])==row['waves']
reports={};pairs=[];nativeSaves=0
for folder in ['native-preparation-finalized','earned-diablo391','diablo-claim']:
 report=json.loads((root/folder/'report.json').read_text());reports[folder]=report;assert report['status']=='observed' and report['errors']==[] and report['console']==[] and not report.get('cleanupErrors')
 states={}
 for p in sorted((root/folder).glob('*.json.gz')):
  s=load(p)
  if not isinstance(s,dict)or not all(k in s for k in ['player','inventory','map','mercs','meta','formation']):continue
  nativeSaves+=1;states[re.sub(r'^\d+-','',p.name[:-8])]=s
  currentItems=owned(s)
  for k,i in owned(prepared).items():assert currentItems.get(k)==i,(folder,p.name,k)
  for k in ['coreStats','skillLevels','comboOrder','respecsRemaining']:assert s['player'][k]==prepared['player'][k]
  assert s['inventory']['equipped']==prepared['inventory']['equipped'];assert s['mercs']['mercEquipment']==prepared['mercs']['mercEquipment'];assert s['endgame']==prepared['endgame'];assert s['map']['challengeOrdinals']['normal']in [391,392];assert s['map']['challengeOrdinals']['nightmare']==0
 for k,s in states.items():
  if k.endswith('-saved'):
   other=k[:-6]+'-continued';assert s==states[other];pairs.append([folder,k,other])
assert len(pairs)==5
r=reports['earned-diablo391'];assert r['retries']==0 and r['outcome']=='earned-act4-area-victory' and r['launches']==[{'ordinal':391,'alias':'chaos-sanctuary'}];assert len(r['areas'])==1 and len(r['areas'][0]['waves'])==7
for w in r['areas'][0]['waves']:
 n=w['wave'];assert w['outcome']=='victory';a=load(root/f'earned-diablo391/391-w{n}-initial.json.gz');b=load(root/f'earned-diablo391/391-w{n}-terminal.json.gz');assert b['liveEnemies']==0 and b['skipDisabled']is True and b['log'][-1]=='Victory! All enemies are defeated.';assert set(a['enemyIds']).issubset(b['enemyIds']);assert next(c for c in b['cards']if c['id']=='unit-card-'+prepared['player']['id'])['dead']is None
assert combat['map']['questProgress'][quest]['objectives']['obj-kill-diablo'] and not combat['map']['questProgress'][quest].get('rewardClaimed',False);assert final['map']['questProgress'][quest]['rewardClaimed'];assert xp(combat)-xp(prepared)==r['totalXP']==40900;assert xp(final)-xp(combat)==25000
assert len(owned(combat))-len(owned(prepared))==128 and len(owned(final))-len(owned(combat))==2;assert final['map']['challengeOrdinals']['normal']==392
assert final==load(root/'diablo-claim/diablo-claimed-continued.json.gz')==load(root/'diablo-claim/act5-available-no-entry.json.gz');assert reports['diablo-claim']['act5EntryEnabled'] and reports['diablo-claim']['zeroNewCombatEntries']
freeze=json.loads((root/'source-freeze.json').read_text());assert not [k for k,h in freeze.items()if hashlib.sha256((repo/k).read_bytes()).hexdigest()!=h]
build=json.loads((root/'build-hashes.json').read_text());assert not [k for k,h in build.items()if hashlib.sha256((root/'dist'/k).read_bytes()).hexdigest()!=h]
scan=json.loads((root/'bridge-scan.json').read_text());assert len(scan)==7 and all(not x for row in scan.values()for x in row.values())
audit={'status':'pass','kind':'root self-audit; independent acceptance pending','diabloAttempt':391,'nextNormal':392,'newGenuineChallenges':1,'nativeWaveVictories':7,'nativeNonwins':0,'preparedItemPayloadsPreserved':22003,'newCombatGear':128,'newQuestGear':2,'earnedHeroCombatXP':40900,'earnedHeroQuestXP':25000,'act5EntryEnabled':True,'act5CombatEntries':0,'heroLevel':final['player']['level'],'heroXP':final['player']['experience'],'ownedItems':len(owned(final)),'statPoints':final['player']['statPoints'],'skillPoints':final['player']['skillPoints'],'nativeSavedStateSnapshots':nativeSaves,'saveCloseContinuePairs':pairs,'sourceHashCount':len(freeze),'sourceDrift':[],'buildHashCount':len(build),'buildDrift':[],'bridgeFreeServedJS':len(json.loads((root/'served-hashes.json').read_text())),'diagnosticRuns':96,'canonicalPairedFullRuns':8,'finalRawSHA256':hashlib.sha256(gzip.decompress((root/'diablo-claim/final.json.gz').read_bytes())).hexdigest(),'limitations':'single genuine English mobile360x640 pilot; historical fixed Date and accelerated100ms playback transport; no30-50h pacing, ActV combat, full-idle matrix or C2-C4/fullG0-G7 acceptance'}
(root/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
