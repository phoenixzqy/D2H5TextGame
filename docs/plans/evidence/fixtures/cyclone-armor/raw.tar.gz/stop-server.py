from pathlib import Path
import json,os,signal,socket,time
root=Path(__file__).resolve().parent
meta=json.loads((root/'server-process.json').read_text())
pid=meta['pid']; assert meta['host']=='127.0.0.1' and meta['port']==4478
cmd=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(bytes([0]))
assert str(root/'serve.py').encode() in cmd
os.kill(pid,signal.SIGTERM)
for attempt in range(50):
 with socket.socket() as s: closed=s.connect_ex(('127.0.0.1',4478))!=0
 if closed and (root/'server-terminal.json').exists():break
 time.sleep(.1)
terminal=json.loads((root/'server-terminal.json').read_text())
assert closed and terminal['pid']==pid and terminal['closed']
print(json.dumps({'pid':pid,'port4478Closed':closed,'serverTerminal':terminal}))
