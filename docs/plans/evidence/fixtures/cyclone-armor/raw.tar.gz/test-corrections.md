Original causal test HP expectations remain97/40 and903/960. Transport changed from absorbed to cycloneAbsorbed after inspection proved the existing absorbed field explicitly means Bone Armor; the original causal source is retained. Initial trusted-combination expectation assumed one DoT event, but the existing scheduler settles at1700 before the3100 death. Exact two-event assertions now retain both amounts/pools and the unchanged3100 death. Initial typecheck exposed a missing paid-payload type predicate; fixed without assertions or suppressions.

Log expected zh-CN copy corrected from 飓风装甲 to the existing skill name 旋风装甲 before GREEN. This preserves the established localized skill identity; damage/Bone separation assertions are unchanged. Original log-red.log retains the initial text.

Native initial two negative-fixture failures: setPlayer intentionally replaces the character and aborts combat. Prerequisite/class loss negatives now use disclosed trusted setState construction to exercise the existing next-wave boundary. Public allocation/reset tests remain native. No runtime behavior was changed to accommodate this fixture.

New cooldown negative initially supplied100 remaining milliseconds, which correctly expired before the1700ms action. Corrected fixture to100000ms; all no-payment/no-power expectations unchanged. Existing engine cooldowns are milliseconds. Original final-focused log retains failure.

Initial browser passed desktop paid cast/prevention and first five-domain reopen, then networkidle timed out on the second reopen. The black-box server helper captures stdout/stderr with PIPE and never drains them; the precache request log can fill that pipe. Confirmed its server PID128778 exited and4478 closed; original report/trace/scripts retained. Customized task server writes access logs to its own file instead; final browser runs with explicit owned server lifecycle. No browser assertion or timeout changes.

Lint found a redundant null guard only under the narrower static parameter type. Widened the private validator parameter to explicitly include null, matching its existing defensive runtime check. Runtime expressions are unchanged.
