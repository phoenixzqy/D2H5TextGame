from pathlib import Path
import json,hashlib
p=Path(__file__).parent
b=p/'browser-corrected'
r=json.loads((b/'browser-report.json').read_text())
assert len(r['cases'])==4 and all(c['pass'] and not c['errors'] for c in r['cases']) and not r['failures']
assert len(r['geometry'])==20
pairs=[]
for before in sorted(b.glob('*-rank*-before-*.json')):
 prefix=before.name.rsplit('-before-',1)[0]
 after=list(b.glob(prefix+'-after-*.json'));assert len(after)==1
 a=json.loads(before.read_text());z=json.loads(after[0].read_text())
 assert a['version']==z['version']==22
 for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==z[domain],(prefix,domain)
 rank=19 if '-rank19' in prefix else 20
 assert z['player']['skillLevels']=={'druid.arctic_blast':1,'druid.cyclone_armor':rank}
 assert z['player']['skillPoints']==(1 if rank==19 else 0)
 assert z['player']['comboOrder']==['skills-druid-cyclone-armor']
 assert 'cycloneArmor' not in json.dumps(z)
 pairs.append({'label':prefix,'before':before.name,'after':after[0].name,'fiveDomainsExact':True,'rank':rank})
assert len(pairs)==8
assert sum(len(c['combat']) for c in r['cases'])==4
images=sorted(b.glob('*.png'));assert len(images)==8
out={'pass':True,'cases':4,'combatEntries':4,'geometry':20,'pairs':pairs,
 'screenshots':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in images},
 'scope':'Disclosed synthetic L30 rank19-to20 high-resource/negative-defense fixture; root audit, not independent QA or earned progress.'}
(p/'browser-attachment-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':True,'cases':4,'combatEntries':4,'geometry':20,'fiveDomainPairs':8,'screenshots':8}))
