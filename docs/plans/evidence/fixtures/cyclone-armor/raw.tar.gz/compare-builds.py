from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def hashes(name):
 return {str(p.relative_to(root/name)):sha(p.read_bytes()) for p in sorted((root/name).rglob('*')) if p.is_file()}
a=hashes('build-final');z=hashes('build-recheck')
assert len(a)==len(z)==760 and a==z
out={'pass':True,'buildFiles':len(a),'identical':True,'note':'Final type-only lint correction emits byte-identical production assets; browser used these same bytes.','hashes':z}
(root/'build-identity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='hashes'}))
