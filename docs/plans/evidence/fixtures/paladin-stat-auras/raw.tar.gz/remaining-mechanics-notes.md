# Next Paladin mechanics — implementation notes, not acceptance

Keep the remaining ten effects open. Next implement Holy Freeze and Conviction
as actual enemy effects, then the pulse/healing/corpse/cleansing families.

## Holy Freeze

Preserve authored unlock18, cap20, coldDamagePct0.03/rank and physDodgePct0.005/rank.
Add actual ambient enemy Chill through the existing combatStatusView and cadence
reconciliation. Player authority is the explicit selected hero projection; never
forge the mercenary holyFreezeAura marker. Living source ends/starts derived
Chill; ordinary existing Chill and the mercenary aura do not multiply cadence.
CHILL_DEFINITION owns the multiplier (currently0.5). Preserve the mercenary-only
cold bonus as mercenary-only, and apply player cold/dodge bonuses only to the hero
and originally fielded living merc. Source changes must preserve pending phases.
No raw enemy statuses or saved stats are modified. Add actor-death and combined
merc/player source tests, including status-state provenance and cold combo views.

## Conviction

Existing descriptions promise -25% all enemy resistances; author a JSON tuning
field for25 percentage points (subtractive, so0 becomes-25), independent of rank.
Preserve existing JSON unlock30 and Sanctuary prerequisite over the contradictory
old spec24. Preserve per-rank elemental0.02 and arcane0.01 increases for hero/merc.
The resistance debuff affects actual enemy defenders, including hits from player
summons, before existing act penalties/clamps. Add to Cold Mastery and Amplify
Damage; source death removes it without modifying raw/saved resistance objects.
Do not call an attacker damage increase the implementation of resistance removal.
Resolve the exact data shape through the schema skill before changing data.

## Other eight requirements still need concrete design and tuning

Holy Fire: real all-enemy fire pulse and Burn; existing copy20 damage/turn must
be reconciled with the engine five-second turn boundaries and rank scaling.
Holy Shock: actual lightning pulses, with newly authored JSON timing/base/scaling.
Prayer: real bounded healing for the original eligible recipients; specify source
versus recipient baseline, cap, interval and fraction carry across waves.
Cleansing: actual poison/curse duration reduction, including existing timed status
representation and explicit curse identity list; retain any adopted healing/dodge.
Redemption: enable and consume the existing authoritative corpse FIFO rather than
counting dead units anew; specify priority against CE/PE, source-life checks, exact
life/mana caps, pulse timing, no double consumption and no saved corpse namespace.
Sanctuary: prove undead identity from authored monster data and implement real
undead damage; choose an explicit time-based repulsion adaptation without adding
movement/range stats. Preserve distinct boss/death/status behavior.
Vigor: explicitly adapt stamina/movement under the project no-movement invariant;
do not expose generic life/speed bonuses as if those alone settle the contract.
Concentration: define actual interruption in this instant-resolution engine and
implement prevention, preserving CC/source and seeded RNG rules. Damage-only
implementation cannot receive functional credit.

These notes deliberately do not choose undocumented healing/pulse/interrupt
coefficients or claim independent design/balance acceptance.
