const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = __dirname;
const baseURL = 'http://127.0.0.1:4462';
const ids = ['thorns','blessed-aim','fanaticism','defiance','resist-fire','resist-cold','resist-lightning','salvation'];
const names = {
 en: ['Thorns','Blessed Aim','Fanaticism','Defiance','Resist Fire','Resist Cold','Resist Lightning','Salvation'],
 'zh-CN': ['荆棘','祝福瞄准','狂热','反抗','抗火','抗冰','抗电','救助']
};
const allIds = ['might','holy-fire','conviction','meditation','thorns','blessed-aim','concentration','holy-freeze','holy-shock','sanctuary','fanaticism','prayer','resist-fire','defiance','resist-cold','cleansing','resist-lightning','vigor','redemption','salvation'];
const summary = {cases:[], geometry:[], failures:[]};
let serial = 0;
async function exportSave(page, label) {
 const pending = page.waitForEvent('download');
 await page.getByTestId('export-save-button').click();
 const dl = await pending, target = path.join(root, `${label}-${++serial}.json`);
 await dl.saveAs(target);
 return JSON.parse(await fs.readFile(target, 'utf8'));
}
async function nav(page, route) {
 await page.locator(`a[href="/${route}"]`).first().click();
 await expect(page.getByTestId(`${route}-screen`)).toBeVisible();
}
function domains(save) {return Object.fromEntries(['player','inventory','map','mercs','formation'].map(k=>[k,save[k]]));}
async function continuePair(page, context, locale, label) {
 await nav(page,'settings');
 await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();
 await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');
 const before=await exportSave(page,label+'-before');
 assert.equal(before.version,22);
 await page.close(); page=await context.newPage();
 await page.goto(baseURL,{waitUntil:'networkidle'});
 await expect(page.getByTestId('home-continue')).toBeEnabled();
 await page.getByTestId('home-continue').click();
 await expect(page.getByTestId('town-screen')).toBeVisible();
 await nav(page,'settings');
 const after=await exportSave(page,label+'-after');
 assert.deepEqual(domains(after),domains(before));
 await nav(page,'skills');
 return {page,selection:after.player.selectedAuraId};
}
async function geometry(page,label) {
 const original=page.viewportSize();
 for (const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]) {
  await page.setViewportSize({width,height});
  const sizes=await page.locator('input[name="selected-player-aura"]').evaluateAll(inputs=>inputs.map(input=>{
    const r=input.closest('label').getBoundingClientRect();return {id:input.value,width:r.width,height:r.height};
  }));
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
  assert.ok(overflow<=0,`${label} overflow ${overflow}`);
  assert.equal(sizes.length,11);
  for(const size of sizes) assert.ok(size.width>=44&&size.height>=44,JSON.stringify(size));
  summary.geometry.push({label,width,height,overflow,sizes});
 }
 await page.setViewportSize(original);
}
(async()=>{
 const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});
 try {
 for(const locale of ['en','zh-CN']) for(const viewport of [{width:1280,height:800},{width:360,height:640}]) {
  const label=`${locale}-${viewport.width}`;
  const context=await browser.newContext({viewport,locale,acceptDownloads:true});
  const errors=[];
  context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
  await context.tracing.start({screenshots:true,snapshots:true,sources:false});
  let page=await context.newPage();
  const result={label,pairs:[],errors};
  try {
   await page.goto(baseURL,{waitUntil:'networkidle'});
   assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');
   await page.getByTestId('home-new-game').click();
   await page.getByTestId('class-paladin').click();
   await page.getByTestId('character-name-input').fill('AuraCheck');
   await page.getByTestId('character-start-btn').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();
   await nav(page,'settings');
   await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
   await nav(page,'skills');
   await page.getByTestId('skill-node-skills-paladin-resist-fire').click();
   await page.getByTestId('skill-detail-panel').getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
   await page.getByRole('radio',{name:names[locale][4],exact:true}).check();
   await expect(page.getByRole('radio',{name:names[locale][4],exact:true})).toBeChecked();
   await geometry(page,label+'-native');
   let pair=await continuePair(page,context,locale,label+'-native');page=pair.page;
   assert.equal(pair.selection,'paladin.resist-fire');result.pairs.push({kind:'native-L1',selection:pair.selection});
   await nav(page,'settings');
   const fresh=await exportSave(page,label+'-fresh');
   // A separate constructed L30 fixture verifies all unlocked controls. No campaign action is performed.
   const {selectedAuraId:ignored,...unselected}=fresh.player;
   const constructed={...fresh,player:{...unselected,level:30,skillPoints:1,
    skillLevels:Object.fromEntries(allIds.map(id=>['paladin.'+id.replace(/-/g,'_'),1]))}};
   await fs.writeFile(path.join(root,label+'-constructed-input.json'),JSON.stringify(constructed,null,2));
   await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   const dialog=page.getByRole('dialog');
   await dialog.getByRole('textbox').fill(JSON.stringify(constructed));
   await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   await expect(dialog).toHaveCount(0);
   await nav(page,'skills');
   for(let i=0;i<ids.length;i++) {
    const radio=page.getByRole('radio',{name:names[locale][i],exact:true});
    await expect(radio).toBeEnabled(); await radio.check();
    await expect(radio).toBeChecked();
    await expect(page.getByRole('status').first()).toContainText(names[locale][i]);
    await page.getByTestId('skill-node-skills-paladin-'+ids[i]).click();
    const detail=page.getByTestId('skill-detail-panel');
    await expect(detail).toContainText(locale==='en'?'These rank bonuses require selecting this aura.':'这些等级加成仅在选择此光环时生效。');
    if(ids[i]==='resist-fire') await expect(detail).toContainText(locale==='en'?'+1 percentage point to all six resistances':'全部六种抗性各增加1个百分点');
    pair=await continuePair(page,context,locale,label+'-'+ids[i]); page=pair.page;
    assert.equal(pair.selection,'paladin.'+ids[i]);
    await expect(page.getByRole('radio',{name:names[locale][i],exact:true})).toBeChecked();
    result.pairs.push({kind:'constructed-L30',selection:pair.selection});
   }
   await geometry(page,label+'-constructed');
   await page.getByRole('radio',{name:names[locale][7],exact:true}).scrollIntoViewIfNeeded();
   await page.screenshot({path:path.join(root,label+'-selection.png'),fullPage:false});
   assert.deepEqual(errors,[]);result.pass=true;
   await context.tracing.stop();
   console.log(label+' PASS: '+result.pairs.length+' exact Continue pairs');
  } catch(error) {
   result.pass=false;result.error=String(error.stack||error);summary.failures.push(label);
   await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});
   await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});
   throw error;
  } finally {
   summary.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(summary,null,2));
   await context.close();
  }
 }
 } finally {await browser.close();}
 assert.equal(summary.cases.length,4);assert.deepEqual(summary.failures,[]);
 console.log('All browser cases passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
