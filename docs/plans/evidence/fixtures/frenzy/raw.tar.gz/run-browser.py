from pathlib import Path
import subprocess,sys,socket,time,json,os
root=Path(__file__).parent
with socket.socket() as sock:
 assert sock.connect_ex(('127.0.0.1',4502))!=0, 'Port occupied; choose a new task port'
with (root/'server.log').open('w') as log:
 server=subprocess.Popen([sys.executable,str(root/'serve.py')],stdout=log,stderr=subprocess.STDOUT)
 try:
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError('Owned server exited before readiness')
   with socket.socket() as sock:
    if sock.connect_ex(('127.0.0.1',4502))==0:break
   time.sleep(.1)
  else:raise RuntimeError('Owned server readiness timeout')
  result=subprocess.run([sys.executable,str(root/'browser-suite.py')],env={**os.environ,'BROWSER_PREFIX':'corrected-browser-'})
 finally:
  if server.poll() is None:server.terminate()
  server.wait(timeout=10)
  (root/'server-stopped.json').write_text(json.dumps({'pid':server.pid,'exit':server.returncode,'stopped':True},indent=2)+'\n')
  print('Owned server stopped',server.pid,server.returncode,flush=True)
sys.exit(result.returncode)
