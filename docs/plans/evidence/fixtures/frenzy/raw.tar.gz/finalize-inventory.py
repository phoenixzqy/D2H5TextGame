from pathlib import Path
import csv,io,json,hashlib,collections
scratch=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert json.loads((scratch/'full.json').read_text())['exit']==0
path=repo/'docs/plans/skill-inventory.csv'
before=path.read_bytes();assert before==(scratch/'inventory-before.csv').read_bytes()
lines=before.splitlines(keepends=True);header=next(csv.reader([lines[0].decode().rstrip('\r\n')]))
idx=header.index('data_id');target='skills-barbarian-frenzy';changed=[]
for i,line in enumerate(lines[1:],1):
 cells=next(csv.reader([line.decode().rstrip('\r\n')]))
 if cells[idx]!=target:continue
 row=dict(zip(header,cells));assert row['behavior_verification']=='unverified'
 row.update(adapter_route='damage+finite-self-speed',risk_flags='author-dual-attempt-and-speed-tuning|independent-acceptance-open|earned-balance-open',behavior_verification='bounded-functional;independent-acceptance-open',contract_evidence='docs/plans/decisions/D04-frenzy-v1.md;docs/plans/evidence/d04-frenzy.md')
 out=io.StringIO();csv.writer(out,lineterminator='\r\n' if line.endswith(b'\r\n') else '\n').writerow([row[k] for k in header]);lines[i]=out.getvalue().encode();changed.append(i)
assert len(changed)==1
result=b''.join(lines);old=list(csv.DictReader(io.StringIO(before.decode())));new=list(csv.DictReader(io.StringIO(result.decode())))
assert len(old)==len(new)==213
assert [r['data_id'] for r in old]==[r['data_id'] for r in new]
assert sum(a==b for a,b in zip(before.splitlines(keepends=True),lines))==len(lines)-1
counts=collections.Counter(r['behavior_verification'] for r in new)
bounded=sum(r['behavior_verification'].startswith('bounded-functional') for r in new)
barbarian=sum(r['class']=='barbarian' and r['behavior_verification'].startswith('bounded-functional') for r in new)
assert bounded==114 and barbarian==16 and counts['unverified']==97
path.write_bytes(result)
audit={'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(result).hexdigest(),'rows':213,'idsOrderPreserved':True,'changedId':target,'changedRows':1,'other212RowsByteExact':True,'counts':dict(counts),'boundedFunctional':bounded,'barbarianBounded':barbarian,'barbarianTotal':30,'independentAcceptance':'open','earnedBalance':'open'}
(scratch/'inventory-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit))
