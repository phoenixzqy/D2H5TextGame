import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills, getSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry(); loadDefaultSkills();
const id = 'skills-barbarian-concentrate', skill = getSkill(id); assert.ok(skill);
const observations = [];
for (const rank of [1, 2, 20]) for (const seed of [7, 19, 41, 97]) {
 const native = playerToCombatUnit({ ...createMockPlayer('Synthetic Concentrate', 'barbarian'), id: 'hero', level: 30,
  skillLevels: { 'skills-barbarian-bash': 1, 'skills-barbarian-stun': 1, [id]: rank }, comboOrder: [id] });
 assert.deepEqual(native.skillOrder, [id]);
 const hold: ActiveStatus = { id: 'stun', sourceId: 'synthetic-after-paid-hold', stacks: 1, remaining: -1, appliedAtMs: 1701 };
 const hero: CombatUnit = { ...native, life: 1000000, mana: 100, statuses: [hold], manaRegenPerSecond: 0, manaRegenBaselinePerSecond: 0,
  stats: { ...native.stats, lifeMax: 1000000, manaMax: 100, attack: 70, attackSpeed: 100, critChance: 0,
   defense: 100, magicResist: 0, physDodge: 0, magicDodge: 0 } };
 const enemy: CombatUnit = { ...hero, id: 'enemy', side: 'enemy', kind: 'monster', skillOrder: [], skillLevels: {}, statuses: [],
  stats: { ...hero.stats, attack: 200, attackSpeed: 50, defense: 0 }, gridPosition: { row: 0, col: 0 } };
 const input = { seed, playerTeam: [hero], enemyTeam: [enemy] }, before = structuredClone(input), actual = runBattleRecorded(input);
 assert.deepEqual(input, before); assert.deepEqual(runBattleRecorded(input), actual);
 const control = runBattleRecorded({ ...input, playerTeam: [{ ...hero, skillOrder: [], skillLevels: {} }] });
 const incoming = (out: typeof actual) => out.events.flatMap(e => e.kind === 'damage' && e.source === 'enemy' && e.target === 'hero' ? [{ at: e.simClockMs, amount: e.amount, dodged: e.dodged }] : []);
 const actualIncoming = incoming(actual), controlIncoming = incoming(control);
 assert.ok(actualIncoming.some(e => !e.dodged && e.amount > 0));
 const mana = actual.events.filter(e => e.kind === 'mana' && e.reason === 'cast');assert.equal(mana.length,1);assert.equal(actual.result.playerTeam[0]?.mana,90);
 const buffs = actual.events.filter(e => e.kind === 'buff' && e.target === 'hero');
 const states = actual.events.flatMap(e => e.kind === 'status-state' && e.target === 'hero' ? e.statuses : []);
 observations.push({ rank, seed, initialDefense: hero.stats.defense, finalDefense: actual.result.playerTeam[0]?.stats.defense,
  paidOnce:true, actualIncoming, controlIncoming, sameIncomingAsBasic:JSON.stringify(actualIncoming)===JSON.stringify(controlIncoming),
  buffs, states, defenseBenefitObserved:buffs.length>0||states.some(s=>s.id!=='stun'),events:actual.events });
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-frenzy-6bup7eqh/concentrate-observations.json', JSON.stringify({ synthetic:true,skill,observations },null,2));
console.log(JSON.stringify(observations.map(({ events,states,actualIncoming,controlIncoming,...row })=>({...row,firstIncoming:actualIncoming.slice(0,3),actualIncomingCount:actualIncoming.length})),null,2));
assert.ok(observations.every(o=>o.defenseBenefitObserved), 'Concentrate promises increased defense, but its paid native hit grants no defense capability or incoming-damage benefit');
