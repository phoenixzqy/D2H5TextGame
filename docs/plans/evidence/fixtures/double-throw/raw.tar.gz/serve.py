from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import os,json,socket
root=Path(__file__).parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(root/'build'),**kwargs)
 def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',4501),Handler)
root.joinpath('server-live.json').write_text(json.dumps({'pid':os.getpid(),'port':4501,'build':str(root/'build')}))
server.serve_forever()
