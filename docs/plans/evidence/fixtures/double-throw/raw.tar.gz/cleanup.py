from pathlib import Path
import gzip
import hashlib
import json
import socket
import tarfile

scratch = Path(__file__).resolve().parent
expected = Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-double-throw-4rxrdvb1')
repo = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
target = repo / 'docs/plans/evidence/fixtures/double-throw'
assert scratch == expected and scratch.resolve() == expected
assert json.loads((scratch / 'task.json').read_text())['root'] == str(expected)
packet = json.loads((target / 'packet.json').read_text())
freeze = json.loads((scratch / 'freeze.json').read_text())
digest = lambda b: hashlib.sha256(b).hexdigest()
archive = target / 'raw.tar.gz'
assert digest(archive.read_bytes()) == packet['archiveSha256']
with tarfile.open(archive) as retained:
    assert set(retained.getnames()) == set(packet['members'])
    for member in retained:
        data = retained.extractfile(member).read()
        assert digest(data) == packet['members'][member.name]['sha256']
for pid in packet['recordedPids']:
    assert not Path('/proc', str(pid)).exists(), ('task process remains', pid)
with socket.socket() as connection:
    connection.settimeout(.5)
    assert connection.connect_ex(('127.0.0.1', 4501)) != 0, 'Task browser port remains open'
for name, sha in freeze['source'].items():
    assert digest((repo / name).read_bytes()) == sha, name
assert digest(gzip.decompress((repo / 'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())) == freeze['genuine']
all_paths = list(scratch.rglob('*'))
assert all(not path.is_symlink() for path in all_paths)
expected_files = {scratch / name: meta['sha256'] for name, meta in packet['members'].items()}
expected_files.update({scratch / 'build' / name: sha for name, sha in freeze['build'].items()})
assert set(expected_files) == {p for p in all_paths if p.is_file()}
for path, sha in expected_files.items():
    assert path.resolve().is_relative_to(scratch)
    assert digest(path.read_bytes()) == sha, path
removed = []
failures = []
for path in sorted(expected_files):
    try:
        path.unlink()
        removed.append(str(path.relative_to(scratch)))
    except OSError as error:
        failures.append({'path': str(path), 'error': str(error)})
for directory in sorted((p for p in all_paths if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
    try:
        directory.rmdir()
    except OSError as error:
        failures.append({'path': str(directory), 'error': str(error)})
try:
    scratch.rmdir()
except OSError as error:
    failures.append({'path': str(scratch), 'error': str(error)})
remaining = [str(p) for p in scratch.rglob('*')] if scratch.exists() else []
receipt = {'scratch': str(scratch), 'removedFiles': len(removed), 'removedPaths': removed,
    'currentBuildFiles': len(freeze['build']), 'priorVerifiedBuildRemovals': 0,
    'totalBuildFileRemovals': len(freeze['build']),
    'totalTaskFileRemovalsIncludingPriorBuilds': len(removed),
    'recordedPids': packet['recordedPids'], 'allRecordedPidsAbsent': True,
    'port4501Closed': True, 'archiveVerified': True, 'scratchAbsent': not scratch.exists(),
    'remaining': remaining, 'failures': failures,
    'preserved': ['source changes/history', 'retained task evidence', 'shared caches',
                  'umbrella worktree/branch/claim', 'genuine save']}
(target / 'cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ['removedPaths','recordedPids']}))
assert remaining == [] and failures == [] and not scratch.exists()
