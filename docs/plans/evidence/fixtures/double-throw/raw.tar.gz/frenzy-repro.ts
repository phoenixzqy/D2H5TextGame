import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills, getSkill } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry(); loadDefaultSkills();
const id = 'skills-barbarian-frenzy', skill = getSkill(id); assert.ok(skill);
const observations = [];
for (const rank of [1, 2, 20]) for (const seed of [7, 19, 41, 97]) {
 const native = playerToCombatUnit({ ...createMockPlayer('Synthetic Frenzy', 'barbarian'), id: 'hero', level: 30,
  skillLevels: { 'skills-barbarian-bash': 1, 'skills-barbarian-double-swing': 1, 'skills-barbarian-double-throw': 1, [id]: rank }, comboOrder: [id] });
 assert.deepEqual(native.skillOrder, [id]);
 const hero: CombatUnit = { ...native, life: 1000000, mana: 1000000, statuses: [], manaRegenPerSecond: 0, manaRegenBaselinePerSecond: 0,
  stats: { ...native.stats, lifeMax: 1000000, manaMax: 1000000, attackSpeed: 100, critChance: 0,
   defense: 0, magicResist: 0, physDodge: 0, magicDodge: 0 } };
 const hold: ActiveStatus = { id: 'stun', sourceId: 'synthetic-enemy-hold', stacks: 1, remaining: -1, appliedAtMs: 0 };
 const enemy: CombatUnit = { ...hero, id: 'enemy', side: 'enemy', kind: 'monster', skillOrder: [], skillLevels: {}, statuses: [hold],
  stats: { ...hero.stats, attackSpeed: 0 }, gridPosition: { row: 0, col: 0 } };
 const input = { seed, playerTeam: [hero], enemyTeam: [enemy] }, before = structuredClone(input), actual = runBattleRecorded(input);
 assert.deepEqual(input, before); assert.deepEqual(runBattleRecorded(input), actual);
 const control = runBattleRecorded({ ...input, playerTeam: [{ ...hero, skillOrder: [], skillLevels: {} }] });
 const times = (out: typeof actual) => out.events.flatMap(e => e.kind === 'action' && e.actor === 'hero' ? [e.simClockMs] : []);
 const actualTimes = times(actual), controlTimes = times(control);
 const hits = actual.events.flatMap(e => e.kind === 'damage' && e.source === 'hero' && !e.dodged && e.amount > 0 ? [e] : []);
 assert.ok(hits.length > 2); assert.ok(actualTimes.length > 2);
 assert.equal(actual.events.filter(e => e.kind === 'mana' && e.reason === 'cast').length, actualTimes.length);
 const deltas = actualTimes.slice(1).map((time, i) => time - (actualTimes[i] ?? 0));
 observations.push({ rank, seed, landedHits: hits.length, actualTimes, controlTimes, deltas,
  sameCadenceAsBasic: JSON.stringify(actualTimes) === JSON.stringify(controlTimes),
  speedIncreaseObserved: deltas.some(delta => delta < 1700),
  initialAttackSpeed: hero.stats.attackSpeed, finalAttackSpeed: actual.result.playerTeam[0]?.stats.attackSpeed,
  finalStatuses: actual.result.playerTeam[0]?.statuses, events: actual.events });
}
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-double-throw-4rxrdvb1/frenzy-observations.json', JSON.stringify({ synthetic: true, skill, observations }, null, 2));
console.log(JSON.stringify(observations.map(({ events, ...row }) => row), null, 2));
assert.ok(observations.every(o => o.speedIncreaseObserved), 'Frenzy promises increasing speed on hits, but repeated paid landed hits never change the action cadence');
