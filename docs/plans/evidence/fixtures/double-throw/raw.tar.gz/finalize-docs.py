from pathlib import Path
import collections,csv,hashlib,io,json,re,subprocess
scratch=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
required=['full','engine','focused-final','types-final','lint','lint-corrected-test','build','browser','compatibility']
receipts={n:json.loads((scratch/(n+'.json')).read_text()) for n in required}
assert all(r['exit']==0 for r in receipts.values())
log=(scratch/'full.log').read_text()
assert re.search(r'Test Files\s+687 passed',log)
assert re.search(r'Tests\s+15103 passed\s*\|\s*2 skipped',log)
duration=re.search(r'Duration\s+([\d.]+)s',log).group(1)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head!=json.loads((scratch/'freeze.json').read_text())['head']
short=head[:8]
(scratch/'final-validation-summary.json').write_text(json.dumps({'sourceCommit':head,'fullTests':15103,'fullFiles':687,'existingSkips':2,'vitestSeconds':float(duration),'receipts':receipts},indent=2)+'\n')
inventory=repo/'docs/plans/skill-inventory.csv'
before=(scratch/'inventory-before.csv').read_bytes();assert inventory.read_bytes()==before
lines=before.splitlines(keepends=True);index=next(i for i,line in enumerate(lines) if line.startswith(b'barbarian,skills-barbarian-double-throw,'))
fields=next(csv.reader([lines[0].decode()]))
row=dict(zip(fields,next(csv.reader([lines[index].decode()]))))
row.update(risk_flags='author-pool-contract|independent-acceptance-open|earned-balance-open',behavior_verification='bounded-functional;independent-acceptance-open',contract_evidence='docs/plans/decisions/D04-double-throw-v1.md;docs/plans/evidence/d04-double-throw.md')
out=io.StringIO(newline='');csv.writer(out,lineterminator='\r\n' if lines[index].endswith(b'\r\n') else '\n').writerow([row[k] for k in fields])
updated=list(lines);updated[index]=out.getvalue().encode()
assert all(a==b for i,(a,b) in enumerate(zip(lines,updated)) if i!=index)
inventory.write_bytes(b''.join(updated));rows=list(csv.DictReader(io.StringIO(inventory.read_text())))
assert len(rows)==len({r['data_id'] for r in rows})==213
counts=dict(collections.Counter(r['behavior_verification'] for r in rows))
assert sum(n for k,n in counts.items() if k.startswith('bounded-functional;'))==113 and counts['unverified']==98
audit={'creditedOnly':'skills-barbarian-double-throw','rows':213,'otherRowsByteExact':212,'orderPreserved':True,'counts':counts,'barbarianBounded':15,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(inventory.read_bytes()).hexdigest()}
(scratch/'inventory-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
evidence=f'''# D04 — Double Throw's actual bounded pair

2026-10-25; [contract](../decisions/D04-double-throw-v1.md),
[BUG215](../../../production/bugs/BUG-215-double-throw-single-attempt.md).
Source/tests/contract `{short}`. Author verification only; independent design/QA
and earned class/build acceptance remain open.

## Behavior

Two total independently resolved throws rotate within the same original up-to-two
living-enemy pool. Existing selection prioritizes enemy summons, then battle
insertion order. Singleton can receive both; dead originals are skipped and
surviving originals can receive remaining attempts. No outside replacement;
caster/pool death ends the cast. Misses consume attempts. One12MP/CD1 commitment.
Preserve Physical50–75/+5rank, unlock12/cap20, Double Swing prerequisite/Bash ancestor
and existing equipment eligibility. No new weapon-stat contribution, save/version,
dependency or global target-policy change. JSON opts into the existing shared
sequence runtime without changing it; closed schema rejects contradictory modes.

The up-to-two pool/default rotation is an explicit author resolution of the old
two-weapon promise. Double Swing retains two passes per target and Fury retains
five total attempts. Both locales now show damage per attempt, two total attempts,
pool/miss/death/payment rules and current/next/MAX correctly.

## Mechanical and integration proof

40new cases/four files:10schema/registration/pure display,20native causal/playback,
2native allocation/wave/save and8actual bilingual UI.36rank/seed/layout scenarios
cover ranks1/2/20 ×seeds7/19/41/97 ×one/two/four enemies. Actual HP/MP deltas,
immutable exact replay and ordinary runBattle equality pass. Full HP/MP/living
active-status playback matches the authoritative result.

Seed41 consumes a first miss and still resolves the second throw. Independent
critical outcomes, ordinary Defense/50%Physical resistance, personal Bone Armor
absorption across reflected hits and lethal-reflection stop are covered. First
original death creates one death/corpse/two boss orbs, second throw remains on
the other original, outside enemies remain unchanged. A killed singleton ends
after one attempt. Enemy-summon priority is verified. Shield/corpse contexts are
explicit synthetic shared-consumer state, not earned Barbarian access.

At500ms action cadence, casts at500/1500ms each pay once;1000ms uses an ordinary
attack before cooldown expiry. Insufficient MP/CD prevents the entire skill.
Native class/unlock/prerequisite/rank/MAX/alias checks, allocation during a frozen
recording, next-wave use and resource-preserving save/import pass. No saved
combat teams/status or pool refill is introduced.

## Browser and build proof

Four production cases:en/zh-CN ×360×640/1280×800. Public create/export/import,
allocation1→2, priority configuration, actual cast and Save-close-new-page-Continue.
All four first casts produce exactly two positive1HP attacks, on Bone WarriorsA/B,
after actual enemy mitigation. This is mechanical proof, not damage viability.
Synthetic L30/pools/imported helmet/fixed combat Date.now are declared; no test
bridge or earned campaign action. Eight pairs preserve player/inventory/map/
mercs/formation exactly; meta idle clocks may advance on real reopen.
20geometry checks cover360×640/412×915/640×360/1280×800/1920×1080, no horizontal
overflow and allocation≥44px.16screenshots/four individually inspected show
bilingual descriptions, current/next per-attempt numbers and real logs.
Existing missing navigation glyphs/full a11y/device/offline acceptance stay open.
Four bridge-free chunks,756present precache URLs. Existing main-bundle/generated
manifest precache warnings and performance/test budgets remain open.

## Validation and limits

Native/schema/display RED15failed/17passed and UI RED8failed are retained.
Focused-final40/4, engine7798/290, compatibility84/7 (including actual shared
loader1/1), types-final/lint/corrected-test lint/build/browser PASS.
Full15103/687/two existing skips PASS:Vitest{duration}s,
wrapper{receipts['full']['seconds']:.3f}s. No new skip, weakened assertion or disabled test was introduced.

Initial typecheck failedTS2379 because a negative display fixture assigned
optional hitSequence:undefined under exactOptionalPropertyTypes. It now omits
the property, preserving the same missing-sequence expectation. The full run
began before this equivalent test-only correction; final focused/typecheck and
surgical lint verify final test bytes. Gameplay source/build stayed frozen;
no full restart or cancellation. The pre-correction fixture/freeze and failed
receipt remain retained. All1185delivered source/config/contracts and760build
hashes/genuine save are audited, including actual committed Git blobs.
Author five-axis/security review has no required finding; independent review
and earned balance remain open.

## Delivery

Only Double Throw gains inventory credit:113bounded-functional/98unverified/
one engine-only/one review-needed; Barbarian15/30. All213IDs/order and212other
rows remain byte-exact. [Frenzy](d04-frenzy-repro.md) separately reproduces inert
speed from repeated paid landed hits, without patch or credit.

RETENTION-CLEANUP-PENDING

[Raw archive](fixtures/double-throw/raw.tar.gz),
[member manifest](fixtures/double-throw/packet.json),
[source audit](fixtures/double-throw/source-delivered.json),
[browser audit](fixtures/double-throw/browser-audit.json),
[cleanup receipt](fixtures/double-throw/cleanup.json).
Genuine Ancients/Rite staysL33/XP149261/nextNormal402/Nightmare0/Baal uncleared,
decompressed SHA256
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`.
C0/C1 retain narrow exits; C2–C4/fullG0–G7/seven classes/two earned builds each/
30–50hour pacing/economy/endgame/independent acceptance and full privatev1 remain
unfinished. No genuine campaign or remote action. Root sole writer/reviewer;
umbrella goal/branch/worktree/claim active.
'''
(repo/'docs/plans/evidence/d04-double-throw.md').write_text(evidence)
bug=repo/'production/bugs/BUG-215-double-throw-single-attempt.md'
s=bug.read_text().replace('- Status: reproduced; repeated-throw/target-pool contract and repair open.',f'- Status: locally fixed in `{short}`; independent/earned acceptance open.')
bug.write_text(s+f'\n\n## Local repair\n\n`{short}` opts into two total original-pool attempts under the [author contract](../../docs/plans/decisions/D04-double-throw-v1.md).40new regressions, production4/4, full15103/687/two existing skips and final types/lint/build pass. [Delivery evidence](../../docs/plans/evidence/d04-double-throw.md) retains original RED/type failure, synthetic limits, committed-source hashes and cleanup. Historical reproduction remains; independent design/QA and earned balance open.\n')
repro=repo/'docs/plans/evidence/d04-double-throw-repro.md'
repro.write_text(repro.read_text()+f'\n\n## Subsequent local repair\n\n`{short}` implements the [author contract](../decisions/D04-double-throw-v1.md). [Delivery verification](d04-double-throw.md) records actual independent original-pool throws, one payment, native save/wave lifecycle and production browser proof. Historical prepatch evidence is preserved; independent/earned acceptance remains open.\n')
ledger=repo/'docs/plans/execution-ledger.md';lines=ledger.read_text().splitlines(keepends=True)
i=next(i for i,line in enumerate(lines) if line.startswith('| D04 Double Throw / BUG215 |'))
lines[i]=f'| D04 Double Throw / BUG215 | locally fixed/verified; independent and earned acceptance open | Source/tests/contract `{short}`: two total independent attempts rotate in existing original up-to-two pool; singleton can receive both, one12MP/CD1, truthful bilingual per-attempt/per-cast UI.40new cases; focused40/4, engine7798/290, compatibility84/7, full15103/687/two existing skips/final types/lint/build PASS. Production4/4/eight exact five-domain Continue pairs/20geometry/16screenshots/four inspected. [Evidence](evidence/d04-double-throw.md).1185source committed blobs/760build/genuine audited. Only Throw credited:113bounded/98unverified/one engine-only/one review-needed, Barbarian15/30. Independent/earned gates and full privatev1 open; genuineL33/next402/Baal uncleared unchanged. |\n'
lines.insert(i+1,'| D04 Frenzy / BUG216 | hit-earned speed missing; contract/repair open |12native rank/seed pairs:35paid casts,27–30positive hits each, unchanged1700ms cadence matching basic controls; only scalar damage registered. [Reproduction](evidence/d04-frenzy-repro.md). No Frenzy patch/credit. |\n')
ledger.write_text(''.join(lines)+f'''\n\n## 2026-10-25 — Double Throw pair verified; Frenzy speed defect reproduced

Source/tests/contract `{short}` implements two total default-sequence attempts
inside the existing original up-to-two pool. Singleton receives both; misses,
mitigation, reflection/shields, target/caster death, actual HP/MP and immutable
resource/living-status playback pass. Native eligibility/allocation-current-wave/
next-wave/save and truthful bilingual current/next/MAX UI verified.
[Evidence](evidence/d04-double-throw.md).

Focused40/4, engine7798/290, compatibility84/7 including real loader1/1,
final types/lint/build/browser PASS; full15103/687/two existing skips,
Vitest{duration}s/wrapper{receipts['full']['seconds']:.3f}s. A negative-preview
fixture's explicit undefined was replaced by omission after full began; final
focused/typecheck/surgical lint cover delivered test bytes. Runtime/build stay
frozen.1185source/config/contract committed blobs,760build and genuine hashes
audited. Production4/4/eight exact five-domain Continue pairs/20geometry/
16screenshots/four inspected. Two first-cast attacks do1HP each; synthetic L30/
pools/helmet/fixed combat Date.now establish mechanics, not earned balance.

Only Throw credited:113bounded/98unverified/one engine-only/one review-needed,
Barbarian15/30;213IDs/order and212other rows byte-exact. Cleanup terminal
is recorded below and in delivery evidence. Frenzy separately reproduces
unchanged1700ms paid-hit cadence across12rank/seed pairs and35casts each,
27–30landed hits; no speed status/capability and no patch/credit.

GenuineL33/XP149261/nextNormal402/Nightmare0/Ancients-Rite claimed/Baal uncleared
and exact hash unchanged. C0/C1 retain narrow exits; C2–C4/fullG0–G7/all-class
earned builds/30–50hour pacing/economy/endgame/independent acceptance/privatev1
unfinished. No genuine campaign/remote action. Root sole writer/reviewer;
umbrella goal/branch/worktree/claim active.
''')
print(json.dumps({'sourceCommit':head,'inventory':audit,'fullVitestSeconds':duration}))
