import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/level30-travincal';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const input=root+'/attempt362/final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,363);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {loadItemBases}=await load('/src/data/loaders/loot.ts');
 const {checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts');
 const {prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts');
 const {deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts');
 const {mitigateDamage}=await load('/src/engine/combat/damage.ts');
 const {hashSeed}=await load('/src/engine/rng.ts');
 const bases=loadItemBases(),merc=save.mercs.ownedMercs.find(m=>m.id===save.mercs.fieldedMercId);
 assert(merc);
 const heroDerive=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
 const initial={hero:heroDerive(save.inventory.equipped),merc:deriveEquippedMercStats(merc,save.mercs.mercEquipment[merc.id])};
 const equipment={hero:{...save.inventory.equipped},merc:{...save.mercs.mercEquipment[merc.id]}};
 const derive=(who,gear)=>who==='hero'?heroDerive(gear):deriveEquippedMercStats(merc,gear);
 const score=(who,gear)=>{
  const s=derive(who,gear),base=initial[who];
  if(s.lifeMax<base.lifeMax*.85||s.manaMax<base.manaMax*.9||s.attackSpeed<base.attackSpeed||s.attack<base.attack*.95)return -Infinity;
  if(s.resistances.lightning<Math.min(base.resistances.lightning,70)||s.resistances.cold<Math.min(base.resistances.cold,60)||s.resistances.fire<Math.min(base.resistances.fire,45))return -Infinity;
  const hit=(type,amount)=>mitigateDamage(amount,{type,defenderArmor:s.defense,defenderMagicResist:s.magicResist,defenderResistances:s.resistances}).final;
  const incoming=.6*(.95*hit('physical',300)+.05*hit('physical',450))*Math.max(.05,.9-s.physDodge)+.4*hit('lightning',80)*Math.max(.05,.9-s.magicDodge);
  const power=1+s.critChance*(s.critDamage-1);
  return s.lifeMax/Math.max(1,incoming)*Math.sqrt(power*(who==='merc'?s.attack/base.attack:1));
 };
 const slots=['head','chest','gloves','boots','belt','amulet'];
 for(let pass=0;pass<2;pass++)for(const who of ['hero','merc'])for(const slot of slots){
  const person=who==='hero'?save.player:merc;
  const occupied=new Set([...Object.entries(equipment[who]).filter(([key])=>key!==slot).map(([,i])=>i?.id),...Object.values(equipment[who==='hero'?'merc':'hero']).map(i=>i?.id)]);
  let best=equipment[who],value=score(who,best);
  for(const item of save.inventory.backpack){
   if(occupied.has(item.id)||!slotMatches(bases.get(item.baseId)?.slot,slot)||!checkEligibility(item,person,bases).eligible)continue;
   const next={...equipment[who],[slot]:item},candidate=score(who,next);
   if(candidate>value+1e-12){best=next;value=candidate;}
  }
  equipment[who]=best;
 }
 const changes=[];
 for(const who of ['hero','merc'])for(const slot of slots){const old=(who==='hero'?save.inventory.equipped:save.mercs.mercEquipment[merc.id])[slot],item=equipment[who][slot];if(item?.id!==old?.id)changes.push({who,slot,from:old?.id??null,to:item.id});}
 const apply=()=>{restoreEarnedSave(save,0);for(const c of changes){const item=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(item);assert.deepEqual(c.who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(merc.id,c.slot,item),{ok:true});}};
 apply();
 const report={kind:'isolated owned-backpack defensive heuristic and eight fixed independent full-area seeds; no actual preparation or attempt consumed, no projected save promoted',inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),heuristic:'two fixed passes over six nonweapon/nonring slots per hero/retained Rogue; observed300physical (95/5% critical at450),80lightning effective life times sqrt critical power; preserve speed, >=85% life, >=90% mana, >=95% attack and capped resistance floors',initial,proposed:{hero:derive('hero',equipment.hero),merc:derive('merc',equipment.merc)},changes,seeds:Array.from({length:8},(_,i)=>hashSeed('L30-Mephisto-owned-defense-v2|'+i)),rows:[]};
 for(const adapted of [false,true])for(const seed of report.seeds){
  if(adapted)apply();else restoreEarnedSave(save,0);
  const h=startEarnedRun({act:3,subAreaId:'areas/act3-durance-of-hate',mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,363);const result=playEarnedTarget(h);
  report.rows.push({adapted,seed,outcome:result.terminalAdvance,waves:result.waves.map(w=>({wave:w.index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life})),players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life}))}))});
  useCombatStore.getState().endCombat();process.stdout.write(JSON.stringify({adapted,seed,outcome:result.terminalAdvance})+'\n');
 }
 report.summary=[false,true].map(adapted=>({adapted,n:report.seeds.length,wins:report.rows.filter(r=>r.adapted===adapted&&r.outcome==='victory').length}));
 assert.deepEqual(await readFile(input),raw);await writeFile(root+'/owned-mephisto-screen-v2.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({summary:report.summary,changes,proposed:report.proposed})+'\n');
}finally{await server.close();}
