import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import { readFile,writeFile } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const task='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/level30-travincal',repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const input=process.argv[2];assert(input);const raw=await readFile(input),save=JSON.parse(gunzipSync(raw));assert.equal(save.player.class,'sorceress');assert.equal(save.player.level,30);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try{
 const load=p=>server.ssrLoadModule(p),{restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{prepareTownRespec,executeTownRespec}=await load('/src/stores/respecActions.ts'),{hashSeed}=await load('/src/engine/rng.ts');
 const total=Object.values(save.player.skillLevels).reduce((a,b)=>a+b,save.player.skillPoints);assert.equal(total,37);assert.equal(save.map.challengeOrdinals.normal,363);
 const retained=['static_field','frozen_orb','blizzard','glacial_spike','ice_blast','ice_bolt'];
 const builds=[
 {id:'retained',recipe:null,order:retained,vitality:false},
 {id:'orb-first',recipe:null,order:['frozen_orb','static_field','blizzard','glacial_spike','ice_blast','ice_bolt'],vitality:false},
 {id:'ice-blast-control',recipe:null,order:['ice_blast','static_field','frozen_orb','glacial_spike','blizzard','ice_bolt'],vitality:false},
 {id:'glacial-control',recipe:null,order:['glacial_spike','static_field','frozen_orb','ice_blast','blizzard','ice_bolt'],vitality:false},
 {id:'blizzard-mastery',recipe:{ice_bolt:1,ice_blast:1,glacial_spike:1,blizzard:20,static_field:1,warmth:1,frost_nova:1,cold_mastery:11},order:['frost_nova','static_field','blizzard','glacial_spike','ice_blast','ice_bolt'],vitality:false},
 {id:'orb-frost-nova',recipe:{ice_bolt:1,ice_blast:1,glacial_spike:1,blizzard:1,frozen_orb:20,static_field:1,warmth:1,frost_nova:1,cold_mastery:10},order:['frost_nova','static_field','frozen_orb','glacial_spike','ice_blast','ice_bolt'],vitality:false}
 ];
 const seeds=Array.from({length:8},(_,i)=>hashSeed('L30-Mephisto-control-screen-v1|'+i));
 const report={kind:'isolated legal preparation screen; no genuine save/attempt/reset/allocation consumed or projected state promoted',input,inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),ordinal:save.map.challengeOrdinals.normal,totalAllocatedBudget:total,builds,seeds,rows:[]};
 for(const build of builds)for(const seed of seeds){
  restoreEarnedSave(save,0);const player=()=>usePlayerStore.getState().player;
  if(build.vitality){const before=player();assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:0,vitality:before.statPoints,energy:0},before),'ok');}
  if(build.recipe){const prepared=prepareTownRespec('npc/ormus','skill');assert.equal(prepared.kind,'ok');assert.equal(executeTownRespec(prepared.request),'ok');assert.equal(player().skillPoints,total);for(const [id,rank]of Object.entries(build.recipe))for(let i=0;i<rank;i++)assert.equal(usePlayerStore.getState().allocateSkillPoint('sorceress.'+id),'ok',id);assert.equal(player().skillPoints,0);}if(build.order)usePlayerStore.getState().setComboOrder(build.order.map(id=>'sorceress.'+id));
  const handle=startEarnedRun({act:3,subAreaId:'areas/act3-durance-of-hate',mode:'manual',runSeed:seed});assert.equal(handle.challengeOrdinal,save.map.challengeOrdinals.normal);const waves=[];
  for(let i=0;i<handle.totalWaves;i++){const wave=playEarnedWave(handle,i);waves.push({wave:i+1,winner:wave.played.outcome.winner,ms:wave.terminalSimClockMs,openingHero:wave.opening.playerTeam.filter(u=>u.kind==='hero').map(u=>({stats:u.stats,skillLevels:u.skillLevels,skillOrder:u.skillOrder,coldResistanceReductionPct:u.coldResistanceReductionPct})),terminal:wave.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana})),remaining:wave.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life,stats:u.stats}))});if(wave.advanceResult!=='next-wave')break;}
  const won=waves.length===handle.totalWaves&&waves.every(w=>w.winner==='player');report.rows.push({build:build.id,seed,won,waves});useCombatStore.getState().endCombat();process.stdout.write(build.id+' seed'+seed+' '+(won?'WIN':'NONWIN')+'\n');
 }
 report.summary=builds.map(b=>({build:b.id,n:seeds.length,wins:report.rows.filter(r=>r.build===b.id&&r.won).length}));assert.deepEqual(await readFile(input),raw);await writeFile(task+'/control-mephisto-screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(report.summary)+'\n');
}finally{await server.close();}
