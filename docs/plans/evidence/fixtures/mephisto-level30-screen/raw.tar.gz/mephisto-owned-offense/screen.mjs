import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/mephisto-owned-offense';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const input=repo+'/docs/plans/evidence/fixtures/earned-act3-through362/retained-final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,363);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {loadItemBases}=await load('/src/data/loaders/loot.ts');
 const {checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts');
 const {isTwoHanded}=await load('/src/engine/inventory/equipValidator.ts');
 const {prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts');
 const {deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts');
 const {mitigateDamage}=await load('/src/engine/combat/damage.ts');
 const {hashSeed}=await load('/src/engine/rng.ts');
 const bases=loadItemBases(),merc=save.mercs.ownedMercs.find(m=>m.id===save.mercs.fieldedMercId);
 assert(merc);
 const heroDerive=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
 const initial={hero:heroDerive(save.inventory.equipped),merc:deriveEquippedMercStats(merc,save.mercs.mercEquipment[merc.id])};
 const equipment={hero:{...save.inventory.equipped},merc:{...save.mercs.mercEquipment[merc.id]}};
 const derive=(who,gear)=>who==='hero'?heroDerive(gear):deriveEquippedMercStats(merc,gear);
 const score=(who,gear)=>{
  const s=derive(who,gear),base=initial[who];
  if(s.lifeMax<base.lifeMax*.9||s.manaMax<base.manaMax*.9||s.attackSpeed<base.attackSpeed||s.attack<base.attack*.95||s.defense<base.defense*.8||s.resistances.physical<base.resistances.physical)return -Infinity;
  if(s.resistances.lightning<Math.min(base.resistances.lightning,70)||s.resistances.cold<Math.min(base.resistances.cold,60)||s.resistances.fire<Math.min(base.resistances.fire,45))return -Infinity;
  const hit=(type,amount)=>mitigateDamage(amount,{type,defenderArmor:s.defense,defenderMagicResist:s.magicResist,defenderResistances:s.resistances}).final;
  const incoming=.6*(.9*hit('physical',300)+.1*hit('physical',525))*Math.max(.05,.9-s.physDodge)+.4*hit('lightning',80)*Math.max(.05,.9-s.magicDodge);
  const power=1+s.critChance*(s.critDamage-1);
  return power*(who==='merc'?s.attack/base.attack:1)*s.attackSpeed/base.attackSpeed*Math.sqrt(s.lifeMax/Math.max(1,incoming));
 };
 const slots=['weapon','head','chest','gloves','boots','belt','amulet','offhand','ring-left','ring-right'];
 for(let pass=0;pass<2;pass++)for(const who of ['hero','merc'])for(const slot of slots){
  if(who==='hero'&&slot==='ring-right')continue;
  const person=who==='hero'?save.player:merc;
  const occupied=new Set([...Object.entries(equipment[who]).filter(([key])=>key!==slot).map(([,i])=>i?.id),...Object.values(equipment[who==='hero'?'merc':'hero']).map(i=>i?.id)]);
  let best=equipment[who],value=score(who,best);
  for(const item of save.inventory.backpack){
   if(isTwoHanded(bases.get(item.baseId))||occupied.has(item.id)||!slotMatches(bases.get(item.baseId)?.slot,slot)||!checkEligibility(item,person,bases).eligible)continue;
   const next={...equipment[who],[slot]:item},candidate=score(who,next);
   if(candidate>value+1e-12){best=next;value=candidate;}
  }
  equipment[who]=best;
 }
 const changes=[];
 for(const who of ['hero','merc'])for(const slot of slots){const old=(who==='hero'?save.inventory.equipped:save.mercs.mercEquipment[merc.id])[slot],item=equipment[who][slot];if(item?.id!==old?.id)changes.push({who,slot,from:old?.id??null,to:item.id});}
 const apply=()=>{restoreEarnedSave(save,0);for(const c of changes){const item=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(item);assert.deepEqual(c.who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(merc.id,c.slot,item),{ok:true});}};
 apply();
 const report={kind:'isolated owned-backpack offensive heuristic and32 fixed independent full-area seeds; no actual preparation or attempt consumed, no projected save promoted',inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),heuristic:'two fixed coordinate passes; hero9/Rogue10 legal one-handed slots; power times sqrt effective life with >=90% life/mana, original speed, >=95% attack, >=80% defense, original physical resistance and capped elemental floors; observed300physical10%crit525',initial,proposed:{hero:derive('hero',equipment.hero),merc:derive('merc',equipment.merc)},changes,seeds:JSON.parse(await readFile('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/mephisto-single-target/screen.json','utf8')).seeds,rows:[]};
 for(const adapted of [true])for(const seed of report.seeds){
  if(adapted)apply();else restoreEarnedSave(save,0);
  const h=startEarnedRun({act:3,subAreaId:'areas/act3-durance-of-hate',mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,363);const result=playEarnedTarget(h);
  report.rows.push({adapted,seed,outcome:result.terminalAdvance,waves:result.waves.map(w=>({wave:w.index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life})),players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life}))}))});
  useCombatStore.getState().endCombat();process.stdout.write(JSON.stringify({adapted,seed,outcome:result.terminalAdvance})+'\n');
 }
 report.summary=[true].map(adapted=>({adapted,n:report.seeds.length,wins:report.rows.filter(r=>r.adapted===adapted&&r.outcome==='victory').length}));
 assert.deepEqual(await readFile(input),raw);await writeFile(root+'/screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({summary:report.summary,changes,proposed:report.proposed})+'\n');
}finally{await server.close();}
