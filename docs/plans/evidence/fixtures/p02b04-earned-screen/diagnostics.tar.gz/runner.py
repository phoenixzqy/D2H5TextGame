from pathlib import Path
import subprocess,sys,time,json,datetime
root=Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
t0=time.monotonic(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(name+'.log')).open('w') as out:
    result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
meta={'command':command,'cwd':str(Path.cwd()),'started':start,'seconds':round(time.monotonic()-t0,3),'exitCode':result.returncode}
(root/(name+'.meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta));sys.exit(result.returncode)
