# P02b04 frozen source expectations — observations, not supplied state

Input runtime/harness at e65af7c, P02b03 ecd86ad. Fixtures:
A frost6-fire1-same40.json (13actions), B frost5-fire1-warmth1-same40.json
(14actions). The only differences are fixture.id, Frost additional points5vs4,
and B's following Warmth1 action. Same name/epoch/seed/actions/gear otherwise.
Byte hashes in fixture-freezes.json. No execution has occurred at freeze.

These recipes are commands. No hero/merc/item/domain snapshots or expected
winner are passed into the harness. Every number below is a conditional source
expectation to compare with actual emitted observations, never a claimed run.
Unexpected refusal/nonwin/timeout does not prove the target build infeasible.

## Acquisition, affordability and ready state

- One farm action,40first-wave preparations, ordinals0..39; nativeclock seed
  policy, no acquisitionrunSeed. Target manual Den ordinal40 uses declared
  seed2223645302. Accepted historical context: p02b00-post-mr-den-feasibility.md;
  actual source paths earned-adapter.ts executeRecipe and earned-playback.ts
  playEarnedWave/abandonEarnedNextWave/playEarnedTarget.
- If all40W1win, authored W1 count8+(ordinal%13) sums554L2kills and11080XP.
  engine/progression/xp.ts: xpForKill(2)=20, xpRequired=floor(100*L^2.5),
  cumulative L6 threshold11013; L6 XP67, next8818. The prior39wins sum10920
  and cannot unlock required-level6 Frost. No extra farm/XP is permitted.
- Each level grants5attributes/1skillpoint (plus milestones not reached);
  initial Fire1spends1, postfarm five available. A Frost1+5=6/Fire1/Warmth0;
  B Frost1+4=5/Fire1/Warmth1; both zero remaining. Starter Ice1remains. Source:
  engine/progression/xp.ts awardXp, features/character/createMockPlayer.ts,
  stores/playerStore.ts allocateSkillPoint, stores/skillsHelpers.ts and
  data/skills/sorceress.json. 6/1/1requires6postfarm points and is excluded.
- Conditional ready hero L6XP67, core Strength10/Dexterity25/Vitality25/Energy45,
  statpoints0, skillpoints0, lifeMax190,manaMax137,ATK32,defense43,speed125,MR0.
  Current resources must equal their native preallocation/pregear values,
  conditional historical120HP/102MP; no refill. Source: progression/stats.ts,
  progression/equipped-stats.ts, playerStore allocation, createMockPlayer,
  accepted p02b00. Native loot/orb/combat outcomes may change current resources;
  record actuals and explain deviations without substituting reference state.
- Merc starts hired rogueL3 with148HP/79MP/ATK25/saveddefense26. Conditional
  same40 XP8310 (75% of11080), advancing through the actual mercXpForLevel
  floor(60*L*1.30^(L-1)) curve gives L9XP249/next4404,lifeMax196. Historical
  current196HP/79MP and fixedATK25 must be reobserved. Source: mercStore.ts
  MERC_XP_SHARE/progression and mercFactory.ts/mercs loader, accepted P13b.
  Do not recompute offense from new level or inject historical healing.
- Hero glove5/boots3 are exact normal items/base/glove-leather and
  items/base/boot-leather; owned merc glove4 is exact normal glove-leather.
  Select first acquired original earned ID still in backpack. Record matching
  journal positions, before/after inventories, owner equipment and originalIDs;
  no globalID literal or best-available fallback. Source: earned-state.ts
  selectEarnedBackpackItem; accepted P13c01b/previous tiny native loot.
  Hero base L6defense35+5+3=43. Merc saveddefense26 is unchanged; equipped
  projection30at target. Missing gear stops native action and target is absent.
- At Energy45, normal recovery9MP/s; Warmth1 multiplies1.04→9.36 and grants
  fire+1%. Frost nominal base A40–50/B37–47 before enemy mitigation. Source:
  engine/progression/warmth.ts, data/skills/sorceress.json and engine skills
  builders/combat effects. Effective casts/misses/crit/freeze/orbs/survival
  remain unmeasured. Source arithmetic is no constant-DPS combat substitute.

## Invariants and outcome accounting

Full report retains2fresh ordered attempts per fixture and1comparison at the
fixed target seed. All returned source/tool identities and actual disk source
entries must match input head; no input source/gameplay changes during runs.
No allocator reset; identity initial state unobserved. Repetitions share only
module allocation state by declared design; no persisted domains are carried
from A to B or across repetitions. Acquisition carries only within an attempt.

For every successful preparation, record actual W1 outcome, exactly one native
settlement, original reward/XP/currency/journal delta, installed W2 at cursor0
and complete native flee snapshots. Installed W2 is unplayed/unawarded and
excluded from attempted logical/UI clocks; its engine calculation affects wall
and memory. At most40preps/attempt, stop nativepreparationnonwin immediately.
For target record every attempted wave and native advance/outcome, actual
reward independently of winner flag, resource/status carry, terminal result,
clears and quest objectives. Stop first native nonwin. No W3/W4/clear/quest
completion is an assertion prerequisite and no claim action exists.

Logical =sum attempted end-event sim clocks/1000. UI-hint=sum attempted opening
recorded event delays/1000. Adapter wall includes execution/restoration; report
CLI execution deadline30s includes startup/import/comparison/encode/write.
Separate exact-group cleanup grace up to2s and totalwall. Maximum4freshattempts,
160prepW1+160installedunplayedW2+16Denwaves. Source supports bounded native
execution, not a guarantee of affordable runtime/report size or final victory.

Record all returned comparator flags without requiring raw/semantic/battle
identity equality to pass. If inequality occurs retain complete diffs and
investigate its source; only known Items' top-level IDs may be omitted from
semantic reward projection. A/B differences are build observations at one seed,
not statistical winrate, independent fourseed sample, or human active-hour
campaign timing. Reps may have different allocator IDs; retain all originals.

Full raw files, fingerprints, manifests, exact command/timing/timeout/error
metadata, conditional check outcomes and independent reviewer findings are
required evidence. A structural failure or timeout stops later commands and
requires separate diagnosis; no rerun, deadline increase, truncation or assertion
weakening. Preserve all partial diagnostics. Full campaign/balance/pacing,
first-act UI, C0–C4/G0–G7 and privatev1 remain unaccepted regardless of outcome.

## Reviewed source locations

Design review traced count to `src/data/maps/sub-areas/act1.json:6,85` and
`src/engine/combat/sub-area-run.ts:405`, XP to `xp.ts:18,29,69,95` and
`combatHelpers.ts:533`, starter ranks/core to `createMockPlayer.ts:33,55,112,119`,
allocation to `playerStore.ts:220`, Frost data to `sorceress.json:37,75`, stats to
`progression/stats.ts:99,105,108,109`, current-resource preservation to
`equipped-stats.ts:8,21`, MR to `combat/mitigation.json:3`, recovery/Warmth to
`combat/recovery.json:3`, `progression/warmth.ts:34,47` and
`sorceress.json:793,807`. Paths shortened here are relative to their directories
in the preceding sections, not new calculation modules.

Merc source: `data/loaders/mercs.ts:98,125,178`,
`data/gacha/mercenaries.json:466`, `stores/mercFactory.ts:19`,
`stores/mercStore.ts:38,54,78,308,344,366`,
`engine/progression/merc-equipment-stats.ts:16,28` and
`stores/mercToCombatUnit.ts:32,59`. Merc L3..8 costs are
304+527+856+1336+2027+3011=8061;8310−8061=249. Every slainXP20 yields
floor(20*.75)=15mercXP, so no rounding discrepancy in the conditional total.
Merc combat entry projects fresh resources; living Den wave carry is a separate
native policy. File locations are reviewed against current head before run.
