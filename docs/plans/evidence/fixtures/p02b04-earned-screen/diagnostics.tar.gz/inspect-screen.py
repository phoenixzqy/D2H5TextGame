from pathlib import Path
import json,hashlib,collections,subprocess,gc
r=Path(__file__).parent;w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
merc='mercs/act1-rogue-inner-sight'
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,h in json.loads((r/'contract-freezes.json').read_text()).items():assert sha((r/name).read_bytes())==h
for name,h in json.loads((r/'preserved-baseline.json').read_text()).items():assert sha((w/name).read_bytes())==h
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
def fingerprint(entries):
 h=hashlib.sha256(b'd2h5-file-entries-v1\0')
 for path,b in sorted(entries):h.update(json.dumps([path,len(b)],separators=(',',':'),ensure_ascii=False).encode());h.update(b)
 return h.hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
identities=['sourceSha','sourceTreeHash','dataHash','nodeVersion','vitestVersion','manifest','collectionPolicy']
summary={}
for label,fixture in [('a','frost6-fire1-same40.json'),('b','frost5-fire1-warmth1-same40.json')]:
 path=r/('screen-'+label+'-earned-report.json');report=json.loads(path.read_text());expected=json.loads((r/fixture).read_text());assert report['fixture']==expected
 assert report['provenance']['fixtureHash']==fingerprint([('fixture.json',canonical(expected).encode())])
 assert report['provenance']['sourceSha']==head
 source=report['sourceBeforeImport'];entries=[]
 for m in source['manifest']:
  b=(w/m['path']).read_bytes();assert len(b)==m['byteLength'] and sha(b)==m['sha256'];entries.append((m['path'],b))
 assert fingerprint(entries)==source['sourceTreeHash'] and fingerprint([(p,b) for p,b in entries if p.startswith('src/data/')])==source['dataHash']
 states=[source,report['sourceAfter']]+[s for a in report['attempts'] for s in [a['sourceBefore'],a['sourceAfter']]]
 assert all(all(s[k]==source[k] for k in identities) for s in states)
 assert [(a['targetSeed'],a['repetition']) for a in report['attempts']]==[(2223645302,1),(2223645302,2)]
 attempts=[]
 for a in report['attempts']:
  assert a['status']=='completed' and a['refusal'] is None and all(x['result']['ok'] for x in a['actions'])
  farms=[f for x in a['actions'] for f in x['farms']];assert len(farms)==40 and [f['handle']['challengeOrdinal'] for f in farms]==list(range(40))
  assert all(len(f['waves'])==1 and f['waves'][0]['advanceResult']=='next-wave' and f['waves'][0]['opening']['outcome']['winner']=='player' and f['abandoned']['opening']['eventCursor']==0 and not f['abandoned']['opening']['playbackComplete'] and f['abandoned']['beforeFlee']==f['abandoned']['afterFlee'] for f in farms)
  prep=[f['waves'][0] for f in farms];target=a['target']['waves'];waves=prep+target
  assert sum(x['actualDelta']['xp'] for x in prep)==11080 and sum(sum(x['actualDelta']['mercXp'].values()) for x in prep)==8310
  assert len(a['acquisitionJournal'])==344
  p=a['preTarget']['player']['player'];ds=p['derivedStats'];ms=a['preTarget']['merc'];m=ms['ownedMercs'][0]
  assert [p['level'],p['experience'],p['experienceToNextLevel'],p['statPoints'],p['skillPoints']]==[6,67,8818,0,0]
  assert p['coreStats']=={'strength':10,'dexterity':25,'vitality':25,'energy':45}
  assert [ds[k] for k in ['life','lifeMax','mana','manaMax','attack','defense','attackSpeed','magicResist']]==[120,190,102,137,32,43,125,0]
  levels=p['skillLevels'];assert levels['sorceress.frost_nova']==(6 if label=='a' else 5) and levels['sorceress.fire_bolt']==1 and levels['sorceress.ice_bolt']==1 and levels.get('sorceress.warmth',0)==(0 if label=='a' else 1)
  assert m['level']==9 and ms['mercProgress'][merc]=={'experience':249,'experienceToNextLevel':4404}
  assert [m['derivedStats'][k] for k in ['life','lifeMax','mana','attack','defense','magicResist']]==[196,196,79,25,26,0]
  for act in a['actions']:
   if act['action']['kind'] in ['allocate-stats','equip-earned']:
    for k in ['life','mana']:assert act['before']['player']['player']['derivedStats'][k]==act['after']['player']['player']['derivedStats'][k]
  gear=[]
  for act in a['actions']:
   if act['action']['kind']!='equip-earned':continue
   iid=act['result']['itemId'];index=next(i for i,x in enumerate(a['acquisitionJournal']) if x['id']==iid);item=a['acquisitionJournal'][index]
   assert item['baseId']==act['action']['selector']['baseId'] and item['baseRolls']['defense']==act['action']['selector']['defense']
   assert iid not in [x['id'] for x in act['after']['inventory']['backpack']]
   gear.append({'owner':act['action']['owner'],'slot':act['action']['slot'],'id':iid,'journalIndex':index,'defense':item['baseRolls']['defense']})
  assert [x['journalIndex'] for x in gear]==[2,3,0]
  hero=target[0]['opening']['playerTeam'][0];mercunit=target[0]['opening']['playerTeam'][1]
  assert hero['manaRegenPerSecond']==(9 if label=='a' else 9.36) and hero['increasedDamagePct']=={'fire':0 if label=='a' else .01}
  assert mercunit['stats']['defense']==30
  logical=0;ui=0
  for x in waves:
   logical+=x['terminalSimClockMs']/1000;wave_ui=0
   for e in x['opening']['recordedEvents']:wave_ui+=e['uiDelayMs']/1000
   ui+=wave_ui
  print('timing comparison', label, a['repetition'], repr(logical), repr(a['timings']['logicalSimSeconds']), repr(ui), repr(a['timings']['uiDelayHintSeconds']), flush=True)
  assert logical==a['timings']['logicalSimSeconds'] and ui==a['timings']['uiDelayHintSeconds']
  wave_summary=[]
  for wave in target:
   out=wave['opening']['outcome'];wave_summary.append({'wave':wave['index']+1,'winner':out['winner'],'advance':wave['advanceResult'],'logicalSeconds':wave['terminalSimClockMs']/1000,'events':len(wave['opening']['recordedEvents']),'openingResources':[{'id':u['id'],'life':u['life'],'mana':u['mana']} for u in wave['opening']['playerTeam']],'finalResources':[{'id':u['id'],'life':u['life'],'mana':u['mana']} for u in out['finalPlayerTeam']],'enemiesAlive':sum(u['life']>0 for u in out['finalEnemyTeam']),'enemyLifeRemaining':sum(u['life'] for u in out['finalEnemyTeam']),'actualDelta':{k:v for k,v in wave['actualDelta'].items() if k!='addedItems'},'addedItems':len(wave['actualDelta']['addedItems'])})
  attempts.append({'rep':a['repetition'],'status':a['status'],'preparations':40,'prepHeroXp':11080,'prepMercXp':8310,'prepItems':344,'prepShardDelta':sum(x['actualDelta']['currencies'].get('rune-shard',0) for x in prep),'readyPlayer':p,'readyMerc':ms,'gear':gear,'targetWaves':wave_summary,'targetAdvance':a['target']['terminalAdvance'],'timings':a['timings'],'terminalQuest':a['terminal']['map']['questProgress'].get('quests/act1-den-of-evil'),'terminalClears':a['terminal']['map'].get('clearedSubAreas')})
 diffs=[]
 def diff(a,b,path=()):
  if type(a)!=type(b):diffs.append({'path':list(path),'first':a,'second':b});return
  if isinstance(a,dict):
   assert a.keys()==b.keys(),path
   for k in a:diff(a[k],b[k],path+(k,))
  elif isinstance(a,list):
   assert len(a)==len(b),path
   for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+(i,))
  elif a!=b:diffs.append({'path':list(path),'first':a,'second':b})
 diff(*report['attempts'])
 (r/('screen-'+label+'-repeat-differences.json')).write_text(json.dumps(diffs,indent=2)+'\n')
 is_item_identity=lambda x: x['path'][-1]=='id' or (len(x['path'])==4 and x['path'][0]=='actions' and x['path'][2:]==['result','itemId'] and report['attempts'][0]['actions'][x['path'][1]]['action']['kind']=='equip-earned')
 ids=[x for x in diffs if is_item_identity(x)];other=[x for x in diffs if not is_item_identity(x)];assert {x['path'][-1] for x in other}=={'repetition','wallSeconds'} and len(other)==2
 pairs=collections.Counter((x['first'],x['second']) for x in ids)
 assert all(x.startswith('it-') and y.startswith('it-') and x.split('-')[1]==y.split('-')[1] for x,y in pairs)
 offsets={int(y.split('-')[2],36)-int(x.split('-')[2],36) for x,y in pairs}
 actual_items=344+sum(len(w['actualDelta']['addedItems']) for w in report['attempts'][0]['target']['waves']);assert offsets=={actual_items} and len(pairs)==actual_items
 summary[label]={'reportBytes':path.stat().st_size,'provenance':report['provenance'],'sourceStates':len(states),'manifestEntries':len(source['manifest']),'comparisons':report['comparisons'],'attempts':attempts,'repeatDifferences':{'total':len(diffs),'itemIdOccurrences':len(ids),'originalItemPairs':len(pairs),'sequenceOffsets':sorted(offsets),'otherFields':['repetition','wallSeconds']}}
 (r/('screen-'+label+'-observed-summary.json')).write_text(json.dumps(summary[label],indent=2)+'\n')
 print(label,json.dumps({'bytes':summary[label]['reportBytes'],'prep':40,'targetWaveWins':[v['winner'] for v in attempts[0]['targetWaves']],'targetAdvance':attempts[0]['targetAdvance'],'repeatDifferences':summary[label]['repeatDifferences']}))
 del report,states,attempts,diffs,pairs,entries;gc.collect()
(r/'screen-observed-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
