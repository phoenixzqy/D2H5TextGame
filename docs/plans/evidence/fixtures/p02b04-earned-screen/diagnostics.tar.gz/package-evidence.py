from pathlib import Path
import json,hashlib,tarfile,collections,subprocess,stat
r=Path(__file__).parent;w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
d=w/'docs/plans/evidence/fixtures/p02b04-earned-screen';d.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
counts={}
for p in sorted(r.glob('*-test-report.json'))+sorted(r.glob('final-unit-report.json')):
 j=json.loads(p.read_text());actual=collections.Counter(a['status'] for f in j['testResults'] for a in f['assertionResults'])
 counts[p.name]={'files':len(j['testResults']),'actual':dict(actual),'aggregatePassed':j['numPassedTests'],'aggregateFailed':j['numFailedTests']}
 assert actual=={'passed':3151 if p.name=='final-unit-report.json' else 1}
(r/'test-report-counts.json').write_text(json.dumps(counts,indent=2)+'\n')
for name in ['final-unit','final-typecheck','final-lint','screen-a','screen-b']:
 assert json.loads((r/(name+'.meta.json')).read_text())['exitCode']==0
for name,h in json.loads((r/'preserved-baseline.json').read_text()).items():assert sha((w/name).read_bytes())==h
for name,h in json.loads((r/'contract-freezes.json').read_text()).items():assert sha((r/name).read_bytes())==h
for name in ['frost6-fire1-same40.json','frost5-fire1-warmth1-same40.json']:(d/name).write_bytes((r/name).read_bytes())
paths=sorted(p for p in r.rglob('*') if p.is_file())
assert all(not p.is_symlink() and stat.S_ISREG(p.stat().st_mode) for p in paths)
records=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths]
a=d/'diagnostics.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=9) as tar:
 for p in paths:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
packet={'task':'P02b04','inputHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'scope':'frozen two recipes, one historical seed/build, two determinism repetitions each; neither clears Den; no C/G/privatev1 acceptance','contractFreezes':json.loads((r/'contract-freezes.json').read_text()),'preservedBaseline':json.loads((r/'preserved-baseline.json').read_text()),'sourceSnapshotHashes':json.loads((r/'source-snapshot-hashes.json').read_text()),'observed':json.loads((r/'screen-observed-summary.json').read_text()),'testCounts':counts,'commands':[json.loads(p.read_text()) for p in sorted(r.glob('*.meta.json'))],'archive':{'file':a.name,'bytes':a.stat().st_size,'sha256':sha(a.read_bytes()),'files':records},'cleanup':{'owner':'root','state':'pending final packet review/release; closing ledger records result','paths':[str(r),str(w/'node_modules/.vite')],'installedTools':'preserved','overallWorktree':'retained for active fullv1'},'limitations':['Four attempts are one seed/build, two determinism reps; no build viability or win-rate estimate','No Den clear, quest completion, idle eligibility, browser/campaign/pacing/finalbalance or C/G acceptance','No new code, data, dependency/config changes; prior P02b03 build retained as historical only','Final Python sequential timing accumulation equals native JS exactly; intermediate1e-9tolerance script and original failures retained','Known Item.id and equip-earned action result.itemId differences retained, never allocator reset','No runtime defect established; no gameplay rerun or tuning from outcome review']}
(d/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'packetSha256':sha((d/'packet.json').read_bytes()),'archiveBytes':a.stat().st_size,'archiveSha256':sha(a.read_bytes()),'records':len(records),'commands':len(packet['commands']),'reports':len(counts),'sourceSnapshots':len(packet['sourceSnapshotHashes'])}))
