# P02b04 — bounded paired same40 fresh-earned Den screening

Full privatev1 objective remains active. This is the first reporting-harness
screen, not campaign, balance or C/G acceptance. Root alone edits/executes;
producer, QA and design review read-only. Begin execution only after P02b03
feature/evidence + closing-ledger commits and independent plan/fixture review.
No gameplay/data/harness/config/dependency/lock change is planned. Preserve all
accepted v1/v2 source/tests, package/README and default tiny bytes.

## Frozen question and sample

Compare two affordable alternative skill spends at exactly the historical
same40 acquisition boundary using current production actions. Two explicit v2
fixtures A/B, one predeclared target seed2223645302, repetitions1/2 per fixture:
maximum4 fresh attempts. Seed is the accepted historical Den clock-hash seed
from p02b00, chosen before execution, not searched for a win. Shared epoch is
1792497600000. No fallback seed, retry, farm, gear substitution, respec, free
point/refill/imported save or allocator reset, even after defeat/refusal.

Shared actions in order:
1. Hire mercs/act1-rogue-inner-sight.
2. Allocate FireBolt1 (skills-sorceress-fire-bolt) and combo[FireBolt].
3. Farm BloodMoor first waves count40, firstChallengeOrdinal0. Play/award each
   W1once; capture installed unplayedW2; nativeflee without award/clear. Native
   persisted earned domains feed the next preparation, not a reset per farm.
4. Checkpointearned40; allocate25attributes:15Vitality/10Energy/0Strength/Dex.
5. A spends5extraFrost ranks (existing1→6); B spends4extraFrost ranks (1→5)
   then1Warmth. Both retain Fire1,Ice1 and zero remaining skillpoints if all40
   awards succeed. 6Frost/1Fire/1Warmth is unaffordable and never executed.
6. Set combo[FrostNova,FireBolt]. Equip acquired original-ID hero normal
   glove-leather displayeddefense5, hero normal boot-leather displayeddefense3,
   owned merc normal glove-leather displayeddefense4, each first-acquired.
   These are the historical three pieces and occur in tiny's first current
   acquisition; do not substitute bestgear/hardcoded allocator IDs. Ordinary
   selector/action eligibility applies. Missing candidate/refusal stops the
   attempt with complete partial evidence, no target.
7. Accept quests/act1-den-of-evil; checkpointready. Target Act1/Den/manual,
   challengeOrdinal40,idleEliteMisses0,merc recipe-actions,summon defaults.

Only fixture id and A/B skill spending differ.13actionsA/14B, within32 limit.
The two fixture JSON files and a source-backed expectation document are frozen,
hashed and independently reviewed before commands. No new implementation logic
is necessary; static recipe records are validated through accepted actual
catalog parser inside sim:earned. Do not add a test whose pass requires victory.

## Observations and source-backed conditional checks

If all40preps win, count8+(ordinal%13) produces554L2kills and11080heroXP,
conditional L6XP67/next8818,25statpoints and5post-Fire skillpoints.39wins are
10920XP and not enough forL6. Reobserve all actual values; no source arithmetic
is injected. Conditional ready hero core10/25/25/45, life120/190,mana102/137,
ATK32/defense43/speed125/MR0. Native postfarm HP/MP persist through stats/gear;
compare before/after resource values rather than assume healing. Merc historical
8310XP→L9XP249/4404,HP196/196,MP79,ATK25,saveddefense26/projected30/MR0;
record current deviations. A mana9/s/fire0%; B9.36/s/fire+1%; nominal Frost base
A40–50/B37–47 before target mitigation. All source references and actual raw
fields in the expectation document; discrepancy investigation before patching.

Report complete preps, journal/IDs, actions, checkpoints, ready state, installed
records and attempted Den wave outcomes/rewards/carry, source identities,
comparisons, logical/UI/wall measures, report bytes, per-seed partial/nonwin.
Compare A/B at semantic prepared state keeping exact original IDs visible. Reps
are determinism observations, not4independent seed samples; only1seed/build.
Raw/semantic/battle equality values remain observations. Den stops first native
nonwin, otherwise native victory. No W3/W4/clear is promised. Quest objective
changes/clear are inspected from production only; no claim action is included.

## Runtime and failure bounds

Two reports execute sequentially A thenB, exactly once each via unchanged
sim:earned with external fixture/output leaves in this taskRAW.30second driver
timeout remains. Add task-owned process-group outer deadline30s/report including
npm/import/encoding/write (60s aggregate execution deadlines, plus separately recorded up to2s termination
grace per report). Root runner records exact
command/start/PID/PGID/wall/exit/timeout. On deadline terminate only that started
process group, wait2s then kill that exact group if still alive; no process-name
or shared-port kills. Preserve partial output/error/time budget evidence, do
not raise cap/truncate data/rerun. Any timeout or unexpected structural exception
stops later executions; native partial refusal/defeat is valid output and B
still runs unless a reviewed safety/resource concern requires stopping.

Maximum160attemptedprepW1,160installedunplayedW2,16attemptedDenwaves (4waves/run).
Native engine can evaluate336battles despite only176attempted.40prep report
bytes/memory/CPU are unmeasured; first output may be much larger than tiny. Check
free disk before A and after A, archive full reports compressed without
loss/omitting fields, clean disposable uncompressedRAW after consumers release.
Do not use synthetic seed/build snapshots as outcome evidence or mislabel
logical/UI time as online human duration. Outer cap is administrative, not
performance acceptance.

## Verification, disposition and cleanup

Use existing full reports, not implementation-derived winner oracles. Root
extracts/independently verifies all comparisons and conditional observations,
frozen hashes and actual source manifests; QA independently audits full outputs.
Preserve errors/deviations/inequalities and investigate source before any runtime
patch; confirmed runtime defects get structured bug report before patching.
No code changes planned, so do not add logic tests merely mirroring JSON. If
new behavior becomes necessary, stop screen changes and obtain independent
frozen genuine RED first. Final relevant checks required by repository contract
are appropriate U/T/L; no build concurrent with source-fingerprint consumers.
Build only if scope/source changes justify it; accepted P02b03 production build
is not claimed as a new-head gameplay test.

Independent final producer/QA/design review, durable bounded Markdown/packet with
complete compressed reports, exact commands/corrections/source snapshots. Commit
evidence/fixtures then separate closing ledger after all consumers release and
exactRAW/.vite/task-generated cleanup/absence verification. Root retains the
claimed worktree for continuing Den feasibility/first-act UI/campaign work. A
failed gate is a next investigated task, never completion or tuning permission.
No push/PR/merge/deployment; no privatev1/C0–C4/G0–G7 acceptance here.
