from pathlib import Path
import json,copy,hashlib
r=Path(__file__).parent
merc='mercs/act1-rogue-inner-sight';fire='skills-sorceress-fire-bolt';frost='skills-sorceress-frost-nova';warmth='skills-sorceress-warmth'
shared={'fixtureVersion':2,'id':'pending','origin':{'kind':'new-character','classId':'sorceress','name':'Same40 Earned','policy':'production-creation-defaults'},'clockEpochMs':1792497600000,'seeds':[2223645302],'acquisitionSeedPolicy':'production-clock','actions':[],'scenario':{'act':1,'subAreaId':'areas/act1-den-of-evil','mode':'manual','challengeOrdinal':40,'idleEliteMisses':0},'mercPolicy':'recipe-actions','summonPolicy':'production-default'}
initial=[{'kind':'hire-merc','mercId':merc},{'kind':'allocate-skill','skillId':fire,'points':1},{'kind':'set-combo','skillIds':[fire]},{'kind':'farm-first-waves','subAreaId':'areas/act1-blood-moor','count':40,'firstChallengeOrdinal':0},{'kind':'checkpoint','id':'earned40'},{'kind':'allocate-stats','deltas':{'strength':0,'dexterity':0,'vitality':15,'energy':10}}]
def equip(owner,slot,base,defense):
 a={'kind':'equip-earned','owner':owner,'slot':slot,'selector':{'baseId':'items/base/'+base,'rarity':'normal','defense':defense,'selection':'first-acquired'}}
 if owner=='merc':a['mercId']=merc
 return a
end=[{'kind':'set-combo','skillIds':[frost,fire]},equip('hero','gloves','glove-leather',5),equip('hero','boots','boot-leather',3),equip('merc','gloves','glove-leather',4),{'kind':'accept-quest','questId':'quests/act1-den-of-evil'},{'kind':'checkpoint','id':'ready'}]
hashes={}
for name,points,warm in [('frost6-fire1-same40',5,False),('frost5-fire1-warmth1-same40',4,True)]:
 f=copy.deepcopy(shared);f['id']='p02b04-'+name;f['actions']=copy.deepcopy(initial)+[{'kind':'allocate-skill','skillId':frost,'points':points}]+([{'kind':'allocate-skill','skillId':warmth,'points':1}] if warm else [])+copy.deepcopy(end)
 assert len(f['actions'])==(14 if warm else 13)
 p=r/(name+'.json');p.write_text(json.dumps(f,indent=2)+'\n');hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(r/'fixture-freezes.json').write_text(json.dumps(hashes,indent=2)+'\n');print(json.dumps(hashes,indent=2))
