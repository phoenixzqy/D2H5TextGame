from pathlib import Path
import subprocess,sys,time,json,datetime,os,signal
root=Path(__file__).parent
name=sys.argv[1];command=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
deadline=30;grace=2;timedout=False;signals=[];execution=None
with (root/(name+'.log')).open('w') as output:
 process=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 pgid=os.getpgid(process.pid)
 assert pgid==process.pid
 (root/(name+'.started.json')).write_text(json.dumps({'command':command,'cwd':str(Path.cwd()),'started':started,'pid':process.pid,'pgid':pgid,'executionDeadlineSeconds':deadline,'terminationGraceSeconds':grace},indent=2)+'\n')
 try:process.wait(timeout=deadline);execution=time.monotonic()-t0
 except subprocess.TimeoutExpired:
  timedout=True;execution=time.monotonic()-t0
  def send(sig):
   try:os.killpg(pgid,sig);signals.append({'signal':sig.name,'pgid':pgid})
   except ProcessLookupError:pass
  send(signal.SIGTERM)
  grace_end=time.monotonic()+grace
  group_alive=True
  while time.monotonic()<grace_end:
   process.poll()
   try:os.killpg(pgid,0)
   except ProcessLookupError:group_alive=False;break
   time.sleep(0.02)
  if group_alive:send(signal.SIGKILL)
  process.wait()
 total=time.monotonic()-t0
meta={'command':command,'cwd':str(Path.cwd()),'started':started,'pid':process.pid,'pgid':pgid,'executionDeadlineSeconds':deadline,'terminationGraceSeconds':grace,'executionSeconds':round(execution,3),'teardownSeconds':round(total-execution,3),'seconds':round(total,3),'exitCode':process.returncode,'timedOut':timedout,'signals':signals}
(root/(name+'.meta.json')).write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta));sys.exit(124 if timedout else process.returncode)
