# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: skills-header-layout.spec.ts >> shared header stays clear en bonus=false
- Location: tests/pwa/skills-header-layout.spec.ts:100:3

# Error details

```
Test timeout of 50000ms exceeded.
```

```
Error: locator.click: Test timeout of 50000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Import Save', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "主导航" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "营地" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: 营地
        - listitem [ref=e10]:
          - link "地图" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: 地图
        - listitem [ref=e14]:
          - link "战斗" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: 战斗
        - listitem [ref=e18]:
          - link "背包" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: 背包
        - listitem [ref=e22]:
          - link "技能" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: 技能
        - listitem [ref=e26]:
          - link "佣兵" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: 佣兵
        - listitem [ref=e30]:
          - link "任务" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: 任务
        - listitem [ref=e34]:
          - link "设置" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: 设置
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]: 设置
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - heading "语言" [level=2] [ref=e44]
            - generic [ref=e45]:
              - button "简体中文" [pressed] [ref=e46] [cursor=pointer]
              - button "English" [ref=e47] [cursor=pointer]
          - generic [ref=e48]:
            - generic [ref=e49] [cursor=pointer]:
              - generic [ref=e50]:
                - generic [ref=e51]: 摸鱼模式
                - generic [ref=e52]: 隐藏图标和颜色，便于上班时游玩
              - checkbox "摸鱼模式" [ref=e53]
            - generic [ref=e55] [cursor=pointer]:
              - generic [ref=e57]: 音效
              - checkbox "音效" [checked] [ref=e58]
            - generic [ref=e60] [cursor=pointer]:
              - generic [ref=e62]: 音乐
              - checkbox "音乐" [checked] [ref=e63]
          - generic [ref=e64]:
            - heading "存档管理" [level=2] [ref=e65]
            - generic [ref=e66]:
              - button "保存" [ref=e67] [cursor=pointer]
              - button "导出存档" [active] [ref=e68] [cursor=pointer]
              - button "导入存档" [ref=e69] [cursor=pointer]
              - button "删除存档" [ref=e70] [cursor=pointer]
          - generic [ref=e71]:
            - link "☕ 给我买杯咖啡" [ref=e72] [cursor=pointer]:
              - /url: https://www.buymeacoffee.com/
            - generic [ref=e73]: "版本: 0.1.0"
  - button "MMMMMMMMMMMMMMMM · 等级 1。点击查看角色面板。" [ref=e74] [cursor=pointer]:
    - generic [ref=e76]: "1"
    - generic [ref=e77]:
      - generic [ref=e78]:
        - generic [ref=e79]: MMMMMMMMMMMMMMMM
        - generic [ref=e80]: 等级 1
      - generic [ref=e81]:
        - generic [ref=e82]: HP
        - progressbar "HP" [ref=e83]
      - generic [ref=e85]:
        - generic [ref=e86]: MP
        - progressbar "MP" [ref=e87]
      - generic [ref=e89]:
        - generic [ref=e90]: XP
        - progressbar "XP" [ref=e91]
```

# Test source

```ts
  1   | /** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
  2   | import { expect, test, type Locator, type Page, type TestInfo } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { navTo } from '../e2e/_helpers';
  6   | 
  7   | const MASTERY = 'skills-sorceress-lightning-mastery';
  8   | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  9   | 
  10  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  11  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  12  | }
  13  | 
  14  | async function backup(page: Page): Promise<SaveCurrent> {
  15  |   await navTo(page, 'settings');
  16  |   const pending = page.waitForEvent('download');
  17  |   await page.getByTestId('export-save-button').click();
  18  |   const download = await pending;
  19  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  20  |   finally { await download.delete(); }
  21  | }
  22  | 
  23  | async function importSave(page: Page, save: SaveCurrent, english: boolean): Promise<void> {
  24  |   const label = english ? 'Import Save' : '导入存档';
> 25  |   await page.getByRole('button', { name: label, exact: true }).click();
      |                                                                ^ Error: locator.click: Test timeout of 50000ms exceeded.
  26  |   const dialog = page.getByRole('dialog');
  27  |   await dialog.getByRole('textbox').fill(JSON.stringify(save));
  28  |   await dialog.getByRole('button', { name: label, exact: true }).click();
  29  |   await expect(dialog).toHaveCount(0);
  30  | }
  31  | 
  32  | /** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
  33  | async function hitPoints(target: Locator): Promise<unknown[]> {
  34  |   return target.evaluate(node => {
  35  |     const b = node.getBoundingClientRect();
  36  |     return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
  37  |       const px = b.left + b.width * x, py = b.top + b.height * y;
  38  |       const hit = document.elementFromPoint(px, py);
  39  |       return { x: px, y: py, clear: hit !== null && node.contains(hit), hit: hit?.tagName ?? null };
  40  |     }));
  41  |   });
  42  | }
  43  | 
  44  | async function clearTarget(target: Locator, label: string): Promise<unknown[]> {
  45  |   await target.scrollIntoViewIfNeeded();
  46  |   const points = await hitPoints(target);
  47  |   for (const point of points) expect.soft(point, label).toMatchObject({ clear: true });
  48  |   return points;
  49  | }
  50  | 
  51  | async function layout(page: Page, bonus: boolean): Promise<unknown> {
  52  |   const measured = await page.evaluate(() => {
  53  |     const main = document.querySelector('main');
  54  |     const hud = document.querySelector('[data-testid="character-hud"]');
  55  |     const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
  56  |     const header = main?.previousElementSibling;
  57  |     if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
  58  |     const rect = (node: Element) => {
  59  |       const b = node.getBoundingClientRect();
  60  |       return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height };
  61  |     };
  62  |     const h = rect(header), m = rect(main), u = rect(hud), c = chip ? rect(chip) : null;
  63  |     const contains = (a: typeof h, b: typeof h) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
  64  |     const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
  65  |       const b = rect(node);
  66  |       const visible = { left: Math.max(b.left,m.left), right: Math.min(b.right,m.right), top: Math.max(b.top,m.top), bottom: Math.min(b.bottom,m.bottom) };
  67  |       const shown = visible.right > visible.left && visible.bottom > visible.top;
  68  |       const overlaps = (a: typeof h) => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
  69  |       return { text: node.textContent, rect:b, visible, shown, hudCollision: overlaps(u), chipCollision: c !== null && overlaps(c) };
  70  |     });
  71  |     return { header: h, main: m, hud: u, chip: c, hudContained: contains(h,u), chipContained: c === null || contains(h,c),
  72  |       mainBelowHud: m.top >= u.bottom, mainBelowChip: c === null || m.top >= c.bottom,
  73  |       chipBelowButton: c === null || c.top >= u.bottom, chipOutsideButton: chip === null || !hud.contains(chip),
  74  |       documentOverflow: document.documentElement.scrollWidth - innerWidth,
  75  |       mainOverflow: main.scrollWidth - main.clientWidth, windowY: scrollY,
  76  |       shellY: main.parentElement?.parentElement?.scrollTop, mainY: main.scrollTop,
  77  |       mainScrollHeight: main.scrollHeight, mainClientHeight: main.clientHeight, targets };
  78  |   });
  79  |   expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  80  |   expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  81  |   expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  82  |   expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  83  |   expect.soft(measured.chipBelowButton).toBe(true);
  84  |   expect.soft(measured.chipOutsideButton).toBe(true);
  85  |   expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  86  |   expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  87  |   expect.soft(measured.windowY).toBe(0); expect.soft(measured.shellY).toBe(0);
  88  |   expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  89  |   expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  90  |   expect.soft(measured.main.height).toBeGreaterThan(0);
  91  |   expect.soft(measured.chip !== null).toBe(bonus);
  92  |   for (const target of measured.targets) {
  93  |     expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
  94  |     expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  95  |   }
  96  |   return measured;
  97  | }
  98  | 
  99  | for (const locale of ['en','zh-CN'] as const) for (const bonus of [false,true]) {
  100 |   test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({ page, context }, info) => {
  101 |     const english = locale === 'en';
  102 |     const errors: string[] = [];
  103 |     page.on('pageerror', error => errors.push(error.message));
  104 |     page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  105 |     await page.goto('/settings');
  106 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  107 |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  108 |     await page.goto('/');
  109 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  110 |     await page.getByTestId('home-new-game').click();
  111 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  112 |     await page.getByTestId('class-sorceress').click();
  113 |     const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
  114 |     await page.getByTestId('character-name-input').fill(name);
  115 |     await page.getByTestId('character-start-btn').click();
  116 |     await expect(page.getByTestId('town-screen')).toBeVisible();
  117 |     const fresh = await backup(page);
  118 |     expect(fresh.player.name).toBe(name);
  119 |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
  120 |       skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: ['skills-sorceress-fire-bolt'] },
  121 |       meta: { ...fresh.meta, idleState: { ...fresh.meta.idleState, lastOnline: Date.now(),
  122 |         activeMultiplier: bonus ? 1.5 : 1, multiplierSecondsRemaining: bonus ? 7200 : 0 } } };
  123 |     await importSave(page, incoming, english);
  124 |     await attach(info, '01-imported-eligibility', incoming);
  125 | 
```