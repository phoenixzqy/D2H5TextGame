/** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { navTo } from '../e2e/_helpers';
const MASTERY = 'skills-sorceress-lightning-mastery';
const sizes = [[360, 640], [412, 915], [640, 360], [375, 667], [393, 851], [768, 1024], [1280, 800], [1920, 1080], [915, 412]];
async function attach(info, name, value) {
  await info.attach(name, {
    body: JSON.stringify(value, null, 2),
    contentType: 'application/json'
  });
}
async function backup(page) {
  await navTo(page, 'settings');
  const pending = page.waitForEvent('download');
  await page.getByTestId('export-save-button').click();
  const download = await pending;
  try {
    return JSON.parse(await readFile(await download.path(), 'utf8'));
  } finally {
    await download.delete();
  }
}
async function importSave(page, save, english) {
  const label = english ? 'Import Save' : '导入存档';
  await page.getByRole('button', {
    name: label,
    exact: true
  }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('textbox').fill(JSON.stringify(save));
  await dialog.getByRole('button', {
    name: label,
    exact: true
  }).click();
  await expect(dialog).toHaveCount(0);
}

/** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
async function hitPoints(target) {
  return target.evaluate(node => {
    const b = node.getBoundingClientRect();
    return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
      var _hit$tagName;
      const px = b.left + b.width * x,
        py = b.top + b.height * y;
      const hit = document.elementFromPoint(px, py);
      return {
        x: px,
        y: py,
        clear: hit !== null && node.contains(hit),
        hit: (_hit$tagName = hit === null || hit === void 0 ? void 0 : hit.tagName) !== null && _hit$tagName !== void 0 ? _hit$tagName : null
      };
    }));
  });
}
async function clearTarget(target, label) {
  await target.scrollIntoViewIfNeeded();
  const points = await hitPoints(target);
  for (const point of points) expect.soft(point, label).toMatchObject({
    clear: true
  });
  return points;
}
async function layout(page, bonus) {
  const measured = await page.evaluate(() => {
    var _main$parentElement;
    const main = document.querySelector('main');
    const hud = document.querySelector('[data-testid="character-hud"]');
    const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
    const header = main === null || main === void 0 ? void 0 : main.previousElementSibling;
    if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
    const rect = node => {
      const b = node.getBoundingClientRect();
      return {
        left: b.left,
        top: b.top,
        right: b.right,
        bottom: b.bottom,
        width: b.width,
        height: b.height
      };
    };
    const h = rect(header),
      m = rect(main),
      u = rect(hud),
      c = chip ? rect(chip) : null;
    const contains = (a, b) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
    const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
      const b = rect(node);
      const visible = {
        left: Math.max(b.left, m.left),
        right: Math.min(b.right, m.right),
        top: Math.max(b.top, m.top),
        bottom: Math.min(b.bottom, m.bottom)
      };
      const shown = visible.right > visible.left && visible.bottom > visible.top;
      const overlaps = a => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
      return {
        text: node.textContent,
        rect: b,
        visible,
        shown,
        hudCollision: overlaps(u),
        chipCollision: c !== null && overlaps(c)
      };
    });
    return {
      header: h,
      main: m,
      hud: u,
      chip: c,
      hudContained: contains(h, u),
      chipContained: c === null || contains(h, c),
      mainBelowHud: m.top >= u.bottom,
      mainBelowChip: c === null || m.top >= c.bottom,
      chipBelowButton: c === null || c.top >= u.bottom,
      chipOutsideButton: chip === null || !hud.contains(chip),
      documentOverflow: document.documentElement.scrollWidth - innerWidth,
      mainOverflow: main.scrollWidth - main.clientWidth,
      windowY: scrollY,
      shellY: (_main$parentElement = main.parentElement) === null || _main$parentElement === void 0 || (_main$parentElement = _main$parentElement.parentElement) === null || _main$parentElement === void 0 ? void 0 : _main$parentElement.scrollTop,
      mainY: main.scrollTop,
      mainScrollHeight: main.scrollHeight,
      mainClientHeight: main.clientHeight,
      targets
    };
  });
  expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  expect.soft(measured.chipBelowButton).toBe(true);
  expect.soft(measured.chipOutsideButton).toBe(true);
  expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.windowY).toBe(0);
  expect.soft(measured.shellY).toBe(0);
  expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  expect.soft(measured.main.height).toBeGreaterThan(0);
  expect.soft(measured.chip !== null).toBe(bonus);
  for (const target of measured.targets) {
    expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
    expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  }
  return measured;
}
for (const locale of ['en', 'zh-CN']) for (const bonus of [false, true]) {
  test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({
    page,
    context
  }, info) => {
    const english = locale === 'en';
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`);
    });
    await page.goto('/settings');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByRole('button', {
      name: english ? 'English' : '简体中文',
      exact: true
    }).click();
    await page.goto('/');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('home-new-game').click();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('class-sorceress').click();
    const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
    await page.getByTestId('character-name-input').fill(name);
    await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    const fresh = await backup(page);
    expect(fresh.player.name).toBe(name);
    const incoming = {
      ...fresh,
      player: {
        ...fresh.player,
        level: 30,
        skillPoints: 2,
        skillLevels: {
          'sorceress.fire_bolt': 1
        },
        comboOrder: ['skills-sorceress-fire-bolt']
      },
      meta: {
        ...fresh.meta,
        idleState: {
          ...fresh.meta.idleState,
          lastOnline: Date.now(),
          activeMultiplier: bonus ? 1.5 : 1,
          multiplierSecondsRemaining: bonus ? 7200 : 0
        }
      }
    };
    await importSave(page, incoming, english);
    await attach(info, '01-imported-eligibility', incoming);
    for (const route of ['town', 'settings', 'skills']) {
      await navTo(page, route);
      await expect(page.getByTestId('character-hud')).toHaveCount(1);
      await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
      await attach(info, `route-${route}`, await layout(page, bonus));
    }
    const panel = page.getByTestId('skill-detail-panel');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    const heading = panel.getByRole('heading', {
      name: english ? 'Lightning Mastery' : '闪电精通',
      exact: true
    });
    const allocate = panel.getByRole('button');
    const description = panel.locator('#skill-detail-panel > p');
    const metrics = [];
    for (const [width, height] of sizes) {
      await page.setViewportSize({
        width,
        height
      });
      await description.scrollIntoViewIfNeeded();
      const originalPosition = await layout(page, bonus);
      if (width === 360 && height === 640) {
        expect.soft(await page.locator('main').evaluate(node => node.scrollTop), 'baseline detail scrolls inside main').toBeGreaterThan(0);
      }
      await info.attach(`layout-${String(width)}x${String(height)}`, {
        body: await page.screenshot(),
        contentType: 'image/png'
      });
      const headingHits = await clearTarget(heading, `${String(width)}x${String(height)} heading`);
      const actionHits = await clearTarget(allocate, `${String(width)}x${String(height)} Allocate`);
      if (!english && width === 360) {
        const cdp = await context.newCDPSession(page);
        try {
          await cdp.send('DOM.enable');
          await cdp.send('CSS.enable');
          const document = await cdp.send('DOM.getDocument');
          const node = await cdp.send('DOM.querySelector', {
            nodeId: document.root.nodeId,
            selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p'
          });
          const fonts = await cdp.send('CSS.getPlatformFontsForNode', {
            nodeId: node.nodeId
          });
          expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
          await attach(info, 'actual-Chinese-platform-fonts', fonts);
        } finally {
          await cdp.detach();
        }
      }
      metrics.push({
        width,
        height,
        originalPosition,
        headingHits,
        actionHits
      });
    }
    await attach(info, '02-layout-metrics', metrics);
    await page.setViewportSize({
      width: 375,
      height: 667
    });
    await description.scrollIntoViewIfNeeded();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await allocate.click(); // Ordinary pointer; Playwright must resolve the actual target.
    await expect(panel).toContainText(english ? 'Lv. 1/20' : '等级 1/20');
    const rank1 = await backup(page);
    expect(rank1.player).toEqual({
      ...incoming.player,
      skillPoints: 1,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 1
      }
    });
    await navTo(page, 'skills');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    await page.setViewportSize({
      width: 915,
      height: 412
    });
    let reached = false;
    for (let step = 0; step < 100; step++) {
      await page.keyboard.press('Tab');
      if (await allocate.evaluate(node => node === document.activeElement)) {
        reached = true;
        break;
      }
    }
    expect(reached).toBe(true);
    await expect(heading).toBeVisible();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await expect(allocate).toBeEnabled();
    await expect(allocate).toBeFocused();
    await clearTarget(allocate, 'keyboard target');
    await page.keyboard.press('Enter');
    await expect(panel).toContainText(english ? 'Lv. 2/20' : '等级 2/20');
    const rank2 = await backup(page);
    expect(rank2.player).toEqual({
      ...rank1.player,
      skillPoints: 0,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 2
      }
    });
    for (const slice of ['inventory', 'mercs', 'map', 'formation']) expect(rank2[slice]).toEqual(incoming[slice]);
    await attach(info, '03-pointer-keyboard-allocation', {
      rank1,
      rank2
    });

    // Real dialog remains above the shared header, including with an active chip.
    const label = english ? 'Import Save' : '导入存档';
    await page.getByRole('button', {
      name: label,
      exact: true
    }).click();
    const modalPriority = await page.evaluate(() => {
      const dialog = document.querySelector('[role="dialog"]');
      return [...document.querySelectorAll('[data-testid="character-hud"], [data-testid="offline-bonus-chip"]')].flatMap(node => {
        const b = node.getBoundingClientRect();
        return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
          const px = b.left + b.width * x,
            py = b.top + b.height * y;
          const hit = document.elementFromPoint(px, py);
          return {
            target: node.getAttribute('data-testid'),
            x: px,
            y: py,
            modalOwnsHit: hit !== null && dialog !== null && dialog.contains(hit)
          };
        }));
      });
    });
    await attach(info, 'modal-priority-at-header', modalPriority);
    expect(modalPriority).toHaveLength(bonus ? 18 : 9);
    for (const point of modalPriority) expect.soft(point).toMatchObject({
      modalOwnsHit: true
    });
    const cancel = page.getByRole('dialog').getByRole('button', {
      name: english ? 'Cancel' : '取消',
      exact: true
    });
    await clearTarget(cancel, 'modal cancel');
    await cancel.click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await page.getByTestId('character-hud').click();
    await expect(page.getByTestId('character-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await navTo(page, 'combat');
    await expect(page.getByTestId('combat-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    const combatHeader = page.getByTestId('combat-screen').locator('header');
    const width = await combatHeader.evaluate(node => {
      var _node$firstElementChi;
      return {
        outer: node.clientWidth,
        inner: (_node$firstElementChi = node.firstElementChild) === null || _node$firstElementChi === void 0 ? void 0 : _node$firstElementChi.getBoundingClientRect().width
      };
    });
    expect(width.inner).toBeGreaterThanOrEqual(width.outer - 32);
    await navTo(page, 'skills');
    await expect(page.getByTestId('character-hud')).toHaveCount(1);
    expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
    await attach(info, '04-console-errors', errors);
    expect(errors).toEqual([]);
    await page.close();
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwicmVhZEZpbGUiLCJuYXZUbyIsIk1BU1RFUlkiLCJzaXplcyIsImF0dGFjaCIsImluZm8iLCJuYW1lIiwidmFsdWUiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnRUeXBlIiwiYmFja3VwIiwicGFnZSIsInBlbmRpbmciLCJ3YWl0Rm9yRXZlbnQiLCJnZXRCeVRlc3RJZCIsImNsaWNrIiwiZG93bmxvYWQiLCJwYXJzZSIsInBhdGgiLCJkZWxldGUiLCJpbXBvcnRTYXZlIiwic2F2ZSIsImVuZ2xpc2giLCJsYWJlbCIsImdldEJ5Um9sZSIsImV4YWN0IiwiZGlhbG9nIiwiZmlsbCIsInRvSGF2ZUNvdW50IiwiaGl0UG9pbnRzIiwidGFyZ2V0IiwiZXZhbHVhdGUiLCJub2RlIiwiYiIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImZsYXRNYXAiLCJ4IiwibWFwIiwieSIsIl9oaXQkdGFnTmFtZSIsInB4IiwibGVmdCIsIndpZHRoIiwicHkiLCJ0b3AiLCJoZWlnaHQiLCJoaXQiLCJkb2N1bWVudCIsImVsZW1lbnRGcm9tUG9pbnQiLCJjbGVhciIsImNvbnRhaW5zIiwidGFnTmFtZSIsImNsZWFyVGFyZ2V0Iiwic2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCIsInBvaW50cyIsInBvaW50Iiwic29mdCIsInRvTWF0Y2hPYmplY3QiLCJsYXlvdXQiLCJib251cyIsIm1lYXN1cmVkIiwiX21haW4kcGFyZW50RWxlbWVudCIsIm1haW4iLCJxdWVyeVNlbGVjdG9yIiwiaHVkIiwiY2hpcCIsImhlYWRlciIsInByZXZpb3VzRWxlbWVudFNpYmxpbmciLCJFcnJvciIsInJlY3QiLCJyaWdodCIsImJvdHRvbSIsImgiLCJtIiwidSIsImMiLCJhIiwidGFyZ2V0cyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJ2aXNpYmxlIiwiTWF0aCIsIm1heCIsIm1pbiIsInNob3duIiwib3ZlcmxhcHMiLCJ0ZXh0IiwidGV4dENvbnRlbnQiLCJodWRDb2xsaXNpb24iLCJjaGlwQ29sbGlzaW9uIiwiaHVkQ29udGFpbmVkIiwiY2hpcENvbnRhaW5lZCIsIm1haW5CZWxvd0h1ZCIsIm1haW5CZWxvd0NoaXAiLCJjaGlwQmVsb3dCdXR0b24iLCJjaGlwT3V0c2lkZUJ1dHRvbiIsImRvY3VtZW50T3ZlcmZsb3ciLCJkb2N1bWVudEVsZW1lbnQiLCJzY3JvbGxXaWR0aCIsImlubmVyV2lkdGgiLCJtYWluT3ZlcmZsb3ciLCJjbGllbnRXaWR0aCIsIndpbmRvd1kiLCJzY3JvbGxZIiwic2hlbGxZIiwicGFyZW50RWxlbWVudCIsInNjcm9sbFRvcCIsIm1haW5ZIiwibWFpblNjcm9sbEhlaWdodCIsInNjcm9sbEhlaWdodCIsIm1haW5DbGllbnRIZWlnaHQiLCJjbGllbnRIZWlnaHQiLCJ0b0JlIiwidG9CZUxlc3NUaGFuT3JFcXVhbCIsInRvQmVHcmVhdGVyVGhhbk9yRXF1YWwiLCJ0b0JlR3JlYXRlclRoYW4iLCJsb2NhbGUiLCJTdHJpbmciLCJjb250ZXh0IiwiZXJyb3JzIiwib24iLCJlcnJvciIsInB1c2giLCJtZXNzYWdlIiwidHlwZSIsImdvdG8iLCJyZXBlYXQiLCJ0b0JlVmlzaWJsZSIsImZyZXNoIiwicGxheWVyIiwiaW5jb21pbmciLCJsZXZlbCIsInNraWxsUG9pbnRzIiwic2tpbGxMZXZlbHMiLCJjb21ib09yZGVyIiwibWV0YSIsImlkbGVTdGF0ZSIsImxhc3RPbmxpbmUiLCJEYXRlIiwibm93IiwiYWN0aXZlTXVsdGlwbGllciIsIm11bHRpcGxpZXJTZWNvbmRzUmVtYWluaW5nIiwicm91dGUiLCJ0b0hhdmVBY2Nlc3NpYmxlTmFtZSIsIlJlZ0V4cCIsInBhbmVsIiwiaGVhZGluZyIsImFsbG9jYXRlIiwiZGVzY3JpcHRpb24iLCJsb2NhdG9yIiwibWV0cmljcyIsInNldFZpZXdwb3J0U2l6ZSIsIm9yaWdpbmFsUG9zaXRpb24iLCJzY3JlZW5zaG90IiwiaGVhZGluZ0hpdHMiLCJhY3Rpb25IaXRzIiwiY2RwIiwibmV3Q0RQU2Vzc2lvbiIsInNlbmQiLCJub2RlSWQiLCJyb290Iiwic2VsZWN0b3IiLCJmb250cyIsInNvbWUiLCJmb250IiwiZmFtaWx5TmFtZSIsImdseXBoQ291bnQiLCJkZXRhY2giLCJ0b0hhdmVUZXh0IiwidG9Db250YWluVGV4dCIsInJhbmsxIiwidG9FcXVhbCIsInJlYWNoZWQiLCJzdGVwIiwia2V5Ym9hcmQiLCJwcmVzcyIsImFjdGl2ZUVsZW1lbnQiLCJ0b0JlRW5hYmxlZCIsInRvQmVGb2N1c2VkIiwicmFuazIiLCJzbGljZSIsIm1vZGFsUHJpb3JpdHkiLCJnZXRBdHRyaWJ1dGUiLCJtb2RhbE93bnNIaXQiLCJ0b0hhdmVMZW5ndGgiLCJjYW5jZWwiLCJjb21iYXRIZWFkZXIiLCJfbm9kZSRmaXJzdEVsZW1lbnRDaGkiLCJvdXRlciIsImlubmVyIiwiZmlyc3RFbGVtZW50Q2hpbGQiLCJ3aW5kb3ciLCJjbG9zZSJdLCJzb3VyY2VzIjpbInNraWxscy1oZWFkZXItbGF5b3V0LnNwZWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqIFByb2R1Y3Rpb24gbGF5b3V0IHJlZ3Jlc3Npb247IGV4cGxpY2l0bHkgaW1wb3J0ZWQgTDMwL2JvbnVzIGVsaWdpYmlsaXR5LCBubyBnYW1lIGJyaWRnZS4gKi9cbmltcG9ydCB7IGV4cGVjdCwgdGVzdCwgdHlwZSBMb2NhdG9yLCB0eXBlIFBhZ2UsIHR5cGUgVGVzdEluZm8gfSBmcm9tICdAcGxheXdyaWdodC90ZXN0JztcbmltcG9ydCB7IHJlYWRGaWxlIH0gZnJvbSAnbm9kZTpmcy9wcm9taXNlcyc7XG5pbXBvcnQgdHlwZSB7IFNhdmVDdXJyZW50IH0gZnJvbSAnLi4vLi4vc3JjL2VuZ2luZS90eXBlcy9zYXZlJztcbmltcG9ydCB7IG5hdlRvIH0gZnJvbSAnLi4vZTJlL19oZWxwZXJzJztcblxuY29uc3QgTUFTVEVSWSA9ICdza2lsbHMtc29yY2VyZXNzLWxpZ2h0bmluZy1tYXN0ZXJ5JztcbmNvbnN0IHNpemVzID0gW1szNjAsNjQwXSxbNDEyLDkxNV0sWzY0MCwzNjBdLFszNzUsNjY3XSxbMzkzLDg1MV0sWzc2OCwxMDI0XSxbMTI4MCw4MDBdLFsxOTIwLDEwODBdLFs5MTUsNDEyXV0gYXMgY29uc3Q7XG5cbmFzeW5jIGZ1bmN0aW9uIGF0dGFjaChpbmZvOiBUZXN0SW5mbywgbmFtZTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBpbmZvLmF0dGFjaChuYW1lLCB7IGJvZHk6IEpTT04uc3RyaW5naWZ5KHZhbHVlLCBudWxsLCAyKSwgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYmFja3VwKHBhZ2U6IFBhZ2UpOiBQcm9taXNlPFNhdmVDdXJyZW50PiB7XG4gIGF3YWl0IG5hdlRvKHBhZ2UsICdzZXR0aW5ncycpO1xuICBjb25zdCBwZW5kaW5nID0gcGFnZS53YWl0Rm9yRXZlbnQoJ2Rvd25sb2FkJyk7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2V4cG9ydC1zYXZlLWJ1dHRvbicpLmNsaWNrKCk7XG4gIGNvbnN0IGRvd25sb2FkID0gYXdhaXQgcGVuZGluZztcbiAgdHJ5IHsgcmV0dXJuIEpTT04ucGFyc2UoYXdhaXQgcmVhZEZpbGUoYXdhaXQgZG93bmxvYWQucGF0aCgpLCAndXRmOCcpKSBhcyBTYXZlQ3VycmVudDsgfVxuICBmaW5hbGx5IHsgYXdhaXQgZG93bmxvYWQuZGVsZXRlKCk7IH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gaW1wb3J0U2F2ZShwYWdlOiBQYWdlLCBzYXZlOiBTYXZlQ3VycmVudCwgZW5nbGlzaDogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBsYWJlbCA9IGVuZ2xpc2ggPyAnSW1wb3J0IFNhdmUnIDogJ+WvvOWFpeWtmOahoyc7XG4gIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IGxhYmVsLCBleGFjdDogdHJ1ZSB9KS5jbGljaygpO1xuICBjb25zdCBkaWFsb2cgPSBwYWdlLmdldEJ5Um9sZSgnZGlhbG9nJyk7XG4gIGF3YWl0IGRpYWxvZy5nZXRCeVJvbGUoJ3RleHRib3gnKS5maWxsKEpTT04uc3RyaW5naWZ5KHNhdmUpKTtcbiAgYXdhaXQgZGlhbG9nLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiBsYWJlbCwgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgYXdhaXQgZXhwZWN0KGRpYWxvZykudG9IYXZlQ291bnQoMCk7XG59XG5cbi8qKiBSZWFkLW9ubHkgZWRnZS9jZW50ZXIgaGl0IHRlc3RzIGNhdGNoIHBhcnRpYWwgb2JzdHJ1Y3Rpb24gdGhhdCB0b0JlVmlzaWJsZSBtaXNzZXMuICovXG5hc3luYyBmdW5jdGlvbiBoaXRQb2ludHModGFyZ2V0OiBMb2NhdG9yKTogUHJvbWlzZTx1bmtub3duW10+IHtcbiAgcmV0dXJuIHRhcmdldC5ldmFsdWF0ZShub2RlID0+IHtcbiAgICBjb25zdCBiID0gbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICByZXR1cm4gWzAuMDUsIDAuNSwgMC45NV0uZmxhdE1hcCh4ID0+IFswLjA1LCAwLjUsIDAuOTVdLm1hcCh5ID0+IHtcbiAgICAgIGNvbnN0IHB4ID0gYi5sZWZ0ICsgYi53aWR0aCAqIHgsIHB5ID0gYi50b3AgKyBiLmhlaWdodCAqIHk7XG4gICAgICBjb25zdCBoaXQgPSBkb2N1bWVudC5lbGVtZW50RnJvbVBvaW50KHB4LCBweSk7XG4gICAgICByZXR1cm4geyB4OiBweCwgeTogcHksIGNsZWFyOiBoaXQgIT09IG51bGwgJiYgbm9kZS5jb250YWlucyhoaXQpLCBoaXQ6IGhpdD8udGFnTmFtZSA/PyBudWxsIH07XG4gICAgfSkpO1xuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2xlYXJUYXJnZXQodGFyZ2V0OiBMb2NhdG9yLCBsYWJlbDogc3RyaW5nKTogUHJvbWlzZTx1bmtub3duW10+IHtcbiAgYXdhaXQgdGFyZ2V0LnNjcm9sbEludG9WaWV3SWZOZWVkZWQoKTtcbiAgY29uc3QgcG9pbnRzID0gYXdhaXQgaGl0UG9pbnRzKHRhcmdldCk7XG4gIGZvciAoY29uc3QgcG9pbnQgb2YgcG9pbnRzKSBleHBlY3Quc29mdChwb2ludCwgbGFiZWwpLnRvTWF0Y2hPYmplY3QoeyBjbGVhcjogdHJ1ZSB9KTtcbiAgcmV0dXJuIHBvaW50cztcbn1cblxuYXN5bmMgZnVuY3Rpb24gbGF5b3V0KHBhZ2U6IFBhZ2UsIGJvbnVzOiBib29sZWFuKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIGNvbnN0IG1lYXN1cmVkID0gYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB7XG4gICAgY29uc3QgbWFpbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ21haW4nKTtcbiAgICBjb25zdCBodWQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbZGF0YS10ZXN0aWQ9XCJjaGFyYWN0ZXItaHVkXCJdJyk7XG4gICAgY29uc3QgY2hpcCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXRlc3RpZD1cIm9mZmxpbmUtYm9udXMtY2hpcFwiXScpO1xuICAgIGNvbnN0IGhlYWRlciA9IG1haW4/LnByZXZpb3VzRWxlbWVudFNpYmxpbmc7XG4gICAgaWYgKCFtYWluIHx8ICFodWQgfHwgIWhlYWRlcikgdGhyb3cgbmV3IEVycm9yKCdFeHBlY3RlZCBtYWluLCBIVUQgYW5kIHNjcmVlbiBoZWFkZXInKTtcbiAgICBjb25zdCByZWN0ID0gKG5vZGU6IEVsZW1lbnQpID0+IHtcbiAgICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgcmV0dXJuIHsgbGVmdDogYi5sZWZ0LCB0b3A6IGIudG9wLCByaWdodDogYi5yaWdodCwgYm90dG9tOiBiLmJvdHRvbSwgd2lkdGg6IGIud2lkdGgsIGhlaWdodDogYi5oZWlnaHQgfTtcbiAgICB9O1xuICAgIGNvbnN0IGggPSByZWN0KGhlYWRlciksIG0gPSByZWN0KG1haW4pLCB1ID0gcmVjdChodWQpLCBjID0gY2hpcCA/IHJlY3QoY2hpcCkgOiBudWxsO1xuICAgIGNvbnN0IGNvbnRhaW5zID0gKGE6IHR5cGVvZiBoLCBiOiB0eXBlb2YgaCkgPT4gYi5sZWZ0ID49IGEubGVmdCAmJiBiLnJpZ2h0IDw9IGEucmlnaHQgJiYgYi50b3AgPj0gYS50b3AgJiYgYi5ib3R0b20gPD0gYS5ib3R0b207XG4gICAgY29uc3QgdGFyZ2V0cyA9IFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJza2lsbC1kZXRhaWwtcGFuZWxcIl0gaDIsIFtkYXRhLXRlc3RpZD1cInNraWxsLWRldGFpbC1wYW5lbFwiXSBidXR0b24nKV0ubWFwKG5vZGUgPT4ge1xuICAgICAgY29uc3QgYiA9IHJlY3Qobm9kZSk7XG4gICAgICBjb25zdCB2aXNpYmxlID0geyBsZWZ0OiBNYXRoLm1heChiLmxlZnQsbS5sZWZ0KSwgcmlnaHQ6IE1hdGgubWluKGIucmlnaHQsbS5yaWdodCksIHRvcDogTWF0aC5tYXgoYi50b3AsbS50b3ApLCBib3R0b206IE1hdGgubWluKGIuYm90dG9tLG0uYm90dG9tKSB9O1xuICAgICAgY29uc3Qgc2hvd24gPSB2aXNpYmxlLnJpZ2h0ID4gdmlzaWJsZS5sZWZ0ICYmIHZpc2libGUuYm90dG9tID4gdmlzaWJsZS50b3A7XG4gICAgICBjb25zdCBvdmVybGFwcyA9IChhOiB0eXBlb2YgaCkgPT4gc2hvd24gJiYgdmlzaWJsZS5sZWZ0IDwgYS5yaWdodCAmJiB2aXNpYmxlLnJpZ2h0ID4gYS5sZWZ0ICYmIHZpc2libGUudG9wIDwgYS5ib3R0b20gJiYgdmlzaWJsZS5ib3R0b20gPiBhLnRvcDtcbiAgICAgIHJldHVybiB7IHRleHQ6IG5vZGUudGV4dENvbnRlbnQsIHJlY3Q6YiwgdmlzaWJsZSwgc2hvd24sIGh1ZENvbGxpc2lvbjogb3ZlcmxhcHModSksIGNoaXBDb2xsaXNpb246IGMgIT09IG51bGwgJiYgb3ZlcmxhcHMoYykgfTtcbiAgICB9KTtcbiAgICByZXR1cm4geyBoZWFkZXI6IGgsIG1haW46IG0sIGh1ZDogdSwgY2hpcDogYywgaHVkQ29udGFpbmVkOiBjb250YWlucyhoLHUpLCBjaGlwQ29udGFpbmVkOiBjID09PSBudWxsIHx8IGNvbnRhaW5zKGgsYyksXG4gICAgICBtYWluQmVsb3dIdWQ6IG0udG9wID49IHUuYm90dG9tLCBtYWluQmVsb3dDaGlwOiBjID09PSBudWxsIHx8IG0udG9wID49IGMuYm90dG9tLFxuICAgICAgY2hpcEJlbG93QnV0dG9uOiBjID09PSBudWxsIHx8IGMudG9wID49IHUuYm90dG9tLCBjaGlwT3V0c2lkZUJ1dHRvbjogY2hpcCA9PT0gbnVsbCB8fCAhaHVkLmNvbnRhaW5zKGNoaXApLFxuICAgICAgZG9jdW1lbnRPdmVyZmxvdzogZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbFdpZHRoIC0gaW5uZXJXaWR0aCxcbiAgICAgIG1haW5PdmVyZmxvdzogbWFpbi5zY3JvbGxXaWR0aCAtIG1haW4uY2xpZW50V2lkdGgsIHdpbmRvd1k6IHNjcm9sbFksXG4gICAgICBzaGVsbFk6IG1haW4ucGFyZW50RWxlbWVudD8ucGFyZW50RWxlbWVudD8uc2Nyb2xsVG9wLCBtYWluWTogbWFpbi5zY3JvbGxUb3AsXG4gICAgICBtYWluU2Nyb2xsSGVpZ2h0OiBtYWluLnNjcm9sbEhlaWdodCwgbWFpbkNsaWVudEhlaWdodDogbWFpbi5jbGllbnRIZWlnaHQsIHRhcmdldHMgfTtcbiAgfSk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZENvbnRhaW5lZCwgJ2hlYWRlciByZXNlcnZlcyBhY3R1YWwgSFVEIGhlaWdodCcpLnRvQmUodHJ1ZSk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmNoaXBDb250YWluZWQsICdoZWFkZXIgcmVzZXJ2ZXMgYWN0aXZlIGJvbnVzIGNoaXAgaGVpZ2h0JykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbkJlbG93SHVkLCAnbWFpbiBjYW5ub3Qgc2Nyb2xsIHVuZGVyIEhVRCcpLnRvQmUodHJ1ZSk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLm1haW5CZWxvd0NoaXAsICdtYWluIGNhbm5vdCBzY3JvbGwgdW5kZXIgY2hpcCcpLnRvQmUodHJ1ZSk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmNoaXBCZWxvd0J1dHRvbikudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcE91dHNpZGVCdXR0b24pLnRvQmUodHJ1ZSk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmRvY3VtZW50T3ZlcmZsb3cpLnRvQmVMZXNzVGhhbk9yRXF1YWwoMCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLm1haW5PdmVyZmxvdykudG9CZUxlc3NUaGFuT3JFcXVhbCgwKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQud2luZG93WSkudG9CZSgwKTsgZXhwZWN0LnNvZnQobWVhc3VyZWQuc2hlbGxZKS50b0JlKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5odWQud2lkdGgpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoNDQpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5odWQuaGVpZ2h0KS50b0JlR3JlYXRlclRoYW5PckVxdWFsKDQ0KTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbi5oZWlnaHQpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcCAhPT0gbnVsbCkudG9CZShib251cyk7XG4gIGZvciAoY29uc3QgdGFyZ2V0IG9mIG1lYXN1cmVkLnRhcmdldHMpIHtcbiAgICBleHBlY3Quc29mdCh0YXJnZXQuaHVkQ29sbGlzaW9uLCAndmlzaWJsZSBkZXRhaWwgcmVtYWlucyBjbGVhciBvZiBIVUQgYXQgb3JpZ2luYWwgc2Nyb2xsIHBvc2l0aW9uJykudG9CZShmYWxzZSk7XG4gICAgZXhwZWN0LnNvZnQodGFyZ2V0LmNoaXBDb2xsaXNpb24sICd2aXNpYmxlIGRldGFpbCByZW1haW5zIGNsZWFyIG9mIGFjdGl2ZSBjaGlwIGF0IG9yaWdpbmFsIHNjcm9sbCBwb3NpdGlvbicpLnRvQmUoZmFsc2UpO1xuICB9XG4gIHJldHVybiBtZWFzdXJlZDtcbn1cblxuZm9yIChjb25zdCBsb2NhbGUgb2YgWydlbicsJ3poLUNOJ10gYXMgY29uc3QpIGZvciAoY29uc3QgYm9udXMgb2YgW2ZhbHNlLHRydWVdKSB7XG4gIHRlc3QoYHNoYXJlZCBoZWFkZXIgc3RheXMgY2xlYXIgJHtsb2NhbGV9IGJvbnVzPSR7U3RyaW5nKGJvbnVzKX1gLCBhc3luYyAoeyBwYWdlLCBjb250ZXh0IH0sIGluZm8pID0+IHtcbiAgICBjb25zdCBlbmdsaXNoID0gbG9jYWxlID09PSAnZW4nO1xuICAgIGNvbnN0IGVycm9yczogc3RyaW5nW10gPSBbXTtcbiAgICBwYWdlLm9uKCdwYWdlZXJyb3InLCBlcnJvciA9PiBlcnJvcnMucHVzaChlcnJvci5tZXNzYWdlKSk7XG4gICAgcGFnZS5vbignY29uc29sZScsIG1lc3NhZ2UgPT4geyBpZiAobWVzc2FnZS50eXBlKCkgPT09ICdlcnJvcicgfHwgbWVzc2FnZS50eXBlKCkgPT09ICd3YXJuaW5nJykgZXJyb3JzLnB1c2goYCR7bWVzc2FnZS50eXBlKCl9OiAke21lc3NhZ2UudGV4dCgpfWApOyB9KTtcbiAgICBhd2FpdCBwYWdlLmdvdG8oJy9zZXR0aW5ncycpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDApO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IGVuZ2xpc2ggPyAnRW5nbGlzaCcgOiAn566A5L2T5Lit5paHJywgZXhhY3Q6IHRydWUgfSkuY2xpY2soKTtcbiAgICBhd2FpdCBwYWdlLmdvdG8oJy8nKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdob21lLW5ldy1nYW1lJykuY2xpY2soKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdjbGFzcy1zb3JjZXJlc3MnKS5jbGljaygpO1xuICAgIGNvbnN0IG5hbWUgPSBlbmdsaXNoID8gJ01NTU1NTU1NTU1NTU1NTU0nIDogJ+mXqicucmVwZWF0KDE2KTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItbmFtZS1pbnB1dCcpLmZpbGwobmFtZSk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLXN0YXJ0LWJ0bicpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ3Rvd24tc2NyZWVuJykpLnRvQmVWaXNpYmxlKCk7XG4gICAgY29uc3QgZnJlc2ggPSBhd2FpdCBiYWNrdXAocGFnZSk7XG4gICAgZXhwZWN0KGZyZXNoLnBsYXllci5uYW1lKS50b0JlKG5hbWUpO1xuICAgIGNvbnN0IGluY29taW5nOiBTYXZlQ3VycmVudCA9IHsgLi4uZnJlc2gsIHBsYXllcjogeyAuLi5mcmVzaC5wbGF5ZXIsIGxldmVsOiAzMCwgc2tpbGxQb2ludHM6IDIsXG4gICAgICBza2lsbExldmVsczogeyAnc29yY2VyZXNzLmZpcmVfYm9sdCc6IDEgfSwgY29tYm9PcmRlcjogWydza2lsbHMtc29yY2VyZXNzLWZpcmUtYm9sdCddIH0sXG4gICAgICBtZXRhOiB7IC4uLmZyZXNoLm1ldGEsIGlkbGVTdGF0ZTogeyAuLi5mcmVzaC5tZXRhLmlkbGVTdGF0ZSwgbGFzdE9ubGluZTogRGF0ZS5ub3coKSxcbiAgICAgICAgYWN0aXZlTXVsdGlwbGllcjogYm9udXMgPyAxLjUgOiAxLCBtdWx0aXBsaWVyU2Vjb25kc1JlbWFpbmluZzogYm9udXMgPyA3MjAwIDogMCB9IH0gfTtcbiAgICBhd2FpdCBpbXBvcnRTYXZlKHBhZ2UsIGluY29taW5nLCBlbmdsaXNoKTtcbiAgICBhd2FpdCBhdHRhY2goaW5mbywgJzAxLWltcG9ydGVkLWVsaWdpYmlsaXR5JywgaW5jb21pbmcpO1xuXG4gICAgZm9yIChjb25zdCByb3V0ZSBvZiBbJ3Rvd24nLCdzZXR0aW5ncycsJ3NraWxscyddKSB7XG4gICAgICBhd2FpdCBuYXZUbyhwYWdlLCByb3V0ZSk7XG4gICAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgxKTtcbiAgICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUFjY2Vzc2libGVOYW1lKG5ldyBSZWdFeHAobmFtZSkpO1xuICAgICAgYXdhaXQgYXR0YWNoKGluZm8sIGByb3V0ZS0ke3JvdXRlfWAsIGF3YWl0IGxheW91dChwYWdlLGJvbnVzKSk7XG4gICAgfVxuICAgIGNvbnN0IHBhbmVsID0gcGFnZS5nZXRCeVRlc3RJZCgnc2tpbGwtZGV0YWlsLXBhbmVsJyk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZChgc2tpbGwtbm9kZS0ke01BU1RFUll9YCkuY2xpY2soKTtcbiAgICBjb25zdCBoZWFkaW5nID0gcGFuZWwuZ2V0QnlSb2xlKCdoZWFkaW5nJywgeyBuYW1lOiBlbmdsaXNoID8gJ0xpZ2h0bmluZyBNYXN0ZXJ5JyA6ICfpl6rnlLXnsr7pgJonLCBleGFjdDogdHJ1ZSB9KTtcbiAgICBjb25zdCBhbGxvY2F0ZSA9IHBhbmVsLmdldEJ5Um9sZSgnYnV0dG9uJyk7XG4gICAgY29uc3QgZGVzY3JpcHRpb24gPSBwYW5lbC5sb2NhdG9yKCcjc2tpbGwtZGV0YWlsLXBhbmVsID4gcCcpO1xuICAgIGNvbnN0IG1ldHJpY3MgPSBbXTtcbiAgICBmb3IgKGNvbnN0IFt3aWR0aCxoZWlnaHRdIG9mIHNpemVzKSB7XG4gICAgICBhd2FpdCBwYWdlLnNldFZpZXdwb3J0U2l6ZSh7IHdpZHRoLGhlaWdodCB9KTtcbiAgICAgIGF3YWl0IGRlc2NyaXB0aW9uLnNjcm9sbEludG9WaWV3SWZOZWVkZWQoKTtcbiAgICAgIGNvbnN0IG9yaWdpbmFsUG9zaXRpb24gPSBhd2FpdCBsYXlvdXQocGFnZSxib251cyk7XG4gICAgICBpZiAod2lkdGggPT09IDM2MCAmJiBoZWlnaHQgPT09IDY0MCkge1xuICAgICAgICBleHBlY3Quc29mdChhd2FpdCBwYWdlLmxvY2F0b3IoJ21haW4nKS5ldmFsdWF0ZShub2RlID0+IG5vZGUuc2Nyb2xsVG9wKSwgJ2Jhc2VsaW5lIGRldGFpbCBzY3JvbGxzIGluc2lkZSBtYWluJykudG9CZUdyZWF0ZXJUaGFuKDApO1xuICAgICAgfVxuICAgICAgYXdhaXQgaW5mby5hdHRhY2goYGxheW91dC0ke1N0cmluZyh3aWR0aCl9eCR7U3RyaW5nKGhlaWdodCl9YCwgeyBib2R5OiBhd2FpdCBwYWdlLnNjcmVlbnNob3QoKSwgY29udGVudFR5cGU6ICdpbWFnZS9wbmcnIH0pO1xuICAgICAgY29uc3QgaGVhZGluZ0hpdHMgPSBhd2FpdCBjbGVhclRhcmdldChoZWFkaW5nLGAke1N0cmluZyh3aWR0aCl9eCR7U3RyaW5nKGhlaWdodCl9IGhlYWRpbmdgKTtcbiAgICAgIGNvbnN0IGFjdGlvbkhpdHMgPSBhd2FpdCBjbGVhclRhcmdldChhbGxvY2F0ZSxgJHtTdHJpbmcod2lkdGgpfXgke1N0cmluZyhoZWlnaHQpfSBBbGxvY2F0ZWApO1xuICAgICAgaWYgKCFlbmdsaXNoICYmIHdpZHRoID09PSAzNjApIHtcbiAgICAgICAgY29uc3QgY2RwID0gYXdhaXQgY29udGV4dC5uZXdDRFBTZXNzaW9uKHBhZ2UpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IGNkcC5zZW5kKCdET00uZW5hYmxlJyk7IGF3YWl0IGNkcC5zZW5kKCdDU1MuZW5hYmxlJyk7XG4gICAgICAgICAgY29uc3QgZG9jdW1lbnQgPSBhd2FpdCBjZHAuc2VuZCgnRE9NLmdldERvY3VtZW50Jyk7XG4gICAgICAgICAgY29uc3Qgbm9kZSA9IGF3YWl0IGNkcC5zZW5kKCdET00ucXVlcnlTZWxlY3RvcicseyBub2RlSWQ6IGRvY3VtZW50LnJvb3Qubm9kZUlkLCBzZWxlY3RvcjogJ1tkYXRhLXRlc3RpZD1cInNraWxsLWRldGFpbC1wYW5lbFwiXSAjc2tpbGwtZGV0YWlsLXBhbmVsID4gcCcgfSk7XG4gICAgICAgICAgY29uc3QgZm9udHMgPSBhd2FpdCBjZHAuc2VuZCgnQ1NTLmdldFBsYXRmb3JtRm9udHNGb3JOb2RlJyx7IG5vZGVJZDogbm9kZS5ub2RlSWQgfSk7XG4gICAgICAgICAgZXhwZWN0KGZvbnRzLmZvbnRzLnNvbWUoZm9udCA9PiBmb250LmZhbWlseU5hbWUgPT09ICdOb3RvIFNhbnMgQ0pLIFNDJyAmJiBmb250LmdseXBoQ291bnQgPiAwKSkudG9CZSh0cnVlKTtcbiAgICAgICAgICBhd2FpdCBhdHRhY2goaW5mbywnYWN0dWFsLUNoaW5lc2UtcGxhdGZvcm0tZm9udHMnLGZvbnRzKTtcbiAgICAgICAgfSBmaW5hbGx5IHsgYXdhaXQgY2RwLmRldGFjaCgpOyB9XG4gICAgICB9XG4gICAgICBtZXRyaWNzLnB1c2goeyB3aWR0aCxoZWlnaHQsb3JpZ2luYWxQb3NpdGlvbixoZWFkaW5nSGl0cyxhY3Rpb25IaXRzIH0pO1xuICAgIH1cbiAgICBhd2FpdCBhdHRhY2goaW5mbywnMDItbGF5b3V0LW1ldHJpY3MnLG1ldHJpY3MpO1xuXG4gICAgYXdhaXQgcGFnZS5zZXRWaWV3cG9ydFNpemUoeyB3aWR0aDozNzUsaGVpZ2h0OjY2NyB9KTtcbiAgICBhd2FpdCBkZXNjcmlwdGlvbi5zY3JvbGxJbnRvVmlld0lmTmVlZGVkKCk7XG4gICAgYXdhaXQgZXhwZWN0KGFsbG9jYXRlKS50b0hhdmVUZXh0KGVuZ2xpc2ggPyAnQWxsb2NhdGUnIDogJ+WIhumFjScpO1xuICAgIGF3YWl0IGFsbG9jYXRlLmNsaWNrKCk7IC8vIE9yZGluYXJ5IHBvaW50ZXI7IFBsYXl3cmlnaHQgbXVzdCByZXNvbHZlIHRoZSBhY3R1YWwgdGFyZ2V0LlxuICAgIGF3YWl0IGV4cGVjdChwYW5lbCkudG9Db250YWluVGV4dChlbmdsaXNoID8gJ0x2LiAxLzIwJyA6ICfnrYnnuqcgMS8yMCcpO1xuICAgIGNvbnN0IHJhbmsxID0gYXdhaXQgYmFja3VwKHBhZ2UpO1xuICAgIGV4cGVjdChyYW5rMS5wbGF5ZXIpLnRvRXF1YWwoeyAuLi5pbmNvbWluZy5wbGF5ZXIsIHNraWxsUG9pbnRzOjEsXG4gICAgICBza2lsbExldmVsczp7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzoxLCdzb3JjZXJlc3MubGlnaHRuaW5nX21hc3RlcnknOjEgfSB9KTtcbiAgICBhd2FpdCBuYXZUbyhwYWdlLCdza2lsbHMnKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKGBza2lsbC1ub2RlLSR7TUFTVEVSWX1gKS5jbGljaygpO1xuICAgIGF3YWl0IHBhZ2Uuc2V0Vmlld3BvcnRTaXplKHsgd2lkdGg6OTE1LGhlaWdodDo0MTIgfSk7XG4gICAgbGV0IHJlYWNoZWQgPSBmYWxzZTtcbiAgICBmb3IgKGxldCBzdGVwPTA7c3RlcDwxMDA7c3RlcCsrKSB7XG4gICAgICBhd2FpdCBwYWdlLmtleWJvYXJkLnByZXNzKCdUYWInKTtcbiAgICAgIGlmIChhd2FpdCBhbGxvY2F0ZS5ldmFsdWF0ZShub2RlID0+IG5vZGUgPT09IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpKSB7IHJlYWNoZWQ9dHJ1ZTticmVhazsgfVxuICAgIH1cbiAgICBleHBlY3QocmVhY2hlZCkudG9CZSh0cnVlKTtcbiAgICBhd2FpdCBleHBlY3QoaGVhZGluZykudG9CZVZpc2libGUoKTtcbiAgICBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvSGF2ZVRleHQoZW5nbGlzaCA/ICdBbGxvY2F0ZScgOiAn5YiG6YWNJyk7XG4gICAgYXdhaXQgZXhwZWN0KGFsbG9jYXRlKS50b0JlRW5hYmxlZCgpOyBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvQmVGb2N1c2VkKCk7XG4gICAgYXdhaXQgY2xlYXJUYXJnZXQoYWxsb2NhdGUsJ2tleWJvYXJkIHRhcmdldCcpO1xuICAgIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ0VudGVyJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhbmVsKS50b0NvbnRhaW5UZXh0KGVuZ2xpc2ggPyAnTHYuIDIvMjAnIDogJ+etiee6pyAyLzIwJyk7XG4gICAgY29uc3QgcmFuazIgPSBhd2FpdCBiYWNrdXAocGFnZSk7XG4gICAgZXhwZWN0KHJhbmsyLnBsYXllcikudG9FcXVhbCh7IC4uLnJhbmsxLnBsYXllcixza2lsbFBvaW50czowLFxuICAgICAgc2tpbGxMZXZlbHM6eyAnc29yY2VyZXNzLmZpcmVfYm9sdCc6MSwnc29yY2VyZXNzLmxpZ2h0bmluZ19tYXN0ZXJ5JzoyIH0gfSk7XG4gICAgZm9yIChjb25zdCBzbGljZSBvZiBbJ2ludmVudG9yeScsJ21lcmNzJywnbWFwJywnZm9ybWF0aW9uJ10gYXMgY29uc3QpIGV4cGVjdChyYW5rMltzbGljZV0pLnRvRXF1YWwoaW5jb21pbmdbc2xpY2VdKTtcbiAgICBhd2FpdCBhdHRhY2goaW5mbywnMDMtcG9pbnRlci1rZXlib2FyZC1hbGxvY2F0aW9uJyx7IHJhbmsxLHJhbmsyIH0pO1xuXG4gICAgLy8gUmVhbCBkaWFsb2cgcmVtYWlucyBhYm92ZSB0aGUgc2hhcmVkIGhlYWRlciwgaW5jbHVkaW5nIHdpdGggYW4gYWN0aXZlIGNoaXAuXG4gICAgY29uc3QgbGFiZWwgPSBlbmdsaXNoID8gJ0ltcG9ydCBTYXZlJyA6ICflr7zlhaXlrZjmoaMnO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHsgbmFtZTpsYWJlbCxleGFjdDp0cnVlIH0pLmNsaWNrKCk7XG4gICAgY29uc3QgbW9kYWxQcmlvcml0eSA9IGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4ge1xuICAgICAgY29uc3QgZGlhbG9nID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW3JvbGU9XCJkaWFsb2dcIl0nKTtcbiAgICAgIHJldHVybiBbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtdGVzdGlkPVwiY2hhcmFjdGVyLWh1ZFwiXSwgW2RhdGEtdGVzdGlkPVwib2ZmbGluZS1ib251cy1jaGlwXCJdJyldLmZsYXRNYXAobm9kZSA9PiB7XG4gICAgICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICByZXR1cm4gWzAuMDUsMC41LDAuOTVdLmZsYXRNYXAoeCA9PiBbMC4wNSwwLjUsMC45NV0ubWFwKHkgPT4ge1xuICAgICAgICAgIGNvbnN0IHB4PWIubGVmdCtiLndpZHRoKngsIHB5PWIudG9wK2IuaGVpZ2h0Knk7XG4gICAgICAgICAgY29uc3QgaGl0PWRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQocHgscHkpO1xuICAgICAgICAgIHJldHVybiB7IHRhcmdldDpub2RlLmdldEF0dHJpYnV0ZSgnZGF0YS10ZXN0aWQnKSx4OnB4LHk6cHksbW9kYWxPd25zSGl0OmhpdCAhPT0gbnVsbCAmJiBkaWFsb2cgIT09IG51bGwgJiYgZGlhbG9nLmNvbnRhaW5zKGhpdCkgfTtcbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJ21vZGFsLXByaW9yaXR5LWF0LWhlYWRlcicsbW9kYWxQcmlvcml0eSk7XG4gICAgZXhwZWN0KG1vZGFsUHJpb3JpdHkpLnRvSGF2ZUxlbmd0aChib251cyA/IDE4IDogOSk7XG4gICAgZm9yIChjb25zdCBwb2ludCBvZiBtb2RhbFByaW9yaXR5KSBleHBlY3Quc29mdChwb2ludCkudG9NYXRjaE9iamVjdCh7IG1vZGFsT3duc0hpdDp0cnVlIH0pO1xuICAgIGNvbnN0IGNhbmNlbCA9IHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKS5nZXRCeVJvbGUoJ2J1dHRvbicseyBuYW1lOmVuZ2xpc2ggPyAnQ2FuY2VsJyA6ICflj5bmtognLGV4YWN0OnRydWUgfSk7XG4gICAgYXdhaXQgY2xlYXJUYXJnZXQoY2FuY2VsLCdtb2RhbCBjYW5jZWwnKTsgYXdhaXQgY2FuY2VsLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1zY3JlZW4nKSkudG9CZVZpc2libGUoKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBuYXZUbyhwYWdlLCdjb21iYXQnKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY29tYmF0LXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDApO1xuICAgIGNvbnN0IGNvbWJhdEhlYWRlciA9IHBhZ2UuZ2V0QnlUZXN0SWQoJ2NvbWJhdC1zY3JlZW4nKS5sb2NhdG9yKCdoZWFkZXInKTtcbiAgICBjb25zdCB3aWR0aCA9IGF3YWl0IGNvbWJhdEhlYWRlci5ldmFsdWF0ZShub2RlID0+ICh7IG91dGVyOm5vZGUuY2xpZW50V2lkdGgsaW5uZXI6bm9kZS5maXJzdEVsZW1lbnRDaGlsZD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggfSkpO1xuICAgIGV4cGVjdCh3aWR0aC5pbm5lcikudG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCh3aWR0aC5vdXRlciAtIDMyKTtcbiAgICBhd2FpdCBuYXZUbyhwYWdlLCdza2lsbHMnKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgxKTtcbiAgICBleHBlY3QoYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAnX19HQU1FX18nIGluIHdpbmRvdykpLnRvQmUoZmFsc2UpO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwNC1jb25zb2xlLWVycm9ycycsZXJyb3JzKTsgZXhwZWN0KGVycm9ycykudG9FcXVhbChbXSk7XG4gICAgYXdhaXQgcGFnZS5jbG9zZSgpO1xuICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxTQUFTQSxNQUFNLEVBQUVDLElBQUksUUFBZ0Qsa0JBQWtCO0FBQ3ZGLFNBQVNDLFFBQVEsUUFBUSxrQkFBa0I7QUFFM0MsU0FBU0MsS0FBSyxRQUFRLGlCQUFpQjtBQUV2QyxNQUFNQyxPQUFPLEdBQUcsb0NBQW9DO0FBQ3BELE1BQU1DLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsSUFBSSxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFVO0FBRXRILGVBQWVDLE1BQU1BLENBQUNDLElBQWMsRUFBRUMsSUFBWSxFQUFFQyxLQUFjLEVBQWlCO0VBQ2pGLE1BQU1GLElBQUksQ0FBQ0QsTUFBTSxDQUFDRSxJQUFJLEVBQUU7SUFBRUUsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFBRUksV0FBVyxFQUFFO0VBQW1CLENBQUMsQ0FBQztBQUNwRztBQUVBLGVBQWVDLE1BQU1BLENBQUNDLElBQVUsRUFBd0I7RUFDdEQsTUFBTVosS0FBSyxDQUFDWSxJQUFJLEVBQUUsVUFBVSxDQUFDO0VBQzdCLE1BQU1DLE9BQU8sR0FBR0QsSUFBSSxDQUFDRSxZQUFZLENBQUMsVUFBVSxDQUFDO0VBQzdDLE1BQU1GLElBQUksQ0FBQ0csV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQ3BELE1BQU1DLFFBQVEsR0FBRyxNQUFNSixPQUFPO0VBQzlCLElBQUk7SUFBRSxPQUFPTCxJQUFJLENBQUNVLEtBQUssQ0FBQyxNQUFNbkIsUUFBUSxDQUFDLE1BQU1rQixRQUFRLENBQUNFLElBQUksQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7RUFBaUIsQ0FBQyxTQUNoRjtJQUFFLE1BQU1GLFFBQVEsQ0FBQ0csTUFBTSxDQUFDLENBQUM7RUFBRTtBQUNyQztBQUVBLGVBQWVDLFVBQVVBLENBQUNULElBQVUsRUFBRVUsSUFBaUIsRUFBRUMsT0FBZ0IsRUFBaUI7RUFDeEYsTUFBTUMsS0FBSyxHQUFHRCxPQUFPLEdBQUcsYUFBYSxHQUFHLE1BQU07RUFDOUMsTUFBTVgsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxFQUFFO0lBQUVwQixJQUFJLEVBQUVtQixLQUFLO0lBQUVFLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDVixLQUFLLENBQUMsQ0FBQztFQUNwRSxNQUFNVyxNQUFNLEdBQUdmLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQztFQUN2QyxNQUFNRSxNQUFNLENBQUNGLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQ0csSUFBSSxDQUFDcEIsSUFBSSxDQUFDQyxTQUFTLENBQUNhLElBQUksQ0FBQyxDQUFDO0VBQzVELE1BQU1LLE1BQU0sQ0FBQ0YsU0FBUyxDQUFDLFFBQVEsRUFBRTtJQUFFcEIsSUFBSSxFQUFFbUIsS0FBSztJQUFFRSxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ1YsS0FBSyxDQUFDLENBQUM7RUFDdEUsTUFBTW5CLE1BQU0sQ0FBQzhCLE1BQU0sQ0FBQyxDQUFDRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3JDOztBQUVBO0FBQ0EsZUFBZUMsU0FBU0EsQ0FBQ0MsTUFBZSxFQUFzQjtFQUM1RCxPQUFPQSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxJQUFJO0lBQzdCLE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3RDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDQyxPQUFPLENBQUNDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQyxJQUFJO01BQUEsSUFBQUMsWUFBQTtNQUMvRCxNQUFNQyxFQUFFLEdBQUdQLENBQUMsQ0FBQ1EsSUFBSSxHQUFHUixDQUFDLENBQUNTLEtBQUssR0FBR04sQ0FBQztRQUFFTyxFQUFFLEdBQUdWLENBQUMsQ0FBQ1csR0FBRyxHQUFHWCxDQUFDLENBQUNZLE1BQU0sR0FBR1AsQ0FBQztNQUMxRCxNQUFNUSxHQUFHLEdBQUdDLFFBQVEsQ0FBQ0MsZ0JBQWdCLENBQUNSLEVBQUUsRUFBRUcsRUFBRSxDQUFDO01BQzdDLE9BQU87UUFBRVAsQ0FBQyxFQUFFSSxFQUFFO1FBQUVGLENBQUMsRUFBRUssRUFBRTtRQUFFTSxLQUFLLEVBQUVILEdBQUcsS0FBSyxJQUFJLElBQUlkLElBQUksQ0FBQ2tCLFFBQVEsQ0FBQ0osR0FBRyxDQUFDO1FBQUVBLEdBQUcsR0FBQVAsWUFBQSxHQUFFTyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRUssT0FBTyxjQUFBWixZQUFBLGNBQUFBLFlBQUEsR0FBSTtNQUFLLENBQUM7SUFDL0YsQ0FBQyxDQUFDLENBQUM7RUFDTCxDQUFDLENBQUM7QUFDSjtBQUVBLGVBQWVhLFdBQVdBLENBQUN0QixNQUFlLEVBQUVQLEtBQWEsRUFBc0I7RUFDN0UsTUFBTU8sTUFBTSxDQUFDdUIsc0JBQXNCLENBQUMsQ0FBQztFQUNyQyxNQUFNQyxNQUFNLEdBQUcsTUFBTXpCLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDO0VBQ3RDLEtBQUssTUFBTXlCLEtBQUssSUFBSUQsTUFBTSxFQUFFMUQsTUFBTSxDQUFDNEQsSUFBSSxDQUFDRCxLQUFLLEVBQUVoQyxLQUFLLENBQUMsQ0FBQ2tDLGFBQWEsQ0FBQztJQUFFUixLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUM7RUFDcEYsT0FBT0ssTUFBTTtBQUNmO0FBRUEsZUFBZUksTUFBTUEsQ0FBQy9DLElBQVUsRUFBRWdELEtBQWMsRUFBb0I7RUFDbEUsTUFBTUMsUUFBUSxHQUFHLE1BQU1qRCxJQUFJLENBQUNvQixRQUFRLENBQUMsTUFBTTtJQUFBLElBQUE4QixtQkFBQTtJQUN6QyxNQUFNQyxJQUFJLEdBQUdmLFFBQVEsQ0FBQ2dCLGFBQWEsQ0FBQyxNQUFNLENBQUM7SUFDM0MsTUFBTUMsR0FBRyxHQUFHakIsUUFBUSxDQUFDZ0IsYUFBYSxDQUFDLCtCQUErQixDQUFDO0lBQ25FLE1BQU1FLElBQUksR0FBR2xCLFFBQVEsQ0FBQ2dCLGFBQWEsQ0FBQyxvQ0FBb0MsQ0FBQztJQUN6RSxNQUFNRyxNQUFNLEdBQUdKLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFSyxzQkFBc0I7SUFDM0MsSUFBSSxDQUFDTCxJQUFJLElBQUksQ0FBQ0UsR0FBRyxJQUFJLENBQUNFLE1BQU0sRUFBRSxNQUFNLElBQUlFLEtBQUssQ0FBQyxzQ0FBc0MsQ0FBQztJQUNyRixNQUFNQyxJQUFJLEdBQUlyQyxJQUFhLElBQUs7TUFDOUIsTUFBTUMsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLHFCQUFxQixDQUFDLENBQUM7TUFDdEMsT0FBTztRQUFFTyxJQUFJLEVBQUVSLENBQUMsQ0FBQ1EsSUFBSTtRQUFFRyxHQUFHLEVBQUVYLENBQUMsQ0FBQ1csR0FBRztRQUFFMEIsS0FBSyxFQUFFckMsQ0FBQyxDQUFDcUMsS0FBSztRQUFFQyxNQUFNLEVBQUV0QyxDQUFDLENBQUNzQyxNQUFNO1FBQUU3QixLQUFLLEVBQUVULENBQUMsQ0FBQ1MsS0FBSztRQUFFRyxNQUFNLEVBQUVaLENBQUMsQ0FBQ1k7TUFBTyxDQUFDO0lBQ3pHLENBQUM7SUFDRCxNQUFNMkIsQ0FBQyxHQUFHSCxJQUFJLENBQUNILE1BQU0sQ0FBQztNQUFFTyxDQUFDLEdBQUdKLElBQUksQ0FBQ1AsSUFBSSxDQUFDO01BQUVZLENBQUMsR0FBR0wsSUFBSSxDQUFDTCxHQUFHLENBQUM7TUFBRVcsQ0FBQyxHQUFHVixJQUFJLEdBQUdJLElBQUksQ0FBQ0osSUFBSSxDQUFDLEdBQUcsSUFBSTtJQUNuRixNQUFNZixRQUFRLEdBQUdBLENBQUMwQixDQUFXLEVBQUUzQyxDQUFXLEtBQUtBLENBQUMsQ0FBQ1EsSUFBSSxJQUFJbUMsQ0FBQyxDQUFDbkMsSUFBSSxJQUFJUixDQUFDLENBQUNxQyxLQUFLLElBQUlNLENBQUMsQ0FBQ04sS0FBSyxJQUFJckMsQ0FBQyxDQUFDVyxHQUFHLElBQUlnQyxDQUFDLENBQUNoQyxHQUFHLElBQUlYLENBQUMsQ0FBQ3NDLE1BQU0sSUFBSUssQ0FBQyxDQUFDTCxNQUFNO0lBQy9ILE1BQU1NLE9BQU8sR0FBRyxDQUFDLEdBQUc5QixRQUFRLENBQUMrQixnQkFBZ0IsQ0FBQyxrRkFBa0YsQ0FBQyxDQUFDLENBQUN6QyxHQUFHLENBQUNMLElBQUksSUFBSTtNQUM3SSxNQUFNQyxDQUFDLEdBQUdvQyxJQUFJLENBQUNyQyxJQUFJLENBQUM7TUFDcEIsTUFBTStDLE9BQU8sR0FBRztRQUFFdEMsSUFBSSxFQUFFdUMsSUFBSSxDQUFDQyxHQUFHLENBQUNoRCxDQUFDLENBQUNRLElBQUksRUFBQ2dDLENBQUMsQ0FBQ2hDLElBQUksQ0FBQztRQUFFNkIsS0FBSyxFQUFFVSxJQUFJLENBQUNFLEdBQUcsQ0FBQ2pELENBQUMsQ0FBQ3FDLEtBQUssRUFBQ0csQ0FBQyxDQUFDSCxLQUFLLENBQUM7UUFBRTFCLEdBQUcsRUFBRW9DLElBQUksQ0FBQ0MsR0FBRyxDQUFDaEQsQ0FBQyxDQUFDVyxHQUFHLEVBQUM2QixDQUFDLENBQUM3QixHQUFHLENBQUM7UUFBRTJCLE1BQU0sRUFBRVMsSUFBSSxDQUFDRSxHQUFHLENBQUNqRCxDQUFDLENBQUNzQyxNQUFNLEVBQUNFLENBQUMsQ0FBQ0YsTUFBTTtNQUFFLENBQUM7TUFDcEosTUFBTVksS0FBSyxHQUFHSixPQUFPLENBQUNULEtBQUssR0FBR1MsT0FBTyxDQUFDdEMsSUFBSSxJQUFJc0MsT0FBTyxDQUFDUixNQUFNLEdBQUdRLE9BQU8sQ0FBQ25DLEdBQUc7TUFDMUUsTUFBTXdDLFFBQVEsR0FBSVIsQ0FBVyxJQUFLTyxLQUFLLElBQUlKLE9BQU8sQ0FBQ3RDLElBQUksR0FBR21DLENBQUMsQ0FBQ04sS0FBSyxJQUFJUyxPQUFPLENBQUNULEtBQUssR0FBR00sQ0FBQyxDQUFDbkMsSUFBSSxJQUFJc0MsT0FBTyxDQUFDbkMsR0FBRyxHQUFHZ0MsQ0FBQyxDQUFDTCxNQUFNLElBQUlRLE9BQU8sQ0FBQ1IsTUFBTSxHQUFHSyxDQUFDLENBQUNoQyxHQUFHO01BQy9JLE9BQU87UUFBRXlDLElBQUksRUFBRXJELElBQUksQ0FBQ3NELFdBQVc7UUFBRWpCLElBQUksRUFBQ3BDLENBQUM7UUFBRThDLE9BQU87UUFBRUksS0FBSztRQUFFSSxZQUFZLEVBQUVILFFBQVEsQ0FBQ1YsQ0FBQyxDQUFDO1FBQUVjLGFBQWEsRUFBRWIsQ0FBQyxLQUFLLElBQUksSUFBSVMsUUFBUSxDQUFDVCxDQUFDO01BQUUsQ0FBQztJQUNoSSxDQUFDLENBQUM7SUFDRixPQUFPO01BQUVULE1BQU0sRUFBRU0sQ0FBQztNQUFFVixJQUFJLEVBQUVXLENBQUM7TUFBRVQsR0FBRyxFQUFFVSxDQUFDO01BQUVULElBQUksRUFBRVUsQ0FBQztNQUFFYyxZQUFZLEVBQUV2QyxRQUFRLENBQUNzQixDQUFDLEVBQUNFLENBQUMsQ0FBQztNQUFFZ0IsYUFBYSxFQUFFZixDQUFDLEtBQUssSUFBSSxJQUFJekIsUUFBUSxDQUFDc0IsQ0FBQyxFQUFDRyxDQUFDLENBQUM7TUFDbkhnQixZQUFZLEVBQUVsQixDQUFDLENBQUM3QixHQUFHLElBQUk4QixDQUFDLENBQUNILE1BQU07TUFBRXFCLGFBQWEsRUFBRWpCLENBQUMsS0FBSyxJQUFJLElBQUlGLENBQUMsQ0FBQzdCLEdBQUcsSUFBSStCLENBQUMsQ0FBQ0osTUFBTTtNQUMvRXNCLGVBQWUsRUFBRWxCLENBQUMsS0FBSyxJQUFJLElBQUlBLENBQUMsQ0FBQy9CLEdBQUcsSUFBSThCLENBQUMsQ0FBQ0gsTUFBTTtNQUFFdUIsaUJBQWlCLEVBQUU3QixJQUFJLEtBQUssSUFBSSxJQUFJLENBQUNELEdBQUcsQ0FBQ2QsUUFBUSxDQUFDZSxJQUFJLENBQUM7TUFDekc4QixnQkFBZ0IsRUFBRWhELFFBQVEsQ0FBQ2lELGVBQWUsQ0FBQ0MsV0FBVyxHQUFHQyxVQUFVO01BQ25FQyxZQUFZLEVBQUVyQyxJQUFJLENBQUNtQyxXQUFXLEdBQUduQyxJQUFJLENBQUNzQyxXQUFXO01BQUVDLE9BQU8sRUFBRUMsT0FBTztNQUNuRUMsTUFBTSxHQUFBMUMsbUJBQUEsR0FBRUMsSUFBSSxDQUFDMEMsYUFBYSxjQUFBM0MsbUJBQUEsZ0JBQUFBLG1CQUFBLEdBQWxCQSxtQkFBQSxDQUFvQjJDLGFBQWEsY0FBQTNDLG1CQUFBLHVCQUFqQ0EsbUJBQUEsQ0FBbUM0QyxTQUFTO01BQUVDLEtBQUssRUFBRTVDLElBQUksQ0FBQzJDLFNBQVM7TUFDM0VFLGdCQUFnQixFQUFFN0MsSUFBSSxDQUFDOEMsWUFBWTtNQUFFQyxnQkFBZ0IsRUFBRS9DLElBQUksQ0FBQ2dELFlBQVk7TUFBRWpDO0lBQVEsQ0FBQztFQUN2RixDQUFDLENBQUM7RUFDRmpGLE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDNkIsWUFBWSxFQUFFLG1DQUFtQyxDQUFDLENBQUNzQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2xGbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUM4QixhQUFhLEVBQUUsMENBQTBDLENBQUMsQ0FBQ3FCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDMUZuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQytCLFlBQVksRUFBRSw4QkFBOEIsQ0FBQyxDQUFDb0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUM3RW5ILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDZ0MsYUFBYSxFQUFFLCtCQUErQixDQUFDLENBQUNtQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQy9FbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNpQyxlQUFlLENBQUMsQ0FBQ2tCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDaERuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ2tDLGlCQUFpQixDQUFDLENBQUNpQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2xEbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNtQyxnQkFBZ0IsQ0FBQyxDQUFDaUIsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0VBQzdEcEgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUN1QyxZQUFZLENBQUMsQ0FBQ2EsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0VBQ3pEcEgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUN5QyxPQUFPLENBQUMsQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUFFbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUMyQyxNQUFNLENBQUMsQ0FBQ1EsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUMzRW5ILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDSSxHQUFHLENBQUN0QixLQUFLLENBQUMsQ0FBQ3VFLHNCQUFzQixDQUFDLEVBQUUsQ0FBQztFQUMxRHJILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDSSxHQUFHLENBQUNuQixNQUFNLENBQUMsQ0FBQ29FLHNCQUFzQixDQUFDLEVBQUUsQ0FBQztFQUMzRHJILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDRSxJQUFJLENBQUNqQixNQUFNLENBQUMsQ0FBQ3FFLGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFDcER0SCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ0ssSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDOEMsSUFBSSxDQUFDcEQsS0FBSyxDQUFDO0VBQy9DLEtBQUssTUFBTTdCLE1BQU0sSUFBSThCLFFBQVEsQ0FBQ2lCLE9BQU8sRUFBRTtJQUNyQ2pGLE1BQU0sQ0FBQzRELElBQUksQ0FBQzFCLE1BQU0sQ0FBQ3lELFlBQVksRUFBRSxpRUFBaUUsQ0FBQyxDQUFDd0IsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUMvR25ILE1BQU0sQ0FBQzRELElBQUksQ0FBQzFCLE1BQU0sQ0FBQzBELGFBQWEsRUFBRSx5RUFBeUUsQ0FBQyxDQUFDdUIsSUFBSSxDQUFDLEtBQUssQ0FBQztFQUMxSDtFQUNBLE9BQU9uRCxRQUFRO0FBQ2pCO0FBRUEsS0FBSyxNQUFNdUQsTUFBTSxJQUFJLENBQUMsSUFBSSxFQUFDLE9BQU8sQ0FBQyxFQUFXLEtBQUssTUFBTXhELEtBQUssSUFBSSxDQUFDLEtBQUssRUFBQyxJQUFJLENBQUMsRUFBRTtFQUM5RTlELElBQUksQ0FBQyw2QkFBNkJzSCxNQUFNLFVBQVVDLE1BQU0sQ0FBQ3pELEtBQUssQ0FBQyxFQUFFLEVBQUUsT0FBTztJQUFFaEQsSUFBSTtJQUFFMEc7RUFBUSxDQUFDLEVBQUVsSCxJQUFJLEtBQUs7SUFDcEcsTUFBTW1CLE9BQU8sR0FBRzZGLE1BQU0sS0FBSyxJQUFJO0lBQy9CLE1BQU1HLE1BQWdCLEdBQUcsRUFBRTtJQUMzQjNHLElBQUksQ0FBQzRHLEVBQUUsQ0FBQyxXQUFXLEVBQUVDLEtBQUssSUFBSUYsTUFBTSxDQUFDRyxJQUFJLENBQUNELEtBQUssQ0FBQ0UsT0FBTyxDQUFDLENBQUM7SUFDekQvRyxJQUFJLENBQUM0RyxFQUFFLENBQUMsU0FBUyxFQUFFRyxPQUFPLElBQUk7TUFBRSxJQUFJQSxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJRCxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUFFTCxNQUFNLENBQUNHLElBQUksQ0FBQyxHQUFHQyxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUFDLEtBQUtELE9BQU8sQ0FBQ3JDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUFFLENBQUMsQ0FBQztJQUN2SixNQUFNMUUsSUFBSSxDQUFDaUgsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUM1QixNQUFNaEksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU1qQixJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLEVBQUU7TUFBRXBCLElBQUksRUFBRWtCLE9BQU8sR0FBRyxTQUFTLEdBQUcsTUFBTTtNQUFFRyxLQUFLLEVBQUU7SUFBSyxDQUFDLENBQUMsQ0FBQ1YsS0FBSyxDQUFDLENBQUM7SUFDM0YsTUFBTUosSUFBSSxDQUFDaUgsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNwQixNQUFNaEksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU1qQixJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDL0MsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDakQsTUFBTVgsSUFBSSxHQUFHa0IsT0FBTyxHQUFHLGtCQUFrQixHQUFHLEdBQUcsQ0FBQ3VHLE1BQU0sQ0FBQyxFQUFFLENBQUM7SUFDMUQsTUFBTWxILElBQUksQ0FBQ0csV0FBVyxDQUFDLHNCQUFzQixDQUFDLENBQUNhLElBQUksQ0FBQ3ZCLElBQUksQ0FBQztJQUN6RCxNQUFNTyxJQUFJLENBQUNHLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUNyRCxNQUFNbkIsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDZ0gsV0FBVyxDQUFDLENBQUM7SUFDM0QsTUFBTUMsS0FBSyxHQUFHLE1BQU1ySCxNQUFNLENBQUNDLElBQUksQ0FBQztJQUNoQ2YsTUFBTSxDQUFDbUksS0FBSyxDQUFDQyxNQUFNLENBQUM1SCxJQUFJLENBQUMsQ0FBQzJHLElBQUksQ0FBQzNHLElBQUksQ0FBQztJQUNwQyxNQUFNNkgsUUFBcUIsR0FBRztNQUFFLEdBQUdGLEtBQUs7TUFBRUMsTUFBTSxFQUFFO1FBQUUsR0FBR0QsS0FBSyxDQUFDQyxNQUFNO1FBQUVFLEtBQUssRUFBRSxFQUFFO1FBQUVDLFdBQVcsRUFBRSxDQUFDO1FBQzVGQyxXQUFXLEVBQUU7VUFBRSxxQkFBcUIsRUFBRTtRQUFFLENBQUM7UUFBRUMsVUFBVSxFQUFFLENBQUMsNEJBQTRCO01BQUUsQ0FBQztNQUN2RkMsSUFBSSxFQUFFO1FBQUUsR0FBR1AsS0FBSyxDQUFDTyxJQUFJO1FBQUVDLFNBQVMsRUFBRTtVQUFFLEdBQUdSLEtBQUssQ0FBQ08sSUFBSSxDQUFDQyxTQUFTO1VBQUVDLFVBQVUsRUFBRUMsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQztVQUNqRkMsZ0JBQWdCLEVBQUVoRixLQUFLLEdBQUcsR0FBRyxHQUFHLENBQUM7VUFBRWlGLDBCQUEwQixFQUFFakYsS0FBSyxHQUFHLElBQUksR0FBRztRQUFFO01BQUU7SUFBRSxDQUFDO0lBQ3pGLE1BQU12QyxVQUFVLENBQUNULElBQUksRUFBRXNILFFBQVEsRUFBRTNHLE9BQU8sQ0FBQztJQUN6QyxNQUFNcEIsTUFBTSxDQUFDQyxJQUFJLEVBQUUseUJBQXlCLEVBQUU4SCxRQUFRLENBQUM7SUFFdkQsS0FBSyxNQUFNWSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUMsVUFBVSxFQUFDLFFBQVEsQ0FBQyxFQUFFO01BQ2hELE1BQU05SSxLQUFLLENBQUNZLElBQUksRUFBRWtJLEtBQUssQ0FBQztNQUN4QixNQUFNakosTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO01BQzlELE1BQU1oQyxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNnSSxvQkFBb0IsQ0FBQyxJQUFJQyxNQUFNLENBQUMzSSxJQUFJLENBQUMsQ0FBQztNQUN0RixNQUFNRixNQUFNLENBQUNDLElBQUksRUFBRSxTQUFTMEksS0FBSyxFQUFFLEVBQUUsTUFBTW5GLE1BQU0sQ0FBQy9DLElBQUksRUFBQ2dELEtBQUssQ0FBQyxDQUFDO0lBQ2hFO0lBQ0EsTUFBTXFGLEtBQUssR0FBR3JJLElBQUksQ0FBQ0csV0FBVyxDQUFDLG9CQUFvQixDQUFDO0lBQ3BELE1BQU1ILElBQUksQ0FBQ0csV0FBVyxDQUFDLGNBQWNkLE9BQU8sRUFBRSxDQUFDLENBQUNlLEtBQUssQ0FBQyxDQUFDO0lBQ3ZELE1BQU1rSSxPQUFPLEdBQUdELEtBQUssQ0FBQ3hILFNBQVMsQ0FBQyxTQUFTLEVBQUU7TUFBRXBCLElBQUksRUFBRWtCLE9BQU8sR0FBRyxtQkFBbUIsR0FBRyxNQUFNO01BQUVHLEtBQUssRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN6RyxNQUFNeUgsUUFBUSxHQUFHRixLQUFLLENBQUN4SCxTQUFTLENBQUMsUUFBUSxDQUFDO0lBQzFDLE1BQU0ySCxXQUFXLEdBQUdILEtBQUssQ0FBQ0ksT0FBTyxDQUFDLHlCQUF5QixDQUFDO0lBQzVELE1BQU1DLE9BQU8sR0FBRyxFQUFFO0lBQ2xCLEtBQUssTUFBTSxDQUFDM0csS0FBSyxFQUFDRyxNQUFNLENBQUMsSUFBSTVDLEtBQUssRUFBRTtNQUNsQyxNQUFNVSxJQUFJLENBQUMySSxlQUFlLENBQUM7UUFBRTVHLEtBQUs7UUFBQ0c7TUFBTyxDQUFDLENBQUM7TUFDNUMsTUFBTXNHLFdBQVcsQ0FBQzlGLHNCQUFzQixDQUFDLENBQUM7TUFDMUMsTUFBTWtHLGdCQUFnQixHQUFHLE1BQU03RixNQUFNLENBQUMvQyxJQUFJLEVBQUNnRCxLQUFLLENBQUM7TUFDakQsSUFBSWpCLEtBQUssS0FBSyxHQUFHLElBQUlHLE1BQU0sS0FBSyxHQUFHLEVBQUU7UUFDbkNqRCxNQUFNLENBQUM0RCxJQUFJLENBQUMsTUFBTTdDLElBQUksQ0FBQ3lJLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQ3JILFFBQVEsQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUN5RSxTQUFTLENBQUMsRUFBRSxxQ0FBcUMsQ0FBQyxDQUFDUyxlQUFlLENBQUMsQ0FBQyxDQUFDO01BQ3BJO01BQ0EsTUFBTS9HLElBQUksQ0FBQ0QsTUFBTSxDQUFDLFVBQVVrSCxNQUFNLENBQUMxRSxLQUFLLENBQUMsSUFBSTBFLE1BQU0sQ0FBQ3ZFLE1BQU0sQ0FBQyxFQUFFLEVBQUU7UUFBRXZDLElBQUksRUFBRSxNQUFNSyxJQUFJLENBQUM2SSxVQUFVLENBQUMsQ0FBQztRQUFFL0ksV0FBVyxFQUFFO01BQVksQ0FBQyxDQUFDO01BQzNILE1BQU1nSixXQUFXLEdBQUcsTUFBTXJHLFdBQVcsQ0FBQzZGLE9BQU8sRUFBQyxHQUFHN0IsTUFBTSxDQUFDMUUsS0FBSyxDQUFDLElBQUkwRSxNQUFNLENBQUN2RSxNQUFNLENBQUMsVUFBVSxDQUFDO01BQzNGLE1BQU02RyxVQUFVLEdBQUcsTUFBTXRHLFdBQVcsQ0FBQzhGLFFBQVEsRUFBQyxHQUFHOUIsTUFBTSxDQUFDMUUsS0FBSyxDQUFDLElBQUkwRSxNQUFNLENBQUN2RSxNQUFNLENBQUMsV0FBVyxDQUFDO01BQzVGLElBQUksQ0FBQ3ZCLE9BQU8sSUFBSW9CLEtBQUssS0FBSyxHQUFHLEVBQUU7UUFDN0IsTUFBTWlILEdBQUcsR0FBRyxNQUFNdEMsT0FBTyxDQUFDdUMsYUFBYSxDQUFDakosSUFBSSxDQUFDO1FBQzdDLElBQUk7VUFDRixNQUFNZ0osR0FBRyxDQUFDRSxJQUFJLENBQUMsWUFBWSxDQUFDO1VBQUUsTUFBTUYsR0FBRyxDQUFDRSxJQUFJLENBQUMsWUFBWSxDQUFDO1VBQzFELE1BQU05RyxRQUFRLEdBQUcsTUFBTTRHLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1VBQ2xELE1BQU03SCxJQUFJLEdBQUcsTUFBTTJILEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLG1CQUFtQixFQUFDO1lBQUVDLE1BQU0sRUFBRS9HLFFBQVEsQ0FBQ2dILElBQUksQ0FBQ0QsTUFBTTtZQUFFRSxRQUFRLEVBQUU7VUFBNkQsQ0FBQyxDQUFDO1VBQ3pKLE1BQU1DLEtBQUssR0FBRyxNQUFNTixHQUFHLENBQUNFLElBQUksQ0FBQyw2QkFBNkIsRUFBQztZQUFFQyxNQUFNLEVBQUU5SCxJQUFJLENBQUM4SDtVQUFPLENBQUMsQ0FBQztVQUNuRmxLLE1BQU0sQ0FBQ3FLLEtBQUssQ0FBQ0EsS0FBSyxDQUFDQyxJQUFJLENBQUNDLElBQUksSUFBSUEsSUFBSSxDQUFDQyxVQUFVLEtBQUssa0JBQWtCLElBQUlELElBQUksQ0FBQ0UsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUN0RCxJQUFJLENBQUMsSUFBSSxDQUFDO1VBQzFHLE1BQU03RyxNQUFNLENBQUNDLElBQUksRUFBQywrQkFBK0IsRUFBQzhKLEtBQUssQ0FBQztRQUMxRCxDQUFDLFNBQVM7VUFBRSxNQUFNTixHQUFHLENBQUNXLE1BQU0sQ0FBQyxDQUFDO1FBQUU7TUFDbEM7TUFDQWpCLE9BQU8sQ0FBQzVCLElBQUksQ0FBQztRQUFFL0UsS0FBSztRQUFDRyxNQUFNO1FBQUMwRyxnQkFBZ0I7UUFBQ0UsV0FBVztRQUFDQztNQUFXLENBQUMsQ0FBQztJQUN4RTtJQUNBLE1BQU14SixNQUFNLENBQUNDLElBQUksRUFBQyxtQkFBbUIsRUFBQ2tKLE9BQU8sQ0FBQztJQUU5QyxNQUFNMUksSUFBSSxDQUFDMkksZUFBZSxDQUFDO01BQUU1RyxLQUFLLEVBQUMsR0FBRztNQUFDRyxNQUFNLEVBQUM7SUFBSSxDQUFDLENBQUM7SUFDcEQsTUFBTXNHLFdBQVcsQ0FBQzlGLHNCQUFzQixDQUFDLENBQUM7SUFDMUMsTUFBTXpELE1BQU0sQ0FBQ3NKLFFBQVEsQ0FBQyxDQUFDcUIsVUFBVSxDQUFDakosT0FBTyxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDOUQsTUFBTTRILFFBQVEsQ0FBQ25JLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN4QixNQUFNbkIsTUFBTSxDQUFDb0osS0FBSyxDQUFDLENBQUN3QixhQUFhLENBQUNsSixPQUFPLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztJQUNuRSxNQUFNbUosS0FBSyxHQUFHLE1BQU0vSixNQUFNLENBQUNDLElBQUksQ0FBQztJQUNoQ2YsTUFBTSxDQUFDNkssS0FBSyxDQUFDekMsTUFBTSxDQUFDLENBQUMwQyxPQUFPLENBQUM7TUFBRSxHQUFHekMsUUFBUSxDQUFDRCxNQUFNO01BQUVHLFdBQVcsRUFBQyxDQUFDO01BQzlEQyxXQUFXLEVBQUM7UUFBRSxxQkFBcUIsRUFBQyxDQUFDO1FBQUMsNkJBQTZCLEVBQUM7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUM1RSxNQUFNckksS0FBSyxDQUFDWSxJQUFJLEVBQUMsUUFBUSxDQUFDO0lBQzFCLE1BQU1BLElBQUksQ0FBQ0csV0FBVyxDQUFDLGNBQWNkLE9BQU8sRUFBRSxDQUFDLENBQUNlLEtBQUssQ0FBQyxDQUFDO0lBQ3ZELE1BQU1KLElBQUksQ0FBQzJJLGVBQWUsQ0FBQztNQUFFNUcsS0FBSyxFQUFDLEdBQUc7TUFBQ0csTUFBTSxFQUFDO0lBQUksQ0FBQyxDQUFDO0lBQ3BELElBQUk4SCxPQUFPLEdBQUcsS0FBSztJQUNuQixLQUFLLElBQUlDLElBQUksR0FBQyxDQUFDLEVBQUNBLElBQUksR0FBQyxHQUFHLEVBQUNBLElBQUksRUFBRSxFQUFFO01BQy9CLE1BQU1qSyxJQUFJLENBQUNrSyxRQUFRLENBQUNDLEtBQUssQ0FBQyxLQUFLLENBQUM7TUFDaEMsSUFBSSxNQUFNNUIsUUFBUSxDQUFDbkgsUUFBUSxDQUFDQyxJQUFJLElBQUlBLElBQUksS0FBS2UsUUFBUSxDQUFDZ0ksYUFBYSxDQUFDLEVBQUU7UUFBRUosT0FBTyxHQUFDLElBQUk7UUFBQztNQUFPO0lBQzlGO0lBQ0EvSyxNQUFNLENBQUMrSyxPQUFPLENBQUMsQ0FBQzVELElBQUksQ0FBQyxJQUFJLENBQUM7SUFDMUIsTUFBTW5ILE1BQU0sQ0FBQ3FKLE9BQU8sQ0FBQyxDQUFDbkIsV0FBVyxDQUFDLENBQUM7SUFDbkMsTUFBTWxJLE1BQU0sQ0FBQ3NKLFFBQVEsQ0FBQyxDQUFDcUIsVUFBVSxDQUFDakosT0FBTyxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDOUQsTUFBTTFCLE1BQU0sQ0FBQ3NKLFFBQVEsQ0FBQyxDQUFDOEIsV0FBVyxDQUFDLENBQUM7SUFBRSxNQUFNcEwsTUFBTSxDQUFDc0osUUFBUSxDQUFDLENBQUMrQixXQUFXLENBQUMsQ0FBQztJQUMxRSxNQUFNN0gsV0FBVyxDQUFDOEYsUUFBUSxFQUFDLGlCQUFpQixDQUFDO0lBQzdDLE1BQU12SSxJQUFJLENBQUNrSyxRQUFRLENBQUNDLEtBQUssQ0FBQyxPQUFPLENBQUM7SUFDbEMsTUFBTWxMLE1BQU0sQ0FBQ29KLEtBQUssQ0FBQyxDQUFDd0IsYUFBYSxDQUFDbEosT0FBTyxHQUFHLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDbkUsTUFBTTRKLEtBQUssR0FBRyxNQUFNeEssTUFBTSxDQUFDQyxJQUFJLENBQUM7SUFDaENmLE1BQU0sQ0FBQ3NMLEtBQUssQ0FBQ2xELE1BQU0sQ0FBQyxDQUFDMEMsT0FBTyxDQUFDO01BQUUsR0FBR0QsS0FBSyxDQUFDekMsTUFBTTtNQUFDRyxXQUFXLEVBQUMsQ0FBQztNQUMxREMsV0FBVyxFQUFDO1FBQUUscUJBQXFCLEVBQUMsQ0FBQztRQUFDLDZCQUE2QixFQUFDO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDNUUsS0FBSyxNQUFNK0MsS0FBSyxJQUFJLENBQUMsV0FBVyxFQUFDLE9BQU8sRUFBQyxLQUFLLEVBQUMsV0FBVyxDQUFDLEVBQVd2TCxNQUFNLENBQUNzTCxLQUFLLENBQUNDLEtBQUssQ0FBQyxDQUFDLENBQUNULE9BQU8sQ0FBQ3pDLFFBQVEsQ0FBQ2tELEtBQUssQ0FBQyxDQUFDO0lBQ25ILE1BQU1qTCxNQUFNLENBQUNDLElBQUksRUFBQyxnQ0FBZ0MsRUFBQztNQUFFc0ssS0FBSztNQUFDUztJQUFNLENBQUMsQ0FBQzs7SUFFbkU7SUFDQSxNQUFNM0osS0FBSyxHQUFHRCxPQUFPLEdBQUcsYUFBYSxHQUFHLE1BQU07SUFDOUMsTUFBTVgsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUVwQixJQUFJLEVBQUNtQixLQUFLO01BQUNFLEtBQUssRUFBQztJQUFLLENBQUMsQ0FBQyxDQUFDVixLQUFLLENBQUMsQ0FBQztJQUNoRSxNQUFNcUssYUFBYSxHQUFHLE1BQU16SyxJQUFJLENBQUNvQixRQUFRLENBQUMsTUFBTTtNQUM5QyxNQUFNTCxNQUFNLEdBQUdxQixRQUFRLENBQUNnQixhQUFhLENBQUMsaUJBQWlCLENBQUM7TUFDeEQsT0FBTyxDQUFDLEdBQUdoQixRQUFRLENBQUMrQixnQkFBZ0IsQ0FBQyxtRUFBbUUsQ0FBQyxDQUFDLENBQUMzQyxPQUFPLENBQUNILElBQUksSUFBSTtRQUN6SCxNQUFNQyxDQUFDLEdBQUdELElBQUksQ0FBQ0UscUJBQXFCLENBQUMsQ0FBQztRQUN0QyxPQUFPLENBQUMsSUFBSSxFQUFDLEdBQUcsRUFBQyxJQUFJLENBQUMsQ0FBQ0MsT0FBTyxDQUFDQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxDQUFDQyxHQUFHLENBQUNDLENBQUMsSUFBSTtVQUMzRCxNQUFNRSxFQUFFLEdBQUNQLENBQUMsQ0FBQ1EsSUFBSSxHQUFDUixDQUFDLENBQUNTLEtBQUssR0FBQ04sQ0FBQztZQUFFTyxFQUFFLEdBQUNWLENBQUMsQ0FBQ1csR0FBRyxHQUFDWCxDQUFDLENBQUNZLE1BQU0sR0FBQ1AsQ0FBQztVQUM5QyxNQUFNUSxHQUFHLEdBQUNDLFFBQVEsQ0FBQ0MsZ0JBQWdCLENBQUNSLEVBQUUsRUFBQ0csRUFBRSxDQUFDO1VBQzFDLE9BQU87WUFBRWIsTUFBTSxFQUFDRSxJQUFJLENBQUNxSixZQUFZLENBQUMsYUFBYSxDQUFDO1lBQUNqSixDQUFDLEVBQUNJLEVBQUU7WUFBQ0YsQ0FBQyxFQUFDSyxFQUFFO1lBQUMySSxZQUFZLEVBQUN4SSxHQUFHLEtBQUssSUFBSSxJQUFJcEIsTUFBTSxLQUFLLElBQUksSUFBSUEsTUFBTSxDQUFDd0IsUUFBUSxDQUFDSixHQUFHO1VBQUUsQ0FBQztRQUNuSSxDQUFDLENBQUMsQ0FBQztNQUNMLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUNGLE1BQU01QyxNQUFNLENBQUNDLElBQUksRUFBQywwQkFBMEIsRUFBQ2lMLGFBQWEsQ0FBQztJQUMzRHhMLE1BQU0sQ0FBQ3dMLGFBQWEsQ0FBQyxDQUFDRyxZQUFZLENBQUM1SCxLQUFLLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNsRCxLQUFLLE1BQU1KLEtBQUssSUFBSTZILGFBQWEsRUFBRXhMLE1BQU0sQ0FBQzRELElBQUksQ0FBQ0QsS0FBSyxDQUFDLENBQUNFLGFBQWEsQ0FBQztNQUFFNkgsWUFBWSxFQUFDO0lBQUssQ0FBQyxDQUFDO0lBQzFGLE1BQU1FLE1BQU0sR0FBRzdLLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDQSxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUVwQixJQUFJLEVBQUNrQixPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7TUFBQ0csS0FBSyxFQUFDO0lBQUssQ0FBQyxDQUFDO0lBQ3pHLE1BQU0yQixXQUFXLENBQUNvSSxNQUFNLEVBQUMsY0FBYyxDQUFDO0lBQUUsTUFBTUEsTUFBTSxDQUFDekssS0FBSyxDQUFDLENBQUM7SUFDOUQsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyRCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLE1BQU1uQixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQ2dILFdBQVcsQ0FBQyxDQUFDO0lBQ2hFLE1BQU1sSSxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTTdCLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFFBQVEsQ0FBQztJQUMxQixNQUFNZixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNnSCxXQUFXLENBQUMsQ0FBQztJQUM3RCxNQUFNbEksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU02SixZQUFZLEdBQUc5SyxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ3NJLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDeEUsTUFBTTFHLEtBQUssR0FBRyxNQUFNK0ksWUFBWSxDQUFDMUosUUFBUSxDQUFDQyxJQUFJO01BQUEsSUFBQTBKLHFCQUFBO01BQUEsT0FBSztRQUFFQyxLQUFLLEVBQUMzSixJQUFJLENBQUNvRSxXQUFXO1FBQUN3RixLQUFLLEdBQUFGLHFCQUFBLEdBQUMxSixJQUFJLENBQUM2SixpQkFBaUIsY0FBQUgscUJBQUEsdUJBQXRCQSxxQkFBQSxDQUF3QnhKLHFCQUFxQixDQUFDLENBQUMsQ0FBQ1E7TUFBTSxDQUFDO0lBQUEsQ0FBQyxDQUFDO0lBQzNJOUMsTUFBTSxDQUFDOEMsS0FBSyxDQUFDa0osS0FBSyxDQUFDLENBQUMzRSxzQkFBc0IsQ0FBQ3ZFLEtBQUssQ0FBQ2lKLEtBQUssR0FBRyxFQUFFLENBQUM7SUFDNUQsTUFBTTVMLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFFBQVEsQ0FBQztJQUMxQixNQUFNZixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOURoQyxNQUFNLENBQUMsTUFBTWUsSUFBSSxDQUFDb0IsUUFBUSxDQUFDLE1BQU0sVUFBVSxJQUFJK0osTUFBTSxDQUFDLENBQUMsQ0FBQy9FLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDbkUsTUFBTTdHLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLG1CQUFtQixFQUFDbUgsTUFBTSxDQUFDO0lBQUUxSCxNQUFNLENBQUMwSCxNQUFNLENBQUMsQ0FBQ29ELE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDekUsTUFBTS9KLElBQUksQ0FBQ29MLEtBQUssQ0FBQyxDQUFDO0VBQ3BCLENBQUMsQ0FBQztBQUNKIiwiaWdub3JlTGlzdCI6W119