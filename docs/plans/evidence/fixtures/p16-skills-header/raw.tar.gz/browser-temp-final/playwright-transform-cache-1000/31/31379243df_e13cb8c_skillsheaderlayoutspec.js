/** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { navTo } from '../e2e/_helpers';
const MASTERY = 'skills-sorceress-lightning-mastery';
const sizes = [[360, 640], [412, 915], [640, 360], [375, 667], [393, 851], [768, 1024], [1280, 800], [1920, 1080], [915, 412]];
async function attach(info, name, value) {
  await info.attach(name, {
    body: JSON.stringify(value, null, 2),
    contentType: 'application/json'
  });
}
async function backup(page) {
  await navTo(page, 'settings');
  const pending = page.waitForEvent('download');
  await page.getByTestId('export-save-button').click();
  const download = await pending;
  try {
    return JSON.parse(await readFile(await download.path(), 'utf8'));
  } finally {
    await download.delete();
  }
}
async function importSave(page, save, english) {
  const label = english ? 'Import Save' : '导入存档';
  await page.getByRole('button', {
    name: label,
    exact: true
  }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('textbox').fill(JSON.stringify(save));
  await dialog.getByRole('button', {
    name: label,
    exact: true
  }).click();
  await expect(dialog).toHaveCount(0);
}

/** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
async function hitPoints(target) {
  return target.evaluate(node => {
    const b = node.getBoundingClientRect();
    return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
      var _hit$tagName, _hit$textContent$slic, _hit$textContent, _hit$closest$getAttri, _hit$closest;
      const px = b.left + b.width * x,
        py = b.top + b.height * y;
      const hit = document.elementFromPoint(px, py);
      return {
        x: px,
        y: py,
        clear: hit !== null && node.contains(hit),
        hit: (_hit$tagName = hit === null || hit === void 0 ? void 0 : hit.tagName) !== null && _hit$tagName !== void 0 ? _hit$tagName : null,
        hitText: (_hit$textContent$slic = hit === null || hit === void 0 || (_hit$textContent = hit.textContent) === null || _hit$textContent === void 0 ? void 0 : _hit$textContent.slice(0, 120)) !== null && _hit$textContent$slic !== void 0 ? _hit$textContent$slic : null,
        hitTestId: (_hit$closest$getAttri = hit === null || hit === void 0 || (_hit$closest = hit.closest('[data-testid]')) === null || _hit$closest === void 0 ? void 0 : _hit$closest.getAttribute('data-testid')) !== null && _hit$closest$getAttri !== void 0 ? _hit$closest$getAttri : null
      };
    }));
  });
}
async function clearTarget(target, label) {
  await target.scrollIntoViewIfNeeded();
  const points = await hitPoints(target);
  for (const point of points) expect.soft(point, label).toMatchObject({
    clear: true
  });
  return points;
}
async function layout(page, bonus) {
  const measured = await page.evaluate(() => {
    var _main$parentElement;
    const main = document.querySelector('main');
    const hud = document.querySelector('[data-testid="character-hud"]');
    const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
    const header = main === null || main === void 0 ? void 0 : main.previousElementSibling;
    if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
    const rect = node => {
      const b = node.getBoundingClientRect();
      return {
        left: b.left,
        top: b.top,
        right: b.right,
        bottom: b.bottom,
        width: b.width,
        height: b.height
      };
    };
    const h = rect(header),
      m = rect(main),
      u = rect(hud),
      c = chip ? rect(chip) : null;
    const contains = (a, b) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
    const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
      const b = rect(node);
      const visible = {
        left: Math.max(b.left, m.left),
        right: Math.min(b.right, m.right),
        top: Math.max(b.top, m.top),
        bottom: Math.min(b.bottom, m.bottom)
      };
      const shown = visible.right > visible.left && visible.bottom > visible.top;
      const overlaps = a => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
      return {
        text: node.textContent,
        rect: b,
        visible,
        shown,
        hudCollision: overlaps(u),
        chipCollision: c !== null && overlaps(c)
      };
    });
    return {
      header: h,
      main: m,
      hud: u,
      chip: c,
      hudContained: contains(h, u),
      chipContained: c === null || contains(h, c),
      mainBelowHud: m.top >= u.bottom,
      mainBelowChip: c === null || m.top >= c.bottom,
      chipBelowButton: c === null || c.top >= u.bottom,
      chipOutsideButton: chip === null || !hud.contains(chip),
      documentOverflow: document.documentElement.scrollWidth - innerWidth,
      mainOverflow: main.scrollWidth - main.clientWidth,
      windowY: scrollY,
      shellY: (_main$parentElement = main.parentElement) === null || _main$parentElement === void 0 || (_main$parentElement = _main$parentElement.parentElement) === null || _main$parentElement === void 0 ? void 0 : _main$parentElement.scrollTop,
      mainY: main.scrollTop,
      mainScrollHeight: main.scrollHeight,
      mainClientHeight: main.clientHeight,
      targets
    };
  });
  expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  expect.soft(measured.chipBelowButton).toBe(true);
  expect.soft(measured.chipOutsideButton).toBe(true);
  expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.windowY).toBe(0);
  expect.soft(measured.shellY).toBe(0);
  expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  expect.soft(measured.main.height).toBeGreaterThan(0);
  expect.soft(measured.chip !== null).toBe(bonus);
  for (const target of measured.targets) {
    expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
    expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  }
  return measured;
}
for (const locale of ['en', 'zh-CN']) for (const bonus of [false, true]) {
  test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({
    page,
    context
  }, info) => {
    const english = locale === 'en';
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`);
    });
    await page.goto('/settings');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.goto('/');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('home-new-game').click();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('class-sorceress').click();
    const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
    await page.getByTestId('character-name-input').fill(name);
    await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    await navTo(page, 'settings');
    const language = page.getByRole('button', {
      name: english ? 'English' : '简体中文',
      exact: true
    });
    await language.click();
    await expect(language).toHaveAttribute('aria-pressed', 'true');
    const fresh = await backup(page);
    expect(fresh.player.name).toBe(name);
    const incoming = {
      ...fresh,
      player: {
        ...fresh.player,
        level: 30,
        skillPoints: 2,
        skillLevels: {
          'sorceress.fire_bolt': 1
        },
        comboOrder: ['skills-sorceress-fire-bolt']
      },
      meta: {
        ...fresh.meta,
        idleState: {
          ...fresh.meta.idleState,
          lastOnline: Date.now(),
          activeMultiplier: bonus ? 1.5 : 1,
          multiplierSecondsRemaining: bonus ? 7200 : 0
        }
      }
    };
    await importSave(page, incoming, english);
    await attach(info, '01-imported-eligibility', incoming);
    for (const route of ['town', 'settings', 'skills']) {
      await navTo(page, route);
      await expect(page.getByTestId('character-hud')).toHaveCount(1);
      await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
      await attach(info, `route-${route}`, await layout(page, bonus));
    }
    const panel = page.getByTestId('skill-detail-panel');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    // Keep the ordinary pointer outside preview nodes while layout changes beneath it.
    await page.mouse.move(1, 1);
    const heading = panel.getByRole('heading', {
      name: english ? 'Lightning Mastery' : '闪电精通',
      exact: true
    });
    const allocate = panel.getByRole('button');
    const description = panel.locator('#skill-detail-panel > p');
    const metrics = [];
    for (const [width, height] of sizes) {
      await page.setViewportSize({
        width,
        height
      });
      await description.scrollIntoViewIfNeeded();
      const originalPosition = await layout(page, bonus);
      if (width === 360 && height === 640) {
        expect.soft(await page.locator('main').evaluate(node => node.scrollTop), 'baseline detail scrolls inside main').toBeGreaterThan(0);
      }
      await info.attach(`layout-${String(width)}x${String(height)}`, {
        body: await page.screenshot(),
        contentType: 'image/png'
      });
      const headingHits = await clearTarget(heading, `${String(width)}x${String(height)} heading`);
      const actionHits = await clearTarget(allocate, `${String(width)}x${String(height)} Allocate`);
      if (!english && width === 360) {
        const cdp = await context.newCDPSession(page);
        try {
          await cdp.send('DOM.enable');
          await cdp.send('CSS.enable');
          const document = await cdp.send('DOM.getDocument');
          const node = await cdp.send('DOM.querySelector', {
            nodeId: document.root.nodeId,
            selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p'
          });
          const fonts = await cdp.send('CSS.getPlatformFontsForNode', {
            nodeId: node.nodeId
          });
          expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
          await attach(info, 'actual-Chinese-platform-fonts', fonts);
        } finally {
          await cdp.detach();
        }
      }
      metrics.push({
        width,
        height,
        originalPosition,
        headingHits,
        actionHits
      });
    }
    await attach(info, '02-layout-metrics', metrics);
    await page.setViewportSize({
      width: 375,
      height: 667
    });
    await description.scrollIntoViewIfNeeded();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await allocate.click(); // Ordinary pointer; Playwright must resolve the actual target.
    await expect(panel).toContainText(english ? 'Lv. 1/20' : '等级 1/20');
    const rank1 = await backup(page);
    expect(rank1.player).toEqual({
      ...incoming.player,
      skillPoints: 1,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 1
      }
    });
    await navTo(page, 'skills');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    await page.mouse.move(1, 1);
    await page.setViewportSize({
      width: 915,
      height: 412
    });
    let reached = false;
    for (let step = 0; step < 100; step++) {
      await page.keyboard.press('Tab');
      if (await allocate.evaluate(node => node === document.activeElement)) {
        reached = true;
        break;
      }
    }
    expect(reached).toBe(true);
    await expect(heading).toBeVisible();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await expect(allocate).toBeEnabled();
    await expect(allocate).toBeFocused();
    await clearTarget(allocate, 'keyboard target');
    await page.keyboard.press('Enter');
    await expect(panel).toContainText(english ? 'Lv. 2/20' : '等级 2/20');
    const rank2 = await backup(page);
    expect(rank2.player).toEqual({
      ...rank1.player,
      skillPoints: 0,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 2
      }
    });
    for (const slice of ['inventory', 'mercs', 'map', 'formation']) expect(rank2[slice]).toEqual(incoming[slice]);
    await attach(info, '03-pointer-keyboard-allocation', {
      rank1,
      rank2
    });

    // Let the actual export status dismiss before opening the unrelated dialog.
    await expect(page.getByRole('status')).toHaveCount(0);
    // Real dialog remains above the shared header, including with an active chip.
    const label = english ? 'Import Save' : '导入存档';
    await page.getByRole('button', {
      name: label,
      exact: true
    }).click();
    const modalPriority = await page.evaluate(() => {
      const dialog = document.querySelector('[role="dialog"]');
      return [...document.querySelectorAll('[data-testid="character-hud"], [data-testid="offline-bonus-chip"]')].flatMap(node => {
        const b = node.getBoundingClientRect();
        return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
          const px = b.left + b.width * x,
            py = b.top + b.height * y;
          const hit = document.elementFromPoint(px, py);
          return {
            target: node.getAttribute('data-testid'),
            x: px,
            y: py,
            modalOwnsHit: hit !== null && dialog !== null && dialog.contains(hit)
          };
        }));
      });
    });
    await attach(info, 'modal-priority-at-header', modalPriority);
    expect(modalPriority).toHaveLength(bonus ? 18 : 9);
    for (const point of modalPriority) expect.soft(point).toMatchObject({
      modalOwnsHit: true
    });
    const cancel = page.getByRole('dialog').getByRole('button', {
      name: english ? 'Cancel' : '取消',
      exact: true
    });
    await attach(info, 'modal-cancel-hits', await clearTarget(cancel, 'modal cancel'));
    await cancel.click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await page.getByTestId('character-hud').click();
    await expect(page.getByTestId('character-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await navTo(page, 'combat');
    await expect(page.getByTestId('combat-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    const combatHeader = page.getByTestId('combat-screen').locator('header');
    const width = await combatHeader.evaluate(node => {
      var _node$firstElementChi;
      return {
        outer: node.clientWidth,
        inner: (_node$firstElementChi = node.firstElementChild) === null || _node$firstElementChi === void 0 ? void 0 : _node$firstElementChi.getBoundingClientRect().width
      };
    });
    expect(width.inner).toBeGreaterThanOrEqual(width.outer - 32);
    await navTo(page, 'skills');
    await expect(page.getByTestId('character-hud')).toHaveCount(1);
    expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
    await attach(info, '04-console-errors', errors);
    expect(errors).toEqual([]);
    await page.close();
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwicmVhZEZpbGUiLCJuYXZUbyIsIk1BU1RFUlkiLCJzaXplcyIsImF0dGFjaCIsImluZm8iLCJuYW1lIiwidmFsdWUiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnRUeXBlIiwiYmFja3VwIiwicGFnZSIsInBlbmRpbmciLCJ3YWl0Rm9yRXZlbnQiLCJnZXRCeVRlc3RJZCIsImNsaWNrIiwiZG93bmxvYWQiLCJwYXJzZSIsInBhdGgiLCJkZWxldGUiLCJpbXBvcnRTYXZlIiwic2F2ZSIsImVuZ2xpc2giLCJsYWJlbCIsImdldEJ5Um9sZSIsImV4YWN0IiwiZGlhbG9nIiwiZmlsbCIsInRvSGF2ZUNvdW50IiwiaGl0UG9pbnRzIiwidGFyZ2V0IiwiZXZhbHVhdGUiLCJub2RlIiwiYiIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImZsYXRNYXAiLCJ4IiwibWFwIiwieSIsIl9oaXQkdGFnTmFtZSIsIl9oaXQkdGV4dENvbnRlbnQkc2xpYyIsIl9oaXQkdGV4dENvbnRlbnQiLCJfaGl0JGNsb3Nlc3QkZ2V0QXR0cmkiLCJfaGl0JGNsb3Nlc3QiLCJweCIsImxlZnQiLCJ3aWR0aCIsInB5IiwidG9wIiwiaGVpZ2h0IiwiaGl0IiwiZG9jdW1lbnQiLCJlbGVtZW50RnJvbVBvaW50IiwiY2xlYXIiLCJjb250YWlucyIsInRhZ05hbWUiLCJoaXRUZXh0IiwidGV4dENvbnRlbnQiLCJzbGljZSIsImhpdFRlc3RJZCIsImNsb3Nlc3QiLCJnZXRBdHRyaWJ1dGUiLCJjbGVhclRhcmdldCIsInNjcm9sbEludG9WaWV3SWZOZWVkZWQiLCJwb2ludHMiLCJwb2ludCIsInNvZnQiLCJ0b01hdGNoT2JqZWN0IiwibGF5b3V0IiwiYm9udXMiLCJtZWFzdXJlZCIsIl9tYWluJHBhcmVudEVsZW1lbnQiLCJtYWluIiwicXVlcnlTZWxlY3RvciIsImh1ZCIsImNoaXAiLCJoZWFkZXIiLCJwcmV2aW91c0VsZW1lbnRTaWJsaW5nIiwiRXJyb3IiLCJyZWN0IiwicmlnaHQiLCJib3R0b20iLCJoIiwibSIsInUiLCJjIiwiYSIsInRhcmdldHMiLCJxdWVyeVNlbGVjdG9yQWxsIiwidmlzaWJsZSIsIk1hdGgiLCJtYXgiLCJtaW4iLCJzaG93biIsIm92ZXJsYXBzIiwidGV4dCIsImh1ZENvbGxpc2lvbiIsImNoaXBDb2xsaXNpb24iLCJodWRDb250YWluZWQiLCJjaGlwQ29udGFpbmVkIiwibWFpbkJlbG93SHVkIiwibWFpbkJlbG93Q2hpcCIsImNoaXBCZWxvd0J1dHRvbiIsImNoaXBPdXRzaWRlQnV0dG9uIiwiZG9jdW1lbnRPdmVyZmxvdyIsImRvY3VtZW50RWxlbWVudCIsInNjcm9sbFdpZHRoIiwiaW5uZXJXaWR0aCIsIm1haW5PdmVyZmxvdyIsImNsaWVudFdpZHRoIiwid2luZG93WSIsInNjcm9sbFkiLCJzaGVsbFkiLCJwYXJlbnRFbGVtZW50Iiwic2Nyb2xsVG9wIiwibWFpblkiLCJtYWluU2Nyb2xsSGVpZ2h0Iiwic2Nyb2xsSGVpZ2h0IiwibWFpbkNsaWVudEhlaWdodCIsImNsaWVudEhlaWdodCIsInRvQmUiLCJ0b0JlTGVzc1RoYW5PckVxdWFsIiwidG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCIsInRvQmVHcmVhdGVyVGhhbiIsImxvY2FsZSIsIlN0cmluZyIsImNvbnRleHQiLCJlcnJvcnMiLCJvbiIsImVycm9yIiwicHVzaCIsIm1lc3NhZ2UiLCJ0eXBlIiwiZ290byIsInJlcGVhdCIsInRvQmVWaXNpYmxlIiwibGFuZ3VhZ2UiLCJ0b0hhdmVBdHRyaWJ1dGUiLCJmcmVzaCIsInBsYXllciIsImluY29taW5nIiwibGV2ZWwiLCJza2lsbFBvaW50cyIsInNraWxsTGV2ZWxzIiwiY29tYm9PcmRlciIsIm1ldGEiLCJpZGxlU3RhdGUiLCJsYXN0T25saW5lIiwiRGF0ZSIsIm5vdyIsImFjdGl2ZU11bHRpcGxpZXIiLCJtdWx0aXBsaWVyU2Vjb25kc1JlbWFpbmluZyIsInJvdXRlIiwidG9IYXZlQWNjZXNzaWJsZU5hbWUiLCJSZWdFeHAiLCJwYW5lbCIsIm1vdXNlIiwibW92ZSIsImhlYWRpbmciLCJhbGxvY2F0ZSIsImRlc2NyaXB0aW9uIiwibG9jYXRvciIsIm1ldHJpY3MiLCJzZXRWaWV3cG9ydFNpemUiLCJvcmlnaW5hbFBvc2l0aW9uIiwic2NyZWVuc2hvdCIsImhlYWRpbmdIaXRzIiwiYWN0aW9uSGl0cyIsImNkcCIsIm5ld0NEUFNlc3Npb24iLCJzZW5kIiwibm9kZUlkIiwicm9vdCIsInNlbGVjdG9yIiwiZm9udHMiLCJzb21lIiwiZm9udCIsImZhbWlseU5hbWUiLCJnbHlwaENvdW50IiwiZGV0YWNoIiwidG9IYXZlVGV4dCIsInRvQ29udGFpblRleHQiLCJyYW5rMSIsInRvRXF1YWwiLCJyZWFjaGVkIiwic3RlcCIsImtleWJvYXJkIiwicHJlc3MiLCJhY3RpdmVFbGVtZW50IiwidG9CZUVuYWJsZWQiLCJ0b0JlRm9jdXNlZCIsInJhbmsyIiwibW9kYWxQcmlvcml0eSIsIm1vZGFsT3duc0hpdCIsInRvSGF2ZUxlbmd0aCIsImNhbmNlbCIsImNvbWJhdEhlYWRlciIsIl9ub2RlJGZpcnN0RWxlbWVudENoaSIsIm91dGVyIiwiaW5uZXIiLCJmaXJzdEVsZW1lbnRDaGlsZCIsIndpbmRvdyIsImNsb3NlIl0sInNvdXJjZXMiOlsic2tpbGxzLWhlYWRlci1sYXlvdXQuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogUHJvZHVjdGlvbiBsYXlvdXQgcmVncmVzc2lvbjsgZXhwbGljaXRseSBpbXBvcnRlZCBMMzAvYm9udXMgZWxpZ2liaWxpdHksIG5vIGdhbWUgYnJpZGdlLiAqL1xuaW1wb3J0IHsgZXhwZWN0LCB0ZXN0LCB0eXBlIExvY2F0b3IsIHR5cGUgUGFnZSwgdHlwZSBUZXN0SW5mbyB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHsgcmVhZEZpbGUgfSBmcm9tICdub2RlOmZzL3Byb21pc2VzJztcbmltcG9ydCB0eXBlIHsgU2F2ZUN1cnJlbnQgfSBmcm9tICcuLi8uLi9zcmMvZW5naW5lL3R5cGVzL3NhdmUnO1xuaW1wb3J0IHsgbmF2VG8gfSBmcm9tICcuLi9lMmUvX2hlbHBlcnMnO1xuXG5jb25zdCBNQVNURVJZID0gJ3NraWxscy1zb3JjZXJlc3MtbGlnaHRuaW5nLW1hc3RlcnknO1xuY29uc3Qgc2l6ZXMgPSBbWzM2MCw2NDBdLFs0MTIsOTE1XSxbNjQwLDM2MF0sWzM3NSw2NjddLFszOTMsODUxXSxbNzY4LDEwMjRdLFsxMjgwLDgwMF0sWzE5MjAsMTA4MF0sWzkxNSw0MTJdXSBhcyBjb25zdDtcblxuYXN5bmMgZnVuY3Rpb24gYXR0YWNoKGluZm86IFRlc3RJbmZvLCBuYW1lOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGluZm8uYXR0YWNoKG5hbWUsIHsgYm9keTogSlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpLCBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBiYWNrdXAocGFnZTogUGFnZSk6IFByb21pc2U8U2F2ZUN1cnJlbnQ+IHtcbiAgYXdhaXQgbmF2VG8ocGFnZSwgJ3NldHRpbmdzJyk7XG4gIGNvbnN0IHBlbmRpbmcgPSBwYWdlLndhaXRGb3JFdmVudCgnZG93bmxvYWQnKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnZXhwb3J0LXNhdmUtYnV0dG9uJykuY2xpY2soKTtcbiAgY29uc3QgZG93bmxvYWQgPSBhd2FpdCBwZW5kaW5nO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZShhd2FpdCByZWFkRmlsZShhd2FpdCBkb3dubG9hZC5wYXRoKCksICd1dGY4JykpIGFzIFNhdmVDdXJyZW50OyB9XG4gIGZpbmFsbHkgeyBhd2FpdCBkb3dubG9hZC5kZWxldGUoKTsgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBpbXBvcnRTYXZlKHBhZ2U6IFBhZ2UsIHNhdmU6IFNhdmVDdXJyZW50LCBlbmdsaXNoOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGxhYmVsID0gZW5nbGlzaCA/ICdJbXBvcnQgU2F2ZScgOiAn5a+85YWl5a2Y5qGjJztcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogbGFiZWwsIGV4YWN0OiB0cnVlIH0pLmNsaWNrKCk7XG4gIGNvbnN0IGRpYWxvZyA9IHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKTtcbiAgYXdhaXQgZGlhbG9nLmdldEJ5Um9sZSgndGV4dGJveCcpLmZpbGwoSlNPTi5zdHJpbmdpZnkoc2F2ZSkpO1xuICBhd2FpdCBkaWFsb2cuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IGxhYmVsLCBleGFjdDogdHJ1ZSB9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QoZGlhbG9nKS50b0hhdmVDb3VudCgwKTtcbn1cblxuLyoqIFJlYWQtb25seSBlZGdlL2NlbnRlciBoaXQgdGVzdHMgY2F0Y2ggcGFydGlhbCBvYnN0cnVjdGlvbiB0aGF0IHRvQmVWaXNpYmxlIG1pc3Nlcy4gKi9cbmFzeW5jIGZ1bmN0aW9uIGhpdFBvaW50cyh0YXJnZXQ6IExvY2F0b3IpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICByZXR1cm4gdGFyZ2V0LmV2YWx1YXRlKG5vZGUgPT4ge1xuICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHJldHVybiBbMC4wNSwgMC41LCAwLjk1XS5mbGF0TWFwKHggPT4gWzAuMDUsIDAuNSwgMC45NV0ubWFwKHkgPT4ge1xuICAgICAgY29uc3QgcHggPSBiLmxlZnQgKyBiLndpZHRoICogeCwgcHkgPSBiLnRvcCArIGIuaGVpZ2h0ICogeTtcbiAgICAgIGNvbnN0IGhpdCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQocHgsIHB5KTtcbiAgICAgIHJldHVybiB7IHg6IHB4LCB5OiBweSwgY2xlYXI6IGhpdCAhPT0gbnVsbCAmJiBub2RlLmNvbnRhaW5zKGhpdCksIGhpdDogaGl0Py50YWdOYW1lID8/IG51bGwsXG4gICAgICAgIGhpdFRleHQ6aGl0Py50ZXh0Q29udGVudD8uc2xpY2UoMCwxMjApID8/IG51bGwsIGhpdFRlc3RJZDpoaXQ/LmNsb3Nlc3QoJ1tkYXRhLXRlc3RpZF0nKT8uZ2V0QXR0cmlidXRlKCdkYXRhLXRlc3RpZCcpID8/IG51bGwgfTtcbiAgICB9KSk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjbGVhclRhcmdldCh0YXJnZXQ6IExvY2F0b3IsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICBhd2FpdCB0YXJnZXQuc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICBjb25zdCBwb2ludHMgPSBhd2FpdCBoaXRQb2ludHModGFyZ2V0KTtcbiAgZm9yIChjb25zdCBwb2ludCBvZiBwb2ludHMpIGV4cGVjdC5zb2Z0KHBvaW50LCBsYWJlbCkudG9NYXRjaE9iamVjdCh7IGNsZWFyOiB0cnVlIH0pO1xuICByZXR1cm4gcG9pbnRzO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsYXlvdXQocGFnZTogUGFnZSwgYm9udXM6IGJvb2xlYW4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgY29uc3QgbWVhc3VyZWQgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICBjb25zdCBtYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWFpbicpO1xuICAgIGNvbnN0IGh1ZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXRlc3RpZD1cImNoYXJhY3Rlci1odWRcIl0nKTtcbiAgICBjb25zdCBjaGlwID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtdGVzdGlkPVwib2ZmbGluZS1ib251cy1jaGlwXCJdJyk7XG4gICAgY29uc3QgaGVhZGVyID0gbWFpbj8ucHJldmlvdXNFbGVtZW50U2libGluZztcbiAgICBpZiAoIW1haW4gfHwgIWh1ZCB8fCAhaGVhZGVyKSB0aHJvdyBuZXcgRXJyb3IoJ0V4cGVjdGVkIG1haW4sIEhVRCBhbmQgc2NyZWVuIGhlYWRlcicpO1xuICAgIGNvbnN0IHJlY3QgPSAobm9kZTogRWxlbWVudCkgPT4ge1xuICAgICAgY29uc3QgYiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICByZXR1cm4geyBsZWZ0OiBiLmxlZnQsIHRvcDogYi50b3AsIHJpZ2h0OiBiLnJpZ2h0LCBib3R0b206IGIuYm90dG9tLCB3aWR0aDogYi53aWR0aCwgaGVpZ2h0OiBiLmhlaWdodCB9O1xuICAgIH07XG4gICAgY29uc3QgaCA9IHJlY3QoaGVhZGVyKSwgbSA9IHJlY3QobWFpbiksIHUgPSByZWN0KGh1ZCksIGMgPSBjaGlwID8gcmVjdChjaGlwKSA6IG51bGw7XG4gICAgY29uc3QgY29udGFpbnMgPSAoYTogdHlwZW9mIGgsIGI6IHR5cGVvZiBoKSA9PiBiLmxlZnQgPj0gYS5sZWZ0ICYmIGIucmlnaHQgPD0gYS5yaWdodCAmJiBiLnRvcCA+PSBhLnRvcCAmJiBiLmJvdHRvbSA8PSBhLmJvdHRvbTtcbiAgICBjb25zdCB0YXJnZXRzID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLXRlc3RpZD1cInNraWxsLWRldGFpbC1wYW5lbFwiXSBoMiwgW2RhdGEtdGVzdGlkPVwic2tpbGwtZGV0YWlsLXBhbmVsXCJdIGJ1dHRvbicpXS5tYXAobm9kZSA9PiB7XG4gICAgICBjb25zdCBiID0gcmVjdChub2RlKTtcbiAgICAgIGNvbnN0IHZpc2libGUgPSB7IGxlZnQ6IE1hdGgubWF4KGIubGVmdCxtLmxlZnQpLCByaWdodDogTWF0aC5taW4oYi5yaWdodCxtLnJpZ2h0KSwgdG9wOiBNYXRoLm1heChiLnRvcCxtLnRvcCksIGJvdHRvbTogTWF0aC5taW4oYi5ib3R0b20sbS5ib3R0b20pIH07XG4gICAgICBjb25zdCBzaG93biA9IHZpc2libGUucmlnaHQgPiB2aXNpYmxlLmxlZnQgJiYgdmlzaWJsZS5ib3R0b20gPiB2aXNpYmxlLnRvcDtcbiAgICAgIGNvbnN0IG92ZXJsYXBzID0gKGE6IHR5cGVvZiBoKSA9PiBzaG93biAmJiB2aXNpYmxlLmxlZnQgPCBhLnJpZ2h0ICYmIHZpc2libGUucmlnaHQgPiBhLmxlZnQgJiYgdmlzaWJsZS50b3AgPCBhLmJvdHRvbSAmJiB2aXNpYmxlLmJvdHRvbSA+IGEudG9wO1xuICAgICAgcmV0dXJuIHsgdGV4dDogbm9kZS50ZXh0Q29udGVudCwgcmVjdDpiLCB2aXNpYmxlLCBzaG93biwgaHVkQ29sbGlzaW9uOiBvdmVybGFwcyh1KSwgY2hpcENvbGxpc2lvbjogYyAhPT0gbnVsbCAmJiBvdmVybGFwcyhjKSB9O1xuICAgIH0pO1xuICAgIHJldHVybiB7IGhlYWRlcjogaCwgbWFpbjogbSwgaHVkOiB1LCBjaGlwOiBjLCBodWRDb250YWluZWQ6IGNvbnRhaW5zKGgsdSksIGNoaXBDb250YWluZWQ6IGMgPT09IG51bGwgfHwgY29udGFpbnMoaCxjKSxcbiAgICAgIG1haW5CZWxvd0h1ZDogbS50b3AgPj0gdS5ib3R0b20sIG1haW5CZWxvd0NoaXA6IGMgPT09IG51bGwgfHwgbS50b3AgPj0gYy5ib3R0b20sXG4gICAgICBjaGlwQmVsb3dCdXR0b246IGMgPT09IG51bGwgfHwgYy50b3AgPj0gdS5ib3R0b20sIGNoaXBPdXRzaWRlQnV0dG9uOiBjaGlwID09PSBudWxsIHx8ICFodWQuY29udGFpbnMoY2hpcCksXG4gICAgICBkb2N1bWVudE92ZXJmbG93OiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGggLSBpbm5lcldpZHRoLFxuICAgICAgbWFpbk92ZXJmbG93OiBtYWluLnNjcm9sbFdpZHRoIC0gbWFpbi5jbGllbnRXaWR0aCwgd2luZG93WTogc2Nyb2xsWSxcbiAgICAgIHNoZWxsWTogbWFpbi5wYXJlbnRFbGVtZW50Py5wYXJlbnRFbGVtZW50Py5zY3JvbGxUb3AsIG1haW5ZOiBtYWluLnNjcm9sbFRvcCxcbiAgICAgIG1haW5TY3JvbGxIZWlnaHQ6IG1haW4uc2Nyb2xsSGVpZ2h0LCBtYWluQ2xpZW50SGVpZ2h0OiBtYWluLmNsaWVudEhlaWdodCwgdGFyZ2V0cyB9O1xuICB9KTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuaHVkQ29udGFpbmVkLCAnaGVhZGVyIHJlc2VydmVzIGFjdHVhbCBIVUQgaGVpZ2h0JykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcENvbnRhaW5lZCwgJ2hlYWRlciByZXNlcnZlcyBhY3RpdmUgYm9udXMgY2hpcCBoZWlnaHQnKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluQmVsb3dIdWQsICdtYWluIGNhbm5vdCBzY3JvbGwgdW5kZXIgSFVEJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbkJlbG93Q2hpcCwgJ21haW4gY2Fubm90IHNjcm9sbCB1bmRlciBjaGlwJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcEJlbG93QnV0dG9uKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwT3V0c2lkZUJ1dHRvbikudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuZG9jdW1lbnRPdmVyZmxvdykudG9CZUxlc3NUaGFuT3JFcXVhbCgwKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbk92ZXJmbG93KS50b0JlTGVzc1RoYW5PckVxdWFsKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC53aW5kb3dZKS50b0JlKDApOyBleHBlY3Quc29mdChtZWFzdXJlZC5zaGVsbFkpLnRvQmUoMCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC53aWR0aCkudG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCg0NCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC5oZWlnaHQpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoNDQpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluLmhlaWdodCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwICE9PSBudWxsKS50b0JlKGJvbnVzKTtcbiAgZm9yIChjb25zdCB0YXJnZXQgb2YgbWVhc3VyZWQudGFyZ2V0cykge1xuICAgIGV4cGVjdC5zb2Z0KHRhcmdldC5odWRDb2xsaXNpb24sICd2aXNpYmxlIGRldGFpbCByZW1haW5zIGNsZWFyIG9mIEhVRCBhdCBvcmlnaW5hbCBzY3JvbGwgcG9zaXRpb24nKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Quc29mdCh0YXJnZXQuY2hpcENvbGxpc2lvbiwgJ3Zpc2libGUgZGV0YWlsIHJlbWFpbnMgY2xlYXIgb2YgYWN0aXZlIGNoaXAgYXQgb3JpZ2luYWwgc2Nyb2xsIHBvc2l0aW9uJykudG9CZShmYWxzZSk7XG4gIH1cbiAgcmV0dXJuIG1lYXN1cmVkO1xufVxuXG5mb3IgKGNvbnN0IGxvY2FsZSBvZiBbJ2VuJywnemgtQ04nXSBhcyBjb25zdCkgZm9yIChjb25zdCBib251cyBvZiBbZmFsc2UsdHJ1ZV0pIHtcbiAgdGVzdChgc2hhcmVkIGhlYWRlciBzdGF5cyBjbGVhciAke2xvY2FsZX0gYm9udXM9JHtTdHJpbmcoYm9udXMpfWAsIGFzeW5jICh7IHBhZ2UsIGNvbnRleHQgfSwgaW5mbykgPT4ge1xuICAgIGNvbnN0IGVuZ2xpc2ggPSBsb2NhbGUgPT09ICdlbic7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICAgIHBhZ2Uub24oJ3BhZ2VlcnJvcicsIGVycm9yID0+IGVycm9ycy5wdXNoKGVycm9yLm1lc3NhZ2UpKTtcbiAgICBwYWdlLm9uKCdjb25zb2xlJywgbWVzc2FnZSA9PiB7IGlmIChtZXNzYWdlLnR5cGUoKSA9PT0gJ2Vycm9yJyB8fCBtZXNzYWdlLnR5cGUoKSA9PT0gJ3dhcm5pbmcnKSBlcnJvcnMucHVzaChgJHttZXNzYWdlLnR5cGUoKX06ICR7bWVzc2FnZS50ZXh0KCl9YCk7IH0pO1xuICAgIGF3YWl0IHBhZ2UuZ290bygnL3NldHRpbmdzJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nb3RvKCcvJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnaG9tZS1uZXctZ2FtZScpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2xhc3Mtc29yY2VyZXNzJykuY2xpY2soKTtcbiAgICBjb25zdCBuYW1lID0gZW5nbGlzaCA/ICdNTU1NTU1NTU1NTU1NTU1NJyA6ICfpl6onLnJlcGVhdCgxNik7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLW5hbWUtaW5wdXQnKS5maWxsKG5hbWUpO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1zdGFydC1idG4nKS5jbGljaygpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCd0b3duLXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NldHRpbmdzJyk7XG4gICAgY29uc3QgbGFuZ3VhZ2UgPSBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiBlbmdsaXNoID8gJ0VuZ2xpc2gnIDogJ+eugOS9k+S4reaWhycsIGV4YWN0OiB0cnVlIH0pO1xuICAgIGF3YWl0IGxhbmd1YWdlLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KGxhbmd1YWdlKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtcHJlc3NlZCcsJ3RydWUnKTtcbiAgICBjb25zdCBmcmVzaCA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QoZnJlc2gucGxheWVyLm5hbWUpLnRvQmUobmFtZSk7XG4gICAgY29uc3QgaW5jb21pbmc6IFNhdmVDdXJyZW50ID0geyAuLi5mcmVzaCwgcGxheWVyOiB7IC4uLmZyZXNoLnBsYXllciwgbGV2ZWw6IDMwLCBza2lsbFBvaW50czogMixcbiAgICAgIHNraWxsTGV2ZWxzOiB7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzogMSB9LCBjb21ib09yZGVyOiBbJ3NraWxscy1zb3JjZXJlc3MtZmlyZS1ib2x0J10gfSxcbiAgICAgIG1ldGE6IHsgLi4uZnJlc2gubWV0YSwgaWRsZVN0YXRlOiB7IC4uLmZyZXNoLm1ldGEuaWRsZVN0YXRlLCBsYXN0T25saW5lOiBEYXRlLm5vdygpLFxuICAgICAgICBhY3RpdmVNdWx0aXBsaWVyOiBib251cyA/IDEuNSA6IDEsIG11bHRpcGxpZXJTZWNvbmRzUmVtYWluaW5nOiBib251cyA/IDcyMDAgOiAwIH0gfSB9O1xuICAgIGF3YWl0IGltcG9ydFNhdmUocGFnZSwgaW5jb21pbmcsIGVuZ2xpc2gpO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCAnMDEtaW1wb3J0ZWQtZWxpZ2liaWxpdHknLCBpbmNvbWluZyk7XG5cbiAgICBmb3IgKGNvbnN0IHJvdXRlIG9mIFsndG93bicsJ3NldHRpbmdzJywnc2tpbGxzJ10pIHtcbiAgICAgIGF3YWl0IG5hdlRvKHBhZ2UsIHJvdXRlKTtcbiAgICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDEpO1xuICAgICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQWNjZXNzaWJsZU5hbWUobmV3IFJlZ0V4cChuYW1lKSk7XG4gICAgICBhd2FpdCBhdHRhY2goaW5mbywgYHJvdXRlLSR7cm91dGV9YCwgYXdhaXQgbGF5b3V0KHBhZ2UsYm9udXMpKTtcbiAgICB9XG4gICAgY29uc3QgcGFuZWwgPSBwYWdlLmdldEJ5VGVzdElkKCdza2lsbC1kZXRhaWwtcGFuZWwnKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKGBza2lsbC1ub2RlLSR7TUFTVEVSWX1gKS5jbGljaygpO1xuICAgIC8vIEtlZXAgdGhlIG9yZGluYXJ5IHBvaW50ZXIgb3V0c2lkZSBwcmV2aWV3IG5vZGVzIHdoaWxlIGxheW91dCBjaGFuZ2VzIGJlbmVhdGggaXQuXG4gICAgYXdhaXQgcGFnZS5tb3VzZS5tb3ZlKDEsMSk7XG4gICAgY29uc3QgaGVhZGluZyA9IHBhbmVsLmdldEJ5Um9sZSgnaGVhZGluZycsIHsgbmFtZTogZW5nbGlzaCA/ICdMaWdodG5pbmcgTWFzdGVyeScgOiAn6Zeq55S157K+6YCaJywgZXhhY3Q6IHRydWUgfSk7XG4gICAgY29uc3QgYWxsb2NhdGUgPSBwYW5lbC5nZXRCeVJvbGUoJ2J1dHRvbicpO1xuICAgIGNvbnN0IGRlc2NyaXB0aW9uID0gcGFuZWwubG9jYXRvcignI3NraWxsLWRldGFpbC1wYW5lbCA+IHAnKTtcbiAgICBjb25zdCBtZXRyaWNzID0gW107XG4gICAgZm9yIChjb25zdCBbd2lkdGgsaGVpZ2h0XSBvZiBzaXplcykge1xuICAgICAgYXdhaXQgcGFnZS5zZXRWaWV3cG9ydFNpemUoeyB3aWR0aCxoZWlnaHQgfSk7XG4gICAgICBhd2FpdCBkZXNjcmlwdGlvbi5zY3JvbGxJbnRvVmlld0lmTmVlZGVkKCk7XG4gICAgICBjb25zdCBvcmlnaW5hbFBvc2l0aW9uID0gYXdhaXQgbGF5b3V0KHBhZ2UsYm9udXMpO1xuICAgICAgaWYgKHdpZHRoID09PSAzNjAgJiYgaGVpZ2h0ID09PSA2NDApIHtcbiAgICAgICAgZXhwZWN0LnNvZnQoYXdhaXQgcGFnZS5sb2NhdG9yKCdtYWluJykuZXZhbHVhdGUobm9kZSA9PiBub2RlLnNjcm9sbFRvcCksICdiYXNlbGluZSBkZXRhaWwgc2Nyb2xscyBpbnNpZGUgbWFpbicpLnRvQmVHcmVhdGVyVGhhbigwKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGluZm8uYXR0YWNoKGBsYXlvdXQtJHtTdHJpbmcod2lkdGgpfXgke1N0cmluZyhoZWlnaHQpfWAsIHsgYm9keTogYXdhaXQgcGFnZS5zY3JlZW5zaG90KCksIGNvbnRlbnRUeXBlOiAnaW1hZ2UvcG5nJyB9KTtcbiAgICAgIGNvbnN0IGhlYWRpbmdIaXRzID0gYXdhaXQgY2xlYXJUYXJnZXQoaGVhZGluZyxgJHtTdHJpbmcod2lkdGgpfXgke1N0cmluZyhoZWlnaHQpfSBoZWFkaW5nYCk7XG4gICAgICBjb25zdCBhY3Rpb25IaXRzID0gYXdhaXQgY2xlYXJUYXJnZXQoYWxsb2NhdGUsYCR7U3RyaW5nKHdpZHRoKX14JHtTdHJpbmcoaGVpZ2h0KX0gQWxsb2NhdGVgKTtcbiAgICAgIGlmICghZW5nbGlzaCAmJiB3aWR0aCA9PT0gMzYwKSB7XG4gICAgICAgIGNvbnN0IGNkcCA9IGF3YWl0IGNvbnRleHQubmV3Q0RQU2Vzc2lvbihwYWdlKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBjZHAuc2VuZCgnRE9NLmVuYWJsZScpOyBhd2FpdCBjZHAuc2VuZCgnQ1NTLmVuYWJsZScpO1xuICAgICAgICAgIGNvbnN0IGRvY3VtZW50ID0gYXdhaXQgY2RwLnNlbmQoJ0RPTS5nZXREb2N1bWVudCcpO1xuICAgICAgICAgIGNvbnN0IG5vZGUgPSBhd2FpdCBjZHAuc2VuZCgnRE9NLnF1ZXJ5U2VsZWN0b3InLHsgbm9kZUlkOiBkb2N1bWVudC5yb290Lm5vZGVJZCwgc2VsZWN0b3I6ICdbZGF0YS10ZXN0aWQ9XCJza2lsbC1kZXRhaWwtcGFuZWxcIl0gI3NraWxsLWRldGFpbC1wYW5lbCA+IHAnIH0pO1xuICAgICAgICAgIGNvbnN0IGZvbnRzID0gYXdhaXQgY2RwLnNlbmQoJ0NTUy5nZXRQbGF0Zm9ybUZvbnRzRm9yTm9kZScseyBub2RlSWQ6IG5vZGUubm9kZUlkIH0pO1xuICAgICAgICAgIGV4cGVjdChmb250cy5mb250cy5zb21lKGZvbnQgPT4gZm9udC5mYW1pbHlOYW1lID09PSAnTm90byBTYW5zIENKSyBTQycgJiYgZm9udC5nbHlwaENvdW50ID4gMCkpLnRvQmUodHJ1ZSk7XG4gICAgICAgICAgYXdhaXQgYXR0YWNoKGluZm8sJ2FjdHVhbC1DaGluZXNlLXBsYXRmb3JtLWZvbnRzJyxmb250cyk7XG4gICAgICAgIH0gZmluYWxseSB7IGF3YWl0IGNkcC5kZXRhY2goKTsgfVxuICAgICAgfVxuICAgICAgbWV0cmljcy5wdXNoKHsgd2lkdGgsaGVpZ2h0LG9yaWdpbmFsUG9zaXRpb24saGVhZGluZ0hpdHMsYWN0aW9uSGl0cyB9KTtcbiAgICB9XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJzAyLWxheW91dC1tZXRyaWNzJyxtZXRyaWNzKTtcblxuICAgIGF3YWl0IHBhZ2Uuc2V0Vmlld3BvcnRTaXplKHsgd2lkdGg6Mzc1LGhlaWdodDo2NjcgfSk7XG4gICAgYXdhaXQgZGVzY3JpcHRpb24uc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICAgIGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9IYXZlVGV4dChlbmdsaXNoID8gJ0FsbG9jYXRlJyA6ICfliIbphY0nKTtcbiAgICBhd2FpdCBhbGxvY2F0ZS5jbGljaygpOyAvLyBPcmRpbmFyeSBwb2ludGVyOyBQbGF5d3JpZ2h0IG11c3QgcmVzb2x2ZSB0aGUgYWN0dWFsIHRhcmdldC5cbiAgICBhd2FpdCBleHBlY3QocGFuZWwpLnRvQ29udGFpblRleHQoZW5nbGlzaCA/ICdMdi4gMS8yMCcgOiAn562J57qnIDEvMjAnKTtcbiAgICBjb25zdCByYW5rMSA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QocmFuazEucGxheWVyKS50b0VxdWFsKHsgLi4uaW5jb21pbmcucGxheWVyLCBza2lsbFBvaW50czoxLFxuICAgICAgc2tpbGxMZXZlbHM6eyAnc29yY2VyZXNzLmZpcmVfYm9sdCc6MSwnc29yY2VyZXNzLmxpZ2h0bmluZ19tYXN0ZXJ5JzoxIH0gfSk7XG4gICAgYXdhaXQgbmF2VG8ocGFnZSwnc2tpbGxzJyk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZChgc2tpbGwtbm9kZS0ke01BU1RFUll9YCkuY2xpY2soKTtcbiAgICBhd2FpdCBwYWdlLm1vdXNlLm1vdmUoMSwxKTtcbiAgICBhd2FpdCBwYWdlLnNldFZpZXdwb3J0U2l6ZSh7IHdpZHRoOjkxNSxoZWlnaHQ6NDEyIH0pO1xuICAgIGxldCByZWFjaGVkID0gZmFsc2U7XG4gICAgZm9yIChsZXQgc3RlcD0wO3N0ZXA8MTAwO3N0ZXArKykge1xuICAgICAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnVGFiJyk7XG4gICAgICBpZiAoYXdhaXQgYWxsb2NhdGUuZXZhbHVhdGUobm9kZSA9PiBub2RlID09PSBkb2N1bWVudC5hY3RpdmVFbGVtZW50KSkgeyByZWFjaGVkPXRydWU7YnJlYWs7IH1cbiAgICB9XG4gICAgZXhwZWN0KHJlYWNoZWQpLnRvQmUodHJ1ZSk7XG4gICAgYXdhaXQgZXhwZWN0KGhlYWRpbmcpLnRvQmVWaXNpYmxlKCk7XG4gICAgYXdhaXQgZXhwZWN0KGFsbG9jYXRlKS50b0hhdmVUZXh0KGVuZ2xpc2ggPyAnQWxsb2NhdGUnIDogJ+WIhumFjScpO1xuICAgIGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9CZUVuYWJsZWQoKTsgYXdhaXQgZXhwZWN0KGFsbG9jYXRlKS50b0JlRm9jdXNlZCgpO1xuICAgIGF3YWl0IGNsZWFyVGFyZ2V0KGFsbG9jYXRlLCdrZXlib2FyZCB0YXJnZXQnKTtcbiAgICBhd2FpdCBwYWdlLmtleWJvYXJkLnByZXNzKCdFbnRlcicpO1xuICAgIGF3YWl0IGV4cGVjdChwYW5lbCkudG9Db250YWluVGV4dChlbmdsaXNoID8gJ0x2LiAyLzIwJyA6ICfnrYnnuqcgMi8yMCcpO1xuICAgIGNvbnN0IHJhbmsyID0gYXdhaXQgYmFja3VwKHBhZ2UpO1xuICAgIGV4cGVjdChyYW5rMi5wbGF5ZXIpLnRvRXF1YWwoeyAuLi5yYW5rMS5wbGF5ZXIsc2tpbGxQb2ludHM6MCxcbiAgICAgIHNraWxsTGV2ZWxzOnsgJ3NvcmNlcmVzcy5maXJlX2JvbHQnOjEsJ3NvcmNlcmVzcy5saWdodG5pbmdfbWFzdGVyeSc6MiB9IH0pO1xuICAgIGZvciAoY29uc3Qgc2xpY2Ugb2YgWydpbnZlbnRvcnknLCdtZXJjcycsJ21hcCcsJ2Zvcm1hdGlvbiddIGFzIGNvbnN0KSBleHBlY3QocmFuazJbc2xpY2VdKS50b0VxdWFsKGluY29taW5nW3NsaWNlXSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJzAzLXBvaW50ZXIta2V5Ym9hcmQtYWxsb2NhdGlvbicseyByYW5rMSxyYW5rMiB9KTtcblxuICAgIC8vIExldCB0aGUgYWN0dWFsIGV4cG9ydCBzdGF0dXMgZGlzbWlzcyBiZWZvcmUgb3BlbmluZyB0aGUgdW5yZWxhdGVkIGRpYWxvZy5cbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ3N0YXR1cycpKS50b0hhdmVDb3VudCgwKTtcbiAgICAvLyBSZWFsIGRpYWxvZyByZW1haW5zIGFib3ZlIHRoZSBzaGFyZWQgaGVhZGVyLCBpbmNsdWRpbmcgd2l0aCBhbiBhY3RpdmUgY2hpcC5cbiAgICBjb25zdCBsYWJlbCA9IGVuZ2xpc2ggPyAnSW1wb3J0IFNhdmUnIDogJ+WvvOWFpeWtmOahoyc7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicseyBuYW1lOmxhYmVsLGV4YWN0OnRydWUgfSkuY2xpY2soKTtcbiAgICBjb25zdCBtb2RhbFByaW9yaXR5ID0gYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB7XG4gICAgICBjb25zdCBkaWFsb2cgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbcm9sZT1cImRpYWxvZ1wiXScpO1xuICAgICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJjaGFyYWN0ZXItaHVkXCJdLCBbZGF0YS10ZXN0aWQ9XCJvZmZsaW5lLWJvbnVzLWNoaXBcIl0nKV0uZmxhdE1hcChub2RlID0+IHtcbiAgICAgICAgY29uc3QgYiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHJldHVybiBbMC4wNSwwLjUsMC45NV0uZmxhdE1hcCh4ID0+IFswLjA1LDAuNSwwLjk1XS5tYXAoeSA9PiB7XG4gICAgICAgICAgY29uc3QgcHg9Yi5sZWZ0K2Iud2lkdGgqeCwgcHk9Yi50b3ArYi5oZWlnaHQqeTtcbiAgICAgICAgICBjb25zdCBoaXQ9ZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludChweCxweSk7XG4gICAgICAgICAgcmV0dXJuIHsgdGFyZ2V0Om5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLXRlc3RpZCcpLHg6cHgseTpweSxtb2RhbE93bnNIaXQ6aGl0ICE9PSBudWxsICYmIGRpYWxvZyAhPT0gbnVsbCAmJiBkaWFsb2cuY29udGFpbnMoaGl0KSB9O1xuICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBhd2FpdCBhdHRhY2goaW5mbywnbW9kYWwtcHJpb3JpdHktYXQtaGVhZGVyJyxtb2RhbFByaW9yaXR5KTtcbiAgICBleHBlY3QobW9kYWxQcmlvcml0eSkudG9IYXZlTGVuZ3RoKGJvbnVzID8gMTggOiA5KTtcbiAgICBmb3IgKGNvbnN0IHBvaW50IG9mIG1vZGFsUHJpb3JpdHkpIGV4cGVjdC5zb2Z0KHBvaW50KS50b01hdGNoT2JqZWN0KHsgbW9kYWxPd25zSGl0OnRydWUgfSk7XG4gICAgY29uc3QgY2FuY2VsID0gcGFnZS5nZXRCeVJvbGUoJ2RpYWxvZycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7IG5hbWU6ZW5nbGlzaCA/ICdDYW5jZWwnIDogJ+WPlua2iCcsZXhhY3Q6dHJ1ZSB9KTtcbiAgICBhd2FpdCBhdHRhY2goaW5mbywnbW9kYWwtY2FuY2VsLWhpdHMnLGF3YWl0IGNsZWFyVGFyZ2V0KGNhbmNlbCwnbW9kYWwgY2FuY2VsJykpOyBhd2FpdCBjYW5jZWwuY2xpY2soKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2RpYWxvZycpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykuY2xpY2soKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDApO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ2NvbWJhdCcpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb21iYXQtc2NyZWVuJykpLnRvQmVWaXNpYmxlKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgY29uc3QgY29tYmF0SGVhZGVyID0gcGFnZS5nZXRCeVRlc3RJZCgnY29tYmF0LXNjcmVlbicpLmxvY2F0b3IoJ2hlYWRlcicpO1xuICAgIGNvbnN0IHdpZHRoID0gYXdhaXQgY29tYmF0SGVhZGVyLmV2YWx1YXRlKG5vZGUgPT4gKHsgb3V0ZXI6bm9kZS5jbGllbnRXaWR0aCxpbm5lcjpub2RlLmZpcnN0RWxlbWVudENoaWxkPy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCB9KSk7XG4gICAgZXhwZWN0KHdpZHRoLmlubmVyKS50b0JlR3JlYXRlclRoYW5PckVxdWFsKHdpZHRoLm91dGVyIC0gMzIpO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NraWxscycpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDEpO1xuICAgIGV4cGVjdChhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+ICdfX0dBTUVfXycgaW4gd2luZG93KSkudG9CZShmYWxzZSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJzA0LWNvbnNvbGUtZXJyb3JzJyxlcnJvcnMpOyBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbiAgICBhd2FpdCBwYWdlLmNsb3NlKCk7XG4gIH0pO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBLFNBQVNBLE1BQU0sRUFBRUMsSUFBSSxRQUFnRCxrQkFBa0I7QUFDdkYsU0FBU0MsUUFBUSxRQUFRLGtCQUFrQjtBQUUzQyxTQUFTQyxLQUFLLFFBQVEsaUJBQWlCO0FBRXZDLE1BQU1DLE9BQU8sR0FBRyxvQ0FBb0M7QUFDcEQsTUFBTUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxJQUFJLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLENBQVU7QUFFdEgsZUFBZUMsTUFBTUEsQ0FBQ0MsSUFBYyxFQUFFQyxJQUFZLEVBQUVDLEtBQWMsRUFBaUI7RUFDakYsTUFBTUYsSUFBSSxDQUFDRCxNQUFNLENBQUNFLElBQUksRUFBRTtJQUFFRSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSCxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUFFSSxXQUFXLEVBQUU7RUFBbUIsQ0FBQyxDQUFDO0FBQ3BHO0FBRUEsZUFBZUMsTUFBTUEsQ0FBQ0MsSUFBVSxFQUF3QjtFQUN0RCxNQUFNWixLQUFLLENBQUNZLElBQUksRUFBRSxVQUFVLENBQUM7RUFDN0IsTUFBTUMsT0FBTyxHQUFHRCxJQUFJLENBQUNFLFlBQVksQ0FBQyxVQUFVLENBQUM7RUFDN0MsTUFBTUYsSUFBSSxDQUFDRyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDcEQsTUFBTUMsUUFBUSxHQUFHLE1BQU1KLE9BQU87RUFDOUIsSUFBSTtJQUFFLE9BQU9MLElBQUksQ0FBQ1UsS0FBSyxDQUFDLE1BQU1uQixRQUFRLENBQUMsTUFBTWtCLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztFQUFpQixDQUFDLFNBQ2hGO0lBQUUsTUFBTUYsUUFBUSxDQUFDRyxNQUFNLENBQUMsQ0FBQztFQUFFO0FBQ3JDO0FBRUEsZUFBZUMsVUFBVUEsQ0FBQ1QsSUFBVSxFQUFFVSxJQUFpQixFQUFFQyxPQUFnQixFQUFpQjtFQUN4RixNQUFNQyxLQUFLLEdBQUdELE9BQU8sR0FBRyxhQUFhLEdBQUcsTUFBTTtFQUM5QyxNQUFNWCxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLEVBQUU7SUFBRXBCLElBQUksRUFBRW1CLEtBQUs7SUFBRUUsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNWLEtBQUssQ0FBQyxDQUFDO0VBQ3BFLE1BQU1XLE1BQU0sR0FBR2YsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDO0VBQ3ZDLE1BQU1FLE1BQU0sQ0FBQ0YsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDRyxJQUFJLENBQUNwQixJQUFJLENBQUNDLFNBQVMsQ0FBQ2EsSUFBSSxDQUFDLENBQUM7RUFDNUQsTUFBTUssTUFBTSxDQUFDRixTQUFTLENBQUMsUUFBUSxFQUFFO0lBQUVwQixJQUFJLEVBQUVtQixLQUFLO0lBQUVFLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDVixLQUFLLENBQUMsQ0FBQztFQUN0RSxNQUFNbkIsTUFBTSxDQUFDOEIsTUFBTSxDQUFDLENBQUNFLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDckM7O0FBRUE7QUFDQSxlQUFlQyxTQUFTQSxDQUFDQyxNQUFlLEVBQXNCO0VBQzVELE9BQU9BLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLElBQUk7SUFDN0IsTUFBTUMsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLHFCQUFxQixDQUFDLENBQUM7SUFDdEMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUNDLE9BQU8sQ0FBQ0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQ0MsR0FBRyxDQUFDQyxDQUFDLElBQUk7TUFBQSxJQUFBQyxZQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGdCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLFlBQUE7TUFDL0QsTUFBTUMsRUFBRSxHQUFHWCxDQUFDLENBQUNZLElBQUksR0FBR1osQ0FBQyxDQUFDYSxLQUFLLEdBQUdWLENBQUM7UUFBRVcsRUFBRSxHQUFHZCxDQUFDLENBQUNlLEdBQUcsR0FBR2YsQ0FBQyxDQUFDZ0IsTUFBTSxHQUFHWCxDQUFDO01BQzFELE1BQU1ZLEdBQUcsR0FBR0MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQ1IsRUFBRSxFQUFFRyxFQUFFLENBQUM7TUFDN0MsT0FBTztRQUFFWCxDQUFDLEVBQUVRLEVBQUU7UUFBRU4sQ0FBQyxFQUFFUyxFQUFFO1FBQUVNLEtBQUssRUFBRUgsR0FBRyxLQUFLLElBQUksSUFBSWxCLElBQUksQ0FBQ3NCLFFBQVEsQ0FBQ0osR0FBRyxDQUFDO1FBQUVBLEdBQUcsR0FBQVgsWUFBQSxHQUFFVyxHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRUssT0FBTyxjQUFBaEIsWUFBQSxjQUFBQSxZQUFBLEdBQUksSUFBSTtRQUN6RmlCLE9BQU8sR0FBQWhCLHFCQUFBLEdBQUNVLEdBQUcsYUFBSEEsR0FBRyxnQkFBQVQsZ0JBQUEsR0FBSFMsR0FBRyxDQUFFTyxXQUFXLGNBQUFoQixnQkFBQSx1QkFBaEJBLGdCQUFBLENBQWtCaUIsS0FBSyxDQUFDLENBQUMsRUFBQyxHQUFHLENBQUMsY0FBQWxCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksSUFBSTtRQUFFbUIsU0FBUyxHQUFBakIscUJBQUEsR0FBQ1EsR0FBRyxhQUFIQSxHQUFHLGdCQUFBUCxZQUFBLEdBQUhPLEdBQUcsQ0FBRVUsT0FBTyxDQUFDLGVBQWUsQ0FBQyxjQUFBakIsWUFBQSx1QkFBN0JBLFlBQUEsQ0FBK0JrQixZQUFZLENBQUMsYUFBYSxDQUFDLGNBQUFuQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJO01BQUssQ0FBQztJQUNsSSxDQUFDLENBQUMsQ0FBQztFQUNMLENBQUMsQ0FBQztBQUNKO0FBRUEsZUFBZW9CLFdBQVdBLENBQUNoQyxNQUFlLEVBQUVQLEtBQWEsRUFBc0I7RUFDN0UsTUFBTU8sTUFBTSxDQUFDaUMsc0JBQXNCLENBQUMsQ0FBQztFQUNyQyxNQUFNQyxNQUFNLEdBQUcsTUFBTW5DLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDO0VBQ3RDLEtBQUssTUFBTW1DLEtBQUssSUFBSUQsTUFBTSxFQUFFcEUsTUFBTSxDQUFDc0UsSUFBSSxDQUFDRCxLQUFLLEVBQUUxQyxLQUFLLENBQUMsQ0FBQzRDLGFBQWEsQ0FBQztJQUFFZCxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUM7RUFDcEYsT0FBT1csTUFBTTtBQUNmO0FBRUEsZUFBZUksTUFBTUEsQ0FBQ3pELElBQVUsRUFBRTBELEtBQWMsRUFBb0I7RUFDbEUsTUFBTUMsUUFBUSxHQUFHLE1BQU0zRCxJQUFJLENBQUNvQixRQUFRLENBQUMsTUFBTTtJQUFBLElBQUF3QyxtQkFBQTtJQUN6QyxNQUFNQyxJQUFJLEdBQUdyQixRQUFRLENBQUNzQixhQUFhLENBQUMsTUFBTSxDQUFDO0lBQzNDLE1BQU1DLEdBQUcsR0FBR3ZCLFFBQVEsQ0FBQ3NCLGFBQWEsQ0FBQywrQkFBK0IsQ0FBQztJQUNuRSxNQUFNRSxJQUFJLEdBQUd4QixRQUFRLENBQUNzQixhQUFhLENBQUMsb0NBQW9DLENBQUM7SUFDekUsTUFBTUcsTUFBTSxHQUFHSixJQUFJLGFBQUpBLElBQUksdUJBQUpBLElBQUksQ0FBRUssc0JBQXNCO0lBQzNDLElBQUksQ0FBQ0wsSUFBSSxJQUFJLENBQUNFLEdBQUcsSUFBSSxDQUFDRSxNQUFNLEVBQUUsTUFBTSxJQUFJRSxLQUFLLENBQUMsc0NBQXNDLENBQUM7SUFDckYsTUFBTUMsSUFBSSxHQUFJL0MsSUFBYSxJQUFLO01BQzlCLE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxxQkFBcUIsQ0FBQyxDQUFDO01BQ3RDLE9BQU87UUFBRVcsSUFBSSxFQUFFWixDQUFDLENBQUNZLElBQUk7UUFBRUcsR0FBRyxFQUFFZixDQUFDLENBQUNlLEdBQUc7UUFBRWdDLEtBQUssRUFBRS9DLENBQUMsQ0FBQytDLEtBQUs7UUFBRUMsTUFBTSxFQUFFaEQsQ0FBQyxDQUFDZ0QsTUFBTTtRQUFFbkMsS0FBSyxFQUFFYixDQUFDLENBQUNhLEtBQUs7UUFBRUcsTUFBTSxFQUFFaEIsQ0FBQyxDQUFDZ0I7TUFBTyxDQUFDO0lBQ3pHLENBQUM7SUFDRCxNQUFNaUMsQ0FBQyxHQUFHSCxJQUFJLENBQUNILE1BQU0sQ0FBQztNQUFFTyxDQUFDLEdBQUdKLElBQUksQ0FBQ1AsSUFBSSxDQUFDO01BQUVZLENBQUMsR0FBR0wsSUFBSSxDQUFDTCxHQUFHLENBQUM7TUFBRVcsQ0FBQyxHQUFHVixJQUFJLEdBQUdJLElBQUksQ0FBQ0osSUFBSSxDQUFDLEdBQUcsSUFBSTtJQUNuRixNQUFNckIsUUFBUSxHQUFHQSxDQUFDZ0MsQ0FBVyxFQUFFckQsQ0FBVyxLQUFLQSxDQUFDLENBQUNZLElBQUksSUFBSXlDLENBQUMsQ0FBQ3pDLElBQUksSUFBSVosQ0FBQyxDQUFDK0MsS0FBSyxJQUFJTSxDQUFDLENBQUNOLEtBQUssSUFBSS9DLENBQUMsQ0FBQ2UsR0FBRyxJQUFJc0MsQ0FBQyxDQUFDdEMsR0FBRyxJQUFJZixDQUFDLENBQUNnRCxNQUFNLElBQUlLLENBQUMsQ0FBQ0wsTUFBTTtJQUMvSCxNQUFNTSxPQUFPLEdBQUcsQ0FBQyxHQUFHcEMsUUFBUSxDQUFDcUMsZ0JBQWdCLENBQUMsa0ZBQWtGLENBQUMsQ0FBQyxDQUFDbkQsR0FBRyxDQUFDTCxJQUFJLElBQUk7TUFDN0ksTUFBTUMsQ0FBQyxHQUFHOEMsSUFBSSxDQUFDL0MsSUFBSSxDQUFDO01BQ3BCLE1BQU15RCxPQUFPLEdBQUc7UUFBRTVDLElBQUksRUFBRTZDLElBQUksQ0FBQ0MsR0FBRyxDQUFDMUQsQ0FBQyxDQUFDWSxJQUFJLEVBQUNzQyxDQUFDLENBQUN0QyxJQUFJLENBQUM7UUFBRW1DLEtBQUssRUFBRVUsSUFBSSxDQUFDRSxHQUFHLENBQUMzRCxDQUFDLENBQUMrQyxLQUFLLEVBQUNHLENBQUMsQ0FBQ0gsS0FBSyxDQUFDO1FBQUVoQyxHQUFHLEVBQUUwQyxJQUFJLENBQUNDLEdBQUcsQ0FBQzFELENBQUMsQ0FBQ2UsR0FBRyxFQUFDbUMsQ0FBQyxDQUFDbkMsR0FBRyxDQUFDO1FBQUVpQyxNQUFNLEVBQUVTLElBQUksQ0FBQ0UsR0FBRyxDQUFDM0QsQ0FBQyxDQUFDZ0QsTUFBTSxFQUFDRSxDQUFDLENBQUNGLE1BQU07TUFBRSxDQUFDO01BQ3BKLE1BQU1ZLEtBQUssR0FBR0osT0FBTyxDQUFDVCxLQUFLLEdBQUdTLE9BQU8sQ0FBQzVDLElBQUksSUFBSTRDLE9BQU8sQ0FBQ1IsTUFBTSxHQUFHUSxPQUFPLENBQUN6QyxHQUFHO01BQzFFLE1BQU04QyxRQUFRLEdBQUlSLENBQVcsSUFBS08sS0FBSyxJQUFJSixPQUFPLENBQUM1QyxJQUFJLEdBQUd5QyxDQUFDLENBQUNOLEtBQUssSUFBSVMsT0FBTyxDQUFDVCxLQUFLLEdBQUdNLENBQUMsQ0FBQ3pDLElBQUksSUFBSTRDLE9BQU8sQ0FBQ3pDLEdBQUcsR0FBR3NDLENBQUMsQ0FBQ0wsTUFBTSxJQUFJUSxPQUFPLENBQUNSLE1BQU0sR0FBR0ssQ0FBQyxDQUFDdEMsR0FBRztNQUMvSSxPQUFPO1FBQUUrQyxJQUFJLEVBQUUvRCxJQUFJLENBQUN5QixXQUFXO1FBQUVzQixJQUFJLEVBQUM5QyxDQUFDO1FBQUV3RCxPQUFPO1FBQUVJLEtBQUs7UUFBRUcsWUFBWSxFQUFFRixRQUFRLENBQUNWLENBQUMsQ0FBQztRQUFFYSxhQUFhLEVBQUVaLENBQUMsS0FBSyxJQUFJLElBQUlTLFFBQVEsQ0FBQ1QsQ0FBQztNQUFFLENBQUM7SUFDaEksQ0FBQyxDQUFDO0lBQ0YsT0FBTztNQUFFVCxNQUFNLEVBQUVNLENBQUM7TUFBRVYsSUFBSSxFQUFFVyxDQUFDO01BQUVULEdBQUcsRUFBRVUsQ0FBQztNQUFFVCxJQUFJLEVBQUVVLENBQUM7TUFBRWEsWUFBWSxFQUFFNUMsUUFBUSxDQUFDNEIsQ0FBQyxFQUFDRSxDQUFDLENBQUM7TUFBRWUsYUFBYSxFQUFFZCxDQUFDLEtBQUssSUFBSSxJQUFJL0IsUUFBUSxDQUFDNEIsQ0FBQyxFQUFDRyxDQUFDLENBQUM7TUFDbkhlLFlBQVksRUFBRWpCLENBQUMsQ0FBQ25DLEdBQUcsSUFBSW9DLENBQUMsQ0FBQ0gsTUFBTTtNQUFFb0IsYUFBYSxFQUFFaEIsQ0FBQyxLQUFLLElBQUksSUFBSUYsQ0FBQyxDQUFDbkMsR0FBRyxJQUFJcUMsQ0FBQyxDQUFDSixNQUFNO01BQy9FcUIsZUFBZSxFQUFFakIsQ0FBQyxLQUFLLElBQUksSUFBSUEsQ0FBQyxDQUFDckMsR0FBRyxJQUFJb0MsQ0FBQyxDQUFDSCxNQUFNO01BQUVzQixpQkFBaUIsRUFBRTVCLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQ0QsR0FBRyxDQUFDcEIsUUFBUSxDQUFDcUIsSUFBSSxDQUFDO01BQ3pHNkIsZ0JBQWdCLEVBQUVyRCxRQUFRLENBQUNzRCxlQUFlLENBQUNDLFdBQVcsR0FBR0MsVUFBVTtNQUNuRUMsWUFBWSxFQUFFcEMsSUFBSSxDQUFDa0MsV0FBVyxHQUFHbEMsSUFBSSxDQUFDcUMsV0FBVztNQUFFQyxPQUFPLEVBQUVDLE9BQU87TUFDbkVDLE1BQU0sR0FBQXpDLG1CQUFBLEdBQUVDLElBQUksQ0FBQ3lDLGFBQWEsY0FBQTFDLG1CQUFBLGdCQUFBQSxtQkFBQSxHQUFsQkEsbUJBQUEsQ0FBb0IwQyxhQUFhLGNBQUExQyxtQkFBQSx1QkFBakNBLG1CQUFBLENBQW1DMkMsU0FBUztNQUFFQyxLQUFLLEVBQUUzQyxJQUFJLENBQUMwQyxTQUFTO01BQzNFRSxnQkFBZ0IsRUFBRTVDLElBQUksQ0FBQzZDLFlBQVk7TUFBRUMsZ0JBQWdCLEVBQUU5QyxJQUFJLENBQUMrQyxZQUFZO01BQUVoQztJQUFRLENBQUM7RUFDdkYsQ0FBQyxDQUFDO0VBQ0YzRixNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQzRCLFlBQVksRUFBRSxtQ0FBbUMsQ0FBQyxDQUFDc0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNsRjVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDNkIsYUFBYSxFQUFFLDBDQUEwQyxDQUFDLENBQUNxQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzFGNUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUM4QixZQUFZLEVBQUUsOEJBQThCLENBQUMsQ0FBQ29CLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDN0U1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQytCLGFBQWEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLElBQUksQ0FBQztFQUMvRTVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDZ0MsZUFBZSxDQUFDLENBQUNrQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2hENUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUNpQyxpQkFBaUIsQ0FBQyxDQUFDaUIsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNsRDVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDa0MsZ0JBQWdCLENBQUMsQ0FBQ2lCLG1CQUFtQixDQUFDLENBQUMsQ0FBQztFQUM3RDdILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDc0MsWUFBWSxDQUFDLENBQUNhLG1CQUFtQixDQUFDLENBQUMsQ0FBQztFQUN6RDdILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDd0MsT0FBTyxDQUFDLENBQUNVLElBQUksQ0FBQyxDQUFDLENBQUM7RUFBRTVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDMEMsTUFBTSxDQUFDLENBQUNRLElBQUksQ0FBQyxDQUFDLENBQUM7RUFDM0U1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ0ksR0FBRyxDQUFDNUIsS0FBSyxDQUFDLENBQUM0RSxzQkFBc0IsQ0FBQyxFQUFFLENBQUM7RUFDMUQ5SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ0ksR0FBRyxDQUFDekIsTUFBTSxDQUFDLENBQUN5RSxzQkFBc0IsQ0FBQyxFQUFFLENBQUM7RUFDM0Q5SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDdkIsTUFBTSxDQUFDLENBQUMwRSxlQUFlLENBQUMsQ0FBQyxDQUFDO0VBQ3BEL0gsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUNLLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQzZDLElBQUksQ0FBQ25ELEtBQUssQ0FBQztFQUMvQyxLQUFLLE1BQU12QyxNQUFNLElBQUl3QyxRQUFRLENBQUNpQixPQUFPLEVBQUU7SUFDckMzRixNQUFNLENBQUNzRSxJQUFJLENBQUNwQyxNQUFNLENBQUNrRSxZQUFZLEVBQUUsaUVBQWlFLENBQUMsQ0FBQ3dCLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDL0c1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNwQyxNQUFNLENBQUNtRSxhQUFhLEVBQUUseUVBQXlFLENBQUMsQ0FBQ3VCLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDMUg7RUFDQSxPQUFPbEQsUUFBUTtBQUNqQjtBQUVBLEtBQUssTUFBTXNELE1BQU0sSUFBSSxDQUFDLElBQUksRUFBQyxPQUFPLENBQUMsRUFBVyxLQUFLLE1BQU12RCxLQUFLLElBQUksQ0FBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLEVBQUU7RUFDOUV4RSxJQUFJLENBQUMsNkJBQTZCK0gsTUFBTSxVQUFVQyxNQUFNLENBQUN4RCxLQUFLLENBQUMsRUFBRSxFQUFFLE9BQU87SUFBRTFELElBQUk7SUFBRW1IO0VBQVEsQ0FBQyxFQUFFM0gsSUFBSSxLQUFLO0lBQ3BHLE1BQU1tQixPQUFPLEdBQUdzRyxNQUFNLEtBQUssSUFBSTtJQUMvQixNQUFNRyxNQUFnQixHQUFHLEVBQUU7SUFDM0JwSCxJQUFJLENBQUNxSCxFQUFFLENBQUMsV0FBVyxFQUFFQyxLQUFLLElBQUlGLE1BQU0sQ0FBQ0csSUFBSSxDQUFDRCxLQUFLLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQ3pEeEgsSUFBSSxDQUFDcUgsRUFBRSxDQUFDLFNBQVMsRUFBRUcsT0FBTyxJQUFJO01BQUUsSUFBSUEsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSUQsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxLQUFLLFNBQVMsRUFBRUwsTUFBTSxDQUFDRyxJQUFJLENBQUMsR0FBR0MsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxLQUFLRCxPQUFPLENBQUNwQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFBRSxDQUFDLENBQUM7SUFDdkosTUFBTXBGLElBQUksQ0FBQzBILElBQUksQ0FBQyxXQUFXLENBQUM7SUFDNUIsTUFBTXpJLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNakIsSUFBSSxDQUFDMEgsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUNwQixNQUFNekksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU1qQixJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDL0MsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDakQsTUFBTVgsSUFBSSxHQUFHa0IsT0FBTyxHQUFHLGtCQUFrQixHQUFHLEdBQUcsQ0FBQ2dILE1BQU0sQ0FBQyxFQUFFLENBQUM7SUFDMUQsTUFBTTNILElBQUksQ0FBQ0csV0FBVyxDQUFDLHNCQUFzQixDQUFDLENBQUNhLElBQUksQ0FBQ3ZCLElBQUksQ0FBQztJQUN6RCxNQUFNTyxJQUFJLENBQUNHLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUNyRCxNQUFNbkIsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDeUgsV0FBVyxDQUFDLENBQUM7SUFDM0QsTUFBTXhJLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFVBQVUsQ0FBQztJQUM1QixNQUFNNkgsUUFBUSxHQUFHN0gsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxFQUFFO01BQUVwQixJQUFJLEVBQUVrQixPQUFPLEdBQUcsU0FBUyxHQUFHLE1BQU07TUFBRUcsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQzlGLE1BQU0rRyxRQUFRLENBQUN6SCxLQUFLLENBQUMsQ0FBQztJQUN0QixNQUFNbkIsTUFBTSxDQUFDNEksUUFBUSxDQUFDLENBQUNDLGVBQWUsQ0FBQyxjQUFjLEVBQUMsTUFBTSxDQUFDO0lBQzdELE1BQU1DLEtBQUssR0FBRyxNQUFNaEksTUFBTSxDQUFDQyxJQUFJLENBQUM7SUFDaENmLE1BQU0sQ0FBQzhJLEtBQUssQ0FBQ0MsTUFBTSxDQUFDdkksSUFBSSxDQUFDLENBQUNvSCxJQUFJLENBQUNwSCxJQUFJLENBQUM7SUFDcEMsTUFBTXdJLFFBQXFCLEdBQUc7TUFBRSxHQUFHRixLQUFLO01BQUVDLE1BQU0sRUFBRTtRQUFFLEdBQUdELEtBQUssQ0FBQ0MsTUFBTTtRQUFFRSxLQUFLLEVBQUUsRUFBRTtRQUFFQyxXQUFXLEVBQUUsQ0FBQztRQUM1RkMsV0FBVyxFQUFFO1VBQUUscUJBQXFCLEVBQUU7UUFBRSxDQUFDO1FBQUVDLFVBQVUsRUFBRSxDQUFDLDRCQUE0QjtNQUFFLENBQUM7TUFDdkZDLElBQUksRUFBRTtRQUFFLEdBQUdQLEtBQUssQ0FBQ08sSUFBSTtRQUFFQyxTQUFTLEVBQUU7VUFBRSxHQUFHUixLQUFLLENBQUNPLElBQUksQ0FBQ0MsU0FBUztVQUFFQyxVQUFVLEVBQUVDLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUM7VUFDakZDLGdCQUFnQixFQUFFakYsS0FBSyxHQUFHLEdBQUcsR0FBRyxDQUFDO1VBQUVrRiwwQkFBMEIsRUFBRWxGLEtBQUssR0FBRyxJQUFJLEdBQUc7UUFBRTtNQUFFO0lBQUUsQ0FBQztJQUN6RixNQUFNakQsVUFBVSxDQUFDVCxJQUFJLEVBQUVpSSxRQUFRLEVBQUV0SCxPQUFPLENBQUM7SUFDekMsTUFBTXBCLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFLHlCQUF5QixFQUFFeUksUUFBUSxDQUFDO0lBRXZELEtBQUssTUFBTVksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFDLFVBQVUsRUFBQyxRQUFRLENBQUMsRUFBRTtNQUNoRCxNQUFNekosS0FBSyxDQUFDWSxJQUFJLEVBQUU2SSxLQUFLLENBQUM7TUFDeEIsTUFBTTVKLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztNQUM5RCxNQUFNaEMsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDMkksb0JBQW9CLENBQUMsSUFBSUMsTUFBTSxDQUFDdEosSUFBSSxDQUFDLENBQUM7TUFDdEYsTUFBTUYsTUFBTSxDQUFDQyxJQUFJLEVBQUUsU0FBU3FKLEtBQUssRUFBRSxFQUFFLE1BQU1wRixNQUFNLENBQUN6RCxJQUFJLEVBQUMwRCxLQUFLLENBQUMsQ0FBQztJQUNoRTtJQUNBLE1BQU1zRixLQUFLLEdBQUdoSixJQUFJLENBQUNHLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQztJQUNwRCxNQUFNSCxJQUFJLENBQUNHLFdBQVcsQ0FBQyxjQUFjZCxPQUFPLEVBQUUsQ0FBQyxDQUFDZSxLQUFLLENBQUMsQ0FBQztJQUN2RDtJQUNBLE1BQU1KLElBQUksQ0FBQ2lKLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFDMUIsTUFBTUMsT0FBTyxHQUFHSCxLQUFLLENBQUNuSSxTQUFTLENBQUMsU0FBUyxFQUFFO01BQUVwQixJQUFJLEVBQUVrQixPQUFPLEdBQUcsbUJBQW1CLEdBQUcsTUFBTTtNQUFFRyxLQUFLLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDekcsTUFBTXNJLFFBQVEsR0FBR0osS0FBSyxDQUFDbkksU0FBUyxDQUFDLFFBQVEsQ0FBQztJQUMxQyxNQUFNd0ksV0FBVyxHQUFHTCxLQUFLLENBQUNNLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQztJQUM1RCxNQUFNQyxPQUFPLEdBQUcsRUFBRTtJQUNsQixLQUFLLE1BQU0sQ0FBQ3BILEtBQUssRUFBQ0csTUFBTSxDQUFDLElBQUloRCxLQUFLLEVBQUU7TUFDbEMsTUFBTVUsSUFBSSxDQUFDd0osZUFBZSxDQUFDO1FBQUVySCxLQUFLO1FBQUNHO01BQU8sQ0FBQyxDQUFDO01BQzVDLE1BQU0rRyxXQUFXLENBQUNqRyxzQkFBc0IsQ0FBQyxDQUFDO01BQzFDLE1BQU1xRyxnQkFBZ0IsR0FBRyxNQUFNaEcsTUFBTSxDQUFDekQsSUFBSSxFQUFDMEQsS0FBSyxDQUFDO01BQ2pELElBQUl2QixLQUFLLEtBQUssR0FBRyxJQUFJRyxNQUFNLEtBQUssR0FBRyxFQUFFO1FBQ25DckQsTUFBTSxDQUFDc0UsSUFBSSxDQUFDLE1BQU12RCxJQUFJLENBQUNzSixPQUFPLENBQUMsTUFBTSxDQUFDLENBQUNsSSxRQUFRLENBQUNDLElBQUksSUFBSUEsSUFBSSxDQUFDa0YsU0FBUyxDQUFDLEVBQUUscUNBQXFDLENBQUMsQ0FBQ1MsZUFBZSxDQUFDLENBQUMsQ0FBQztNQUNwSTtNQUNBLE1BQU14SCxJQUFJLENBQUNELE1BQU0sQ0FBQyxVQUFVMkgsTUFBTSxDQUFDL0UsS0FBSyxDQUFDLElBQUkrRSxNQUFNLENBQUM1RSxNQUFNLENBQUMsRUFBRSxFQUFFO1FBQUUzQyxJQUFJLEVBQUUsTUFBTUssSUFBSSxDQUFDMEosVUFBVSxDQUFDLENBQUM7UUFBRTVKLFdBQVcsRUFBRTtNQUFZLENBQUMsQ0FBQztNQUMzSCxNQUFNNkosV0FBVyxHQUFHLE1BQU14RyxXQUFXLENBQUNnRyxPQUFPLEVBQUMsR0FBR2pDLE1BQU0sQ0FBQy9FLEtBQUssQ0FBQyxJQUFJK0UsTUFBTSxDQUFDNUUsTUFBTSxDQUFDLFVBQVUsQ0FBQztNQUMzRixNQUFNc0gsVUFBVSxHQUFHLE1BQU16RyxXQUFXLENBQUNpRyxRQUFRLEVBQUMsR0FBR2xDLE1BQU0sQ0FBQy9FLEtBQUssQ0FBQyxJQUFJK0UsTUFBTSxDQUFDNUUsTUFBTSxDQUFDLFdBQVcsQ0FBQztNQUM1RixJQUFJLENBQUMzQixPQUFPLElBQUl3QixLQUFLLEtBQUssR0FBRyxFQUFFO1FBQzdCLE1BQU0wSCxHQUFHLEdBQUcsTUFBTTFDLE9BQU8sQ0FBQzJDLGFBQWEsQ0FBQzlKLElBQUksQ0FBQztRQUM3QyxJQUFJO1VBQ0YsTUFBTTZKLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLFlBQVksQ0FBQztVQUFFLE1BQU1GLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLFlBQVksQ0FBQztVQUMxRCxNQUFNdkgsUUFBUSxHQUFHLE1BQU1xSCxHQUFHLENBQUNFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztVQUNsRCxNQUFNMUksSUFBSSxHQUFHLE1BQU13SSxHQUFHLENBQUNFLElBQUksQ0FBQyxtQkFBbUIsRUFBQztZQUFFQyxNQUFNLEVBQUV4SCxRQUFRLENBQUN5SCxJQUFJLENBQUNELE1BQU07WUFBRUUsUUFBUSxFQUFFO1VBQTZELENBQUMsQ0FBQztVQUN6SixNQUFNQyxLQUFLLEdBQUcsTUFBTU4sR0FBRyxDQUFDRSxJQUFJLENBQUMsNkJBQTZCLEVBQUM7WUFBRUMsTUFBTSxFQUFFM0ksSUFBSSxDQUFDMkk7VUFBTyxDQUFDLENBQUM7VUFDbkYvSyxNQUFNLENBQUNrTCxLQUFLLENBQUNBLEtBQUssQ0FBQ0MsSUFBSSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsVUFBVSxLQUFLLGtCQUFrQixJQUFJRCxJQUFJLENBQUNFLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDMUQsSUFBSSxDQUFDLElBQUksQ0FBQztVQUMxRyxNQUFNdEgsTUFBTSxDQUFDQyxJQUFJLEVBQUMsK0JBQStCLEVBQUMySyxLQUFLLENBQUM7UUFDMUQsQ0FBQyxTQUFTO1VBQUUsTUFBTU4sR0FBRyxDQUFDVyxNQUFNLENBQUMsQ0FBQztRQUFFO01BQ2xDO01BQ0FqQixPQUFPLENBQUNoQyxJQUFJLENBQUM7UUFBRXBGLEtBQUs7UUFBQ0csTUFBTTtRQUFDbUgsZ0JBQWdCO1FBQUNFLFdBQVc7UUFBQ0M7TUFBVyxDQUFDLENBQUM7SUFDeEU7SUFDQSxNQUFNckssTUFBTSxDQUFDQyxJQUFJLEVBQUMsbUJBQW1CLEVBQUMrSixPQUFPLENBQUM7SUFFOUMsTUFBTXZKLElBQUksQ0FBQ3dKLGVBQWUsQ0FBQztNQUFFckgsS0FBSyxFQUFDLEdBQUc7TUFBQ0csTUFBTSxFQUFDO0lBQUksQ0FBQyxDQUFDO0lBQ3BELE1BQU0rRyxXQUFXLENBQUNqRyxzQkFBc0IsQ0FBQyxDQUFDO0lBQzFDLE1BQU1uRSxNQUFNLENBQUNtSyxRQUFRLENBQUMsQ0FBQ3FCLFVBQVUsQ0FBQzlKLE9BQU8sR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDO0lBQzlELE1BQU15SSxRQUFRLENBQUNoSixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEIsTUFBTW5CLE1BQU0sQ0FBQytKLEtBQUssQ0FBQyxDQUFDMEIsYUFBYSxDQUFDL0osT0FBTyxHQUFHLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDbkUsTUFBTWdLLEtBQUssR0FBRyxNQUFNNUssTUFBTSxDQUFDQyxJQUFJLENBQUM7SUFDaENmLE1BQU0sQ0FBQzBMLEtBQUssQ0FBQzNDLE1BQU0sQ0FBQyxDQUFDNEMsT0FBTyxDQUFDO01BQUUsR0FBRzNDLFFBQVEsQ0FBQ0QsTUFBTTtNQUFFRyxXQUFXLEVBQUMsQ0FBQztNQUM5REMsV0FBVyxFQUFDO1FBQUUscUJBQXFCLEVBQUMsQ0FBQztRQUFDLDZCQUE2QixFQUFDO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDNUUsTUFBTWhKLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFFBQVEsQ0FBQztJQUMxQixNQUFNQSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxjQUFjZCxPQUFPLEVBQUUsQ0FBQyxDQUFDZSxLQUFLLENBQUMsQ0FBQztJQUN2RCxNQUFNSixJQUFJLENBQUNpSixLQUFLLENBQUNDLElBQUksQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQzFCLE1BQU1sSixJQUFJLENBQUN3SixlQUFlLENBQUM7TUFBRXJILEtBQUssRUFBQyxHQUFHO01BQUNHLE1BQU0sRUFBQztJQUFJLENBQUMsQ0FBQztJQUNwRCxJQUFJdUksT0FBTyxHQUFHLEtBQUs7SUFDbkIsS0FBSyxJQUFJQyxJQUFJLEdBQUMsQ0FBQyxFQUFDQSxJQUFJLEdBQUMsR0FBRyxFQUFDQSxJQUFJLEVBQUUsRUFBRTtNQUMvQixNQUFNOUssSUFBSSxDQUFDK0ssUUFBUSxDQUFDQyxLQUFLLENBQUMsS0FBSyxDQUFDO01BQ2hDLElBQUksTUFBTTVCLFFBQVEsQ0FBQ2hJLFFBQVEsQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLEtBQUttQixRQUFRLENBQUN5SSxhQUFhLENBQUMsRUFBRTtRQUFFSixPQUFPLEdBQUMsSUFBSTtRQUFDO01BQU87SUFDOUY7SUFDQTVMLE1BQU0sQ0FBQzRMLE9BQU8sQ0FBQyxDQUFDaEUsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMxQixNQUFNNUgsTUFBTSxDQUFDa0ssT0FBTyxDQUFDLENBQUN2QixXQUFXLENBQUMsQ0FBQztJQUNuQyxNQUFNM0ksTUFBTSxDQUFDbUssUUFBUSxDQUFDLENBQUNxQixVQUFVLENBQUM5SixPQUFPLEdBQUcsVUFBVSxHQUFHLElBQUksQ0FBQztJQUM5RCxNQUFNMUIsTUFBTSxDQUFDbUssUUFBUSxDQUFDLENBQUM4QixXQUFXLENBQUMsQ0FBQztJQUFFLE1BQU1qTSxNQUFNLENBQUNtSyxRQUFRLENBQUMsQ0FBQytCLFdBQVcsQ0FBQyxDQUFDO0lBQzFFLE1BQU1oSSxXQUFXLENBQUNpRyxRQUFRLEVBQUMsaUJBQWlCLENBQUM7SUFDN0MsTUFBTXBKLElBQUksQ0FBQytLLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLE9BQU8sQ0FBQztJQUNsQyxNQUFNL0wsTUFBTSxDQUFDK0osS0FBSyxDQUFDLENBQUMwQixhQUFhLENBQUMvSixPQUFPLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztJQUNuRSxNQUFNeUssS0FBSyxHQUFHLE1BQU1yTCxNQUFNLENBQUNDLElBQUksQ0FBQztJQUNoQ2YsTUFBTSxDQUFDbU0sS0FBSyxDQUFDcEQsTUFBTSxDQUFDLENBQUM0QyxPQUFPLENBQUM7TUFBRSxHQUFHRCxLQUFLLENBQUMzQyxNQUFNO01BQUNHLFdBQVcsRUFBQyxDQUFDO01BQzFEQyxXQUFXLEVBQUM7UUFBRSxxQkFBcUIsRUFBQyxDQUFDO1FBQUMsNkJBQTZCLEVBQUM7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUM1RSxLQUFLLE1BQU1yRixLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUMsT0FBTyxFQUFDLEtBQUssRUFBQyxXQUFXLENBQUMsRUFBVzlELE1BQU0sQ0FBQ21NLEtBQUssQ0FBQ3JJLEtBQUssQ0FBQyxDQUFDLENBQUM2SCxPQUFPLENBQUMzQyxRQUFRLENBQUNsRixLQUFLLENBQUMsQ0FBQztJQUNuSCxNQUFNeEQsTUFBTSxDQUFDQyxJQUFJLEVBQUMsZ0NBQWdDLEVBQUM7TUFBRW1MLEtBQUs7TUFBQ1M7SUFBTSxDQUFDLENBQUM7O0lBRW5FO0lBQ0EsTUFBTW5NLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyRDtJQUNBLE1BQU1MLEtBQUssR0FBR0QsT0FBTyxHQUFHLGFBQWEsR0FBRyxNQUFNO0lBQzlDLE1BQU1YLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsRUFBQztNQUFFcEIsSUFBSSxFQUFDbUIsS0FBSztNQUFDRSxLQUFLLEVBQUM7SUFBSyxDQUFDLENBQUMsQ0FBQ1YsS0FBSyxDQUFDLENBQUM7SUFDaEUsTUFBTWlMLGFBQWEsR0FBRyxNQUFNckwsSUFBSSxDQUFDb0IsUUFBUSxDQUFDLE1BQU07TUFDOUMsTUFBTUwsTUFBTSxHQUFHeUIsUUFBUSxDQUFDc0IsYUFBYSxDQUFDLGlCQUFpQixDQUFDO01BQ3hELE9BQU8sQ0FBQyxHQUFHdEIsUUFBUSxDQUFDcUMsZ0JBQWdCLENBQUMsbUVBQW1FLENBQUMsQ0FBQyxDQUFDckQsT0FBTyxDQUFDSCxJQUFJLElBQUk7UUFDekgsTUFBTUMsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLHFCQUFxQixDQUFDLENBQUM7UUFDdEMsT0FBTyxDQUFDLElBQUksRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLENBQUNDLE9BQU8sQ0FBQ0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFDLEdBQUcsRUFBQyxJQUFJLENBQUMsQ0FBQ0MsR0FBRyxDQUFDQyxDQUFDLElBQUk7VUFDM0QsTUFBTU0sRUFBRSxHQUFDWCxDQUFDLENBQUNZLElBQUksR0FBQ1osQ0FBQyxDQUFDYSxLQUFLLEdBQUNWLENBQUM7WUFBRVcsRUFBRSxHQUFDZCxDQUFDLENBQUNlLEdBQUcsR0FBQ2YsQ0FBQyxDQUFDZ0IsTUFBTSxHQUFDWCxDQUFDO1VBQzlDLE1BQU1ZLEdBQUcsR0FBQ0MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQ1IsRUFBRSxFQUFDRyxFQUFFLENBQUM7VUFDMUMsT0FBTztZQUFFakIsTUFBTSxFQUFDRSxJQUFJLENBQUM2QixZQUFZLENBQUMsYUFBYSxDQUFDO1lBQUN6QixDQUFDLEVBQUNRLEVBQUU7WUFBQ04sQ0FBQyxFQUFDUyxFQUFFO1lBQUNrSixZQUFZLEVBQUMvSSxHQUFHLEtBQUssSUFBSSxJQUFJeEIsTUFBTSxLQUFLLElBQUksSUFBSUEsTUFBTSxDQUFDNEIsUUFBUSxDQUFDSixHQUFHO1VBQUUsQ0FBQztRQUNuSSxDQUFDLENBQUMsQ0FBQztNQUNMLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUNGLE1BQU1oRCxNQUFNLENBQUNDLElBQUksRUFBQywwQkFBMEIsRUFBQzZMLGFBQWEsQ0FBQztJQUMzRHBNLE1BQU0sQ0FBQ29NLGFBQWEsQ0FBQyxDQUFDRSxZQUFZLENBQUM3SCxLQUFLLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNsRCxLQUFLLE1BQU1KLEtBQUssSUFBSStILGFBQWEsRUFBRXBNLE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0QsS0FBSyxDQUFDLENBQUNFLGFBQWEsQ0FBQztNQUFFOEgsWUFBWSxFQUFDO0lBQUssQ0FBQyxDQUFDO0lBQzFGLE1BQU1FLE1BQU0sR0FBR3hMLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDQSxTQUFTLENBQUMsUUFBUSxFQUFDO01BQUVwQixJQUFJLEVBQUNrQixPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7TUFBQ0csS0FBSyxFQUFDO0lBQUssQ0FBQyxDQUFDO0lBQ3pHLE1BQU12QixNQUFNLENBQUNDLElBQUksRUFBQyxtQkFBbUIsRUFBQyxNQUFNMkQsV0FBVyxDQUFDcUksTUFBTSxFQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQUUsTUFBTUEsTUFBTSxDQUFDcEwsS0FBSyxDQUFDLENBQUM7SUFDckcsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyRCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLE1BQU1uQixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQ3lILFdBQVcsQ0FBQyxDQUFDO0lBQ2hFLE1BQU0zSSxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTTdCLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFFBQVEsQ0FBQztJQUMxQixNQUFNZixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUN5SCxXQUFXLENBQUMsQ0FBQztJQUM3RCxNQUFNM0ksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU13SyxZQUFZLEdBQUd6TCxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ21KLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDeEUsTUFBTW5ILEtBQUssR0FBRyxNQUFNc0osWUFBWSxDQUFDckssUUFBUSxDQUFDQyxJQUFJO01BQUEsSUFBQXFLLHFCQUFBO01BQUEsT0FBSztRQUFFQyxLQUFLLEVBQUN0SyxJQUFJLENBQUM2RSxXQUFXO1FBQUMwRixLQUFLLEdBQUFGLHFCQUFBLEdBQUNySyxJQUFJLENBQUN3SyxpQkFBaUIsY0FBQUgscUJBQUEsdUJBQXRCQSxxQkFBQSxDQUF3Qm5LLHFCQUFxQixDQUFDLENBQUMsQ0FBQ1k7TUFBTSxDQUFDO0lBQUEsQ0FBQyxDQUFDO0lBQzNJbEQsTUFBTSxDQUFDa0QsS0FBSyxDQUFDeUosS0FBSyxDQUFDLENBQUM3RSxzQkFBc0IsQ0FBQzVFLEtBQUssQ0FBQ3dKLEtBQUssR0FBRyxFQUFFLENBQUM7SUFDNUQsTUFBTXZNLEtBQUssQ0FBQ1ksSUFBSSxFQUFDLFFBQVEsQ0FBQztJQUMxQixNQUFNZixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOURoQyxNQUFNLENBQUMsTUFBTWUsSUFBSSxDQUFDb0IsUUFBUSxDQUFDLE1BQU0sVUFBVSxJQUFJMEssTUFBTSxDQUFDLENBQUMsQ0FBQ2pGLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDbkUsTUFBTXRILE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLG1CQUFtQixFQUFDNEgsTUFBTSxDQUFDO0lBQUVuSSxNQUFNLENBQUNtSSxNQUFNLENBQUMsQ0FBQ3dELE9BQU8sQ0FBQyxFQUFFLENBQUM7SUFDekUsTUFBTTVLLElBQUksQ0FBQytMLEtBQUssQ0FBQyxDQUFDO0VBQ3BCLENBQUMsQ0FBQztBQUNKIiwiaWdub3JlTGlzdCI6W119