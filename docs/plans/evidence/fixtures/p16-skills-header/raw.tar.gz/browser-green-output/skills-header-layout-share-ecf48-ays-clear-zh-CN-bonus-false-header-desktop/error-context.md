# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: skills-header-layout.spec.ts >> shared header stays clear zh-CN bonus=false
- Location: tests/pwa/skills-header-layout.spec.ts:101:3

# Error details

```
Test timeout of 50000ms exceeded.
```

```
Error: locator.scrollIntoViewIfNeeded: Test timeout of 50000ms exceeded.
Call log:
  - waiting for getByTestId('skill-detail-panel').getByRole('heading', { name: '闪电精通', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "主导航" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "营地" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: 营地
      - listitem [ref=e10]:
        - link "地图" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: 地图
      - listitem [ref=e14]:
        - link "战斗" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: 战斗
      - listitem [ref=e18]:
        - link "背包" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: 背包
      - listitem [ref=e22]:
        - link "技能" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: 技能
      - listitem [ref=e26]:
        - link "佣兵" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: 佣兵
      - listitem [ref=e30]:
        - link "任务" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: 任务
      - listitem [ref=e34]:
        - link "设置" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: 设置
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e40]: 技能
      - button "闪闪闪闪闪闪闪闪闪闪闪闪闪闪闪闪 · 等级 30。点击查看角色面板。" [ref=e42] [cursor=pointer]:
        - generic [ref=e44]: "30"
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: 闪闪闪闪闪闪闪闪闪闪闪闪闪闪闪闪
            - generic [ref=e48]: 等级 30
          - generic [ref=e49]:
            - generic [ref=e50]: HP
            - progressbar "HP" [ref=e51]
          - generic [ref=e53]:
            - generic [ref=e54]: MP
            - progressbar "MP" [ref=e55]
          - generic [ref=e57]:
            - generic [ref=e58]: XP
            - progressbar "XP" [ref=e59]
    - main [ref=e60]:
      - generic [ref=e61]:
        - generic [ref=e62]:
          - generic [ref=e63]: "剩余技能点: 2"
          - generic [ref=e64]: 等级 30
        - generic [ref=e65]:
          - tablist [ref=e66]:
            - tab "技能树" [selected] [ref=e67] [cursor=pointer]
            - tab "主动技能" [ref=e68] [cursor=pointer]
          - tabpanel "技能树" [ref=e69]:
            - generic [ref=e70]:
              - generic [ref=e71]:
                - generic [ref=e72]:
                  - heading "冰冷法术" [level=2] [ref=e73]
                  - paragraph [ref=e74]: 悬停、聚焦或点击节点，查看当前与下一级威力。
                  - generic [ref=e75]:
                    - img [ref=e76]
                    - button "冰冻箭，等级 0 / 20，可学习" [ref=e81] [cursor=pointer]:
                      - generic [ref=e82]:
                        - img [ref=e83]
                        - generic [ref=e84]: 冰冻箭
                      - generic [ref=e85]: 冰冻箭
                      - generic [ref=e86]: 0/20
                    - button "寒冰甲，等级 0 / 20，可学习" [ref=e87] [cursor=pointer]:
                      - generic [ref=e88]:
                        - img [ref=e89]
                        - generic [ref=e90]: 寒冰甲
                      - generic [ref=e91]: 寒冰甲
                      - generic [ref=e92]: 0/20
                    - button "冰霜新星，等级 0 / 20，未解锁" [ref=e93] [cursor=pointer]:
                      - generic [ref=e94]:
                        - img [ref=e95]
                        - generic [ref=e96]: 冰霜新星
                      - generic [ref=e97]: 冰霜新星
                      - generic [ref=e98]: 🔒
                      - generic [ref=e99]: 0/20
                    - button "冰风暴，等级 0 / 20，未解锁" [ref=e100] [cursor=pointer]:
                      - generic [ref=e101]:
                        - img [ref=e102]
                        - generic [ref=e103]: 冰风暴
                      - generic [ref=e104]: 冰风暴
                      - generic [ref=e105]: 🔒
                      - generic [ref=e106]: 0/20
                    - button "颤栗甲，等级 0 / 20，未解锁" [ref=e107] [cursor=pointer]:
                      - generic [ref=e108]:
                        - img [ref=e109]
                        - generic [ref=e110]: 颤栗甲
                      - generic [ref=e111]: 颤栗甲
                      - generic [ref=e112]: 🔒
                      - generic [ref=e113]: 0/20
                    - button "冰尖柱，等级 0 / 20，未解锁" [ref=e114] [cursor=pointer]:
                      - generic [ref=e115]:
                        - img [ref=e116]
                        - generic [ref=e117]: 冰尖柱
                      - generic [ref=e118]: 冰尖柱
                      - generic [ref=e119]: 🔒
                      - generic [ref=e120]: 0/20
                    - button "寒冰装甲，等级 0 / 20，未解锁" [ref=e121] [cursor=pointer]:
                      - generic [ref=e122]:
                        - img [ref=e123]
                        - generic [ref=e124]: 寒冰装甲
                      - generic [ref=e125]: 寒冰装甲
                      - generic [ref=e126]: 🔒
                      - generic [ref=e127]: 0/20
                    - button "暴风雪，等级 0 / 20，未解锁" [ref=e128] [cursor=pointer]:
                      - generic [ref=e129]:
                        - img [ref=e130]
                        - generic [ref=e131]: 暴风雪
                      - generic [ref=e132]: 暴风雪
                      - generic [ref=e133]: 🔒
                      - generic [ref=e134]: 0/20
                    - button "冰封球，等级 0 / 20，未解锁" [ref=e135] [cursor=pointer]:
                      - generic [ref=e136]:
                        - img [ref=e137]
                        - generic [ref=e138]: 冰封球
                      - generic [ref=e139]: 冰封球
                      - generic [ref=e140]: 🔒
                      - generic [ref=e141]: 0/20
                    - button "冰冷精通，等级 0 / 20，可学习" [ref=e142] [cursor=pointer]:
                      - generic [ref=e143]:
                        - img [ref=e144]
                        - generic [ref=e145]: 冰冷精通
                      - generic [ref=e146]: 冰冷精通
                      - generic [ref=e147]: 0/20
                - generic [ref=e148]:
                  - heading "闪电法术" [level=2] [ref=e149]
                  - paragraph [ref=e150]: 悬停、聚焦或点击节点，查看当前与下一级威力。
                  - generic [ref=e151]:
                    - img [ref=e152]
                    - button "充能弹，等级 0 / 20，可学习" [ref=e156] [cursor=pointer]:
                      - generic [ref=e157]:
                        - img [ref=e158]
                        - generic [ref=e159]: 充能弹
                      - generic [ref=e160]: 充能弹
                      - generic [ref=e161]: 0/20
                    - button "心灵传动，等级 0 / 20，可学习" [ref=e162] [cursor=pointer]:
                      - generic [ref=e163]:
                        - img [ref=e164]
                        - generic [ref=e165]: 心灵传动
                      - generic [ref=e166]: 心灵传动
                      - generic [ref=e167]: 0/20
                    - button "静电力场，等级 0 / 20，可学习" [ref=e168] [cursor=pointer]:
                      - generic [ref=e169]:
                        - img [ref=e170]
                        - generic [ref=e171]: 静电力场
                      - generic [ref=e172]: 静电力场
                      - generic [ref=e173]: 0/20
                    - button "新星，等级 0 / 20，未解锁" [ref=e174] [cursor=pointer]:
                      - generic [ref=e175]:
                        - img [ref=e176]
                        - generic [ref=e177]: 新星
                      - generic [ref=e178]: 新星
                      - generic [ref=e179]: 🔒
                      - generic [ref=e180]: 0/20
                    - button "闪电，等级 0 / 20，未解锁" [ref=e181] [cursor=pointer]:
                      - generic [ref=e182]:
                        - img [ref=e183]
                        - generic [ref=e184]: 闪电
                      - generic [ref=e185]: 闪电
                      - generic [ref=e186]: 🔒
                      - generic [ref=e187]: 0/20
                    - button "传送，等级 0 / 20，未解锁" [ref=e188] [cursor=pointer]:
                      - generic [ref=e189]:
                        - img [ref=e190]
                        - generic [ref=e191]: 传送
                      - generic [ref=e192]: 传送
                      - generic [ref=e193]: 🔒
                      - generic [ref=e194]: 0/20
                    - button "闪电链，等级 0 / 20，未解锁" [ref=e195] [cursor=pointer]:
                      - generic [ref=e196]:
                        - img [ref=e197]
                        - generic [ref=e198]: 闪电链
                      - generic [ref=e199]: 闪电链
                      - generic [ref=e200]: 🔒
                      - generic [ref=e201]: 0/20
                    - button "能量护盾，等级 0 / 20，未解锁" [ref=e202] [cursor=pointer]:
                      - generic [ref=e203]:
                        - img [ref=e204]
                        - generic [ref=e205]: 能量护盾
                      - generic [ref=e206]: 能量护盾
                      - generic [ref=e207]: 🔒
                      - generic [ref=e208]: 0/20
                    - button "雷暴，等级 0 / 20，未解锁" [ref=e209] [cursor=pointer]:
                      - generic [ref=e210]:
                        - img [ref=e211]
                        - generic [ref=e212]: 雷暴
                      - generic [ref=e213]: 雷暴
                      - generic [ref=e214]: 🔒
                      - generic [ref=e215]: 0/20
                    - button "闪电精通，等级 0 / 20，可学习" [active] [ref=e216] [cursor=pointer]:
                      - generic [ref=e217]:
                        - img [ref=e218]
                        - generic [ref=e219]: 闪电精通
                      - generic [ref=e220]: 闪电精通
                      - generic [ref=e221]: 0/20
                - generic [ref=e222]:
                  - heading "火焰法术" [level=2] [ref=e223]
                  - paragraph [ref=e224]: 悬停、聚焦或点击节点，查看当前与下一级威力。
                  - generic [ref=e225]:
                    - img [ref=e226]
                    - button "温暖，等级 0 / 20，可学习" [ref=e231] [cursor=pointer]:
                      - generic [ref=e232]:
                        - img [ref=e233]
                        - generic [ref=e234]: 温暖
                      - generic [ref=e235]: 温暖
                      - generic [ref=e236]: 0/20
                    - button "火弹，等级 1 / 20，已学习" [ref=e237] [cursor=pointer]:
                      - generic [ref=e238]:
                        - img [ref=e239]
                        - generic [ref=e240]: 火弹
                      - generic [ref=e241]: 火弹
                      - generic [ref=e242]: 1/20
                    - button "炼狱，等级 0 / 20，可学习" [ref=e243] [cursor=pointer]:
                      - generic [ref=e244]:
                        - img [ref=e245]
                        - generic [ref=e246]: 炼狱
                      - generic [ref=e247]: 炼狱
                      - generic [ref=e248]: 0/20
                    - button "火球术，等级 0 / 20，可学习" [ref=e249] [cursor=pointer]:
                      - generic [ref=e250]:
                        - img [ref=e251]
                        - generic [ref=e252]: 火球术
                      - generic [ref=e253]: 火球术
                      - generic [ref=e254]: 0/20
                    - button "炽烈之径，等级 0 / 20，未解锁" [ref=e255] [cursor=pointer]:
                      - generic [ref=e256]:
                        - img [ref=e257]
                        - generic [ref=e258]: 炽烈之径
                      - generic [ref=e259]: 炽烈之径
                      - generic [ref=e260]: 🔒
                      - generic [ref=e261]: 0/20
                    - button "附魔，等级 0 / 20，未解锁" [ref=e262] [cursor=pointer]:
                      - generic [ref=e263]:
                        - img [ref=e264]
                        - generic [ref=e265]: 附魔
                      - generic [ref=e266]: 附魔
                      - generic [ref=e267]: 🔒
                      - generic [ref=e268]: 0/20
                    - button "火墙，等级 0 / 20，未解锁" [ref=e269] [cursor=pointer]:
                      - generic [ref=e270]:
                        - img [ref=e271]
                        - generic [ref=e272]: 火墙
                      - generic [ref=e273]: 火墙
                      - generic [ref=e274]: 🔒
                      - generic [ref=e275]: 0/20
                    - button "流星术，等级 0 / 20，未解锁" [ref=e276] [cursor=pointer]:
                      - generic [ref=e277]:
                        - img [ref=e278]
                        - generic [ref=e279]: 流星术
                      - generic [ref=e280]: 流星术
                      - generic [ref=e281]: 🔒
                      - generic [ref=e282]: 0/20
                    - button "九头海蛇，等级 0 / 20，未解锁" [ref=e283] [cursor=pointer]:
                      - generic [ref=e284]:
                        - img [ref=e285]
                        - generic [ref=e286]: 九头海蛇
                      - generic [ref=e287]: 九头海蛇
                      - generic [ref=e288]: 🔒
                      - generic [ref=e289]: 0/20
                    - button "火焰精通，等级 0 / 20，可学习" [ref=e290] [cursor=pointer]:
                      - generic [ref=e291]:
                        - img [ref=e292]
                        - generic [ref=e293]: 火焰精通
                      - generic [ref=e294]: 火焰精通
                      - generic [ref=e295]: 0/20
              - generic [ref=e297]:
                - generic [ref=e298]:
                  - generic [ref=e299]:
                    - heading "雷暴" [level=2] [ref=e300]
                    - paragraph [ref=e301]: 未学习 / 20 · 主动
                  - button "需要前置" [disabled] [ref=e302]
                - paragraph [ref=e303]: 雷暴：造成 70 ~ 110 点闪电伤害。
                - generic [ref=e304]:
                  - generic [ref=e305]:
                    - heading "未学习" [level=3] [ref=e306]
                    - paragraph [ref=e307]: 投入技能点后显示当前属性。
                  - generic [ref=e308]:
                    - heading "学习后 Lv.1" [level=3] [ref=e309]
                    - generic [ref=e310]:
                      - generic [ref=e311]:
                        - term [ref=e312]: 闪电攻击
                        - definition [ref=e313]: 70 ~ 110
                      - generic [ref=e314]:
                        - term [ref=e315]: 法力消耗
                        - definition [ref=e316]: "30"
                      - generic [ref=e317]:
                        - term [ref=e318]: 冷却
                        - definition [ref=e319]: 4 秒
                      - generic [ref=e320]:
                        - term [ref=e321]: 附加
                        - definition [ref=e322]: 麻痹
                  - generic [ref=e323]:
                    - heading "需求" [level=3] [ref=e324]
                    - generic [ref=e325]:
                      - generic [ref=e326]:
                        - term [ref=e327]: 角色等级
                        - definition [ref=e328]: 等级 24已满足
                      - generic [ref=e329]:
                        - term [ref=e330]: 前置技能
                        - definition [ref=e331]: 闪电链（未学习）, 新星（未学习）
```

# Test source

```ts
  1   | /** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
  2   | import { expect, test, type Locator, type Page, type TestInfo } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { navTo } from '../e2e/_helpers';
  6   | 
  7   | const MASTERY = 'skills-sorceress-lightning-mastery';
  8   | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  9   | 
  10  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  11  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  12  | }
  13  | 
  14  | async function backup(page: Page): Promise<SaveCurrent> {
  15  |   await navTo(page, 'settings');
  16  |   const pending = page.waitForEvent('download');
  17  |   await page.getByTestId('export-save-button').click();
  18  |   const download = await pending;
  19  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  20  |   finally { await download.delete(); }
  21  | }
  22  | 
  23  | async function importSave(page: Page, save: SaveCurrent, english: boolean): Promise<void> {
  24  |   const label = english ? 'Import Save' : '导入存档';
  25  |   await page.getByRole('button', { name: label, exact: true }).click();
  26  |   const dialog = page.getByRole('dialog');
  27  |   await dialog.getByRole('textbox').fill(JSON.stringify(save));
  28  |   await dialog.getByRole('button', { name: label, exact: true }).click();
  29  |   await expect(dialog).toHaveCount(0);
  30  | }
  31  | 
  32  | /** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
  33  | async function hitPoints(target: Locator): Promise<unknown[]> {
  34  |   return target.evaluate(node => {
  35  |     const b = node.getBoundingClientRect();
  36  |     return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
  37  |       const px = b.left + b.width * x, py = b.top + b.height * y;
  38  |       const hit = document.elementFromPoint(px, py);
  39  |       return { x: px, y: py, clear: hit !== null && node.contains(hit), hit: hit?.tagName ?? null,
  40  |         hitText:hit?.textContent?.slice(0,120) ?? null, hitTestId:hit?.closest('[data-testid]')?.getAttribute('data-testid') ?? null };
  41  |     }));
  42  |   });
  43  | }
  44  | 
  45  | async function clearTarget(target: Locator, label: string): Promise<unknown[]> {
> 46  |   await target.scrollIntoViewIfNeeded();
      |                ^ Error: locator.scrollIntoViewIfNeeded: Test timeout of 50000ms exceeded.
  47  |   const points = await hitPoints(target);
  48  |   for (const point of points) expect.soft(point, label).toMatchObject({ clear: true });
  49  |   return points;
  50  | }
  51  | 
  52  | async function layout(page: Page, bonus: boolean): Promise<unknown> {
  53  |   const measured = await page.evaluate(() => {
  54  |     const main = document.querySelector('main');
  55  |     const hud = document.querySelector('[data-testid="character-hud"]');
  56  |     const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
  57  |     const header = main?.previousElementSibling;
  58  |     if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
  59  |     const rect = (node: Element) => {
  60  |       const b = node.getBoundingClientRect();
  61  |       return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height };
  62  |     };
  63  |     const h = rect(header), m = rect(main), u = rect(hud), c = chip ? rect(chip) : null;
  64  |     const contains = (a: typeof h, b: typeof h) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
  65  |     const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
  66  |       const b = rect(node);
  67  |       const visible = { left: Math.max(b.left,m.left), right: Math.min(b.right,m.right), top: Math.max(b.top,m.top), bottom: Math.min(b.bottom,m.bottom) };
  68  |       const shown = visible.right > visible.left && visible.bottom > visible.top;
  69  |       const overlaps = (a: typeof h) => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
  70  |       return { text: node.textContent, rect:b, visible, shown, hudCollision: overlaps(u), chipCollision: c !== null && overlaps(c) };
  71  |     });
  72  |     return { header: h, main: m, hud: u, chip: c, hudContained: contains(h,u), chipContained: c === null || contains(h,c),
  73  |       mainBelowHud: m.top >= u.bottom, mainBelowChip: c === null || m.top >= c.bottom,
  74  |       chipBelowButton: c === null || c.top >= u.bottom, chipOutsideButton: chip === null || !hud.contains(chip),
  75  |       documentOverflow: document.documentElement.scrollWidth - innerWidth,
  76  |       mainOverflow: main.scrollWidth - main.clientWidth, windowY: scrollY,
  77  |       shellY: main.parentElement?.parentElement?.scrollTop, mainY: main.scrollTop,
  78  |       mainScrollHeight: main.scrollHeight, mainClientHeight: main.clientHeight, targets };
  79  |   });
  80  |   expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  81  |   expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  82  |   expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  83  |   expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  84  |   expect.soft(measured.chipBelowButton).toBe(true);
  85  |   expect.soft(measured.chipOutsideButton).toBe(true);
  86  |   expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  87  |   expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  88  |   expect.soft(measured.windowY).toBe(0); expect.soft(measured.shellY).toBe(0);
  89  |   expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  90  |   expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  91  |   expect.soft(measured.main.height).toBeGreaterThan(0);
  92  |   expect.soft(measured.chip !== null).toBe(bonus);
  93  |   for (const target of measured.targets) {
  94  |     expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
  95  |     expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  96  |   }
  97  |   return measured;
  98  | }
  99  | 
  100 | for (const locale of ['en','zh-CN'] as const) for (const bonus of [false,true]) {
  101 |   test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({ page, context }, info) => {
  102 |     const english = locale === 'en';
  103 |     const errors: string[] = [];
  104 |     page.on('pageerror', error => errors.push(error.message));
  105 |     page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  106 |     await page.goto('/settings');
  107 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  108 |     await page.goto('/');
  109 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  110 |     await page.getByTestId('home-new-game').click();
  111 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  112 |     await page.getByTestId('class-sorceress').click();
  113 |     const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
  114 |     await page.getByTestId('character-name-input').fill(name);
  115 |     await page.getByTestId('character-start-btn').click();
  116 |     await expect(page.getByTestId('town-screen')).toBeVisible();
  117 |     await navTo(page,'settings');
  118 |     const language = page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true });
  119 |     await language.click();
  120 |     await expect(language).toHaveAttribute('aria-pressed','true');
  121 |     const fresh = await backup(page);
  122 |     expect(fresh.player.name).toBe(name);
  123 |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
  124 |       skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: ['skills-sorceress-fire-bolt'] },
  125 |       meta: { ...fresh.meta, idleState: { ...fresh.meta.idleState, lastOnline: Date.now(),
  126 |         activeMultiplier: bonus ? 1.5 : 1, multiplierSecondsRemaining: bonus ? 7200 : 0 } } };
  127 |     await importSave(page, incoming, english);
  128 |     await attach(info, '01-imported-eligibility', incoming);
  129 | 
  130 |     for (const route of ['town','settings','skills']) {
  131 |       await navTo(page, route);
  132 |       await expect(page.getByTestId('character-hud')).toHaveCount(1);
  133 |       await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
  134 |       await attach(info, `route-${route}`, await layout(page,bonus));
  135 |     }
  136 |     const panel = page.getByTestId('skill-detail-panel');
  137 |     await page.getByTestId(`skill-node-${MASTERY}`).click();
  138 |     const heading = panel.getByRole('heading', { name: english ? 'Lightning Mastery' : '闪电精通', exact: true });
  139 |     const allocate = panel.getByRole('button');
  140 |     const description = panel.locator('#skill-detail-panel > p');
  141 |     const metrics = [];
  142 |     for (const [width,height] of sizes) {
  143 |       await page.setViewportSize({ width,height });
  144 |       await description.scrollIntoViewIfNeeded();
  145 |       const originalPosition = await layout(page,bonus);
  146 |       if (width === 360 && height === 640) {
```