const {readFileSync,writeFileSync}=require('node:fs');
const {join}=require('node:path');
const {chromium}=require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({headless:true});
 try{
  const page=await browser.newPage();
  const sizes=[[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]];
  for(const label of ['en-bonus-off','en-bonus-on','zh-CN-bonus-off','zh-CN-bonus-on']){
   const inputs=sizes.map(([w,h])=>({title:`${label} ${w}x${h}`,src:'data:image/png;base64,'+readFileSync(join(__dirname,'browser-extracted-final',`${label}-layout-${w}x${h}.png`)).toString('base64')}));
   const data=await page.evaluate(async inputs=>{
    const canvas=document.createElement('canvas');canvas.width=1440;canvas.height=1600;const ctx=canvas.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,1440,1600);ctx.font='16px sans-serif';
    for(let i=0;i<inputs.length;i++){const im=new Image();im.src=inputs[i].src;await im.decode();const scale=Math.min(474/im.width,500/im.height);const w=im.width*scale,h=im.height*scale,x=(i%3)*480,y=Math.floor(i/3)*533;ctx.fillStyle='black';ctx.fillText(inputs[i].title,x+5,y+18);ctx.drawImage(im,x+(480-w)/2,y+26,w,h);}
    return canvas.toDataURL('image/jpeg',0.85).split(',')[1];
   },inputs);
   writeFileSync(join(__dirname,`contact-final-${label}.jpg`),Buffer.from(data,'base64'));
  }
  await page.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
