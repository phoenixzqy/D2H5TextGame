/** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { navTo } from '../e2e/_helpers';
const MASTERY = 'skills-sorceress-lightning-mastery';
const sizes = [[360, 640], [412, 915], [640, 360], [375, 667], [393, 851], [768, 1024], [1280, 800], [1920, 1080], [915, 412]];
async function attach(info, name, value) {
  await info.attach(name, {
    body: JSON.stringify(value, null, 2),
    contentType: 'application/json'
  });
}
async function backup(page) {
  await navTo(page, 'settings');
  const pending = page.waitForEvent('download');
  await page.getByTestId('export-save-button').click();
  const download = await pending;
  try {
    return JSON.parse(await readFile(await download.path(), 'utf8'));
  } finally {
    await download.delete();
  }
}
async function importSave(page, save, english) {
  const label = english ? 'Import Save' : '导入存档';
  await page.getByRole('button', {
    name: label,
    exact: true
  }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('textbox').fill(JSON.stringify(save));
  await dialog.getByRole('button', {
    name: label,
    exact: true
  }).click();
  await expect(dialog).toHaveCount(0);
}

/** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
async function hitPoints(target) {
  return target.evaluate(node => {
    const b = node.getBoundingClientRect();
    return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
      var _hit$tagName;
      const px = b.left + b.width * x,
        py = b.top + b.height * y;
      const hit = document.elementFromPoint(px, py);
      return {
        x: px,
        y: py,
        clear: hit !== null && node.contains(hit),
        hit: (_hit$tagName = hit === null || hit === void 0 ? void 0 : hit.tagName) !== null && _hit$tagName !== void 0 ? _hit$tagName : null
      };
    }));
  });
}
async function clearTarget(target, label) {
  await target.scrollIntoViewIfNeeded();
  const points = await hitPoints(target);
  for (const point of points) expect.soft(point, label).toMatchObject({
    clear: true
  });
  return points;
}
async function layout(page, bonus) {
  const measured = await page.evaluate(() => {
    var _main$parentElement;
    const main = document.querySelector('main');
    const hud = document.querySelector('[data-testid="character-hud"]');
    const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
    const header = main === null || main === void 0 ? void 0 : main.previousElementSibling;
    if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
    const rect = node => {
      const b = node.getBoundingClientRect();
      return {
        left: b.left,
        top: b.top,
        right: b.right,
        bottom: b.bottom,
        width: b.width,
        height: b.height
      };
    };
    const h = rect(header),
      m = rect(main),
      u = rect(hud),
      c = chip ? rect(chip) : null;
    const contains = (a, b) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
    const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
      const b = rect(node);
      const visible = {
        left: Math.max(b.left, m.left),
        right: Math.min(b.right, m.right),
        top: Math.max(b.top, m.top),
        bottom: Math.min(b.bottom, m.bottom)
      };
      const shown = visible.right > visible.left && visible.bottom > visible.top;
      const overlaps = a => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
      return {
        text: node.textContent,
        rect: b,
        visible,
        shown,
        hudCollision: overlaps(u),
        chipCollision: c !== null && overlaps(c)
      };
    });
    return {
      header: h,
      main: m,
      hud: u,
      chip: c,
      hudContained: contains(h, u),
      chipContained: c === null || contains(h, c),
      mainBelowHud: m.top >= u.bottom,
      mainBelowChip: c === null || m.top >= c.bottom,
      chipBelowButton: c === null || c.top >= u.bottom,
      chipOutsideButton: chip === null || !hud.contains(chip),
      documentOverflow: document.documentElement.scrollWidth - innerWidth,
      mainOverflow: main.scrollWidth - main.clientWidth,
      windowY: scrollY,
      shellY: (_main$parentElement = main.parentElement) === null || _main$parentElement === void 0 || (_main$parentElement = _main$parentElement.parentElement) === null || _main$parentElement === void 0 ? void 0 : _main$parentElement.scrollTop,
      mainY: main.scrollTop,
      mainScrollHeight: main.scrollHeight,
      mainClientHeight: main.clientHeight,
      targets
    };
  });
  expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  expect.soft(measured.chipBelowButton).toBe(true);
  expect.soft(measured.chipOutsideButton).toBe(true);
  expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.windowY).toBe(0);
  expect.soft(measured.shellY).toBe(0);
  expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  expect.soft(measured.main.height).toBeGreaterThan(0);
  expect.soft(measured.chip !== null).toBe(bonus);
  for (const target of measured.targets) {
    expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
    expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  }
  return measured;
}
for (const locale of ['en', 'zh-CN']) for (const bonus of [false, true]) {
  test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({
    page,
    context
  }, info) => {
    const english = locale === 'en';
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`);
    });
    await page.goto('/settings');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.goto('/');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('home-new-game').click();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('class-sorceress').click();
    const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
    await page.getByTestId('character-name-input').fill(name);
    await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    await navTo(page, 'settings');
    const language = page.getByRole('button', {
      name: english ? 'English' : '简体中文',
      exact: true
    });
    await language.click();
    await expect(language).toHaveAttribute('aria-pressed', 'true');
    const fresh = await backup(page);
    expect(fresh.player.name).toBe(name);
    const incoming = {
      ...fresh,
      player: {
        ...fresh.player,
        level: 30,
        skillPoints: 2,
        skillLevels: {
          'sorceress.fire_bolt': 1
        },
        comboOrder: ['skills-sorceress-fire-bolt']
      },
      meta: {
        ...fresh.meta,
        idleState: {
          ...fresh.meta.idleState,
          lastOnline: Date.now(),
          activeMultiplier: bonus ? 1.5 : 1,
          multiplierSecondsRemaining: bonus ? 7200 : 0
        }
      }
    };
    await importSave(page, incoming, english);
    await attach(info, '01-imported-eligibility', incoming);
    for (const route of ['town', 'settings', 'skills']) {
      await navTo(page, route);
      await expect(page.getByTestId('character-hud')).toHaveCount(1);
      await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
      await attach(info, `route-${route}`, await layout(page, bonus));
    }
    const panel = page.getByTestId('skill-detail-panel');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    const heading = panel.getByRole('heading', {
      name: english ? 'Lightning Mastery' : '闪电精通',
      exact: true
    });
    const allocate = panel.getByRole('button');
    const description = panel.locator('#skill-detail-panel > p');
    const metrics = [];
    for (const [width, height] of sizes) {
      await page.setViewportSize({
        width,
        height
      });
      await description.scrollIntoViewIfNeeded();
      const originalPosition = await layout(page, bonus);
      if (width === 360 && height === 640) {
        expect.soft(await page.locator('main').evaluate(node => node.scrollTop), 'baseline detail scrolls inside main').toBeGreaterThan(0);
      }
      await info.attach(`layout-${String(width)}x${String(height)}`, {
        body: await page.screenshot(),
        contentType: 'image/png'
      });
      const headingHits = await clearTarget(heading, `${String(width)}x${String(height)} heading`);
      const actionHits = await clearTarget(allocate, `${String(width)}x${String(height)} Allocate`);
      if (!english && width === 360) {
        const cdp = await context.newCDPSession(page);
        try {
          await cdp.send('DOM.enable');
          await cdp.send('CSS.enable');
          const document = await cdp.send('DOM.getDocument');
          const node = await cdp.send('DOM.querySelector', {
            nodeId: document.root.nodeId,
            selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p'
          });
          const fonts = await cdp.send('CSS.getPlatformFontsForNode', {
            nodeId: node.nodeId
          });
          expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
          await attach(info, 'actual-Chinese-platform-fonts', fonts);
        } finally {
          await cdp.detach();
        }
      }
      metrics.push({
        width,
        height,
        originalPosition,
        headingHits,
        actionHits
      });
    }
    await attach(info, '02-layout-metrics', metrics);
    await page.setViewportSize({
      width: 375,
      height: 667
    });
    await description.scrollIntoViewIfNeeded();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await allocate.click(); // Ordinary pointer; Playwright must resolve the actual target.
    await expect(panel).toContainText(english ? 'Lv. 1/20' : '等级 1/20');
    const rank1 = await backup(page);
    expect(rank1.player).toEqual({
      ...incoming.player,
      skillPoints: 1,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 1
      }
    });
    await navTo(page, 'skills');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    await page.setViewportSize({
      width: 915,
      height: 412
    });
    let reached = false;
    for (let step = 0; step < 100; step++) {
      await page.keyboard.press('Tab');
      if (await allocate.evaluate(node => node === document.activeElement)) {
        reached = true;
        break;
      }
    }
    expect(reached).toBe(true);
    await expect(heading).toBeVisible();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await expect(allocate).toBeEnabled();
    await expect(allocate).toBeFocused();
    await clearTarget(allocate, 'keyboard target');
    await page.keyboard.press('Enter');
    await expect(panel).toContainText(english ? 'Lv. 2/20' : '等级 2/20');
    const rank2 = await backup(page);
    expect(rank2.player).toEqual({
      ...rank1.player,
      skillPoints: 0,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 2
      }
    });
    for (const slice of ['inventory', 'mercs', 'map', 'formation']) expect(rank2[slice]).toEqual(incoming[slice]);
    await attach(info, '03-pointer-keyboard-allocation', {
      rank1,
      rank2
    });

    // Real dialog remains above the shared header, including with an active chip.
    const label = english ? 'Import Save' : '导入存档';
    await page.getByRole('button', {
      name: label,
      exact: true
    }).click();
    const modalPriority = await page.evaluate(() => {
      const dialog = document.querySelector('[role="dialog"]');
      return [...document.querySelectorAll('[data-testid="character-hud"], [data-testid="offline-bonus-chip"]')].flatMap(node => {
        const b = node.getBoundingClientRect();
        return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
          const px = b.left + b.width * x,
            py = b.top + b.height * y;
          const hit = document.elementFromPoint(px, py);
          return {
            target: node.getAttribute('data-testid'),
            x: px,
            y: py,
            modalOwnsHit: hit !== null && dialog !== null && dialog.contains(hit)
          };
        }));
      });
    });
    await attach(info, 'modal-priority-at-header', modalPriority);
    expect(modalPriority).toHaveLength(bonus ? 18 : 9);
    for (const point of modalPriority) expect.soft(point).toMatchObject({
      modalOwnsHit: true
    });
    const cancel = page.getByRole('dialog').getByRole('button', {
      name: english ? 'Cancel' : '取消',
      exact: true
    });
    await clearTarget(cancel, 'modal cancel');
    await cancel.click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await page.getByTestId('character-hud').click();
    await expect(page.getByTestId('character-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await navTo(page, 'combat');
    await expect(page.getByTestId('combat-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    const combatHeader = page.getByTestId('combat-screen').locator('header');
    const width = await combatHeader.evaluate(node => {
      var _node$firstElementChi;
      return {
        outer: node.clientWidth,
        inner: (_node$firstElementChi = node.firstElementChild) === null || _node$firstElementChi === void 0 ? void 0 : _node$firstElementChi.getBoundingClientRect().width
      };
    });
    expect(width.inner).toBeGreaterThanOrEqual(width.outer - 32);
    await navTo(page, 'skills');
    await expect(page.getByTestId('character-hud')).toHaveCount(1);
    expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
    await attach(info, '04-console-errors', errors);
    expect(errors).toEqual([]);
    await page.close();
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwicmVhZEZpbGUiLCJuYXZUbyIsIk1BU1RFUlkiLCJzaXplcyIsImF0dGFjaCIsImluZm8iLCJuYW1lIiwidmFsdWUiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnRUeXBlIiwiYmFja3VwIiwicGFnZSIsInBlbmRpbmciLCJ3YWl0Rm9yRXZlbnQiLCJnZXRCeVRlc3RJZCIsImNsaWNrIiwiZG93bmxvYWQiLCJwYXJzZSIsInBhdGgiLCJkZWxldGUiLCJpbXBvcnRTYXZlIiwic2F2ZSIsImVuZ2xpc2giLCJsYWJlbCIsImdldEJ5Um9sZSIsImV4YWN0IiwiZGlhbG9nIiwiZmlsbCIsInRvSGF2ZUNvdW50IiwiaGl0UG9pbnRzIiwidGFyZ2V0IiwiZXZhbHVhdGUiLCJub2RlIiwiYiIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImZsYXRNYXAiLCJ4IiwibWFwIiwieSIsIl9oaXQkdGFnTmFtZSIsInB4IiwibGVmdCIsIndpZHRoIiwicHkiLCJ0b3AiLCJoZWlnaHQiLCJoaXQiLCJkb2N1bWVudCIsImVsZW1lbnRGcm9tUG9pbnQiLCJjbGVhciIsImNvbnRhaW5zIiwidGFnTmFtZSIsImNsZWFyVGFyZ2V0Iiwic2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCIsInBvaW50cyIsInBvaW50Iiwic29mdCIsInRvTWF0Y2hPYmplY3QiLCJsYXlvdXQiLCJib251cyIsIm1lYXN1cmVkIiwiX21haW4kcGFyZW50RWxlbWVudCIsIm1haW4iLCJxdWVyeVNlbGVjdG9yIiwiaHVkIiwiY2hpcCIsImhlYWRlciIsInByZXZpb3VzRWxlbWVudFNpYmxpbmciLCJFcnJvciIsInJlY3QiLCJyaWdodCIsImJvdHRvbSIsImgiLCJtIiwidSIsImMiLCJhIiwidGFyZ2V0cyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJ2aXNpYmxlIiwiTWF0aCIsIm1heCIsIm1pbiIsInNob3duIiwib3ZlcmxhcHMiLCJ0ZXh0IiwidGV4dENvbnRlbnQiLCJodWRDb2xsaXNpb24iLCJjaGlwQ29sbGlzaW9uIiwiaHVkQ29udGFpbmVkIiwiY2hpcENvbnRhaW5lZCIsIm1haW5CZWxvd0h1ZCIsIm1haW5CZWxvd0NoaXAiLCJjaGlwQmVsb3dCdXR0b24iLCJjaGlwT3V0c2lkZUJ1dHRvbiIsImRvY3VtZW50T3ZlcmZsb3ciLCJkb2N1bWVudEVsZW1lbnQiLCJzY3JvbGxXaWR0aCIsImlubmVyV2lkdGgiLCJtYWluT3ZlcmZsb3ciLCJjbGllbnRXaWR0aCIsIndpbmRvd1kiLCJzY3JvbGxZIiwic2hlbGxZIiwicGFyZW50RWxlbWVudCIsInNjcm9sbFRvcCIsIm1haW5ZIiwibWFpblNjcm9sbEhlaWdodCIsInNjcm9sbEhlaWdodCIsIm1haW5DbGllbnRIZWlnaHQiLCJjbGllbnRIZWlnaHQiLCJ0b0JlIiwidG9CZUxlc3NUaGFuT3JFcXVhbCIsInRvQmVHcmVhdGVyVGhhbk9yRXF1YWwiLCJ0b0JlR3JlYXRlclRoYW4iLCJsb2NhbGUiLCJTdHJpbmciLCJjb250ZXh0IiwiZXJyb3JzIiwib24iLCJlcnJvciIsInB1c2giLCJtZXNzYWdlIiwidHlwZSIsImdvdG8iLCJyZXBlYXQiLCJ0b0JlVmlzaWJsZSIsImxhbmd1YWdlIiwidG9IYXZlQXR0cmlidXRlIiwiZnJlc2giLCJwbGF5ZXIiLCJpbmNvbWluZyIsImxldmVsIiwic2tpbGxQb2ludHMiLCJza2lsbExldmVscyIsImNvbWJvT3JkZXIiLCJtZXRhIiwiaWRsZVN0YXRlIiwibGFzdE9ubGluZSIsIkRhdGUiLCJub3ciLCJhY3RpdmVNdWx0aXBsaWVyIiwibXVsdGlwbGllclNlY29uZHNSZW1haW5pbmciLCJyb3V0ZSIsInRvSGF2ZUFjY2Vzc2libGVOYW1lIiwiUmVnRXhwIiwicGFuZWwiLCJoZWFkaW5nIiwiYWxsb2NhdGUiLCJkZXNjcmlwdGlvbiIsImxvY2F0b3IiLCJtZXRyaWNzIiwic2V0Vmlld3BvcnRTaXplIiwib3JpZ2luYWxQb3NpdGlvbiIsInNjcmVlbnNob3QiLCJoZWFkaW5nSGl0cyIsImFjdGlvbkhpdHMiLCJjZHAiLCJuZXdDRFBTZXNzaW9uIiwic2VuZCIsIm5vZGVJZCIsInJvb3QiLCJzZWxlY3RvciIsImZvbnRzIiwic29tZSIsImZvbnQiLCJmYW1pbHlOYW1lIiwiZ2x5cGhDb3VudCIsImRldGFjaCIsInRvSGF2ZVRleHQiLCJ0b0NvbnRhaW5UZXh0IiwicmFuazEiLCJ0b0VxdWFsIiwicmVhY2hlZCIsInN0ZXAiLCJrZXlib2FyZCIsInByZXNzIiwiYWN0aXZlRWxlbWVudCIsInRvQmVFbmFibGVkIiwidG9CZUZvY3VzZWQiLCJyYW5rMiIsInNsaWNlIiwibW9kYWxQcmlvcml0eSIsImdldEF0dHJpYnV0ZSIsIm1vZGFsT3duc0hpdCIsInRvSGF2ZUxlbmd0aCIsImNhbmNlbCIsImNvbWJhdEhlYWRlciIsIl9ub2RlJGZpcnN0RWxlbWVudENoaSIsIm91dGVyIiwiaW5uZXIiLCJmaXJzdEVsZW1lbnRDaGlsZCIsIndpbmRvdyIsImNsb3NlIl0sInNvdXJjZXMiOlsic2tpbGxzLWhlYWRlci1sYXlvdXQuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogUHJvZHVjdGlvbiBsYXlvdXQgcmVncmVzc2lvbjsgZXhwbGljaXRseSBpbXBvcnRlZCBMMzAvYm9udXMgZWxpZ2liaWxpdHksIG5vIGdhbWUgYnJpZGdlLiAqL1xuaW1wb3J0IHsgZXhwZWN0LCB0ZXN0LCB0eXBlIExvY2F0b3IsIHR5cGUgUGFnZSwgdHlwZSBUZXN0SW5mbyB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHsgcmVhZEZpbGUgfSBmcm9tICdub2RlOmZzL3Byb21pc2VzJztcbmltcG9ydCB0eXBlIHsgU2F2ZUN1cnJlbnQgfSBmcm9tICcuLi8uLi9zcmMvZW5naW5lL3R5cGVzL3NhdmUnO1xuaW1wb3J0IHsgbmF2VG8gfSBmcm9tICcuLi9lMmUvX2hlbHBlcnMnO1xuXG5jb25zdCBNQVNURVJZID0gJ3NraWxscy1zb3JjZXJlc3MtbGlnaHRuaW5nLW1hc3RlcnknO1xuY29uc3Qgc2l6ZXMgPSBbWzM2MCw2NDBdLFs0MTIsOTE1XSxbNjQwLDM2MF0sWzM3NSw2NjddLFszOTMsODUxXSxbNzY4LDEwMjRdLFsxMjgwLDgwMF0sWzE5MjAsMTA4MF0sWzkxNSw0MTJdXSBhcyBjb25zdDtcblxuYXN5bmMgZnVuY3Rpb24gYXR0YWNoKGluZm86IFRlc3RJbmZvLCBuYW1lOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGluZm8uYXR0YWNoKG5hbWUsIHsgYm9keTogSlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpLCBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBiYWNrdXAocGFnZTogUGFnZSk6IFByb21pc2U8U2F2ZUN1cnJlbnQ+IHtcbiAgYXdhaXQgbmF2VG8ocGFnZSwgJ3NldHRpbmdzJyk7XG4gIGNvbnN0IHBlbmRpbmcgPSBwYWdlLndhaXRGb3JFdmVudCgnZG93bmxvYWQnKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnZXhwb3J0LXNhdmUtYnV0dG9uJykuY2xpY2soKTtcbiAgY29uc3QgZG93bmxvYWQgPSBhd2FpdCBwZW5kaW5nO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZShhd2FpdCByZWFkRmlsZShhd2FpdCBkb3dubG9hZC5wYXRoKCksICd1dGY4JykpIGFzIFNhdmVDdXJyZW50OyB9XG4gIGZpbmFsbHkgeyBhd2FpdCBkb3dubG9hZC5kZWxldGUoKTsgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBpbXBvcnRTYXZlKHBhZ2U6IFBhZ2UsIHNhdmU6IFNhdmVDdXJyZW50LCBlbmdsaXNoOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGxhYmVsID0gZW5nbGlzaCA/ICdJbXBvcnQgU2F2ZScgOiAn5a+85YWl5a2Y5qGjJztcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogbGFiZWwsIGV4YWN0OiB0cnVlIH0pLmNsaWNrKCk7XG4gIGNvbnN0IGRpYWxvZyA9IHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKTtcbiAgYXdhaXQgZGlhbG9nLmdldEJ5Um9sZSgndGV4dGJveCcpLmZpbGwoSlNPTi5zdHJpbmdpZnkoc2F2ZSkpO1xuICBhd2FpdCBkaWFsb2cuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IGxhYmVsLCBleGFjdDogdHJ1ZSB9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QoZGlhbG9nKS50b0hhdmVDb3VudCgwKTtcbn1cblxuLyoqIFJlYWQtb25seSBlZGdlL2NlbnRlciBoaXQgdGVzdHMgY2F0Y2ggcGFydGlhbCBvYnN0cnVjdGlvbiB0aGF0IHRvQmVWaXNpYmxlIG1pc3Nlcy4gKi9cbmFzeW5jIGZ1bmN0aW9uIGhpdFBvaW50cyh0YXJnZXQ6IExvY2F0b3IpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICByZXR1cm4gdGFyZ2V0LmV2YWx1YXRlKG5vZGUgPT4ge1xuICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHJldHVybiBbMC4wNSwgMC41LCAwLjk1XS5mbGF0TWFwKHggPT4gWzAuMDUsIDAuNSwgMC45NV0ubWFwKHkgPT4ge1xuICAgICAgY29uc3QgcHggPSBiLmxlZnQgKyBiLndpZHRoICogeCwgcHkgPSBiLnRvcCArIGIuaGVpZ2h0ICogeTtcbiAgICAgIGNvbnN0IGhpdCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQocHgsIHB5KTtcbiAgICAgIHJldHVybiB7IHg6IHB4LCB5OiBweSwgY2xlYXI6IGhpdCAhPT0gbnVsbCAmJiBub2RlLmNvbnRhaW5zKGhpdCksIGhpdDogaGl0Py50YWdOYW1lID8/IG51bGwgfTtcbiAgICB9KSk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjbGVhclRhcmdldCh0YXJnZXQ6IExvY2F0b3IsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICBhd2FpdCB0YXJnZXQuc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICBjb25zdCBwb2ludHMgPSBhd2FpdCBoaXRQb2ludHModGFyZ2V0KTtcbiAgZm9yIChjb25zdCBwb2ludCBvZiBwb2ludHMpIGV4cGVjdC5zb2Z0KHBvaW50LCBsYWJlbCkudG9NYXRjaE9iamVjdCh7IGNsZWFyOiB0cnVlIH0pO1xuICByZXR1cm4gcG9pbnRzO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsYXlvdXQocGFnZTogUGFnZSwgYm9udXM6IGJvb2xlYW4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgY29uc3QgbWVhc3VyZWQgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICBjb25zdCBtYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWFpbicpO1xuICAgIGNvbnN0IGh1ZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXRlc3RpZD1cImNoYXJhY3Rlci1odWRcIl0nKTtcbiAgICBjb25zdCBjaGlwID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtdGVzdGlkPVwib2ZmbGluZS1ib251cy1jaGlwXCJdJyk7XG4gICAgY29uc3QgaGVhZGVyID0gbWFpbj8ucHJldmlvdXNFbGVtZW50U2libGluZztcbiAgICBpZiAoIW1haW4gfHwgIWh1ZCB8fCAhaGVhZGVyKSB0aHJvdyBuZXcgRXJyb3IoJ0V4cGVjdGVkIG1haW4sIEhVRCBhbmQgc2NyZWVuIGhlYWRlcicpO1xuICAgIGNvbnN0IHJlY3QgPSAobm9kZTogRWxlbWVudCkgPT4ge1xuICAgICAgY29uc3QgYiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICByZXR1cm4geyBsZWZ0OiBiLmxlZnQsIHRvcDogYi50b3AsIHJpZ2h0OiBiLnJpZ2h0LCBib3R0b206IGIuYm90dG9tLCB3aWR0aDogYi53aWR0aCwgaGVpZ2h0OiBiLmhlaWdodCB9O1xuICAgIH07XG4gICAgY29uc3QgaCA9IHJlY3QoaGVhZGVyKSwgbSA9IHJlY3QobWFpbiksIHUgPSByZWN0KGh1ZCksIGMgPSBjaGlwID8gcmVjdChjaGlwKSA6IG51bGw7XG4gICAgY29uc3QgY29udGFpbnMgPSAoYTogdHlwZW9mIGgsIGI6IHR5cGVvZiBoKSA9PiBiLmxlZnQgPj0gYS5sZWZ0ICYmIGIucmlnaHQgPD0gYS5yaWdodCAmJiBiLnRvcCA+PSBhLnRvcCAmJiBiLmJvdHRvbSA8PSBhLmJvdHRvbTtcbiAgICBjb25zdCB0YXJnZXRzID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLXRlc3RpZD1cInNraWxsLWRldGFpbC1wYW5lbFwiXSBoMiwgW2RhdGEtdGVzdGlkPVwic2tpbGwtZGV0YWlsLXBhbmVsXCJdIGJ1dHRvbicpXS5tYXAobm9kZSA9PiB7XG4gICAgICBjb25zdCBiID0gcmVjdChub2RlKTtcbiAgICAgIGNvbnN0IHZpc2libGUgPSB7IGxlZnQ6IE1hdGgubWF4KGIubGVmdCxtLmxlZnQpLCByaWdodDogTWF0aC5taW4oYi5yaWdodCxtLnJpZ2h0KSwgdG9wOiBNYXRoLm1heChiLnRvcCxtLnRvcCksIGJvdHRvbTogTWF0aC5taW4oYi5ib3R0b20sbS5ib3R0b20pIH07XG4gICAgICBjb25zdCBzaG93biA9IHZpc2libGUucmlnaHQgPiB2aXNpYmxlLmxlZnQgJiYgdmlzaWJsZS5ib3R0b20gPiB2aXNpYmxlLnRvcDtcbiAgICAgIGNvbnN0IG92ZXJsYXBzID0gKGE6IHR5cGVvZiBoKSA9PiBzaG93biAmJiB2aXNpYmxlLmxlZnQgPCBhLnJpZ2h0ICYmIHZpc2libGUucmlnaHQgPiBhLmxlZnQgJiYgdmlzaWJsZS50b3AgPCBhLmJvdHRvbSAmJiB2aXNpYmxlLmJvdHRvbSA+IGEudG9wO1xuICAgICAgcmV0dXJuIHsgdGV4dDogbm9kZS50ZXh0Q29udGVudCwgcmVjdDpiLCB2aXNpYmxlLCBzaG93biwgaHVkQ29sbGlzaW9uOiBvdmVybGFwcyh1KSwgY2hpcENvbGxpc2lvbjogYyAhPT0gbnVsbCAmJiBvdmVybGFwcyhjKSB9O1xuICAgIH0pO1xuICAgIHJldHVybiB7IGhlYWRlcjogaCwgbWFpbjogbSwgaHVkOiB1LCBjaGlwOiBjLCBodWRDb250YWluZWQ6IGNvbnRhaW5zKGgsdSksIGNoaXBDb250YWluZWQ6IGMgPT09IG51bGwgfHwgY29udGFpbnMoaCxjKSxcbiAgICAgIG1haW5CZWxvd0h1ZDogbS50b3AgPj0gdS5ib3R0b20sIG1haW5CZWxvd0NoaXA6IGMgPT09IG51bGwgfHwgbS50b3AgPj0gYy5ib3R0b20sXG4gICAgICBjaGlwQmVsb3dCdXR0b246IGMgPT09IG51bGwgfHwgYy50b3AgPj0gdS5ib3R0b20sIGNoaXBPdXRzaWRlQnV0dG9uOiBjaGlwID09PSBudWxsIHx8ICFodWQuY29udGFpbnMoY2hpcCksXG4gICAgICBkb2N1bWVudE92ZXJmbG93OiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGggLSBpbm5lcldpZHRoLFxuICAgICAgbWFpbk92ZXJmbG93OiBtYWluLnNjcm9sbFdpZHRoIC0gbWFpbi5jbGllbnRXaWR0aCwgd2luZG93WTogc2Nyb2xsWSxcbiAgICAgIHNoZWxsWTogbWFpbi5wYXJlbnRFbGVtZW50Py5wYXJlbnRFbGVtZW50Py5zY3JvbGxUb3AsIG1haW5ZOiBtYWluLnNjcm9sbFRvcCxcbiAgICAgIG1haW5TY3JvbGxIZWlnaHQ6IG1haW4uc2Nyb2xsSGVpZ2h0LCBtYWluQ2xpZW50SGVpZ2h0OiBtYWluLmNsaWVudEhlaWdodCwgdGFyZ2V0cyB9O1xuICB9KTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuaHVkQ29udGFpbmVkLCAnaGVhZGVyIHJlc2VydmVzIGFjdHVhbCBIVUQgaGVpZ2h0JykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcENvbnRhaW5lZCwgJ2hlYWRlciByZXNlcnZlcyBhY3RpdmUgYm9udXMgY2hpcCBoZWlnaHQnKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluQmVsb3dIdWQsICdtYWluIGNhbm5vdCBzY3JvbGwgdW5kZXIgSFVEJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbkJlbG93Q2hpcCwgJ21haW4gY2Fubm90IHNjcm9sbCB1bmRlciBjaGlwJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcEJlbG93QnV0dG9uKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwT3V0c2lkZUJ1dHRvbikudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuZG9jdW1lbnRPdmVyZmxvdykudG9CZUxlc3NUaGFuT3JFcXVhbCgwKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbk92ZXJmbG93KS50b0JlTGVzc1RoYW5PckVxdWFsKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC53aW5kb3dZKS50b0JlKDApOyBleHBlY3Quc29mdChtZWFzdXJlZC5zaGVsbFkpLnRvQmUoMCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC53aWR0aCkudG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCg0NCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC5oZWlnaHQpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoNDQpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluLmhlaWdodCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwICE9PSBudWxsKS50b0JlKGJvbnVzKTtcbiAgZm9yIChjb25zdCB0YXJnZXQgb2YgbWVhc3VyZWQudGFyZ2V0cykge1xuICAgIGV4cGVjdC5zb2Z0KHRhcmdldC5odWRDb2xsaXNpb24sICd2aXNpYmxlIGRldGFpbCByZW1haW5zIGNsZWFyIG9mIEhVRCBhdCBvcmlnaW5hbCBzY3JvbGwgcG9zaXRpb24nKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Quc29mdCh0YXJnZXQuY2hpcENvbGxpc2lvbiwgJ3Zpc2libGUgZGV0YWlsIHJlbWFpbnMgY2xlYXIgb2YgYWN0aXZlIGNoaXAgYXQgb3JpZ2luYWwgc2Nyb2xsIHBvc2l0aW9uJykudG9CZShmYWxzZSk7XG4gIH1cbiAgcmV0dXJuIG1lYXN1cmVkO1xufVxuXG5mb3IgKGNvbnN0IGxvY2FsZSBvZiBbJ2VuJywnemgtQ04nXSBhcyBjb25zdCkgZm9yIChjb25zdCBib251cyBvZiBbZmFsc2UsdHJ1ZV0pIHtcbiAgdGVzdChgc2hhcmVkIGhlYWRlciBzdGF5cyBjbGVhciAke2xvY2FsZX0gYm9udXM9JHtTdHJpbmcoYm9udXMpfWAsIGFzeW5jICh7IHBhZ2UsIGNvbnRleHQgfSwgaW5mbykgPT4ge1xuICAgIGNvbnN0IGVuZ2xpc2ggPSBsb2NhbGUgPT09ICdlbic7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICAgIHBhZ2Uub24oJ3BhZ2VlcnJvcicsIGVycm9yID0+IGVycm9ycy5wdXNoKGVycm9yLm1lc3NhZ2UpKTtcbiAgICBwYWdlLm9uKCdjb25zb2xlJywgbWVzc2FnZSA9PiB7IGlmIChtZXNzYWdlLnR5cGUoKSA9PT0gJ2Vycm9yJyB8fCBtZXNzYWdlLnR5cGUoKSA9PT0gJ3dhcm5pbmcnKSBlcnJvcnMucHVzaChgJHttZXNzYWdlLnR5cGUoKX06ICR7bWVzc2FnZS50ZXh0KCl9YCk7IH0pO1xuICAgIGF3YWl0IHBhZ2UuZ290bygnL3NldHRpbmdzJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nb3RvKCcvJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnaG9tZS1uZXctZ2FtZScpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2xhc3Mtc29yY2VyZXNzJykuY2xpY2soKTtcbiAgICBjb25zdCBuYW1lID0gZW5nbGlzaCA/ICdNTU1NTU1NTU1NTU1NTU1NJyA6ICfpl6onLnJlcGVhdCgxNik7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLW5hbWUtaW5wdXQnKS5maWxsKG5hbWUpO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1zdGFydC1idG4nKS5jbGljaygpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCd0b3duLXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NldHRpbmdzJyk7XG4gICAgY29uc3QgbGFuZ3VhZ2UgPSBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiBlbmdsaXNoID8gJ0VuZ2xpc2gnIDogJ+eugOS9k+S4reaWhycsIGV4YWN0OiB0cnVlIH0pO1xuICAgIGF3YWl0IGxhbmd1YWdlLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KGxhbmd1YWdlKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtcHJlc3NlZCcsJ3RydWUnKTtcbiAgICBjb25zdCBmcmVzaCA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QoZnJlc2gucGxheWVyLm5hbWUpLnRvQmUobmFtZSk7XG4gICAgY29uc3QgaW5jb21pbmc6IFNhdmVDdXJyZW50ID0geyAuLi5mcmVzaCwgcGxheWVyOiB7IC4uLmZyZXNoLnBsYXllciwgbGV2ZWw6IDMwLCBza2lsbFBvaW50czogMixcbiAgICAgIHNraWxsTGV2ZWxzOiB7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzogMSB9LCBjb21ib09yZGVyOiBbJ3NraWxscy1zb3JjZXJlc3MtZmlyZS1ib2x0J10gfSxcbiAgICAgIG1ldGE6IHsgLi4uZnJlc2gubWV0YSwgaWRsZVN0YXRlOiB7IC4uLmZyZXNoLm1ldGEuaWRsZVN0YXRlLCBsYXN0T25saW5lOiBEYXRlLm5vdygpLFxuICAgICAgICBhY3RpdmVNdWx0aXBsaWVyOiBib251cyA/IDEuNSA6IDEsIG11bHRpcGxpZXJTZWNvbmRzUmVtYWluaW5nOiBib251cyA/IDcyMDAgOiAwIH0gfSB9O1xuICAgIGF3YWl0IGltcG9ydFNhdmUocGFnZSwgaW5jb21pbmcsIGVuZ2xpc2gpO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCAnMDEtaW1wb3J0ZWQtZWxpZ2liaWxpdHknLCBpbmNvbWluZyk7XG5cbiAgICBmb3IgKGNvbnN0IHJvdXRlIG9mIFsndG93bicsJ3NldHRpbmdzJywnc2tpbGxzJ10pIHtcbiAgICAgIGF3YWl0IG5hdlRvKHBhZ2UsIHJvdXRlKTtcbiAgICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDEpO1xuICAgICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQWNjZXNzaWJsZU5hbWUobmV3IFJlZ0V4cChuYW1lKSk7XG4gICAgICBhd2FpdCBhdHRhY2goaW5mbywgYHJvdXRlLSR7cm91dGV9YCwgYXdhaXQgbGF5b3V0KHBhZ2UsYm9udXMpKTtcbiAgICB9XG4gICAgY29uc3QgcGFuZWwgPSBwYWdlLmdldEJ5VGVzdElkKCdza2lsbC1kZXRhaWwtcGFuZWwnKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKGBza2lsbC1ub2RlLSR7TUFTVEVSWX1gKS5jbGljaygpO1xuICAgIGNvbnN0IGhlYWRpbmcgPSBwYW5lbC5nZXRCeVJvbGUoJ2hlYWRpbmcnLCB7IG5hbWU6IGVuZ2xpc2ggPyAnTGlnaHRuaW5nIE1hc3RlcnknIDogJ+mXqueUteeyvumAmicsIGV4YWN0OiB0cnVlIH0pO1xuICAgIGNvbnN0IGFsbG9jYXRlID0gcGFuZWwuZ2V0QnlSb2xlKCdidXR0b24nKTtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHBhbmVsLmxvY2F0b3IoJyNza2lsbC1kZXRhaWwtcGFuZWwgPiBwJyk7XG4gICAgY29uc3QgbWV0cmljcyA9IFtdO1xuICAgIGZvciAoY29uc3QgW3dpZHRoLGhlaWdodF0gb2Ygc2l6ZXMpIHtcbiAgICAgIGF3YWl0IHBhZ2Uuc2V0Vmlld3BvcnRTaXplKHsgd2lkdGgsaGVpZ2h0IH0pO1xuICAgICAgYXdhaXQgZGVzY3JpcHRpb24uc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICAgICAgY29uc3Qgb3JpZ2luYWxQb3NpdGlvbiA9IGF3YWl0IGxheW91dChwYWdlLGJvbnVzKTtcbiAgICAgIGlmICh3aWR0aCA9PT0gMzYwICYmIGhlaWdodCA9PT0gNjQwKSB7XG4gICAgICAgIGV4cGVjdC5zb2Z0KGF3YWl0IHBhZ2UubG9jYXRvcignbWFpbicpLmV2YWx1YXRlKG5vZGUgPT4gbm9kZS5zY3JvbGxUb3ApLCAnYmFzZWxpbmUgZGV0YWlsIHNjcm9sbHMgaW5zaWRlIG1haW4nKS50b0JlR3JlYXRlclRoYW4oMCk7XG4gICAgICB9XG4gICAgICBhd2FpdCBpbmZvLmF0dGFjaChgbGF5b3V0LSR7U3RyaW5nKHdpZHRoKX14JHtTdHJpbmcoaGVpZ2h0KX1gLCB7IGJvZHk6IGF3YWl0IHBhZ2Uuc2NyZWVuc2hvdCgpLCBjb250ZW50VHlwZTogJ2ltYWdlL3BuZycgfSk7XG4gICAgICBjb25zdCBoZWFkaW5nSGl0cyA9IGF3YWl0IGNsZWFyVGFyZ2V0KGhlYWRpbmcsYCR7U3RyaW5nKHdpZHRoKX14JHtTdHJpbmcoaGVpZ2h0KX0gaGVhZGluZ2ApO1xuICAgICAgY29uc3QgYWN0aW9uSGl0cyA9IGF3YWl0IGNsZWFyVGFyZ2V0KGFsbG9jYXRlLGAke1N0cmluZyh3aWR0aCl9eCR7U3RyaW5nKGhlaWdodCl9IEFsbG9jYXRlYCk7XG4gICAgICBpZiAoIWVuZ2xpc2ggJiYgd2lkdGggPT09IDM2MCkge1xuICAgICAgICBjb25zdCBjZHAgPSBhd2FpdCBjb250ZXh0Lm5ld0NEUFNlc3Npb24ocGFnZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2RwLnNlbmQoJ0RPTS5lbmFibGUnKTsgYXdhaXQgY2RwLnNlbmQoJ0NTUy5lbmFibGUnKTtcbiAgICAgICAgICBjb25zdCBkb2N1bWVudCA9IGF3YWl0IGNkcC5zZW5kKCdET00uZ2V0RG9jdW1lbnQnKTtcbiAgICAgICAgICBjb25zdCBub2RlID0gYXdhaXQgY2RwLnNlbmQoJ0RPTS5xdWVyeVNlbGVjdG9yJyx7IG5vZGVJZDogZG9jdW1lbnQucm9vdC5ub2RlSWQsIHNlbGVjdG9yOiAnW2RhdGEtdGVzdGlkPVwic2tpbGwtZGV0YWlsLXBhbmVsXCJdICNza2lsbC1kZXRhaWwtcGFuZWwgPiBwJyB9KTtcbiAgICAgICAgICBjb25zdCBmb250cyA9IGF3YWl0IGNkcC5zZW5kKCdDU1MuZ2V0UGxhdGZvcm1Gb250c0Zvck5vZGUnLHsgbm9kZUlkOiBub2RlLm5vZGVJZCB9KTtcbiAgICAgICAgICBleHBlY3QoZm9udHMuZm9udHMuc29tZShmb250ID0+IGZvbnQuZmFtaWx5TmFtZSA9PT0gJ05vdG8gU2FucyBDSksgU0MnICYmIGZvbnQuZ2x5cGhDb3VudCA+IDApKS50b0JlKHRydWUpO1xuICAgICAgICAgIGF3YWl0IGF0dGFjaChpbmZvLCdhY3R1YWwtQ2hpbmVzZS1wbGF0Zm9ybS1mb250cycsZm9udHMpO1xuICAgICAgICB9IGZpbmFsbHkgeyBhd2FpdCBjZHAuZGV0YWNoKCk7IH1cbiAgICAgIH1cbiAgICAgIG1ldHJpY3MucHVzaCh7IHdpZHRoLGhlaWdodCxvcmlnaW5hbFBvc2l0aW9uLGhlYWRpbmdIaXRzLGFjdGlvbkhpdHMgfSk7XG4gICAgfVxuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwMi1sYXlvdXQtbWV0cmljcycsbWV0cmljcyk7XG5cbiAgICBhd2FpdCBwYWdlLnNldFZpZXdwb3J0U2l6ZSh7IHdpZHRoOjM3NSxoZWlnaHQ6NjY3IH0pO1xuICAgIGF3YWl0IGRlc2NyaXB0aW9uLnNjcm9sbEludG9WaWV3SWZOZWVkZWQoKTtcbiAgICBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvSGF2ZVRleHQoZW5nbGlzaCA/ICdBbGxvY2F0ZScgOiAn5YiG6YWNJyk7XG4gICAgYXdhaXQgYWxsb2NhdGUuY2xpY2soKTsgLy8gT3JkaW5hcnkgcG9pbnRlcjsgUGxheXdyaWdodCBtdXN0IHJlc29sdmUgdGhlIGFjdHVhbCB0YXJnZXQuXG4gICAgYXdhaXQgZXhwZWN0KHBhbmVsKS50b0NvbnRhaW5UZXh0KGVuZ2xpc2ggPyAnTHYuIDEvMjAnIDogJ+etiee6pyAxLzIwJyk7XG4gICAgY29uc3QgcmFuazEgPSBhd2FpdCBiYWNrdXAocGFnZSk7XG4gICAgZXhwZWN0KHJhbmsxLnBsYXllcikudG9FcXVhbCh7IC4uLmluY29taW5nLnBsYXllciwgc2tpbGxQb2ludHM6MSxcbiAgICAgIHNraWxsTGV2ZWxzOnsgJ3NvcmNlcmVzcy5maXJlX2JvbHQnOjEsJ3NvcmNlcmVzcy5saWdodG5pbmdfbWFzdGVyeSc6MSB9IH0pO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NraWxscycpO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoYHNraWxsLW5vZGUtJHtNQVNURVJZfWApLmNsaWNrKCk7XG4gICAgYXdhaXQgcGFnZS5zZXRWaWV3cG9ydFNpemUoeyB3aWR0aDo5MTUsaGVpZ2h0OjQxMiB9KTtcbiAgICBsZXQgcmVhY2hlZCA9IGZhbHNlO1xuICAgIGZvciAobGV0IHN0ZXA9MDtzdGVwPDEwMDtzdGVwKyspIHtcbiAgICAgIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ1RhYicpO1xuICAgICAgaWYgKGF3YWl0IGFsbG9jYXRlLmV2YWx1YXRlKG5vZGUgPT4gbm9kZSA9PT0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkpIHsgcmVhY2hlZD10cnVlO2JyZWFrOyB9XG4gICAgfVxuICAgIGV4cGVjdChyZWFjaGVkKS50b0JlKHRydWUpO1xuICAgIGF3YWl0IGV4cGVjdChoZWFkaW5nKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9IYXZlVGV4dChlbmdsaXNoID8gJ0FsbG9jYXRlJyA6ICfliIbphY0nKTtcbiAgICBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvQmVFbmFibGVkKCk7IGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9CZUZvY3VzZWQoKTtcbiAgICBhd2FpdCBjbGVhclRhcmdldChhbGxvY2F0ZSwna2V5Ym9hcmQgdGFyZ2V0Jyk7XG4gICAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnRW50ZXInKTtcbiAgICBhd2FpdCBleHBlY3QocGFuZWwpLnRvQ29udGFpblRleHQoZW5nbGlzaCA/ICdMdi4gMi8yMCcgOiAn562J57qnIDIvMjAnKTtcbiAgICBjb25zdCByYW5rMiA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QocmFuazIucGxheWVyKS50b0VxdWFsKHsgLi4ucmFuazEucGxheWVyLHNraWxsUG9pbnRzOjAsXG4gICAgICBza2lsbExldmVsczp7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzoxLCdzb3JjZXJlc3MubGlnaHRuaW5nX21hc3RlcnknOjIgfSB9KTtcbiAgICBmb3IgKGNvbnN0IHNsaWNlIG9mIFsnaW52ZW50b3J5JywnbWVyY3MnLCdtYXAnLCdmb3JtYXRpb24nXSBhcyBjb25zdCkgZXhwZWN0KHJhbmsyW3NsaWNlXSkudG9FcXVhbChpbmNvbWluZ1tzbGljZV0pO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwMy1wb2ludGVyLWtleWJvYXJkLWFsbG9jYXRpb24nLHsgcmFuazEscmFuazIgfSk7XG5cbiAgICAvLyBSZWFsIGRpYWxvZyByZW1haW5zIGFib3ZlIHRoZSBzaGFyZWQgaGVhZGVyLCBpbmNsdWRpbmcgd2l0aCBhbiBhY3RpdmUgY2hpcC5cbiAgICBjb25zdCBsYWJlbCA9IGVuZ2xpc2ggPyAnSW1wb3J0IFNhdmUnIDogJ+WvvOWFpeWtmOahoyc7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicseyBuYW1lOmxhYmVsLGV4YWN0OnRydWUgfSkuY2xpY2soKTtcbiAgICBjb25zdCBtb2RhbFByaW9yaXR5ID0gYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiB7XG4gICAgICBjb25zdCBkaWFsb2cgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbcm9sZT1cImRpYWxvZ1wiXScpO1xuICAgICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJjaGFyYWN0ZXItaHVkXCJdLCBbZGF0YS10ZXN0aWQ9XCJvZmZsaW5lLWJvbnVzLWNoaXBcIl0nKV0uZmxhdE1hcChub2RlID0+IHtcbiAgICAgICAgY29uc3QgYiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHJldHVybiBbMC4wNSwwLjUsMC45NV0uZmxhdE1hcCh4ID0+IFswLjA1LDAuNSwwLjk1XS5tYXAoeSA9PiB7XG4gICAgICAgICAgY29uc3QgcHg9Yi5sZWZ0K2Iud2lkdGgqeCwgcHk9Yi50b3ArYi5oZWlnaHQqeTtcbiAgICAgICAgICBjb25zdCBoaXQ9ZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludChweCxweSk7XG4gICAgICAgICAgcmV0dXJuIHsgdGFyZ2V0Om5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLXRlc3RpZCcpLHg6cHgseTpweSxtb2RhbE93bnNIaXQ6aGl0ICE9PSBudWxsICYmIGRpYWxvZyAhPT0gbnVsbCAmJiBkaWFsb2cuY29udGFpbnMoaGl0KSB9O1xuICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBhd2FpdCBhdHRhY2goaW5mbywnbW9kYWwtcHJpb3JpdHktYXQtaGVhZGVyJyxtb2RhbFByaW9yaXR5KTtcbiAgICBleHBlY3QobW9kYWxQcmlvcml0eSkudG9IYXZlTGVuZ3RoKGJvbnVzID8gMTggOiA5KTtcbiAgICBmb3IgKGNvbnN0IHBvaW50IG9mIG1vZGFsUHJpb3JpdHkpIGV4cGVjdC5zb2Z0KHBvaW50KS50b01hdGNoT2JqZWN0KHsgbW9kYWxPd25zSGl0OnRydWUgfSk7XG4gICAgY29uc3QgY2FuY2VsID0gcGFnZS5nZXRCeVJvbGUoJ2RpYWxvZycpLmdldEJ5Um9sZSgnYnV0dG9uJyx7IG5hbWU6ZW5nbGlzaCA/ICdDYW5jZWwnIDogJ+WPlua2iCcsZXhhY3Q6dHJ1ZSB9KTtcbiAgICBhd2FpdCBjbGVhclRhcmdldChjYW5jZWwsJ21vZGFsIGNhbmNlbCcpOyBhd2FpdCBjYW5jZWwuY2xpY2soKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVJvbGUoJ2RpYWxvZycpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykuY2xpY2soKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDApO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ2NvbWJhdCcpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjb21iYXQtc2NyZWVuJykpLnRvQmVWaXNpYmxlKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgY29uc3QgY29tYmF0SGVhZGVyID0gcGFnZS5nZXRCeVRlc3RJZCgnY29tYmF0LXNjcmVlbicpLmxvY2F0b3IoJ2hlYWRlcicpO1xuICAgIGNvbnN0IHdpZHRoID0gYXdhaXQgY29tYmF0SGVhZGVyLmV2YWx1YXRlKG5vZGUgPT4gKHsgb3V0ZXI6bm9kZS5jbGllbnRXaWR0aCxpbm5lcjpub2RlLmZpcnN0RWxlbWVudENoaWxkPy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCB9KSk7XG4gICAgZXhwZWN0KHdpZHRoLmlubmVyKS50b0JlR3JlYXRlclRoYW5PckVxdWFsKHdpZHRoLm91dGVyIC0gMzIpO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NraWxscycpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDEpO1xuICAgIGV4cGVjdChhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+ICdfX0dBTUVfXycgaW4gd2luZG93KSkudG9CZShmYWxzZSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJzA0LWNvbnNvbGUtZXJyb3JzJyxlcnJvcnMpOyBleHBlY3QoZXJyb3JzKS50b0VxdWFsKFtdKTtcbiAgICBhd2FpdCBwYWdlLmNsb3NlKCk7XG4gIH0pO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBLFNBQVNBLE1BQU0sRUFBRUMsSUFBSSxRQUFnRCxrQkFBa0I7QUFDdkYsU0FBU0MsUUFBUSxRQUFRLGtCQUFrQjtBQUUzQyxTQUFTQyxLQUFLLFFBQVEsaUJBQWlCO0FBRXZDLE1BQU1DLE9BQU8sR0FBRyxvQ0FBb0M7QUFDcEQsTUFBTUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxJQUFJLEVBQUMsR0FBRyxDQUFDLEVBQUMsQ0FBQyxJQUFJLEVBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxHQUFHLEVBQUMsR0FBRyxDQUFDLENBQVU7QUFFdEgsZUFBZUMsTUFBTUEsQ0FBQ0MsSUFBYyxFQUFFQyxJQUFZLEVBQUVDLEtBQWMsRUFBaUI7RUFDakYsTUFBTUYsSUFBSSxDQUFDRCxNQUFNLENBQUNFLElBQUksRUFBRTtJQUFFRSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDSCxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUFFSSxXQUFXLEVBQUU7RUFBbUIsQ0FBQyxDQUFDO0FBQ3BHO0FBRUEsZUFBZUMsTUFBTUEsQ0FBQ0MsSUFBVSxFQUF3QjtFQUN0RCxNQUFNWixLQUFLLENBQUNZLElBQUksRUFBRSxVQUFVLENBQUM7RUFDN0IsTUFBTUMsT0FBTyxHQUFHRCxJQUFJLENBQUNFLFlBQVksQ0FBQyxVQUFVLENBQUM7RUFDN0MsTUFBTUYsSUFBSSxDQUFDRyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7RUFDcEQsTUFBTUMsUUFBUSxHQUFHLE1BQU1KLE9BQU87RUFDOUIsSUFBSTtJQUFFLE9BQU9MLElBQUksQ0FBQ1UsS0FBSyxDQUFDLE1BQU1uQixRQUFRLENBQUMsTUFBTWtCLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztFQUFpQixDQUFDLFNBQ2hGO0lBQUUsTUFBTUYsUUFBUSxDQUFDRyxNQUFNLENBQUMsQ0FBQztFQUFFO0FBQ3JDO0FBRUEsZUFBZUMsVUFBVUEsQ0FBQ1QsSUFBVSxFQUFFVSxJQUFpQixFQUFFQyxPQUFnQixFQUFpQjtFQUN4RixNQUFNQyxLQUFLLEdBQUdELE9BQU8sR0FBRyxhQUFhLEdBQUcsTUFBTTtFQUM5QyxNQUFNWCxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLEVBQUU7SUFBRXBCLElBQUksRUFBRW1CLEtBQUs7SUFBRUUsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDLENBQUNWLEtBQUssQ0FBQyxDQUFDO0VBQ3BFLE1BQU1XLE1BQU0sR0FBR2YsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDO0VBQ3ZDLE1BQU1FLE1BQU0sQ0FBQ0YsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDRyxJQUFJLENBQUNwQixJQUFJLENBQUNDLFNBQVMsQ0FBQ2EsSUFBSSxDQUFDLENBQUM7RUFDNUQsTUFBTUssTUFBTSxDQUFDRixTQUFTLENBQUMsUUFBUSxFQUFFO0lBQUVwQixJQUFJLEVBQUVtQixLQUFLO0lBQUVFLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDVixLQUFLLENBQUMsQ0FBQztFQUN0RSxNQUFNbkIsTUFBTSxDQUFDOEIsTUFBTSxDQUFDLENBQUNFLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDckM7O0FBRUE7QUFDQSxlQUFlQyxTQUFTQSxDQUFDQyxNQUFlLEVBQXNCO0VBQzVELE9BQU9BLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxJQUFJLElBQUk7SUFDN0IsTUFBTUMsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLHFCQUFxQixDQUFDLENBQUM7SUFDdEMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUNDLE9BQU8sQ0FBQ0MsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQ0MsR0FBRyxDQUFDQyxDQUFDLElBQUk7TUFBQSxJQUFBQyxZQUFBO01BQy9ELE1BQU1DLEVBQUUsR0FBR1AsQ0FBQyxDQUFDUSxJQUFJLEdBQUdSLENBQUMsQ0FBQ1MsS0FBSyxHQUFHTixDQUFDO1FBQUVPLEVBQUUsR0FBR1YsQ0FBQyxDQUFDVyxHQUFHLEdBQUdYLENBQUMsQ0FBQ1ksTUFBTSxHQUFHUCxDQUFDO01BQzFELE1BQU1RLEdBQUcsR0FBR0MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQ1IsRUFBRSxFQUFFRyxFQUFFLENBQUM7TUFDN0MsT0FBTztRQUFFUCxDQUFDLEVBQUVJLEVBQUU7UUFBRUYsQ0FBQyxFQUFFSyxFQUFFO1FBQUVNLEtBQUssRUFBRUgsR0FBRyxLQUFLLElBQUksSUFBSWQsSUFBSSxDQUFDa0IsUUFBUSxDQUFDSixHQUFHLENBQUM7UUFBRUEsR0FBRyxHQUFBUCxZQUFBLEdBQUVPLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFSyxPQUFPLGNBQUFaLFlBQUEsY0FBQUEsWUFBQSxHQUFJO01BQUssQ0FBQztJQUMvRixDQUFDLENBQUMsQ0FBQztFQUNMLENBQUMsQ0FBQztBQUNKO0FBRUEsZUFBZWEsV0FBV0EsQ0FBQ3RCLE1BQWUsRUFBRVAsS0FBYSxFQUFzQjtFQUM3RSxNQUFNTyxNQUFNLENBQUN1QixzQkFBc0IsQ0FBQyxDQUFDO0VBQ3JDLE1BQU1DLE1BQU0sR0FBRyxNQUFNekIsU0FBUyxDQUFDQyxNQUFNLENBQUM7RUFDdEMsS0FBSyxNQUFNeUIsS0FBSyxJQUFJRCxNQUFNLEVBQUUxRCxNQUFNLENBQUM0RCxJQUFJLENBQUNELEtBQUssRUFBRWhDLEtBQUssQ0FBQyxDQUFDa0MsYUFBYSxDQUFDO0lBQUVSLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQztFQUNwRixPQUFPSyxNQUFNO0FBQ2Y7QUFFQSxlQUFlSSxNQUFNQSxDQUFDL0MsSUFBVSxFQUFFZ0QsS0FBYyxFQUFvQjtFQUNsRSxNQUFNQyxRQUFRLEdBQUcsTUFBTWpELElBQUksQ0FBQ29CLFFBQVEsQ0FBQyxNQUFNO0lBQUEsSUFBQThCLG1CQUFBO0lBQ3pDLE1BQU1DLElBQUksR0FBR2YsUUFBUSxDQUFDZ0IsYUFBYSxDQUFDLE1BQU0sQ0FBQztJQUMzQyxNQUFNQyxHQUFHLEdBQUdqQixRQUFRLENBQUNnQixhQUFhLENBQUMsK0JBQStCLENBQUM7SUFDbkUsTUFBTUUsSUFBSSxHQUFHbEIsUUFBUSxDQUFDZ0IsYUFBYSxDQUFDLG9DQUFvQyxDQUFDO0lBQ3pFLE1BQU1HLE1BQU0sR0FBR0osSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVLLHNCQUFzQjtJQUMzQyxJQUFJLENBQUNMLElBQUksSUFBSSxDQUFDRSxHQUFHLElBQUksQ0FBQ0UsTUFBTSxFQUFFLE1BQU0sSUFBSUUsS0FBSyxDQUFDLHNDQUFzQyxDQUFDO0lBQ3JGLE1BQU1DLElBQUksR0FBSXJDLElBQWEsSUFBSztNQUM5QixNQUFNQyxDQUFDLEdBQUdELElBQUksQ0FBQ0UscUJBQXFCLENBQUMsQ0FBQztNQUN0QyxPQUFPO1FBQUVPLElBQUksRUFBRVIsQ0FBQyxDQUFDUSxJQUFJO1FBQUVHLEdBQUcsRUFBRVgsQ0FBQyxDQUFDVyxHQUFHO1FBQUUwQixLQUFLLEVBQUVyQyxDQUFDLENBQUNxQyxLQUFLO1FBQUVDLE1BQU0sRUFBRXRDLENBQUMsQ0FBQ3NDLE1BQU07UUFBRTdCLEtBQUssRUFBRVQsQ0FBQyxDQUFDUyxLQUFLO1FBQUVHLE1BQU0sRUFBRVosQ0FBQyxDQUFDWTtNQUFPLENBQUM7SUFDekcsQ0FBQztJQUNELE1BQU0yQixDQUFDLEdBQUdILElBQUksQ0FBQ0gsTUFBTSxDQUFDO01BQUVPLENBQUMsR0FBR0osSUFBSSxDQUFDUCxJQUFJLENBQUM7TUFBRVksQ0FBQyxHQUFHTCxJQUFJLENBQUNMLEdBQUcsQ0FBQztNQUFFVyxDQUFDLEdBQUdWLElBQUksR0FBR0ksSUFBSSxDQUFDSixJQUFJLENBQUMsR0FBRyxJQUFJO0lBQ25GLE1BQU1mLFFBQVEsR0FBR0EsQ0FBQzBCLENBQVcsRUFBRTNDLENBQVcsS0FBS0EsQ0FBQyxDQUFDUSxJQUFJLElBQUltQyxDQUFDLENBQUNuQyxJQUFJLElBQUlSLENBQUMsQ0FBQ3FDLEtBQUssSUFBSU0sQ0FBQyxDQUFDTixLQUFLLElBQUlyQyxDQUFDLENBQUNXLEdBQUcsSUFBSWdDLENBQUMsQ0FBQ2hDLEdBQUcsSUFBSVgsQ0FBQyxDQUFDc0MsTUFBTSxJQUFJSyxDQUFDLENBQUNMLE1BQU07SUFDL0gsTUFBTU0sT0FBTyxHQUFHLENBQUMsR0FBRzlCLFFBQVEsQ0FBQytCLGdCQUFnQixDQUFDLGtGQUFrRixDQUFDLENBQUMsQ0FBQ3pDLEdBQUcsQ0FBQ0wsSUFBSSxJQUFJO01BQzdJLE1BQU1DLENBQUMsR0FBR29DLElBQUksQ0FBQ3JDLElBQUksQ0FBQztNQUNwQixNQUFNK0MsT0FBTyxHQUFHO1FBQUV0QyxJQUFJLEVBQUV1QyxJQUFJLENBQUNDLEdBQUcsQ0FBQ2hELENBQUMsQ0FBQ1EsSUFBSSxFQUFDZ0MsQ0FBQyxDQUFDaEMsSUFBSSxDQUFDO1FBQUU2QixLQUFLLEVBQUVVLElBQUksQ0FBQ0UsR0FBRyxDQUFDakQsQ0FBQyxDQUFDcUMsS0FBSyxFQUFDRyxDQUFDLENBQUNILEtBQUssQ0FBQztRQUFFMUIsR0FBRyxFQUFFb0MsSUFBSSxDQUFDQyxHQUFHLENBQUNoRCxDQUFDLENBQUNXLEdBQUcsRUFBQzZCLENBQUMsQ0FBQzdCLEdBQUcsQ0FBQztRQUFFMkIsTUFBTSxFQUFFUyxJQUFJLENBQUNFLEdBQUcsQ0FBQ2pELENBQUMsQ0FBQ3NDLE1BQU0sRUFBQ0UsQ0FBQyxDQUFDRixNQUFNO01BQUUsQ0FBQztNQUNwSixNQUFNWSxLQUFLLEdBQUdKLE9BQU8sQ0FBQ1QsS0FBSyxHQUFHUyxPQUFPLENBQUN0QyxJQUFJLElBQUlzQyxPQUFPLENBQUNSLE1BQU0sR0FBR1EsT0FBTyxDQUFDbkMsR0FBRztNQUMxRSxNQUFNd0MsUUFBUSxHQUFJUixDQUFXLElBQUtPLEtBQUssSUFBSUosT0FBTyxDQUFDdEMsSUFBSSxHQUFHbUMsQ0FBQyxDQUFDTixLQUFLLElBQUlTLE9BQU8sQ0FBQ1QsS0FBSyxHQUFHTSxDQUFDLENBQUNuQyxJQUFJLElBQUlzQyxPQUFPLENBQUNuQyxHQUFHLEdBQUdnQyxDQUFDLENBQUNMLE1BQU0sSUFBSVEsT0FBTyxDQUFDUixNQUFNLEdBQUdLLENBQUMsQ0FBQ2hDLEdBQUc7TUFDL0ksT0FBTztRQUFFeUMsSUFBSSxFQUFFckQsSUFBSSxDQUFDc0QsV0FBVztRQUFFakIsSUFBSSxFQUFDcEMsQ0FBQztRQUFFOEMsT0FBTztRQUFFSSxLQUFLO1FBQUVJLFlBQVksRUFBRUgsUUFBUSxDQUFDVixDQUFDLENBQUM7UUFBRWMsYUFBYSxFQUFFYixDQUFDLEtBQUssSUFBSSxJQUFJUyxRQUFRLENBQUNULENBQUM7TUFBRSxDQUFDO0lBQ2hJLENBQUMsQ0FBQztJQUNGLE9BQU87TUFBRVQsTUFBTSxFQUFFTSxDQUFDO01BQUVWLElBQUksRUFBRVcsQ0FBQztNQUFFVCxHQUFHLEVBQUVVLENBQUM7TUFBRVQsSUFBSSxFQUFFVSxDQUFDO01BQUVjLFlBQVksRUFBRXZDLFFBQVEsQ0FBQ3NCLENBQUMsRUFBQ0UsQ0FBQyxDQUFDO01BQUVnQixhQUFhLEVBQUVmLENBQUMsS0FBSyxJQUFJLElBQUl6QixRQUFRLENBQUNzQixDQUFDLEVBQUNHLENBQUMsQ0FBQztNQUNuSGdCLFlBQVksRUFBRWxCLENBQUMsQ0FBQzdCLEdBQUcsSUFBSThCLENBQUMsQ0FBQ0gsTUFBTTtNQUFFcUIsYUFBYSxFQUFFakIsQ0FBQyxLQUFLLElBQUksSUFBSUYsQ0FBQyxDQUFDN0IsR0FBRyxJQUFJK0IsQ0FBQyxDQUFDSixNQUFNO01BQy9Fc0IsZUFBZSxFQUFFbEIsQ0FBQyxLQUFLLElBQUksSUFBSUEsQ0FBQyxDQUFDL0IsR0FBRyxJQUFJOEIsQ0FBQyxDQUFDSCxNQUFNO01BQUV1QixpQkFBaUIsRUFBRTdCLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQ0QsR0FBRyxDQUFDZCxRQUFRLENBQUNlLElBQUksQ0FBQztNQUN6RzhCLGdCQUFnQixFQUFFaEQsUUFBUSxDQUFDaUQsZUFBZSxDQUFDQyxXQUFXLEdBQUdDLFVBQVU7TUFDbkVDLFlBQVksRUFBRXJDLElBQUksQ0FBQ21DLFdBQVcsR0FBR25DLElBQUksQ0FBQ3NDLFdBQVc7TUFBRUMsT0FBTyxFQUFFQyxPQUFPO01BQ25FQyxNQUFNLEdBQUExQyxtQkFBQSxHQUFFQyxJQUFJLENBQUMwQyxhQUFhLGNBQUEzQyxtQkFBQSxnQkFBQUEsbUJBQUEsR0FBbEJBLG1CQUFBLENBQW9CMkMsYUFBYSxjQUFBM0MsbUJBQUEsdUJBQWpDQSxtQkFBQSxDQUFtQzRDLFNBQVM7TUFBRUMsS0FBSyxFQUFFNUMsSUFBSSxDQUFDMkMsU0FBUztNQUMzRUUsZ0JBQWdCLEVBQUU3QyxJQUFJLENBQUM4QyxZQUFZO01BQUVDLGdCQUFnQixFQUFFL0MsSUFBSSxDQUFDZ0QsWUFBWTtNQUFFakM7SUFBUSxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUNGakYsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUM2QixZQUFZLEVBQUUsbUNBQW1DLENBQUMsQ0FBQ3NCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbEZuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQzhCLGFBQWEsRUFBRSwwQ0FBMEMsQ0FBQyxDQUFDcUIsSUFBSSxDQUFDLElBQUksQ0FBQztFQUMxRm5ILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDK0IsWUFBWSxFQUFFLDhCQUE4QixDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzdFbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNnQyxhQUFhLEVBQUUsK0JBQStCLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDL0VuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ2lDLGVBQWUsQ0FBQyxDQUFDa0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRG5ILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDa0MsaUJBQWlCLENBQUMsQ0FBQ2lCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbERuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ21DLGdCQUFnQixDQUFDLENBQUNpQixtQkFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDN0RwSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ3VDLFlBQVksQ0FBQyxDQUFDYSxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDekRwSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQ3lDLE9BQU8sQ0FBQyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUVuSCxNQUFNLENBQUM0RCxJQUFJLENBQUNJLFFBQVEsQ0FBQzJDLE1BQU0sQ0FBQyxDQUFDUSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzNFbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNJLEdBQUcsQ0FBQ3RCLEtBQUssQ0FBQyxDQUFDdUUsc0JBQXNCLENBQUMsRUFBRSxDQUFDO0VBQzFEckgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNJLEdBQUcsQ0FBQ25CLE1BQU0sQ0FBQyxDQUFDb0Usc0JBQXNCLENBQUMsRUFBRSxDQUFDO0VBQzNEckgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDSSxRQUFRLENBQUNFLElBQUksQ0FBQ2pCLE1BQU0sQ0FBQyxDQUFDcUUsZUFBZSxDQUFDLENBQUMsQ0FBQztFQUNwRHRILE1BQU0sQ0FBQzRELElBQUksQ0FBQ0ksUUFBUSxDQUFDSyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUM4QyxJQUFJLENBQUNwRCxLQUFLLENBQUM7RUFDL0MsS0FBSyxNQUFNN0IsTUFBTSxJQUFJOEIsUUFBUSxDQUFDaUIsT0FBTyxFQUFFO0lBQ3JDakYsTUFBTSxDQUFDNEQsSUFBSSxDQUFDMUIsTUFBTSxDQUFDeUQsWUFBWSxFQUFFLGlFQUFpRSxDQUFDLENBQUN3QixJQUFJLENBQUMsS0FBSyxDQUFDO0lBQy9HbkgsTUFBTSxDQUFDNEQsSUFBSSxDQUFDMUIsTUFBTSxDQUFDMEQsYUFBYSxFQUFFLHlFQUF5RSxDQUFDLENBQUN1QixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQzFIO0VBQ0EsT0FBT25ELFFBQVE7QUFDakI7QUFFQSxLQUFLLE1BQU11RCxNQUFNLElBQUksQ0FBQyxJQUFJLEVBQUMsT0FBTyxDQUFDLEVBQVcsS0FBSyxNQUFNeEQsS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxFQUFFO0VBQzlFOUQsSUFBSSxDQUFDLDZCQUE2QnNILE1BQU0sVUFBVUMsTUFBTSxDQUFDekQsS0FBSyxDQUFDLEVBQUUsRUFBRSxPQUFPO0lBQUVoRCxJQUFJO0lBQUUwRztFQUFRLENBQUMsRUFBRWxILElBQUksS0FBSztJQUNwRyxNQUFNbUIsT0FBTyxHQUFHNkYsTUFBTSxLQUFLLElBQUk7SUFDL0IsTUFBTUcsTUFBZ0IsR0FBRyxFQUFFO0lBQzNCM0csSUFBSSxDQUFDNEcsRUFBRSxDQUFDLFdBQVcsRUFBRUMsS0FBSyxJQUFJRixNQUFNLENBQUNHLElBQUksQ0FBQ0QsS0FBSyxDQUFDRSxPQUFPLENBQUMsQ0FBQztJQUN6RC9HLElBQUksQ0FBQzRHLEVBQUUsQ0FBQyxTQUFTLEVBQUVHLE9BQU8sSUFBSTtNQUFFLElBQUlBLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUlELE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUVMLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdDLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBS0QsT0FBTyxDQUFDckMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZKLE1BQU0xRSxJQUFJLENBQUNpSCxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzVCLE1BQU1oSSxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTWpCLElBQUksQ0FBQ2lILElBQUksQ0FBQyxHQUFHLENBQUM7SUFDcEIsTUFBTWhJLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLE1BQU1uQixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTWpCLElBQUksQ0FBQ0csV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQ2pELE1BQU1YLElBQUksR0FBR2tCLE9BQU8sR0FBRyxrQkFBa0IsR0FBRyxHQUFHLENBQUN1RyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQzFELE1BQU1sSCxJQUFJLENBQUNHLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDYSxJQUFJLENBQUN2QixJQUFJLENBQUM7SUFDekQsTUFBTU8sSUFBSSxDQUFDRyxXQUFXLENBQUMscUJBQXFCLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDckQsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ2dILFdBQVcsQ0FBQyxDQUFDO0lBQzNELE1BQU0vSCxLQUFLLENBQUNZLElBQUksRUFBQyxVQUFVLENBQUM7SUFDNUIsTUFBTW9ILFFBQVEsR0FBR3BILElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFcEIsSUFBSSxFQUFFa0IsT0FBTyxHQUFHLFNBQVMsR0FBRyxNQUFNO01BQUVHLEtBQUssRUFBRTtJQUFLLENBQUMsQ0FBQztJQUM5RixNQUFNc0csUUFBUSxDQUFDaEgsS0FBSyxDQUFDLENBQUM7SUFDdEIsTUFBTW5CLE1BQU0sQ0FBQ21JLFFBQVEsQ0FBQyxDQUFDQyxlQUFlLENBQUMsY0FBYyxFQUFDLE1BQU0sQ0FBQztJQUM3RCxNQUFNQyxLQUFLLEdBQUcsTUFBTXZILE1BQU0sQ0FBQ0MsSUFBSSxDQUFDO0lBQ2hDZixNQUFNLENBQUNxSSxLQUFLLENBQUNDLE1BQU0sQ0FBQzlILElBQUksQ0FBQyxDQUFDMkcsSUFBSSxDQUFDM0csSUFBSSxDQUFDO0lBQ3BDLE1BQU0rSCxRQUFxQixHQUFHO01BQUUsR0FBR0YsS0FBSztNQUFFQyxNQUFNLEVBQUU7UUFBRSxHQUFHRCxLQUFLLENBQUNDLE1BQU07UUFBRUUsS0FBSyxFQUFFLEVBQUU7UUFBRUMsV0FBVyxFQUFFLENBQUM7UUFDNUZDLFdBQVcsRUFBRTtVQUFFLHFCQUFxQixFQUFFO1FBQUUsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQyw0QkFBNEI7TUFBRSxDQUFDO01BQ3ZGQyxJQUFJLEVBQUU7UUFBRSxHQUFHUCxLQUFLLENBQUNPLElBQUk7UUFBRUMsU0FBUyxFQUFFO1VBQUUsR0FBR1IsS0FBSyxDQUFDTyxJQUFJLENBQUNDLFNBQVM7VUFBRUMsVUFBVSxFQUFFQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDO1VBQ2pGQyxnQkFBZ0IsRUFBRWxGLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztVQUFFbUYsMEJBQTBCLEVBQUVuRixLQUFLLEdBQUcsSUFBSSxHQUFHO1FBQUU7TUFBRTtJQUFFLENBQUM7SUFDekYsTUFBTXZDLFVBQVUsQ0FBQ1QsSUFBSSxFQUFFd0gsUUFBUSxFQUFFN0csT0FBTyxDQUFDO0lBQ3pDLE1BQU1wQixNQUFNLENBQUNDLElBQUksRUFBRSx5QkFBeUIsRUFBRWdJLFFBQVEsQ0FBQztJQUV2RCxLQUFLLE1BQU1ZLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLEVBQUU7TUFDaEQsTUFBTWhKLEtBQUssQ0FBQ1ksSUFBSSxFQUFFb0ksS0FBSyxDQUFDO01BQ3hCLE1BQU1uSixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7TUFDOUQsTUFBTWhDLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2tJLG9CQUFvQixDQUFDLElBQUlDLE1BQU0sQ0FBQzdJLElBQUksQ0FBQyxDQUFDO01BQ3RGLE1BQU1GLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFLFNBQVM0SSxLQUFLLEVBQUUsRUFBRSxNQUFNckYsTUFBTSxDQUFDL0MsSUFBSSxFQUFDZ0QsS0FBSyxDQUFDLENBQUM7SUFDaEU7SUFDQSxNQUFNdUYsS0FBSyxHQUFHdkksSUFBSSxDQUFDRyxXQUFXLENBQUMsb0JBQW9CLENBQUM7SUFDcEQsTUFBTUgsSUFBSSxDQUFDRyxXQUFXLENBQUMsY0FBY2QsT0FBTyxFQUFFLENBQUMsQ0FBQ2UsS0FBSyxDQUFDLENBQUM7SUFDdkQsTUFBTW9JLE9BQU8sR0FBR0QsS0FBSyxDQUFDMUgsU0FBUyxDQUFDLFNBQVMsRUFBRTtNQUFFcEIsSUFBSSxFQUFFa0IsT0FBTyxHQUFHLG1CQUFtQixHQUFHLE1BQU07TUFBRUcsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3pHLE1BQU0ySCxRQUFRLEdBQUdGLEtBQUssQ0FBQzFILFNBQVMsQ0FBQyxRQUFRLENBQUM7SUFDMUMsTUFBTTZILFdBQVcsR0FBR0gsS0FBSyxDQUFDSSxPQUFPLENBQUMseUJBQXlCLENBQUM7SUFDNUQsTUFBTUMsT0FBTyxHQUFHLEVBQUU7SUFDbEIsS0FBSyxNQUFNLENBQUM3RyxLQUFLLEVBQUNHLE1BQU0sQ0FBQyxJQUFJNUMsS0FBSyxFQUFFO01BQ2xDLE1BQU1VLElBQUksQ0FBQzZJLGVBQWUsQ0FBQztRQUFFOUcsS0FBSztRQUFDRztNQUFPLENBQUMsQ0FBQztNQUM1QyxNQUFNd0csV0FBVyxDQUFDaEcsc0JBQXNCLENBQUMsQ0FBQztNQUMxQyxNQUFNb0csZ0JBQWdCLEdBQUcsTUFBTS9GLE1BQU0sQ0FBQy9DLElBQUksRUFBQ2dELEtBQUssQ0FBQztNQUNqRCxJQUFJakIsS0FBSyxLQUFLLEdBQUcsSUFBSUcsTUFBTSxLQUFLLEdBQUcsRUFBRTtRQUNuQ2pELE1BQU0sQ0FBQzRELElBQUksQ0FBQyxNQUFNN0MsSUFBSSxDQUFDMkksT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDdkgsUUFBUSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ3lFLFNBQVMsQ0FBQyxFQUFFLHFDQUFxQyxDQUFDLENBQUNTLGVBQWUsQ0FBQyxDQUFDLENBQUM7TUFDcEk7TUFDQSxNQUFNL0csSUFBSSxDQUFDRCxNQUFNLENBQUMsVUFBVWtILE1BQU0sQ0FBQzFFLEtBQUssQ0FBQyxJQUFJMEUsTUFBTSxDQUFDdkUsTUFBTSxDQUFDLEVBQUUsRUFBRTtRQUFFdkMsSUFBSSxFQUFFLE1BQU1LLElBQUksQ0FBQytJLFVBQVUsQ0FBQyxDQUFDO1FBQUVqSixXQUFXLEVBQUU7TUFBWSxDQUFDLENBQUM7TUFDM0gsTUFBTWtKLFdBQVcsR0FBRyxNQUFNdkcsV0FBVyxDQUFDK0YsT0FBTyxFQUFDLEdBQUcvQixNQUFNLENBQUMxRSxLQUFLLENBQUMsSUFBSTBFLE1BQU0sQ0FBQ3ZFLE1BQU0sQ0FBQyxVQUFVLENBQUM7TUFDM0YsTUFBTStHLFVBQVUsR0FBRyxNQUFNeEcsV0FBVyxDQUFDZ0csUUFBUSxFQUFDLEdBQUdoQyxNQUFNLENBQUMxRSxLQUFLLENBQUMsSUFBSTBFLE1BQU0sQ0FBQ3ZFLE1BQU0sQ0FBQyxXQUFXLENBQUM7TUFDNUYsSUFBSSxDQUFDdkIsT0FBTyxJQUFJb0IsS0FBSyxLQUFLLEdBQUcsRUFBRTtRQUM3QixNQUFNbUgsR0FBRyxHQUFHLE1BQU14QyxPQUFPLENBQUN5QyxhQUFhLENBQUNuSixJQUFJLENBQUM7UUFDN0MsSUFBSTtVQUNGLE1BQU1rSixHQUFHLENBQUNFLElBQUksQ0FBQyxZQUFZLENBQUM7VUFBRSxNQUFNRixHQUFHLENBQUNFLElBQUksQ0FBQyxZQUFZLENBQUM7VUFDMUQsTUFBTWhILFFBQVEsR0FBRyxNQUFNOEcsR0FBRyxDQUFDRSxJQUFJLENBQUMsaUJBQWlCLENBQUM7VUFDbEQsTUFBTS9ILElBQUksR0FBRyxNQUFNNkgsR0FBRyxDQUFDRSxJQUFJLENBQUMsbUJBQW1CLEVBQUM7WUFBRUMsTUFBTSxFQUFFakgsUUFBUSxDQUFDa0gsSUFBSSxDQUFDRCxNQUFNO1lBQUVFLFFBQVEsRUFBRTtVQUE2RCxDQUFDLENBQUM7VUFDekosTUFBTUMsS0FBSyxHQUFHLE1BQU1OLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLDZCQUE2QixFQUFDO1lBQUVDLE1BQU0sRUFBRWhJLElBQUksQ0FBQ2dJO1VBQU8sQ0FBQyxDQUFDO1VBQ25GcEssTUFBTSxDQUFDdUssS0FBSyxDQUFDQSxLQUFLLENBQUNDLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLFVBQVUsS0FBSyxrQkFBa0IsSUFBSUQsSUFBSSxDQUFDRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUM7VUFDMUcsTUFBTTdHLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLCtCQUErQixFQUFDZ0ssS0FBSyxDQUFDO1FBQzFELENBQUMsU0FBUztVQUFFLE1BQU1OLEdBQUcsQ0FBQ1csTUFBTSxDQUFDLENBQUM7UUFBRTtNQUNsQztNQUNBakIsT0FBTyxDQUFDOUIsSUFBSSxDQUFDO1FBQUUvRSxLQUFLO1FBQUNHLE1BQU07UUFBQzRHLGdCQUFnQjtRQUFDRSxXQUFXO1FBQUNDO01BQVcsQ0FBQyxDQUFDO0lBQ3hFO0lBQ0EsTUFBTTFKLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLG1CQUFtQixFQUFDb0osT0FBTyxDQUFDO0lBRTlDLE1BQU01SSxJQUFJLENBQUM2SSxlQUFlLENBQUM7TUFBRTlHLEtBQUssRUFBQyxHQUFHO01BQUNHLE1BQU0sRUFBQztJQUFJLENBQUMsQ0FBQztJQUNwRCxNQUFNd0csV0FBVyxDQUFDaEcsc0JBQXNCLENBQUMsQ0FBQztJQUMxQyxNQUFNekQsTUFBTSxDQUFDd0osUUFBUSxDQUFDLENBQUNxQixVQUFVLENBQUNuSixPQUFPLEdBQUcsVUFBVSxHQUFHLElBQUksQ0FBQztJQUM5RCxNQUFNOEgsUUFBUSxDQUFDckksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hCLE1BQU1uQixNQUFNLENBQUNzSixLQUFLLENBQUMsQ0FBQ3dCLGFBQWEsQ0FBQ3BKLE9BQU8sR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDO0lBQ25FLE1BQU1xSixLQUFLLEdBQUcsTUFBTWpLLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDO0lBQ2hDZixNQUFNLENBQUMrSyxLQUFLLENBQUN6QyxNQUFNLENBQUMsQ0FBQzBDLE9BQU8sQ0FBQztNQUFFLEdBQUd6QyxRQUFRLENBQUNELE1BQU07TUFBRUcsV0FBVyxFQUFDLENBQUM7TUFDOURDLFdBQVcsRUFBQztRQUFFLHFCQUFxQixFQUFDLENBQUM7UUFBQyw2QkFBNkIsRUFBQztNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQzVFLE1BQU12SSxLQUFLLENBQUNZLElBQUksRUFBQyxRQUFRLENBQUM7SUFDMUIsTUFBTUEsSUFBSSxDQUFDRyxXQUFXLENBQUMsY0FBY2QsT0FBTyxFQUFFLENBQUMsQ0FBQ2UsS0FBSyxDQUFDLENBQUM7SUFDdkQsTUFBTUosSUFBSSxDQUFDNkksZUFBZSxDQUFDO01BQUU5RyxLQUFLLEVBQUMsR0FBRztNQUFDRyxNQUFNLEVBQUM7SUFBSSxDQUFDLENBQUM7SUFDcEQsSUFBSWdJLE9BQU8sR0FBRyxLQUFLO0lBQ25CLEtBQUssSUFBSUMsSUFBSSxHQUFDLENBQUMsRUFBQ0EsSUFBSSxHQUFDLEdBQUcsRUFBQ0EsSUFBSSxFQUFFLEVBQUU7TUFDL0IsTUFBTW5LLElBQUksQ0FBQ29LLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLEtBQUssQ0FBQztNQUNoQyxJQUFJLE1BQU01QixRQUFRLENBQUNySCxRQUFRLENBQUNDLElBQUksSUFBSUEsSUFBSSxLQUFLZSxRQUFRLENBQUNrSSxhQUFhLENBQUMsRUFBRTtRQUFFSixPQUFPLEdBQUMsSUFBSTtRQUFDO01BQU87SUFDOUY7SUFDQWpMLE1BQU0sQ0FBQ2lMLE9BQU8sQ0FBQyxDQUFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMxQixNQUFNbkgsTUFBTSxDQUFDdUosT0FBTyxDQUFDLENBQUNyQixXQUFXLENBQUMsQ0FBQztJQUNuQyxNQUFNbEksTUFBTSxDQUFDd0osUUFBUSxDQUFDLENBQUNxQixVQUFVLENBQUNuSixPQUFPLEdBQUcsVUFBVSxHQUFHLElBQUksQ0FBQztJQUM5RCxNQUFNMUIsTUFBTSxDQUFDd0osUUFBUSxDQUFDLENBQUM4QixXQUFXLENBQUMsQ0FBQztJQUFFLE1BQU10TCxNQUFNLENBQUN3SixRQUFRLENBQUMsQ0FBQytCLFdBQVcsQ0FBQyxDQUFDO0lBQzFFLE1BQU0vSCxXQUFXLENBQUNnRyxRQUFRLEVBQUMsaUJBQWlCLENBQUM7SUFDN0MsTUFBTXpJLElBQUksQ0FBQ29LLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLE9BQU8sQ0FBQztJQUNsQyxNQUFNcEwsTUFBTSxDQUFDc0osS0FBSyxDQUFDLENBQUN3QixhQUFhLENBQUNwSixPQUFPLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztJQUNuRSxNQUFNOEosS0FBSyxHQUFHLE1BQU0xSyxNQUFNLENBQUNDLElBQUksQ0FBQztJQUNoQ2YsTUFBTSxDQUFDd0wsS0FBSyxDQUFDbEQsTUFBTSxDQUFDLENBQUMwQyxPQUFPLENBQUM7TUFBRSxHQUFHRCxLQUFLLENBQUN6QyxNQUFNO01BQUNHLFdBQVcsRUFBQyxDQUFDO01BQzFEQyxXQUFXLEVBQUM7UUFBRSxxQkFBcUIsRUFBQyxDQUFDO1FBQUMsNkJBQTZCLEVBQUM7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUM1RSxLQUFLLE1BQU0rQyxLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUMsT0FBTyxFQUFDLEtBQUssRUFBQyxXQUFXLENBQUMsRUFBV3pMLE1BQU0sQ0FBQ3dMLEtBQUssQ0FBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ1QsT0FBTyxDQUFDekMsUUFBUSxDQUFDa0QsS0FBSyxDQUFDLENBQUM7SUFDbkgsTUFBTW5MLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLGdDQUFnQyxFQUFDO01BQUV3SyxLQUFLO01BQUNTO0lBQU0sQ0FBQyxDQUFDOztJQUVuRTtJQUNBLE1BQU03SixLQUFLLEdBQUdELE9BQU8sR0FBRyxhQUFhLEdBQUcsTUFBTTtJQUM5QyxNQUFNWCxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBRXBCLElBQUksRUFBQ21CLEtBQUs7TUFBQ0UsS0FBSyxFQUFDO0lBQUssQ0FBQyxDQUFDLENBQUNWLEtBQUssQ0FBQyxDQUFDO0lBQ2hFLE1BQU11SyxhQUFhLEdBQUcsTUFBTTNLLElBQUksQ0FBQ29CLFFBQVEsQ0FBQyxNQUFNO01BQzlDLE1BQU1MLE1BQU0sR0FBR3FCLFFBQVEsQ0FBQ2dCLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztNQUN4RCxPQUFPLENBQUMsR0FBR2hCLFFBQVEsQ0FBQytCLGdCQUFnQixDQUFDLG1FQUFtRSxDQUFDLENBQUMsQ0FBQzNDLE9BQU8sQ0FBQ0gsSUFBSSxJQUFJO1FBQ3pILE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLEVBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxDQUFDQyxPQUFPLENBQUNDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQyxJQUFJO1VBQzNELE1BQU1FLEVBQUUsR0FBQ1AsQ0FBQyxDQUFDUSxJQUFJLEdBQUNSLENBQUMsQ0FBQ1MsS0FBSyxHQUFDTixDQUFDO1lBQUVPLEVBQUUsR0FBQ1YsQ0FBQyxDQUFDVyxHQUFHLEdBQUNYLENBQUMsQ0FBQ1ksTUFBTSxHQUFDUCxDQUFDO1VBQzlDLE1BQU1RLEdBQUcsR0FBQ0MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQ1IsRUFBRSxFQUFDRyxFQUFFLENBQUM7VUFDMUMsT0FBTztZQUFFYixNQUFNLEVBQUNFLElBQUksQ0FBQ3VKLFlBQVksQ0FBQyxhQUFhLENBQUM7WUFBQ25KLENBQUMsRUFBQ0ksRUFBRTtZQUFDRixDQUFDLEVBQUNLLEVBQUU7WUFBQzZJLFlBQVksRUFBQzFJLEdBQUcsS0FBSyxJQUFJLElBQUlwQixNQUFNLEtBQUssSUFBSSxJQUFJQSxNQUFNLENBQUN3QixRQUFRLENBQUNKLEdBQUc7VUFBRSxDQUFDO1FBQ25JLENBQUMsQ0FBQyxDQUFDO01BQ0wsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDO0lBQ0YsTUFBTTVDLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLDBCQUEwQixFQUFDbUwsYUFBYSxDQUFDO0lBQzNEMUwsTUFBTSxDQUFDMEwsYUFBYSxDQUFDLENBQUNHLFlBQVksQ0FBQzlILEtBQUssR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ2xELEtBQUssTUFBTUosS0FBSyxJQUFJK0gsYUFBYSxFQUFFMUwsTUFBTSxDQUFDNEQsSUFBSSxDQUFDRCxLQUFLLENBQUMsQ0FBQ0UsYUFBYSxDQUFDO01BQUUrSCxZQUFZLEVBQUM7SUFBSyxDQUFDLENBQUM7SUFDMUYsTUFBTUUsTUFBTSxHQUFHL0ssSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUNBLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBRXBCLElBQUksRUFBQ2tCLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSTtNQUFDRyxLQUFLLEVBQUM7SUFBSyxDQUFDLENBQUM7SUFDekcsTUFBTTJCLFdBQVcsQ0FBQ3NJLE1BQU0sRUFBQyxjQUFjLENBQUM7SUFBRSxNQUFNQSxNQUFNLENBQUMzSyxLQUFLLENBQUMsQ0FBQztJQUM5RCxNQUFNbkIsTUFBTSxDQUFDZSxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDSSxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ3JELE1BQU1qQixJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDL0MsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDZ0gsV0FBVyxDQUFDLENBQUM7SUFDaEUsTUFBTWxJLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNN0IsS0FBSyxDQUFDWSxJQUFJLEVBQUMsUUFBUSxDQUFDO0lBQzFCLE1BQU1mLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2dILFdBQVcsQ0FBQyxDQUFDO0lBQzdELE1BQU1sSSxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTStKLFlBQVksR0FBR2hMLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDd0ksT0FBTyxDQUFDLFFBQVEsQ0FBQztJQUN4RSxNQUFNNUcsS0FBSyxHQUFHLE1BQU1pSixZQUFZLENBQUM1SixRQUFRLENBQUNDLElBQUk7TUFBQSxJQUFBNEoscUJBQUE7TUFBQSxPQUFLO1FBQUVDLEtBQUssRUFBQzdKLElBQUksQ0FBQ29FLFdBQVc7UUFBQzBGLEtBQUssR0FBQUYscUJBQUEsR0FBQzVKLElBQUksQ0FBQytKLGlCQUFpQixjQUFBSCxxQkFBQSx1QkFBdEJBLHFCQUFBLENBQXdCMUoscUJBQXFCLENBQUMsQ0FBQyxDQUFDUTtNQUFNLENBQUM7SUFBQSxDQUFDLENBQUM7SUFDM0k5QyxNQUFNLENBQUM4QyxLQUFLLENBQUNvSixLQUFLLENBQUMsQ0FBQzdFLHNCQUFzQixDQUFDdkUsS0FBSyxDQUFDbUosS0FBSyxHQUFHLEVBQUUsQ0FBQztJQUM1RCxNQUFNOUwsS0FBSyxDQUFDWSxJQUFJLEVBQUMsUUFBUSxDQUFDO0lBQzFCLE1BQU1mLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RGhDLE1BQU0sQ0FBQyxNQUFNZSxJQUFJLENBQUNvQixRQUFRLENBQUMsTUFBTSxVQUFVLElBQUlpSyxNQUFNLENBQUMsQ0FBQyxDQUFDakYsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUNuRSxNQUFNN0csTUFBTSxDQUFDQyxJQUFJLEVBQUMsbUJBQW1CLEVBQUNtSCxNQUFNLENBQUM7SUFBRTFILE1BQU0sQ0FBQzBILE1BQU0sQ0FBQyxDQUFDc0QsT0FBTyxDQUFDLEVBQUUsQ0FBQztJQUN6RSxNQUFNakssSUFBSSxDQUFDc0wsS0FBSyxDQUFDLENBQUM7RUFDcEIsQ0FBQyxDQUFDO0FBQ0oiLCJpZ25vcmVMaXN0IjpbXX0=