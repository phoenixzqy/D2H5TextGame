# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: skills-header-layout.spec.ts >> shared header stays clear zh-CN bonus=true
- Location: tests/pwa/skills-header-layout.spec.ts:100:3

# Error details

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves actual HUD height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: header reserves active bonus chip height

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under HUD

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: main cannot scroll under chip

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

```
Error: visible detail remains clear of HUD at original scroll position

expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

```
Error: visible detail remains clear of active chip at original scroll position

expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

```
Error: 915x412 Allocate

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: 915x412 Allocate

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: 915x412 Allocate

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: 915x412 Allocate

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: 915x412 Allocate

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: keyboard target

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: keyboard target

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: keyboard target

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: keyboard target

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: keyboard target

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

```
Error: modal cancel

expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
-   "clear": true,
+   "clear": false,
  }
```

# Test source

```ts
  1   | /** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
  2   | import { expect, test, type Locator, type Page, type TestInfo } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { navTo } from '../e2e/_helpers';
  6   | 
  7   | const MASTERY = 'skills-sorceress-lightning-mastery';
  8   | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  9   | 
  10  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  11  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  12  | }
  13  | 
  14  | async function backup(page: Page): Promise<SaveCurrent> {
  15  |   await navTo(page, 'settings');
  16  |   const pending = page.waitForEvent('download');
  17  |   await page.getByTestId('export-save-button').click();
  18  |   const download = await pending;
  19  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  20  |   finally { await download.delete(); }
  21  | }
  22  | 
  23  | async function importSave(page: Page, save: SaveCurrent, english: boolean): Promise<void> {
  24  |   const label = english ? 'Import Save' : '导入存档';
  25  |   await page.getByRole('button', { name: label, exact: true }).click();
  26  |   const dialog = page.getByRole('dialog');
  27  |   await dialog.getByRole('textbox').fill(JSON.stringify(save));
  28  |   await dialog.getByRole('button', { name: label, exact: true }).click();
  29  |   await expect(dialog).toHaveCount(0);
  30  | }
  31  | 
  32  | /** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
  33  | async function hitPoints(target: Locator): Promise<unknown[]> {
  34  |   return target.evaluate(node => {
  35  |     const b = node.getBoundingClientRect();
  36  |     return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
  37  |       const px = b.left + b.width * x, py = b.top + b.height * y;
  38  |       const hit = document.elementFromPoint(px, py);
  39  |       return { x: px, y: py, clear: hit !== null && node.contains(hit), hit: hit?.tagName ?? null };
  40  |     }));
  41  |   });
  42  | }
  43  | 
  44  | async function clearTarget(target: Locator, label: string): Promise<unknown[]> {
  45  |   await target.scrollIntoViewIfNeeded();
  46  |   const points = await hitPoints(target);
> 47  |   for (const point of points) expect.soft(point, label).toMatchObject({ clear: true });
      |                                                         ^ Error: modal cancel
  48  |   return points;
  49  | }
  50  | 
  51  | async function layout(page: Page, bonus: boolean): Promise<unknown> {
  52  |   const measured = await page.evaluate(() => {
  53  |     const main = document.querySelector('main');
  54  |     const hud = document.querySelector('[data-testid="character-hud"]');
  55  |     const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
  56  |     const header = main?.previousElementSibling;
  57  |     if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
  58  |     const rect = (node: Element) => {
  59  |       const b = node.getBoundingClientRect();
  60  |       return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height };
  61  |     };
  62  |     const h = rect(header), m = rect(main), u = rect(hud), c = chip ? rect(chip) : null;
  63  |     const contains = (a: typeof h, b: typeof h) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
  64  |     const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
  65  |       const b = rect(node);
  66  |       const visible = { left: Math.max(b.left,m.left), right: Math.min(b.right,m.right), top: Math.max(b.top,m.top), bottom: Math.min(b.bottom,m.bottom) };
  67  |       const shown = visible.right > visible.left && visible.bottom > visible.top;
  68  |       const overlaps = (a: typeof h) => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
  69  |       return { text: node.textContent, rect:b, visible, shown, hudCollision: overlaps(u), chipCollision: c !== null && overlaps(c) };
  70  |     });
  71  |     return { header: h, main: m, hud: u, chip: c, hudContained: contains(h,u), chipContained: c === null || contains(h,c),
  72  |       mainBelowHud: m.top >= u.bottom, mainBelowChip: c === null || m.top >= c.bottom,
  73  |       chipBelowButton: c === null || c.top >= u.bottom, chipOutsideButton: chip === null || !hud.contains(chip),
  74  |       documentOverflow: document.documentElement.scrollWidth - innerWidth,
  75  |       mainOverflow: main.scrollWidth - main.clientWidth, windowY: scrollY,
  76  |       shellY: main.parentElement?.parentElement?.scrollTop, mainY: main.scrollTop,
  77  |       mainScrollHeight: main.scrollHeight, mainClientHeight: main.clientHeight, targets };
  78  |   });
  79  |   expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  80  |   expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  81  |   expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  82  |   expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  83  |   expect.soft(measured.chipBelowButton).toBe(true);
  84  |   expect.soft(measured.chipOutsideButton).toBe(true);
  85  |   expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  86  |   expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  87  |   expect.soft(measured.windowY).toBe(0); expect.soft(measured.shellY).toBe(0);
  88  |   expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  89  |   expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  90  |   expect.soft(measured.main.height).toBeGreaterThan(0);
  91  |   expect.soft(measured.chip !== null).toBe(bonus);
  92  |   for (const target of measured.targets) {
  93  |     expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
  94  |     expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  95  |   }
  96  |   return measured;
  97  | }
  98  | 
  99  | for (const locale of ['en','zh-CN'] as const) for (const bonus of [false,true]) {
  100 |   test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({ page, context }, info) => {
  101 |     const english = locale === 'en';
  102 |     const errors: string[] = [];
  103 |     page.on('pageerror', error => errors.push(error.message));
  104 |     page.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  105 |     await page.goto('/settings');
  106 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  107 |     await page.goto('/');
  108 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  109 |     await page.getByTestId('home-new-game').click();
  110 |     await expect(page.getByTestId('character-hud')).toHaveCount(0);
  111 |     await page.getByTestId('class-sorceress').click();
  112 |     const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
  113 |     await page.getByTestId('character-name-input').fill(name);
  114 |     await page.getByTestId('character-start-btn').click();
  115 |     await expect(page.getByTestId('town-screen')).toBeVisible();
  116 |     await navTo(page,'settings');
  117 |     const language = page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true });
  118 |     await language.click();
  119 |     await expect(language).toHaveAttribute('aria-pressed','true');
  120 |     const fresh = await backup(page);
  121 |     expect(fresh.player.name).toBe(name);
  122 |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
  123 |       skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: ['skills-sorceress-fire-bolt'] },
  124 |       meta: { ...fresh.meta, idleState: { ...fresh.meta.idleState, lastOnline: Date.now(),
  125 |         activeMultiplier: bonus ? 1.5 : 1, multiplierSecondsRemaining: bonus ? 7200 : 0 } } };
  126 |     await importSave(page, incoming, english);
  127 |     await attach(info, '01-imported-eligibility', incoming);
  128 | 
  129 |     for (const route of ['town','settings','skills']) {
  130 |       await navTo(page, route);
  131 |       await expect(page.getByTestId('character-hud')).toHaveCount(1);
  132 |       await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
  133 |       await attach(info, `route-${route}`, await layout(page,bonus));
  134 |     }
  135 |     const panel = page.getByTestId('skill-detail-panel');
  136 |     await page.getByTestId(`skill-node-${MASTERY}`).click();
  137 |     const heading = panel.getByRole('heading', { name: english ? 'Lightning Mastery' : '闪电精通', exact: true });
  138 |     const allocate = panel.getByRole('button');
  139 |     const description = panel.locator('#skill-detail-panel > p');
  140 |     const metrics = [];
  141 |     for (const [width,height] of sizes) {
  142 |       await page.setViewportSize({ width,height });
  143 |       await description.scrollIntoViewIfNeeded();
  144 |       const originalPosition = await layout(page,bonus);
  145 |       if (width === 360 && height === 640) {
  146 |         expect.soft(await page.locator('main').evaluate(node => node.scrollTop), 'baseline detail scrolls inside main').toBeGreaterThan(0);
  147 |       }
```