from pathlib import Path
import os,sys
r=Path(__file__).resolve().parent
attempt=sys.argv[1]
env=dict(os.environ)
env.pop('VITE_E2E',None)
env.update(FONTCONFIG_FILE=str(r/'fontconfig.xml'),FONTCONFIG_PATH=str(r),TMPDIR=str(r/('browser-temp-'+attempt)),HEADER_LAYOUT_OUTPUT_DIR=str(r/('browser-'+attempt+'-output')),HEADER_LAYOUT_REPORT=str(r/('browser-'+attempt+'-report.json')))
os.execvpe('node_modules/.bin/playwright',['node_modules/.bin/playwright','test','--config','tests/pwa/skills-header-layout.config.ts'],env)
