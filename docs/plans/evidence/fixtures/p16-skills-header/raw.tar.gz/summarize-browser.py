from pathlib import Path
import json,base64,hashlib,sys
r=Path(__file__).resolve().parent
attempt=sys.argv[1]
d=json.loads((r/('browser-'+attempt+'-report.json')).read_text())
out=r/('browser-extracted-'+attempt);out.mkdir()
records=[];cases=[]
for suite in d['suites']:
 for spec in suite['specs']:
  result=spec['tests'][0]['results'][0]
  label=('en' if ' en ' in spec['title'] else 'zh-CN')+('-bonus-on' if 'bonus=true' in spec['title'] else '-bonus-off')
  values={}
  for a in result['attachments']:
   if 'body' not in a:continue
   b=base64.b64decode(a['body']);ext='.png' if a['contentType']=='image/png' else '.json'
   p=out/(label+'-'+a['name']+ext);p.write_bytes(b)
   records.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
   if ext=='.json':values[a['name']]=json.loads(b)
  cases.append({'case':spec['title'],'status':result['status'],'errors':len(result['errors']),'metrics':values.get('02-layout-metrics'),
    'modal':values.get('modal-priority-at-header'),'cancel':values.get('modal-cancel-hits'),'fonts':values.get('actual-Chinese-platform-fonts'),
    'console':values.get('04-console-errors'),'allocation':values.get('03-pointer-keyboard-allocation')})
(r/('browser-'+attempt+'-assessment.json')).write_text(json.dumps({'stats':d['stats'],'attachments':records,'cases':cases},indent=2)+'\n')
print(json.dumps({'stats':d['stats'],'attachments':len(records),'screenshots':sum(x['path'].endswith('.png') for x in records),'attachmentBytes':sum(x['bytes'] for x in records)}))
