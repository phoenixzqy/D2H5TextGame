# P16 / BUG-063 — shared header and Skills controls

Status: bounded collision fix validated locally; no remote publication. Full P16, private-v1, C0–C4 and G0–G7 remain open.

## Behavior and cause

The character HUD and active bonus chip now occupy the shared wrapping header above main. Their actual height reserves space, including long names and small portrait screens; the chip stays below/outside the navigation button. HUD visibility, navigation, accessible name, bars, save-failure ordering and combat title behavior are preserved. Main remains the scrolling container, with the top safe-area inset applied once.

The Skills detail panel also scrolls normally at desktop breakpoints. Its former 336px bottom-sticky layout could lift its heading/action behind the header in a 285px/317px landscape main. Technical/UX review accepts losing the pinned desktop preview; existing heights, inner overflow, selection and preview behavior remain.

## Failure evidence and corrections

Prepatch production baseline v4 fails all four locale/bonus cases: 31/67/31/67 soft assertions. At 915×412 the Allocate edges hit HUD/chip (3/9 without bonus, 5/9 with bonus), and HUD/chip bounds overlap. The baseline does not newly reproduce the earlier 375×667 visual collision.

The three-source header-only repair passes containment and main placement, but v5 remains RED with18/27/18/27 errors exclusively at915×412: heading/action/native-target edge checks hit header/HUD/chip. The oversized sticky panel explains the remaining obstruction. The fourth source change removes only `md:sticky md:bottom-2 md:z-10`.

All actual failed attempts are retained. Browser v2 English setup selected locale before a navigation reset; v3 selects after creation and verifies selection. V4 waits for the real export status to dismiss before modal checks and records hit owners; the earlier single bad Cancel point remains inconclusively diagnosed (toast overlap is a supported hypothesis). First partial-repair GREEN attempt timed out when a stationary mouse previewed Thunder Storm during resize; v5 moves the ordinary pointer outside nodes after selection. Assertions were retained throughout. The two browser paths were committed as explicit known-RED TDD preparation before the five-path source/bug increment; v5 partial-source evidence is bound to its source freeze, not that test-only HEAD. A contact-sheet scratch attempt failed for missing PIL; bounded installed Playwright canvas created the sheets without installing tools.

## Validation, 2026-10-21

Final gates run serially without source mutation: focused75/4files; full4527/186files (79.28s Vitest,80.520s wrapper); typecheck11.773s; lint30.608s; fresh production bridge/build9.201s. Browser4passed/0skipped/0flaky,38.734s Playwright/39.990s wrapper. All exit0; no wrapper stops/signals. The existing15s full-unit target is missed, and the existing manifest-precache build warning remains. No engine source changed, so no separate engine gate was needed.

Four production-browser scenarios combine en/zh-CN and bonus absent/present, with a valid16-character name and nine CSS viewports:360×640,412×915,640×360,375×667,393×851,768×1024,1280×800,1920×1080,915×412. All36samples pass header containment, main placement, no horizontal overflow, heading/action edge and center hits, and original-scroll collision checks. Ordinary pointer allocates rank1; guarded native Tab/Enter allocates rank2. Exported full-player expectations and untouched inventory/merc/map/formation slices pass. Route/hide/HUD navigation and full combat title pass. All54 actual-header modal hit points and36 Cancel hit points pass; console errors/warnings are empty. Actual CDP font reports show39 Chinese prose glyphs rendered with Noto Sans CJK SC in each Chinese scenario. The production build has no game bridge; no internal state injection is used.

Root visually reviewed36 exact screenshots via four contact sheets and inspected full-size en915×412 bonus and zh-CN360×640 bonus images. QA/producer independently assess evidence before closure. Screenshots record scroll positions; below-fold content still needs scrolling, and existing icon glyph boxes remain. This is collision acceptance, not full readability/accessibility, real-device, all-browser, performance, earned-campaign, balance or private-v1 certification. Eligibility is explicitly imported L30; no new persistence or autosave acceptance is claimed.

## Durable evidence and cleanup

Pending verified packet/archive and exact artifact cleanup. Preserve all failure/correction/source/review records, not only final GREEN. Original checkout remains untouched; umbrella worktree claim continues. No push, PR, merge or deployment.
