/** Production layout regression; explicitly imported L30/bonus eligibility, no game bridge. */
import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { navTo } from '../e2e/_helpers';
const MASTERY = 'skills-sorceress-lightning-mastery';
const sizes = [[360, 640], [412, 915], [640, 360], [375, 667], [393, 851], [768, 1024], [1280, 800], [1920, 1080], [915, 412]];
async function attach(info, name, value) {
  await info.attach(name, {
    body: JSON.stringify(value, null, 2),
    contentType: 'application/json'
  });
}
async function backup(page) {
  await navTo(page, 'settings');
  const pending = page.waitForEvent('download');
  await page.getByTestId('export-save-button').click();
  const download = await pending;
  try {
    return JSON.parse(await readFile(await download.path(), 'utf8'));
  } finally {
    await download.delete();
  }
}
async function importSave(page, save, english) {
  const label = english ? 'Import Save' : '导入存档';
  await page.getByRole('button', {
    name: label,
    exact: true
  }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('textbox').fill(JSON.stringify(save));
  await dialog.getByRole('button', {
    name: label,
    exact: true
  }).click();
  await expect(dialog).toHaveCount(0);
}

/** Read-only edge/center hit tests catch partial obstruction that toBeVisible misses. */
async function hitPoints(target) {
  return target.evaluate(node => {
    const b = node.getBoundingClientRect();
    return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
      var _hit$tagName, _hit$textContent$slic, _hit$textContent, _hit$closest$getAttri, _hit$closest;
      const px = b.left + b.width * x,
        py = b.top + b.height * y;
      const hit = document.elementFromPoint(px, py);
      return {
        x: px,
        y: py,
        clear: hit !== null && node.contains(hit),
        hit: (_hit$tagName = hit === null || hit === void 0 ? void 0 : hit.tagName) !== null && _hit$tagName !== void 0 ? _hit$tagName : null,
        hitText: (_hit$textContent$slic = hit === null || hit === void 0 || (_hit$textContent = hit.textContent) === null || _hit$textContent === void 0 ? void 0 : _hit$textContent.slice(0, 120)) !== null && _hit$textContent$slic !== void 0 ? _hit$textContent$slic : null,
        hitTestId: (_hit$closest$getAttri = hit === null || hit === void 0 || (_hit$closest = hit.closest('[data-testid]')) === null || _hit$closest === void 0 ? void 0 : _hit$closest.getAttribute('data-testid')) !== null && _hit$closest$getAttri !== void 0 ? _hit$closest$getAttri : null
      };
    }));
  });
}
async function clearTarget(target, label) {
  await target.scrollIntoViewIfNeeded();
  const points = await hitPoints(target);
  for (const point of points) expect.soft(point, label).toMatchObject({
    clear: true
  });
  return points;
}
async function layout(page, bonus) {
  const measured = await page.evaluate(() => {
    var _main$parentElement;
    const main = document.querySelector('main');
    const hud = document.querySelector('[data-testid="character-hud"]');
    const chip = document.querySelector('[data-testid="offline-bonus-chip"]');
    const header = main === null || main === void 0 ? void 0 : main.previousElementSibling;
    if (!main || !hud || !header) throw new Error('Expected main, HUD and screen header');
    const rect = node => {
      const b = node.getBoundingClientRect();
      return {
        left: b.left,
        top: b.top,
        right: b.right,
        bottom: b.bottom,
        width: b.width,
        height: b.height
      };
    };
    const h = rect(header),
      m = rect(main),
      u = rect(hud),
      c = chip ? rect(chip) : null;
    const contains = (a, b) => b.left >= a.left && b.right <= a.right && b.top >= a.top && b.bottom <= a.bottom;
    const targets = [...document.querySelectorAll('[data-testid="skill-detail-panel"] h2, [data-testid="skill-detail-panel"] button')].map(node => {
      const b = rect(node);
      const visible = {
        left: Math.max(b.left, m.left),
        right: Math.min(b.right, m.right),
        top: Math.max(b.top, m.top),
        bottom: Math.min(b.bottom, m.bottom)
      };
      const shown = visible.right > visible.left && visible.bottom > visible.top;
      const overlaps = a => shown && visible.left < a.right && visible.right > a.left && visible.top < a.bottom && visible.bottom > a.top;
      return {
        text: node.textContent,
        rect: b,
        visible,
        shown,
        hudCollision: overlaps(u),
        chipCollision: c !== null && overlaps(c)
      };
    });
    return {
      header: h,
      main: m,
      hud: u,
      chip: c,
      hudContained: contains(h, u),
      chipContained: c === null || contains(h, c),
      mainBelowHud: m.top >= u.bottom,
      mainBelowChip: c === null || m.top >= c.bottom,
      chipBelowButton: c === null || c.top >= u.bottom,
      chipOutsideButton: chip === null || !hud.contains(chip),
      documentOverflow: document.documentElement.scrollWidth - innerWidth,
      mainOverflow: main.scrollWidth - main.clientWidth,
      windowY: scrollY,
      shellY: (_main$parentElement = main.parentElement) === null || _main$parentElement === void 0 || (_main$parentElement = _main$parentElement.parentElement) === null || _main$parentElement === void 0 ? void 0 : _main$parentElement.scrollTop,
      mainY: main.scrollTop,
      mainScrollHeight: main.scrollHeight,
      mainClientHeight: main.clientHeight,
      targets
    };
  });
  expect.soft(measured.hudContained, 'header reserves actual HUD height').toBe(true);
  expect.soft(measured.chipContained, 'header reserves active bonus chip height').toBe(true);
  expect.soft(measured.mainBelowHud, 'main cannot scroll under HUD').toBe(true);
  expect.soft(measured.mainBelowChip, 'main cannot scroll under chip').toBe(true);
  expect.soft(measured.chipBelowButton).toBe(true);
  expect.soft(measured.chipOutsideButton).toBe(true);
  expect.soft(measured.documentOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.mainOverflow).toBeLessThanOrEqual(0);
  expect.soft(measured.windowY).toBe(0);
  expect.soft(measured.shellY).toBe(0);
  expect.soft(measured.hud.width).toBeGreaterThanOrEqual(44);
  expect.soft(measured.hud.height).toBeGreaterThanOrEqual(44);
  expect.soft(measured.main.height).toBeGreaterThan(0);
  expect.soft(measured.chip !== null).toBe(bonus);
  for (const target of measured.targets) {
    expect.soft(target.hudCollision, 'visible detail remains clear of HUD at original scroll position').toBe(false);
    expect.soft(target.chipCollision, 'visible detail remains clear of active chip at original scroll position').toBe(false);
  }
  return measured;
}
for (const locale of ['en', 'zh-CN']) for (const bonus of [false, true]) {
  test(`shared header stays clear ${locale} bonus=${String(bonus)}`, async ({
    page,
    context
  }, info) => {
    const english = locale === 'en';
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`);
    });
    await page.goto('/settings');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.goto('/');
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('home-new-game').click();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await page.getByTestId('class-sorceress').click();
    const name = english ? 'MMMMMMMMMMMMMMMM' : '闪'.repeat(16);
    await page.getByTestId('character-name-input').fill(name);
    await page.getByTestId('character-start-btn').click();
    await expect(page.getByTestId('town-screen')).toBeVisible();
    await navTo(page, 'settings');
    const language = page.getByRole('button', {
      name: english ? 'English' : '简体中文',
      exact: true
    });
    await language.click();
    await expect(language).toHaveAttribute('aria-pressed', 'true');
    const fresh = await backup(page);
    expect(fresh.player.name).toBe(name);
    const incoming = {
      ...fresh,
      player: {
        ...fresh.player,
        level: 30,
        skillPoints: 2,
        skillLevels: {
          'sorceress.fire_bolt': 1
        },
        comboOrder: ['skills-sorceress-fire-bolt']
      },
      meta: {
        ...fresh.meta,
        idleState: {
          ...fresh.meta.idleState,
          lastOnline: Date.now(),
          activeMultiplier: bonus ? 1.5 : 1,
          multiplierSecondsRemaining: bonus ? 7200 : 0
        }
      }
    };
    await importSave(page, incoming, english);
    await attach(info, '01-imported-eligibility', incoming);
    for (const route of ['town', 'settings', 'skills']) {
      await navTo(page, route);
      await expect(page.getByTestId('character-hud')).toHaveCount(1);
      await expect(page.getByTestId('character-hud')).toHaveAccessibleName(new RegExp(name));
      await attach(info, `route-${route}`, await layout(page, bonus));
    }
    const panel = page.getByTestId('skill-detail-panel');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    const heading = panel.getByRole('heading', {
      name: english ? 'Lightning Mastery' : '闪电精通',
      exact: true
    });
    const allocate = panel.getByRole('button');
    const description = panel.locator('#skill-detail-panel > p');
    const metrics = [];
    for (const [width, height] of sizes) {
      await page.setViewportSize({
        width,
        height
      });
      await description.scrollIntoViewIfNeeded();
      const originalPosition = await layout(page, bonus);
      if (width === 360 && height === 640) {
        expect.soft(await page.locator('main').evaluate(node => node.scrollTop), 'baseline detail scrolls inside main').toBeGreaterThan(0);
      }
      await info.attach(`layout-${String(width)}x${String(height)}`, {
        body: await page.screenshot(),
        contentType: 'image/png'
      });
      const headingHits = await clearTarget(heading, `${String(width)}x${String(height)} heading`);
      const actionHits = await clearTarget(allocate, `${String(width)}x${String(height)} Allocate`);
      if (!english && width === 360) {
        const cdp = await context.newCDPSession(page);
        try {
          await cdp.send('DOM.enable');
          await cdp.send('CSS.enable');
          const document = await cdp.send('DOM.getDocument');
          const node = await cdp.send('DOM.querySelector', {
            nodeId: document.root.nodeId,
            selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p'
          });
          const fonts = await cdp.send('CSS.getPlatformFontsForNode', {
            nodeId: node.nodeId
          });
          expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
          await attach(info, 'actual-Chinese-platform-fonts', fonts);
        } finally {
          await cdp.detach();
        }
      }
      metrics.push({
        width,
        height,
        originalPosition,
        headingHits,
        actionHits
      });
    }
    await attach(info, '02-layout-metrics', metrics);
    await page.setViewportSize({
      width: 375,
      height: 667
    });
    await description.scrollIntoViewIfNeeded();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await allocate.click(); // Ordinary pointer; Playwright must resolve the actual target.
    await expect(panel).toContainText(english ? 'Lv. 1/20' : '等级 1/20');
    const rank1 = await backup(page);
    expect(rank1.player).toEqual({
      ...incoming.player,
      skillPoints: 1,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 1
      }
    });
    await navTo(page, 'skills');
    await page.getByTestId(`skill-node-${MASTERY}`).click();
    await page.setViewportSize({
      width: 915,
      height: 412
    });
    let reached = false;
    for (let step = 0; step < 100; step++) {
      await page.keyboard.press('Tab');
      if (await allocate.evaluate(node => node === document.activeElement)) {
        reached = true;
        break;
      }
    }
    expect(reached).toBe(true);
    await expect(heading).toBeVisible();
    await expect(allocate).toHaveText(english ? 'Allocate' : '分配');
    await expect(allocate).toBeEnabled();
    await expect(allocate).toBeFocused();
    await clearTarget(allocate, 'keyboard target');
    await page.keyboard.press('Enter');
    await expect(panel).toContainText(english ? 'Lv. 2/20' : '等级 2/20');
    const rank2 = await backup(page);
    expect(rank2.player).toEqual({
      ...rank1.player,
      skillPoints: 0,
      skillLevels: {
        'sorceress.fire_bolt': 1,
        'sorceress.lightning_mastery': 2
      }
    });
    for (const slice of ['inventory', 'mercs', 'map', 'formation']) expect(rank2[slice]).toEqual(incoming[slice]);
    await attach(info, '03-pointer-keyboard-allocation', {
      rank1,
      rank2
    });

    // Let the actual export status dismiss before opening the unrelated dialog.
    await expect(page.getByRole('status')).toHaveCount(0);
    // Real dialog remains above the shared header, including with an active chip.
    const label = english ? 'Import Save' : '导入存档';
    await page.getByRole('button', {
      name: label,
      exact: true
    }).click();
    const modalPriority = await page.evaluate(() => {
      const dialog = document.querySelector('[role="dialog"]');
      return [...document.querySelectorAll('[data-testid="character-hud"], [data-testid="offline-bonus-chip"]')].flatMap(node => {
        const b = node.getBoundingClientRect();
        return [0.05, 0.5, 0.95].flatMap(x => [0.05, 0.5, 0.95].map(y => {
          const px = b.left + b.width * x,
            py = b.top + b.height * y;
          const hit = document.elementFromPoint(px, py);
          return {
            target: node.getAttribute('data-testid'),
            x: px,
            y: py,
            modalOwnsHit: hit !== null && dialog !== null && dialog.contains(hit)
          };
        }));
      });
    });
    await attach(info, 'modal-priority-at-header', modalPriority);
    expect(modalPriority).toHaveLength(bonus ? 18 : 9);
    for (const point of modalPriority) expect.soft(point).toMatchObject({
      modalOwnsHit: true
    });
    const cancel = page.getByRole('dialog').getByRole('button', {
      name: english ? 'Cancel' : '取消',
      exact: true
    });
    await attach(info, 'modal-cancel-hits', await clearTarget(cancel, 'modal cancel'));
    await cancel.click();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    await page.getByTestId('character-hud').click();
    await expect(page.getByTestId('character-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    await navTo(page, 'combat');
    await expect(page.getByTestId('combat-screen')).toBeVisible();
    await expect(page.getByTestId('character-hud')).toHaveCount(0);
    const combatHeader = page.getByTestId('combat-screen').locator('header');
    const width = await combatHeader.evaluate(node => {
      var _node$firstElementChi;
      return {
        outer: node.clientWidth,
        inner: (_node$firstElementChi = node.firstElementChild) === null || _node$firstElementChi === void 0 ? void 0 : _node$firstElementChi.getBoundingClientRect().width
      };
    });
    expect(width.inner).toBeGreaterThanOrEqual(width.outer - 32);
    await navTo(page, 'skills');
    await expect(page.getByTestId('character-hud')).toHaveCount(1);
    expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
    await attach(info, '04-console-errors', errors);
    expect(errors).toEqual([]);
    await page.close();
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleHBlY3QiLCJ0ZXN0IiwicmVhZEZpbGUiLCJuYXZUbyIsIk1BU1RFUlkiLCJzaXplcyIsImF0dGFjaCIsImluZm8iLCJuYW1lIiwidmFsdWUiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbnRlbnRUeXBlIiwiYmFja3VwIiwicGFnZSIsInBlbmRpbmciLCJ3YWl0Rm9yRXZlbnQiLCJnZXRCeVRlc3RJZCIsImNsaWNrIiwiZG93bmxvYWQiLCJwYXJzZSIsInBhdGgiLCJkZWxldGUiLCJpbXBvcnRTYXZlIiwic2F2ZSIsImVuZ2xpc2giLCJsYWJlbCIsImdldEJ5Um9sZSIsImV4YWN0IiwiZGlhbG9nIiwiZmlsbCIsInRvSGF2ZUNvdW50IiwiaGl0UG9pbnRzIiwidGFyZ2V0IiwiZXZhbHVhdGUiLCJub2RlIiwiYiIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsImZsYXRNYXAiLCJ4IiwibWFwIiwieSIsIl9oaXQkdGFnTmFtZSIsIl9oaXQkdGV4dENvbnRlbnQkc2xpYyIsIl9oaXQkdGV4dENvbnRlbnQiLCJfaGl0JGNsb3Nlc3QkZ2V0QXR0cmkiLCJfaGl0JGNsb3Nlc3QiLCJweCIsImxlZnQiLCJ3aWR0aCIsInB5IiwidG9wIiwiaGVpZ2h0IiwiaGl0IiwiZG9jdW1lbnQiLCJlbGVtZW50RnJvbVBvaW50IiwiY2xlYXIiLCJjb250YWlucyIsInRhZ05hbWUiLCJoaXRUZXh0IiwidGV4dENvbnRlbnQiLCJzbGljZSIsImhpdFRlc3RJZCIsImNsb3Nlc3QiLCJnZXRBdHRyaWJ1dGUiLCJjbGVhclRhcmdldCIsInNjcm9sbEludG9WaWV3SWZOZWVkZWQiLCJwb2ludHMiLCJwb2ludCIsInNvZnQiLCJ0b01hdGNoT2JqZWN0IiwibGF5b3V0IiwiYm9udXMiLCJtZWFzdXJlZCIsIl9tYWluJHBhcmVudEVsZW1lbnQiLCJtYWluIiwicXVlcnlTZWxlY3RvciIsImh1ZCIsImNoaXAiLCJoZWFkZXIiLCJwcmV2aW91c0VsZW1lbnRTaWJsaW5nIiwiRXJyb3IiLCJyZWN0IiwicmlnaHQiLCJib3R0b20iLCJoIiwibSIsInUiLCJjIiwiYSIsInRhcmdldHMiLCJxdWVyeVNlbGVjdG9yQWxsIiwidmlzaWJsZSIsIk1hdGgiLCJtYXgiLCJtaW4iLCJzaG93biIsIm92ZXJsYXBzIiwidGV4dCIsImh1ZENvbGxpc2lvbiIsImNoaXBDb2xsaXNpb24iLCJodWRDb250YWluZWQiLCJjaGlwQ29udGFpbmVkIiwibWFpbkJlbG93SHVkIiwibWFpbkJlbG93Q2hpcCIsImNoaXBCZWxvd0J1dHRvbiIsImNoaXBPdXRzaWRlQnV0dG9uIiwiZG9jdW1lbnRPdmVyZmxvdyIsImRvY3VtZW50RWxlbWVudCIsInNjcm9sbFdpZHRoIiwiaW5uZXJXaWR0aCIsIm1haW5PdmVyZmxvdyIsImNsaWVudFdpZHRoIiwid2luZG93WSIsInNjcm9sbFkiLCJzaGVsbFkiLCJwYXJlbnRFbGVtZW50Iiwic2Nyb2xsVG9wIiwibWFpblkiLCJtYWluU2Nyb2xsSGVpZ2h0Iiwic2Nyb2xsSGVpZ2h0IiwibWFpbkNsaWVudEhlaWdodCIsImNsaWVudEhlaWdodCIsInRvQmUiLCJ0b0JlTGVzc1RoYW5PckVxdWFsIiwidG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCIsInRvQmVHcmVhdGVyVGhhbiIsImxvY2FsZSIsIlN0cmluZyIsImNvbnRleHQiLCJlcnJvcnMiLCJvbiIsImVycm9yIiwicHVzaCIsIm1lc3NhZ2UiLCJ0eXBlIiwiZ290byIsInJlcGVhdCIsInRvQmVWaXNpYmxlIiwibGFuZ3VhZ2UiLCJ0b0hhdmVBdHRyaWJ1dGUiLCJmcmVzaCIsInBsYXllciIsImluY29taW5nIiwibGV2ZWwiLCJza2lsbFBvaW50cyIsInNraWxsTGV2ZWxzIiwiY29tYm9PcmRlciIsIm1ldGEiLCJpZGxlU3RhdGUiLCJsYXN0T25saW5lIiwiRGF0ZSIsIm5vdyIsImFjdGl2ZU11bHRpcGxpZXIiLCJtdWx0aXBsaWVyU2Vjb25kc1JlbWFpbmluZyIsInJvdXRlIiwidG9IYXZlQWNjZXNzaWJsZU5hbWUiLCJSZWdFeHAiLCJwYW5lbCIsImhlYWRpbmciLCJhbGxvY2F0ZSIsImRlc2NyaXB0aW9uIiwibG9jYXRvciIsIm1ldHJpY3MiLCJzZXRWaWV3cG9ydFNpemUiLCJvcmlnaW5hbFBvc2l0aW9uIiwic2NyZWVuc2hvdCIsImhlYWRpbmdIaXRzIiwiYWN0aW9uSGl0cyIsImNkcCIsIm5ld0NEUFNlc3Npb24iLCJzZW5kIiwibm9kZUlkIiwicm9vdCIsInNlbGVjdG9yIiwiZm9udHMiLCJzb21lIiwiZm9udCIsImZhbWlseU5hbWUiLCJnbHlwaENvdW50IiwiZGV0YWNoIiwidG9IYXZlVGV4dCIsInRvQ29udGFpblRleHQiLCJyYW5rMSIsInRvRXF1YWwiLCJyZWFjaGVkIiwic3RlcCIsImtleWJvYXJkIiwicHJlc3MiLCJhY3RpdmVFbGVtZW50IiwidG9CZUVuYWJsZWQiLCJ0b0JlRm9jdXNlZCIsInJhbmsyIiwibW9kYWxQcmlvcml0eSIsIm1vZGFsT3duc0hpdCIsInRvSGF2ZUxlbmd0aCIsImNhbmNlbCIsImNvbWJhdEhlYWRlciIsIl9ub2RlJGZpcnN0RWxlbWVudENoaSIsIm91dGVyIiwiaW5uZXIiLCJmaXJzdEVsZW1lbnRDaGlsZCIsIndpbmRvdyIsImNsb3NlIl0sInNvdXJjZXMiOlsic2tpbGxzLWhlYWRlci1sYXlvdXQuc3BlYy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiogUHJvZHVjdGlvbiBsYXlvdXQgcmVncmVzc2lvbjsgZXhwbGljaXRseSBpbXBvcnRlZCBMMzAvYm9udXMgZWxpZ2liaWxpdHksIG5vIGdhbWUgYnJpZGdlLiAqL1xuaW1wb3J0IHsgZXhwZWN0LCB0ZXN0LCB0eXBlIExvY2F0b3IsIHR5cGUgUGFnZSwgdHlwZSBUZXN0SW5mbyB9IGZyb20gJ0BwbGF5d3JpZ2h0L3Rlc3QnO1xuaW1wb3J0IHsgcmVhZEZpbGUgfSBmcm9tICdub2RlOmZzL3Byb21pc2VzJztcbmltcG9ydCB0eXBlIHsgU2F2ZUN1cnJlbnQgfSBmcm9tICcuLi8uLi9zcmMvZW5naW5lL3R5cGVzL3NhdmUnO1xuaW1wb3J0IHsgbmF2VG8gfSBmcm9tICcuLi9lMmUvX2hlbHBlcnMnO1xuXG5jb25zdCBNQVNURVJZID0gJ3NraWxscy1zb3JjZXJlc3MtbGlnaHRuaW5nLW1hc3RlcnknO1xuY29uc3Qgc2l6ZXMgPSBbWzM2MCw2NDBdLFs0MTIsOTE1XSxbNjQwLDM2MF0sWzM3NSw2NjddLFszOTMsODUxXSxbNzY4LDEwMjRdLFsxMjgwLDgwMF0sWzE5MjAsMTA4MF0sWzkxNSw0MTJdXSBhcyBjb25zdDtcblxuYXN5bmMgZnVuY3Rpb24gYXR0YWNoKGluZm86IFRlc3RJbmZvLCBuYW1lOiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGluZm8uYXR0YWNoKG5hbWUsIHsgYm9keTogSlNPTi5zdHJpbmdpZnkodmFsdWUsIG51bGwsIDIpLCBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBiYWNrdXAocGFnZTogUGFnZSk6IFByb21pc2U8U2F2ZUN1cnJlbnQ+IHtcbiAgYXdhaXQgbmF2VG8ocGFnZSwgJ3NldHRpbmdzJyk7XG4gIGNvbnN0IHBlbmRpbmcgPSBwYWdlLndhaXRGb3JFdmVudCgnZG93bmxvYWQnKTtcbiAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnZXhwb3J0LXNhdmUtYnV0dG9uJykuY2xpY2soKTtcbiAgY29uc3QgZG93bmxvYWQgPSBhd2FpdCBwZW5kaW5nO1xuICB0cnkgeyByZXR1cm4gSlNPTi5wYXJzZShhd2FpdCByZWFkRmlsZShhd2FpdCBkb3dubG9hZC5wYXRoKCksICd1dGY4JykpIGFzIFNhdmVDdXJyZW50OyB9XG4gIGZpbmFsbHkgeyBhd2FpdCBkb3dubG9hZC5kZWxldGUoKTsgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBpbXBvcnRTYXZlKHBhZ2U6IFBhZ2UsIHNhdmU6IFNhdmVDdXJyZW50LCBlbmdsaXNoOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGxhYmVsID0gZW5nbGlzaCA/ICdJbXBvcnQgU2F2ZScgOiAn5a+85YWl5a2Y5qGjJztcbiAgYXdhaXQgcGFnZS5nZXRCeVJvbGUoJ2J1dHRvbicsIHsgbmFtZTogbGFiZWwsIGV4YWN0OiB0cnVlIH0pLmNsaWNrKCk7XG4gIGNvbnN0IGRpYWxvZyA9IHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKTtcbiAgYXdhaXQgZGlhbG9nLmdldEJ5Um9sZSgndGV4dGJveCcpLmZpbGwoSlNPTi5zdHJpbmdpZnkoc2F2ZSkpO1xuICBhd2FpdCBkaWFsb2cuZ2V0QnlSb2xlKCdidXR0b24nLCB7IG5hbWU6IGxhYmVsLCBleGFjdDogdHJ1ZSB9KS5jbGljaygpO1xuICBhd2FpdCBleHBlY3QoZGlhbG9nKS50b0hhdmVDb3VudCgwKTtcbn1cblxuLyoqIFJlYWQtb25seSBlZGdlL2NlbnRlciBoaXQgdGVzdHMgY2F0Y2ggcGFydGlhbCBvYnN0cnVjdGlvbiB0aGF0IHRvQmVWaXNpYmxlIG1pc3Nlcy4gKi9cbmFzeW5jIGZ1bmN0aW9uIGhpdFBvaW50cyh0YXJnZXQ6IExvY2F0b3IpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICByZXR1cm4gdGFyZ2V0LmV2YWx1YXRlKG5vZGUgPT4ge1xuICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHJldHVybiBbMC4wNSwgMC41LCAwLjk1XS5mbGF0TWFwKHggPT4gWzAuMDUsIDAuNSwgMC45NV0ubWFwKHkgPT4ge1xuICAgICAgY29uc3QgcHggPSBiLmxlZnQgKyBiLndpZHRoICogeCwgcHkgPSBiLnRvcCArIGIuaGVpZ2h0ICogeTtcbiAgICAgIGNvbnN0IGhpdCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQocHgsIHB5KTtcbiAgICAgIHJldHVybiB7IHg6IHB4LCB5OiBweSwgY2xlYXI6IGhpdCAhPT0gbnVsbCAmJiBub2RlLmNvbnRhaW5zKGhpdCksIGhpdDogaGl0Py50YWdOYW1lID8/IG51bGwsXG4gICAgICAgIGhpdFRleHQ6aGl0Py50ZXh0Q29udGVudD8uc2xpY2UoMCwxMjApID8/IG51bGwsIGhpdFRlc3RJZDpoaXQ/LmNsb3Nlc3QoJ1tkYXRhLXRlc3RpZF0nKT8uZ2V0QXR0cmlidXRlKCdkYXRhLXRlc3RpZCcpID8/IG51bGwgfTtcbiAgICB9KSk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjbGVhclRhcmdldCh0YXJnZXQ6IExvY2F0b3IsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPHVua25vd25bXT4ge1xuICBhd2FpdCB0YXJnZXQuc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICBjb25zdCBwb2ludHMgPSBhd2FpdCBoaXRQb2ludHModGFyZ2V0KTtcbiAgZm9yIChjb25zdCBwb2ludCBvZiBwb2ludHMpIGV4cGVjdC5zb2Z0KHBvaW50LCBsYWJlbCkudG9NYXRjaE9iamVjdCh7IGNsZWFyOiB0cnVlIH0pO1xuICByZXR1cm4gcG9pbnRzO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsYXlvdXQocGFnZTogUGFnZSwgYm9udXM6IGJvb2xlYW4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgY29uc3QgbWVhc3VyZWQgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICBjb25zdCBtYWluID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignbWFpbicpO1xuICAgIGNvbnN0IGh1ZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLXRlc3RpZD1cImNoYXJhY3Rlci1odWRcIl0nKTtcbiAgICBjb25zdCBjaGlwID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2RhdGEtdGVzdGlkPVwib2ZmbGluZS1ib251cy1jaGlwXCJdJyk7XG4gICAgY29uc3QgaGVhZGVyID0gbWFpbj8ucHJldmlvdXNFbGVtZW50U2libGluZztcbiAgICBpZiAoIW1haW4gfHwgIWh1ZCB8fCAhaGVhZGVyKSB0aHJvdyBuZXcgRXJyb3IoJ0V4cGVjdGVkIG1haW4sIEhVRCBhbmQgc2NyZWVuIGhlYWRlcicpO1xuICAgIGNvbnN0IHJlY3QgPSAobm9kZTogRWxlbWVudCkgPT4ge1xuICAgICAgY29uc3QgYiA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICByZXR1cm4geyBsZWZ0OiBiLmxlZnQsIHRvcDogYi50b3AsIHJpZ2h0OiBiLnJpZ2h0LCBib3R0b206IGIuYm90dG9tLCB3aWR0aDogYi53aWR0aCwgaGVpZ2h0OiBiLmhlaWdodCB9O1xuICAgIH07XG4gICAgY29uc3QgaCA9IHJlY3QoaGVhZGVyKSwgbSA9IHJlY3QobWFpbiksIHUgPSByZWN0KGh1ZCksIGMgPSBjaGlwID8gcmVjdChjaGlwKSA6IG51bGw7XG4gICAgY29uc3QgY29udGFpbnMgPSAoYTogdHlwZW9mIGgsIGI6IHR5cGVvZiBoKSA9PiBiLmxlZnQgPj0gYS5sZWZ0ICYmIGIucmlnaHQgPD0gYS5yaWdodCAmJiBiLnRvcCA+PSBhLnRvcCAmJiBiLmJvdHRvbSA8PSBhLmJvdHRvbTtcbiAgICBjb25zdCB0YXJnZXRzID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLXRlc3RpZD1cInNraWxsLWRldGFpbC1wYW5lbFwiXSBoMiwgW2RhdGEtdGVzdGlkPVwic2tpbGwtZGV0YWlsLXBhbmVsXCJdIGJ1dHRvbicpXS5tYXAobm9kZSA9PiB7XG4gICAgICBjb25zdCBiID0gcmVjdChub2RlKTtcbiAgICAgIGNvbnN0IHZpc2libGUgPSB7IGxlZnQ6IE1hdGgubWF4KGIubGVmdCxtLmxlZnQpLCByaWdodDogTWF0aC5taW4oYi5yaWdodCxtLnJpZ2h0KSwgdG9wOiBNYXRoLm1heChiLnRvcCxtLnRvcCksIGJvdHRvbTogTWF0aC5taW4oYi5ib3R0b20sbS5ib3R0b20pIH07XG4gICAgICBjb25zdCBzaG93biA9IHZpc2libGUucmlnaHQgPiB2aXNpYmxlLmxlZnQgJiYgdmlzaWJsZS5ib3R0b20gPiB2aXNpYmxlLnRvcDtcbiAgICAgIGNvbnN0IG92ZXJsYXBzID0gKGE6IHR5cGVvZiBoKSA9PiBzaG93biAmJiB2aXNpYmxlLmxlZnQgPCBhLnJpZ2h0ICYmIHZpc2libGUucmlnaHQgPiBhLmxlZnQgJiYgdmlzaWJsZS50b3AgPCBhLmJvdHRvbSAmJiB2aXNpYmxlLmJvdHRvbSA+IGEudG9wO1xuICAgICAgcmV0dXJuIHsgdGV4dDogbm9kZS50ZXh0Q29udGVudCwgcmVjdDpiLCB2aXNpYmxlLCBzaG93biwgaHVkQ29sbGlzaW9uOiBvdmVybGFwcyh1KSwgY2hpcENvbGxpc2lvbjogYyAhPT0gbnVsbCAmJiBvdmVybGFwcyhjKSB9O1xuICAgIH0pO1xuICAgIHJldHVybiB7IGhlYWRlcjogaCwgbWFpbjogbSwgaHVkOiB1LCBjaGlwOiBjLCBodWRDb250YWluZWQ6IGNvbnRhaW5zKGgsdSksIGNoaXBDb250YWluZWQ6IGMgPT09IG51bGwgfHwgY29udGFpbnMoaCxjKSxcbiAgICAgIG1haW5CZWxvd0h1ZDogbS50b3AgPj0gdS5ib3R0b20sIG1haW5CZWxvd0NoaXA6IGMgPT09IG51bGwgfHwgbS50b3AgPj0gYy5ib3R0b20sXG4gICAgICBjaGlwQmVsb3dCdXR0b246IGMgPT09IG51bGwgfHwgYy50b3AgPj0gdS5ib3R0b20sIGNoaXBPdXRzaWRlQnV0dG9uOiBjaGlwID09PSBudWxsIHx8ICFodWQuY29udGFpbnMoY2hpcCksXG4gICAgICBkb2N1bWVudE92ZXJmbG93OiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGggLSBpbm5lcldpZHRoLFxuICAgICAgbWFpbk92ZXJmbG93OiBtYWluLnNjcm9sbFdpZHRoIC0gbWFpbi5jbGllbnRXaWR0aCwgd2luZG93WTogc2Nyb2xsWSxcbiAgICAgIHNoZWxsWTogbWFpbi5wYXJlbnRFbGVtZW50Py5wYXJlbnRFbGVtZW50Py5zY3JvbGxUb3AsIG1haW5ZOiBtYWluLnNjcm9sbFRvcCxcbiAgICAgIG1haW5TY3JvbGxIZWlnaHQ6IG1haW4uc2Nyb2xsSGVpZ2h0LCBtYWluQ2xpZW50SGVpZ2h0OiBtYWluLmNsaWVudEhlaWdodCwgdGFyZ2V0cyB9O1xuICB9KTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuaHVkQ29udGFpbmVkLCAnaGVhZGVyIHJlc2VydmVzIGFjdHVhbCBIVUQgaGVpZ2h0JykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcENvbnRhaW5lZCwgJ2hlYWRlciByZXNlcnZlcyBhY3RpdmUgYm9udXMgY2hpcCBoZWlnaHQnKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluQmVsb3dIdWQsICdtYWluIGNhbm5vdCBzY3JvbGwgdW5kZXIgSFVEJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbkJlbG93Q2hpcCwgJ21haW4gY2Fubm90IHNjcm9sbCB1bmRlciBjaGlwJykudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuY2hpcEJlbG93QnV0dG9uKS50b0JlKHRydWUpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwT3V0c2lkZUJ1dHRvbikudG9CZSh0cnVlKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQuZG9jdW1lbnRPdmVyZmxvdykudG9CZUxlc3NUaGFuT3JFcXVhbCgwKTtcbiAgZXhwZWN0LnNvZnQobWVhc3VyZWQubWFpbk92ZXJmbG93KS50b0JlTGVzc1RoYW5PckVxdWFsKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC53aW5kb3dZKS50b0JlKDApOyBleHBlY3Quc29mdChtZWFzdXJlZC5zaGVsbFkpLnRvQmUoMCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC53aWR0aCkudG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCg0NCk7XG4gIGV4cGVjdC5zb2Z0KG1lYXN1cmVkLmh1ZC5oZWlnaHQpLnRvQmVHcmVhdGVyVGhhbk9yRXF1YWwoNDQpO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5tYWluLmhlaWdodCkudG9CZUdyZWF0ZXJUaGFuKDApO1xuICBleHBlY3Quc29mdChtZWFzdXJlZC5jaGlwICE9PSBudWxsKS50b0JlKGJvbnVzKTtcbiAgZm9yIChjb25zdCB0YXJnZXQgb2YgbWVhc3VyZWQudGFyZ2V0cykge1xuICAgIGV4cGVjdC5zb2Z0KHRhcmdldC5odWRDb2xsaXNpb24sICd2aXNpYmxlIGRldGFpbCByZW1haW5zIGNsZWFyIG9mIEhVRCBhdCBvcmlnaW5hbCBzY3JvbGwgcG9zaXRpb24nKS50b0JlKGZhbHNlKTtcbiAgICBleHBlY3Quc29mdCh0YXJnZXQuY2hpcENvbGxpc2lvbiwgJ3Zpc2libGUgZGV0YWlsIHJlbWFpbnMgY2xlYXIgb2YgYWN0aXZlIGNoaXAgYXQgb3JpZ2luYWwgc2Nyb2xsIHBvc2l0aW9uJykudG9CZShmYWxzZSk7XG4gIH1cbiAgcmV0dXJuIG1lYXN1cmVkO1xufVxuXG5mb3IgKGNvbnN0IGxvY2FsZSBvZiBbJ2VuJywnemgtQ04nXSBhcyBjb25zdCkgZm9yIChjb25zdCBib251cyBvZiBbZmFsc2UsdHJ1ZV0pIHtcbiAgdGVzdChgc2hhcmVkIGhlYWRlciBzdGF5cyBjbGVhciAke2xvY2FsZX0gYm9udXM9JHtTdHJpbmcoYm9udXMpfWAsIGFzeW5jICh7IHBhZ2UsIGNvbnRleHQgfSwgaW5mbykgPT4ge1xuICAgIGNvbnN0IGVuZ2xpc2ggPSBsb2NhbGUgPT09ICdlbic7XG4gICAgY29uc3QgZXJyb3JzOiBzdHJpbmdbXSA9IFtdO1xuICAgIHBhZ2Uub24oJ3BhZ2VlcnJvcicsIGVycm9yID0+IGVycm9ycy5wdXNoKGVycm9yLm1lc3NhZ2UpKTtcbiAgICBwYWdlLm9uKCdjb25zb2xlJywgbWVzc2FnZSA9PiB7IGlmIChtZXNzYWdlLnR5cGUoKSA9PT0gJ2Vycm9yJyB8fCBtZXNzYWdlLnR5cGUoKSA9PT0gJ3dhcm5pbmcnKSBlcnJvcnMucHVzaChgJHttZXNzYWdlLnR5cGUoKX06ICR7bWVzc2FnZS50ZXh0KCl9YCk7IH0pO1xuICAgIGF3YWl0IHBhZ2UuZ290bygnL3NldHRpbmdzJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nb3RvKCcvJyk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnaG9tZS1uZXctZ2FtZScpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2xhc3Mtc29yY2VyZXNzJykuY2xpY2soKTtcbiAgICBjb25zdCBuYW1lID0gZW5nbGlzaCA/ICdNTU1NTU1NTU1NTU1NTU1NJyA6ICfpl6onLnJlcGVhdCgxNik7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLW5hbWUtaW5wdXQnKS5maWxsKG5hbWUpO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1zdGFydC1idG4nKS5jbGljaygpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCd0b3duLXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NldHRpbmdzJyk7XG4gICAgY29uc3QgbGFuZ3VhZ2UgPSBwYWdlLmdldEJ5Um9sZSgnYnV0dG9uJywgeyBuYW1lOiBlbmdsaXNoID8gJ0VuZ2xpc2gnIDogJ+eugOS9k+S4reaWhycsIGV4YWN0OiB0cnVlIH0pO1xuICAgIGF3YWl0IGxhbmd1YWdlLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KGxhbmd1YWdlKS50b0hhdmVBdHRyaWJ1dGUoJ2FyaWEtcHJlc3NlZCcsJ3RydWUnKTtcbiAgICBjb25zdCBmcmVzaCA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QoZnJlc2gucGxheWVyLm5hbWUpLnRvQmUobmFtZSk7XG4gICAgY29uc3QgaW5jb21pbmc6IFNhdmVDdXJyZW50ID0geyAuLi5mcmVzaCwgcGxheWVyOiB7IC4uLmZyZXNoLnBsYXllciwgbGV2ZWw6IDMwLCBza2lsbFBvaW50czogMixcbiAgICAgIHNraWxsTGV2ZWxzOiB7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzogMSB9LCBjb21ib09yZGVyOiBbJ3NraWxscy1zb3JjZXJlc3MtZmlyZS1ib2x0J10gfSxcbiAgICAgIG1ldGE6IHsgLi4uZnJlc2gubWV0YSwgaWRsZVN0YXRlOiB7IC4uLmZyZXNoLm1ldGEuaWRsZVN0YXRlLCBsYXN0T25saW5lOiBEYXRlLm5vdygpLFxuICAgICAgICBhY3RpdmVNdWx0aXBsaWVyOiBib251cyA/IDEuNSA6IDEsIG11bHRpcGxpZXJTZWNvbmRzUmVtYWluaW5nOiBib251cyA/IDcyMDAgOiAwIH0gfSB9O1xuICAgIGF3YWl0IGltcG9ydFNhdmUocGFnZSwgaW5jb21pbmcsIGVuZ2xpc2gpO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCAnMDEtaW1wb3J0ZWQtZWxpZ2liaWxpdHknLCBpbmNvbWluZyk7XG5cbiAgICBmb3IgKGNvbnN0IHJvdXRlIG9mIFsndG93bicsJ3NldHRpbmdzJywnc2tpbGxzJ10pIHtcbiAgICAgIGF3YWl0IG5hdlRvKHBhZ2UsIHJvdXRlKTtcbiAgICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDEpO1xuICAgICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1odWQnKSkudG9IYXZlQWNjZXNzaWJsZU5hbWUobmV3IFJlZ0V4cChuYW1lKSk7XG4gICAgICBhd2FpdCBhdHRhY2goaW5mbywgYHJvdXRlLSR7cm91dGV9YCwgYXdhaXQgbGF5b3V0KHBhZ2UsYm9udXMpKTtcbiAgICB9XG4gICAgY29uc3QgcGFuZWwgPSBwYWdlLmdldEJ5VGVzdElkKCdza2lsbC1kZXRhaWwtcGFuZWwnKTtcbiAgICBhd2FpdCBwYWdlLmdldEJ5VGVzdElkKGBza2lsbC1ub2RlLSR7TUFTVEVSWX1gKS5jbGljaygpO1xuICAgIGNvbnN0IGhlYWRpbmcgPSBwYW5lbC5nZXRCeVJvbGUoJ2hlYWRpbmcnLCB7IG5hbWU6IGVuZ2xpc2ggPyAnTGlnaHRuaW5nIE1hc3RlcnknIDogJ+mXqueUteeyvumAmicsIGV4YWN0OiB0cnVlIH0pO1xuICAgIGNvbnN0IGFsbG9jYXRlID0gcGFuZWwuZ2V0QnlSb2xlKCdidXR0b24nKTtcbiAgICBjb25zdCBkZXNjcmlwdGlvbiA9IHBhbmVsLmxvY2F0b3IoJyNza2lsbC1kZXRhaWwtcGFuZWwgPiBwJyk7XG4gICAgY29uc3QgbWV0cmljcyA9IFtdO1xuICAgIGZvciAoY29uc3QgW3dpZHRoLGhlaWdodF0gb2Ygc2l6ZXMpIHtcbiAgICAgIGF3YWl0IHBhZ2Uuc2V0Vmlld3BvcnRTaXplKHsgd2lkdGgsaGVpZ2h0IH0pO1xuICAgICAgYXdhaXQgZGVzY3JpcHRpb24uc2Nyb2xsSW50b1ZpZXdJZk5lZWRlZCgpO1xuICAgICAgY29uc3Qgb3JpZ2luYWxQb3NpdGlvbiA9IGF3YWl0IGxheW91dChwYWdlLGJvbnVzKTtcbiAgICAgIGlmICh3aWR0aCA9PT0gMzYwICYmIGhlaWdodCA9PT0gNjQwKSB7XG4gICAgICAgIGV4cGVjdC5zb2Z0KGF3YWl0IHBhZ2UubG9jYXRvcignbWFpbicpLmV2YWx1YXRlKG5vZGUgPT4gbm9kZS5zY3JvbGxUb3ApLCAnYmFzZWxpbmUgZGV0YWlsIHNjcm9sbHMgaW5zaWRlIG1haW4nKS50b0JlR3JlYXRlclRoYW4oMCk7XG4gICAgICB9XG4gICAgICBhd2FpdCBpbmZvLmF0dGFjaChgbGF5b3V0LSR7U3RyaW5nKHdpZHRoKX14JHtTdHJpbmcoaGVpZ2h0KX1gLCB7IGJvZHk6IGF3YWl0IHBhZ2Uuc2NyZWVuc2hvdCgpLCBjb250ZW50VHlwZTogJ2ltYWdlL3BuZycgfSk7XG4gICAgICBjb25zdCBoZWFkaW5nSGl0cyA9IGF3YWl0IGNsZWFyVGFyZ2V0KGhlYWRpbmcsYCR7U3RyaW5nKHdpZHRoKX14JHtTdHJpbmcoaGVpZ2h0KX0gaGVhZGluZ2ApO1xuICAgICAgY29uc3QgYWN0aW9uSGl0cyA9IGF3YWl0IGNsZWFyVGFyZ2V0KGFsbG9jYXRlLGAke1N0cmluZyh3aWR0aCl9eCR7U3RyaW5nKGhlaWdodCl9IEFsbG9jYXRlYCk7XG4gICAgICBpZiAoIWVuZ2xpc2ggJiYgd2lkdGggPT09IDM2MCkge1xuICAgICAgICBjb25zdCBjZHAgPSBhd2FpdCBjb250ZXh0Lm5ld0NEUFNlc3Npb24ocGFnZSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2RwLnNlbmQoJ0RPTS5lbmFibGUnKTsgYXdhaXQgY2RwLnNlbmQoJ0NTUy5lbmFibGUnKTtcbiAgICAgICAgICBjb25zdCBkb2N1bWVudCA9IGF3YWl0IGNkcC5zZW5kKCdET00uZ2V0RG9jdW1lbnQnKTtcbiAgICAgICAgICBjb25zdCBub2RlID0gYXdhaXQgY2RwLnNlbmQoJ0RPTS5xdWVyeVNlbGVjdG9yJyx7IG5vZGVJZDogZG9jdW1lbnQucm9vdC5ub2RlSWQsIHNlbGVjdG9yOiAnW2RhdGEtdGVzdGlkPVwic2tpbGwtZGV0YWlsLXBhbmVsXCJdICNza2lsbC1kZXRhaWwtcGFuZWwgPiBwJyB9KTtcbiAgICAgICAgICBjb25zdCBmb250cyA9IGF3YWl0IGNkcC5zZW5kKCdDU1MuZ2V0UGxhdGZvcm1Gb250c0Zvck5vZGUnLHsgbm9kZUlkOiBub2RlLm5vZGVJZCB9KTtcbiAgICAgICAgICBleHBlY3QoZm9udHMuZm9udHMuc29tZShmb250ID0+IGZvbnQuZmFtaWx5TmFtZSA9PT0gJ05vdG8gU2FucyBDSksgU0MnICYmIGZvbnQuZ2x5cGhDb3VudCA+IDApKS50b0JlKHRydWUpO1xuICAgICAgICAgIGF3YWl0IGF0dGFjaChpbmZvLCdhY3R1YWwtQ2hpbmVzZS1wbGF0Zm9ybS1mb250cycsZm9udHMpO1xuICAgICAgICB9IGZpbmFsbHkgeyBhd2FpdCBjZHAuZGV0YWNoKCk7IH1cbiAgICAgIH1cbiAgICAgIG1ldHJpY3MucHVzaCh7IHdpZHRoLGhlaWdodCxvcmlnaW5hbFBvc2l0aW9uLGhlYWRpbmdIaXRzLGFjdGlvbkhpdHMgfSk7XG4gICAgfVxuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwMi1sYXlvdXQtbWV0cmljcycsbWV0cmljcyk7XG5cbiAgICBhd2FpdCBwYWdlLnNldFZpZXdwb3J0U2l6ZSh7IHdpZHRoOjM3NSxoZWlnaHQ6NjY3IH0pO1xuICAgIGF3YWl0IGRlc2NyaXB0aW9uLnNjcm9sbEludG9WaWV3SWZOZWVkZWQoKTtcbiAgICBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvSGF2ZVRleHQoZW5nbGlzaCA/ICdBbGxvY2F0ZScgOiAn5YiG6YWNJyk7XG4gICAgYXdhaXQgYWxsb2NhdGUuY2xpY2soKTsgLy8gT3JkaW5hcnkgcG9pbnRlcjsgUGxheXdyaWdodCBtdXN0IHJlc29sdmUgdGhlIGFjdHVhbCB0YXJnZXQuXG4gICAgYXdhaXQgZXhwZWN0KHBhbmVsKS50b0NvbnRhaW5UZXh0KGVuZ2xpc2ggPyAnTHYuIDEvMjAnIDogJ+etiee6pyAxLzIwJyk7XG4gICAgY29uc3QgcmFuazEgPSBhd2FpdCBiYWNrdXAocGFnZSk7XG4gICAgZXhwZWN0KHJhbmsxLnBsYXllcikudG9FcXVhbCh7IC4uLmluY29taW5nLnBsYXllciwgc2tpbGxQb2ludHM6MSxcbiAgICAgIHNraWxsTGV2ZWxzOnsgJ3NvcmNlcmVzcy5maXJlX2JvbHQnOjEsJ3NvcmNlcmVzcy5saWdodG5pbmdfbWFzdGVyeSc6MSB9IH0pO1xuICAgIGF3YWl0IG5hdlRvKHBhZ2UsJ3NraWxscycpO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlUZXN0SWQoYHNraWxsLW5vZGUtJHtNQVNURVJZfWApLmNsaWNrKCk7XG4gICAgYXdhaXQgcGFnZS5zZXRWaWV3cG9ydFNpemUoeyB3aWR0aDo5MTUsaGVpZ2h0OjQxMiB9KTtcbiAgICBsZXQgcmVhY2hlZCA9IGZhbHNlO1xuICAgIGZvciAobGV0IHN0ZXA9MDtzdGVwPDEwMDtzdGVwKyspIHtcbiAgICAgIGF3YWl0IHBhZ2Uua2V5Ym9hcmQucHJlc3MoJ1RhYicpO1xuICAgICAgaWYgKGF3YWl0IGFsbG9jYXRlLmV2YWx1YXRlKG5vZGUgPT4gbm9kZSA9PT0gZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkpIHsgcmVhY2hlZD10cnVlO2JyZWFrOyB9XG4gICAgfVxuICAgIGV4cGVjdChyZWFjaGVkKS50b0JlKHRydWUpO1xuICAgIGF3YWl0IGV4cGVjdChoZWFkaW5nKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9IYXZlVGV4dChlbmdsaXNoID8gJ0FsbG9jYXRlJyA6ICfliIbphY0nKTtcbiAgICBhd2FpdCBleHBlY3QoYWxsb2NhdGUpLnRvQmVFbmFibGVkKCk7IGF3YWl0IGV4cGVjdChhbGxvY2F0ZSkudG9CZUZvY3VzZWQoKTtcbiAgICBhd2FpdCBjbGVhclRhcmdldChhbGxvY2F0ZSwna2V5Ym9hcmQgdGFyZ2V0Jyk7XG4gICAgYXdhaXQgcGFnZS5rZXlib2FyZC5wcmVzcygnRW50ZXInKTtcbiAgICBhd2FpdCBleHBlY3QocGFuZWwpLnRvQ29udGFpblRleHQoZW5nbGlzaCA/ICdMdi4gMi8yMCcgOiAn562J57qnIDIvMjAnKTtcbiAgICBjb25zdCByYW5rMiA9IGF3YWl0IGJhY2t1cChwYWdlKTtcbiAgICBleHBlY3QocmFuazIucGxheWVyKS50b0VxdWFsKHsgLi4ucmFuazEucGxheWVyLHNraWxsUG9pbnRzOjAsXG4gICAgICBza2lsbExldmVsczp7ICdzb3JjZXJlc3MuZmlyZV9ib2x0JzoxLCdzb3JjZXJlc3MubGlnaHRuaW5nX21hc3RlcnknOjIgfSB9KTtcbiAgICBmb3IgKGNvbnN0IHNsaWNlIG9mIFsnaW52ZW50b3J5JywnbWVyY3MnLCdtYXAnLCdmb3JtYXRpb24nXSBhcyBjb25zdCkgZXhwZWN0KHJhbmsyW3NsaWNlXSkudG9FcXVhbChpbmNvbWluZ1tzbGljZV0pO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwMy1wb2ludGVyLWtleWJvYXJkLWFsbG9jYXRpb24nLHsgcmFuazEscmFuazIgfSk7XG5cbiAgICAvLyBMZXQgdGhlIGFjdHVhbCBleHBvcnQgc3RhdHVzIGRpc21pc3MgYmVmb3JlIG9wZW5pbmcgdGhlIHVucmVsYXRlZCBkaWFsb2cuXG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdzdGF0dXMnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgLy8gUmVhbCBkaWFsb2cgcmVtYWlucyBhYm92ZSB0aGUgc2hhcmVkIGhlYWRlciwgaW5jbHVkaW5nIHdpdGggYW4gYWN0aXZlIGNoaXAuXG4gICAgY29uc3QgbGFiZWwgPSBlbmdsaXNoID8gJ0ltcG9ydCBTYXZlJyA6ICflr7zlhaXlrZjmoaMnO1xuICAgIGF3YWl0IHBhZ2UuZ2V0QnlSb2xlKCdidXR0b24nLHsgbmFtZTpsYWJlbCxleGFjdDp0cnVlIH0pLmNsaWNrKCk7XG4gICAgY29uc3QgbW9kYWxQcmlvcml0eSA9IGF3YWl0IHBhZ2UuZXZhbHVhdGUoKCkgPT4ge1xuICAgICAgY29uc3QgZGlhbG9nID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW3JvbGU9XCJkaWFsb2dcIl0nKTtcbiAgICAgIHJldHVybiBbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtdGVzdGlkPVwiY2hhcmFjdGVyLWh1ZFwiXSwgW2RhdGEtdGVzdGlkPVwib2ZmbGluZS1ib251cy1jaGlwXCJdJyldLmZsYXRNYXAobm9kZSA9PiB7XG4gICAgICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICByZXR1cm4gWzAuMDUsMC41LDAuOTVdLmZsYXRNYXAoeCA9PiBbMC4wNSwwLjUsMC45NV0ubWFwKHkgPT4ge1xuICAgICAgICAgIGNvbnN0IHB4PWIubGVmdCtiLndpZHRoKngsIHB5PWIudG9wK2IuaGVpZ2h0Knk7XG4gICAgICAgICAgY29uc3QgaGl0PWRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQocHgscHkpO1xuICAgICAgICAgIHJldHVybiB7IHRhcmdldDpub2RlLmdldEF0dHJpYnV0ZSgnZGF0YS10ZXN0aWQnKSx4OnB4LHk6cHksbW9kYWxPd25zSGl0OmhpdCAhPT0gbnVsbCAmJiBkaWFsb2cgIT09IG51bGwgJiYgZGlhbG9nLmNvbnRhaW5zKGhpdCkgfTtcbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJ21vZGFsLXByaW9yaXR5LWF0LWhlYWRlcicsbW9kYWxQcmlvcml0eSk7XG4gICAgZXhwZWN0KG1vZGFsUHJpb3JpdHkpLnRvSGF2ZUxlbmd0aChib251cyA/IDE4IDogOSk7XG4gICAgZm9yIChjb25zdCBwb2ludCBvZiBtb2RhbFByaW9yaXR5KSBleHBlY3Quc29mdChwb2ludCkudG9NYXRjaE9iamVjdCh7IG1vZGFsT3duc0hpdDp0cnVlIH0pO1xuICAgIGNvbnN0IGNhbmNlbCA9IHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKS5nZXRCeVJvbGUoJ2J1dHRvbicseyBuYW1lOmVuZ2xpc2ggPyAnQ2FuY2VsJyA6ICflj5bmtognLGV4YWN0OnRydWUgfSk7XG4gICAgYXdhaXQgYXR0YWNoKGluZm8sJ21vZGFsLWNhbmNlbC1oaXRzJyxhd2FpdCBjbGVhclRhcmdldChjYW5jZWwsJ21vZGFsIGNhbmNlbCcpKTsgYXdhaXQgY2FuY2VsLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlSb2xlKCdkaWFsb2cnKSkudG9IYXZlQ291bnQoMCk7XG4gICAgYXdhaXQgcGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpLmNsaWNrKCk7XG4gICAgYXdhaXQgZXhwZWN0KHBhZ2UuZ2V0QnlUZXN0SWQoJ2NoYXJhY3Rlci1zY3JlZW4nKSkudG9CZVZpc2libGUoKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgwKTtcbiAgICBhd2FpdCBuYXZUbyhwYWdlLCdjb21iYXQnKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY29tYmF0LXNjcmVlbicpKS50b0JlVmlzaWJsZSgpO1xuICAgIGF3YWl0IGV4cGVjdChwYWdlLmdldEJ5VGVzdElkKCdjaGFyYWN0ZXItaHVkJykpLnRvSGF2ZUNvdW50KDApO1xuICAgIGNvbnN0IGNvbWJhdEhlYWRlciA9IHBhZ2UuZ2V0QnlUZXN0SWQoJ2NvbWJhdC1zY3JlZW4nKS5sb2NhdG9yKCdoZWFkZXInKTtcbiAgICBjb25zdCB3aWR0aCA9IGF3YWl0IGNvbWJhdEhlYWRlci5ldmFsdWF0ZShub2RlID0+ICh7IG91dGVyOm5vZGUuY2xpZW50V2lkdGgsaW5uZXI6bm9kZS5maXJzdEVsZW1lbnRDaGlsZD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggfSkpO1xuICAgIGV4cGVjdCh3aWR0aC5pbm5lcikudG9CZUdyZWF0ZXJUaGFuT3JFcXVhbCh3aWR0aC5vdXRlciAtIDMyKTtcbiAgICBhd2FpdCBuYXZUbyhwYWdlLCdza2lsbHMnKTtcbiAgICBhd2FpdCBleHBlY3QocGFnZS5nZXRCeVRlc3RJZCgnY2hhcmFjdGVyLWh1ZCcpKS50b0hhdmVDb3VudCgxKTtcbiAgICBleHBlY3QoYXdhaXQgcGFnZS5ldmFsdWF0ZSgoKSA9PiAnX19HQU1FX18nIGluIHdpbmRvdykpLnRvQmUoZmFsc2UpO1xuICAgIGF3YWl0IGF0dGFjaChpbmZvLCcwNC1jb25zb2xlLWVycm9ycycsZXJyb3JzKTsgZXhwZWN0KGVycm9ycykudG9FcXVhbChbXSk7XG4gICAgYXdhaXQgcGFnZS5jbG9zZSgpO1xuICB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxTQUFTQSxNQUFNLEVBQUVDLElBQUksUUFBZ0Qsa0JBQWtCO0FBQ3ZGLFNBQVNDLFFBQVEsUUFBUSxrQkFBa0I7QUFFM0MsU0FBU0MsS0FBSyxRQUFRLGlCQUFpQjtBQUV2QyxNQUFNQyxPQUFPLEdBQUcsb0NBQW9DO0FBQ3BELE1BQU1DLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsSUFBSSxFQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsSUFBSSxFQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQyxDQUFVO0FBRXRILGVBQWVDLE1BQU1BLENBQUNDLElBQWMsRUFBRUMsSUFBWSxFQUFFQyxLQUFjLEVBQWlCO0VBQ2pGLE1BQU1GLElBQUksQ0FBQ0QsTUFBTSxDQUFDRSxJQUFJLEVBQUU7SUFBRUUsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFBRUksV0FBVyxFQUFFO0VBQW1CLENBQUMsQ0FBQztBQUNwRztBQUVBLGVBQWVDLE1BQU1BLENBQUNDLElBQVUsRUFBd0I7RUFDdEQsTUFBTVosS0FBSyxDQUFDWSxJQUFJLEVBQUUsVUFBVSxDQUFDO0VBQzdCLE1BQU1DLE9BQU8sR0FBR0QsSUFBSSxDQUFDRSxZQUFZLENBQUMsVUFBVSxDQUFDO0VBQzdDLE1BQU1GLElBQUksQ0FBQ0csV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0VBQ3BELE1BQU1DLFFBQVEsR0FBRyxNQUFNSixPQUFPO0VBQzlCLElBQUk7SUFBRSxPQUFPTCxJQUFJLENBQUNVLEtBQUssQ0FBQyxNQUFNbkIsUUFBUSxDQUFDLE1BQU1rQixRQUFRLENBQUNFLElBQUksQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7RUFBaUIsQ0FBQyxTQUNoRjtJQUFFLE1BQU1GLFFBQVEsQ0FBQ0csTUFBTSxDQUFDLENBQUM7RUFBRTtBQUNyQztBQUVBLGVBQWVDLFVBQVVBLENBQUNULElBQVUsRUFBRVUsSUFBaUIsRUFBRUMsT0FBZ0IsRUFBaUI7RUFDeEYsTUFBTUMsS0FBSyxHQUFHRCxPQUFPLEdBQUcsYUFBYSxHQUFHLE1BQU07RUFDOUMsTUFBTVgsSUFBSSxDQUFDYSxTQUFTLENBQUMsUUFBUSxFQUFFO0lBQUVwQixJQUFJLEVBQUVtQixLQUFLO0lBQUVFLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQyxDQUFDVixLQUFLLENBQUMsQ0FBQztFQUNwRSxNQUFNVyxNQUFNLEdBQUdmLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQztFQUN2QyxNQUFNRSxNQUFNLENBQUNGLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQ0csSUFBSSxDQUFDcEIsSUFBSSxDQUFDQyxTQUFTLENBQUNhLElBQUksQ0FBQyxDQUFDO0VBQzVELE1BQU1LLE1BQU0sQ0FBQ0YsU0FBUyxDQUFDLFFBQVEsRUFBRTtJQUFFcEIsSUFBSSxFQUFFbUIsS0FBSztJQUFFRSxLQUFLLEVBQUU7RUFBSyxDQUFDLENBQUMsQ0FBQ1YsS0FBSyxDQUFDLENBQUM7RUFDdEUsTUFBTW5CLE1BQU0sQ0FBQzhCLE1BQU0sQ0FBQyxDQUFDRSxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3JDOztBQUVBO0FBQ0EsZUFBZUMsU0FBU0EsQ0FBQ0MsTUFBZSxFQUFzQjtFQUM1RCxPQUFPQSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsSUFBSSxJQUFJO0lBQzdCLE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3RDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDQyxPQUFPLENBQUNDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQyxJQUFJO01BQUEsSUFBQUMsWUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxZQUFBO01BQy9ELE1BQU1DLEVBQUUsR0FBR1gsQ0FBQyxDQUFDWSxJQUFJLEdBQUdaLENBQUMsQ0FBQ2EsS0FBSyxHQUFHVixDQUFDO1FBQUVXLEVBQUUsR0FBR2QsQ0FBQyxDQUFDZSxHQUFHLEdBQUdmLENBQUMsQ0FBQ2dCLE1BQU0sR0FBR1gsQ0FBQztNQUMxRCxNQUFNWSxHQUFHLEdBQUdDLFFBQVEsQ0FBQ0MsZ0JBQWdCLENBQUNSLEVBQUUsRUFBRUcsRUFBRSxDQUFDO01BQzdDLE9BQU87UUFBRVgsQ0FBQyxFQUFFUSxFQUFFO1FBQUVOLENBQUMsRUFBRVMsRUFBRTtRQUFFTSxLQUFLLEVBQUVILEdBQUcsS0FBSyxJQUFJLElBQUlsQixJQUFJLENBQUNzQixRQUFRLENBQUNKLEdBQUcsQ0FBQztRQUFFQSxHQUFHLEdBQUFYLFlBQUEsR0FBRVcsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUVLLE9BQU8sY0FBQWhCLFlBQUEsY0FBQUEsWUFBQSxHQUFJLElBQUk7UUFDekZpQixPQUFPLEdBQUFoQixxQkFBQSxHQUFDVSxHQUFHLGFBQUhBLEdBQUcsZ0JBQUFULGdCQUFBLEdBQUhTLEdBQUcsQ0FBRU8sV0FBVyxjQUFBaEIsZ0JBQUEsdUJBQWhCQSxnQkFBQSxDQUFrQmlCLEtBQUssQ0FBQyxDQUFDLEVBQUMsR0FBRyxDQUFDLGNBQUFsQixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLElBQUk7UUFBRW1CLFNBQVMsR0FBQWpCLHFCQUFBLEdBQUNRLEdBQUcsYUFBSEEsR0FBRyxnQkFBQVAsWUFBQSxHQUFITyxHQUFHLENBQUVVLE9BQU8sQ0FBQyxlQUFlLENBQUMsY0FBQWpCLFlBQUEsdUJBQTdCQSxZQUFBLENBQStCa0IsWUFBWSxDQUFDLGFBQWEsQ0FBQyxjQUFBbkIscUJBQUEsY0FBQUEscUJBQUEsR0FBSTtNQUFLLENBQUM7SUFDbEksQ0FBQyxDQUFDLENBQUM7RUFDTCxDQUFDLENBQUM7QUFDSjtBQUVBLGVBQWVvQixXQUFXQSxDQUFDaEMsTUFBZSxFQUFFUCxLQUFhLEVBQXNCO0VBQzdFLE1BQU1PLE1BQU0sQ0FBQ2lDLHNCQUFzQixDQUFDLENBQUM7RUFDckMsTUFBTUMsTUFBTSxHQUFHLE1BQU1uQyxTQUFTLENBQUNDLE1BQU0sQ0FBQztFQUN0QyxLQUFLLE1BQU1tQyxLQUFLLElBQUlELE1BQU0sRUFBRXBFLE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0QsS0FBSyxFQUFFMUMsS0FBSyxDQUFDLENBQUM0QyxhQUFhLENBQUM7SUFBRWQsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ3BGLE9BQU9XLE1BQU07QUFDZjtBQUVBLGVBQWVJLE1BQU1BLENBQUN6RCxJQUFVLEVBQUUwRCxLQUFjLEVBQW9CO0VBQ2xFLE1BQU1DLFFBQVEsR0FBRyxNQUFNM0QsSUFBSSxDQUFDb0IsUUFBUSxDQUFDLE1BQU07SUFBQSxJQUFBd0MsbUJBQUE7SUFDekMsTUFBTUMsSUFBSSxHQUFHckIsUUFBUSxDQUFDc0IsYUFBYSxDQUFDLE1BQU0sQ0FBQztJQUMzQyxNQUFNQyxHQUFHLEdBQUd2QixRQUFRLENBQUNzQixhQUFhLENBQUMsK0JBQStCLENBQUM7SUFDbkUsTUFBTUUsSUFBSSxHQUFHeEIsUUFBUSxDQUFDc0IsYUFBYSxDQUFDLG9DQUFvQyxDQUFDO0lBQ3pFLE1BQU1HLE1BQU0sR0FBR0osSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVLLHNCQUFzQjtJQUMzQyxJQUFJLENBQUNMLElBQUksSUFBSSxDQUFDRSxHQUFHLElBQUksQ0FBQ0UsTUFBTSxFQUFFLE1BQU0sSUFBSUUsS0FBSyxDQUFDLHNDQUFzQyxDQUFDO0lBQ3JGLE1BQU1DLElBQUksR0FBSS9DLElBQWEsSUFBSztNQUM5QixNQUFNQyxDQUFDLEdBQUdELElBQUksQ0FBQ0UscUJBQXFCLENBQUMsQ0FBQztNQUN0QyxPQUFPO1FBQUVXLElBQUksRUFBRVosQ0FBQyxDQUFDWSxJQUFJO1FBQUVHLEdBQUcsRUFBRWYsQ0FBQyxDQUFDZSxHQUFHO1FBQUVnQyxLQUFLLEVBQUUvQyxDQUFDLENBQUMrQyxLQUFLO1FBQUVDLE1BQU0sRUFBRWhELENBQUMsQ0FBQ2dELE1BQU07UUFBRW5DLEtBQUssRUFBRWIsQ0FBQyxDQUFDYSxLQUFLO1FBQUVHLE1BQU0sRUFBRWhCLENBQUMsQ0FBQ2dCO01BQU8sQ0FBQztJQUN6RyxDQUFDO0lBQ0QsTUFBTWlDLENBQUMsR0FBR0gsSUFBSSxDQUFDSCxNQUFNLENBQUM7TUFBRU8sQ0FBQyxHQUFHSixJQUFJLENBQUNQLElBQUksQ0FBQztNQUFFWSxDQUFDLEdBQUdMLElBQUksQ0FBQ0wsR0FBRyxDQUFDO01BQUVXLENBQUMsR0FBR1YsSUFBSSxHQUFHSSxJQUFJLENBQUNKLElBQUksQ0FBQyxHQUFHLElBQUk7SUFDbkYsTUFBTXJCLFFBQVEsR0FBR0EsQ0FBQ2dDLENBQVcsRUFBRXJELENBQVcsS0FBS0EsQ0FBQyxDQUFDWSxJQUFJLElBQUl5QyxDQUFDLENBQUN6QyxJQUFJLElBQUlaLENBQUMsQ0FBQytDLEtBQUssSUFBSU0sQ0FBQyxDQUFDTixLQUFLLElBQUkvQyxDQUFDLENBQUNlLEdBQUcsSUFBSXNDLENBQUMsQ0FBQ3RDLEdBQUcsSUFBSWYsQ0FBQyxDQUFDZ0QsTUFBTSxJQUFJSyxDQUFDLENBQUNMLE1BQU07SUFDL0gsTUFBTU0sT0FBTyxHQUFHLENBQUMsR0FBR3BDLFFBQVEsQ0FBQ3FDLGdCQUFnQixDQUFDLGtGQUFrRixDQUFDLENBQUMsQ0FBQ25ELEdBQUcsQ0FBQ0wsSUFBSSxJQUFJO01BQzdJLE1BQU1DLENBQUMsR0FBRzhDLElBQUksQ0FBQy9DLElBQUksQ0FBQztNQUNwQixNQUFNeUQsT0FBTyxHQUFHO1FBQUU1QyxJQUFJLEVBQUU2QyxJQUFJLENBQUNDLEdBQUcsQ0FBQzFELENBQUMsQ0FBQ1ksSUFBSSxFQUFDc0MsQ0FBQyxDQUFDdEMsSUFBSSxDQUFDO1FBQUVtQyxLQUFLLEVBQUVVLElBQUksQ0FBQ0UsR0FBRyxDQUFDM0QsQ0FBQyxDQUFDK0MsS0FBSyxFQUFDRyxDQUFDLENBQUNILEtBQUssQ0FBQztRQUFFaEMsR0FBRyxFQUFFMEMsSUFBSSxDQUFDQyxHQUFHLENBQUMxRCxDQUFDLENBQUNlLEdBQUcsRUFBQ21DLENBQUMsQ0FBQ25DLEdBQUcsQ0FBQztRQUFFaUMsTUFBTSxFQUFFUyxJQUFJLENBQUNFLEdBQUcsQ0FBQzNELENBQUMsQ0FBQ2dELE1BQU0sRUFBQ0UsQ0FBQyxDQUFDRixNQUFNO01BQUUsQ0FBQztNQUNwSixNQUFNWSxLQUFLLEdBQUdKLE9BQU8sQ0FBQ1QsS0FBSyxHQUFHUyxPQUFPLENBQUM1QyxJQUFJLElBQUk0QyxPQUFPLENBQUNSLE1BQU0sR0FBR1EsT0FBTyxDQUFDekMsR0FBRztNQUMxRSxNQUFNOEMsUUFBUSxHQUFJUixDQUFXLElBQUtPLEtBQUssSUFBSUosT0FBTyxDQUFDNUMsSUFBSSxHQUFHeUMsQ0FBQyxDQUFDTixLQUFLLElBQUlTLE9BQU8sQ0FBQ1QsS0FBSyxHQUFHTSxDQUFDLENBQUN6QyxJQUFJLElBQUk0QyxPQUFPLENBQUN6QyxHQUFHLEdBQUdzQyxDQUFDLENBQUNMLE1BQU0sSUFBSVEsT0FBTyxDQUFDUixNQUFNLEdBQUdLLENBQUMsQ0FBQ3RDLEdBQUc7TUFDL0ksT0FBTztRQUFFK0MsSUFBSSxFQUFFL0QsSUFBSSxDQUFDeUIsV0FBVztRQUFFc0IsSUFBSSxFQUFDOUMsQ0FBQztRQUFFd0QsT0FBTztRQUFFSSxLQUFLO1FBQUVHLFlBQVksRUFBRUYsUUFBUSxDQUFDVixDQUFDLENBQUM7UUFBRWEsYUFBYSxFQUFFWixDQUFDLEtBQUssSUFBSSxJQUFJUyxRQUFRLENBQUNULENBQUM7TUFBRSxDQUFDO0lBQ2hJLENBQUMsQ0FBQztJQUNGLE9BQU87TUFBRVQsTUFBTSxFQUFFTSxDQUFDO01BQUVWLElBQUksRUFBRVcsQ0FBQztNQUFFVCxHQUFHLEVBQUVVLENBQUM7TUFBRVQsSUFBSSxFQUFFVSxDQUFDO01BQUVhLFlBQVksRUFBRTVDLFFBQVEsQ0FBQzRCLENBQUMsRUFBQ0UsQ0FBQyxDQUFDO01BQUVlLGFBQWEsRUFBRWQsQ0FBQyxLQUFLLElBQUksSUFBSS9CLFFBQVEsQ0FBQzRCLENBQUMsRUFBQ0csQ0FBQyxDQUFDO01BQ25IZSxZQUFZLEVBQUVqQixDQUFDLENBQUNuQyxHQUFHLElBQUlvQyxDQUFDLENBQUNILE1BQU07TUFBRW9CLGFBQWEsRUFBRWhCLENBQUMsS0FBSyxJQUFJLElBQUlGLENBQUMsQ0FBQ25DLEdBQUcsSUFBSXFDLENBQUMsQ0FBQ0osTUFBTTtNQUMvRXFCLGVBQWUsRUFBRWpCLENBQUMsS0FBSyxJQUFJLElBQUlBLENBQUMsQ0FBQ3JDLEdBQUcsSUFBSW9DLENBQUMsQ0FBQ0gsTUFBTTtNQUFFc0IsaUJBQWlCLEVBQUU1QixJQUFJLEtBQUssSUFBSSxJQUFJLENBQUNELEdBQUcsQ0FBQ3BCLFFBQVEsQ0FBQ3FCLElBQUksQ0FBQztNQUN6RzZCLGdCQUFnQixFQUFFckQsUUFBUSxDQUFDc0QsZUFBZSxDQUFDQyxXQUFXLEdBQUdDLFVBQVU7TUFDbkVDLFlBQVksRUFBRXBDLElBQUksQ0FBQ2tDLFdBQVcsR0FBR2xDLElBQUksQ0FBQ3FDLFdBQVc7TUFBRUMsT0FBTyxFQUFFQyxPQUFPO01BQ25FQyxNQUFNLEdBQUF6QyxtQkFBQSxHQUFFQyxJQUFJLENBQUN5QyxhQUFhLGNBQUExQyxtQkFBQSxnQkFBQUEsbUJBQUEsR0FBbEJBLG1CQUFBLENBQW9CMEMsYUFBYSxjQUFBMUMsbUJBQUEsdUJBQWpDQSxtQkFBQSxDQUFtQzJDLFNBQVM7TUFBRUMsS0FBSyxFQUFFM0MsSUFBSSxDQUFDMEMsU0FBUztNQUMzRUUsZ0JBQWdCLEVBQUU1QyxJQUFJLENBQUM2QyxZQUFZO01BQUVDLGdCQUFnQixFQUFFOUMsSUFBSSxDQUFDK0MsWUFBWTtNQUFFaEM7SUFBUSxDQUFDO0VBQ3ZGLENBQUMsQ0FBQztFQUNGM0YsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUM0QixZQUFZLEVBQUUsbUNBQW1DLENBQUMsQ0FBQ3NCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbEY1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQzZCLGFBQWEsRUFBRSwwQ0FBMEMsQ0FBQyxDQUFDcUIsSUFBSSxDQUFDLElBQUksQ0FBQztFQUMxRjVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDOEIsWUFBWSxFQUFFLDhCQUE4QixDQUFDLENBQUNvQixJQUFJLENBQUMsSUFBSSxDQUFDO0VBQzdFNUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUMrQixhQUFhLEVBQUUsK0JBQStCLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDL0U1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ2dDLGVBQWUsQ0FBQyxDQUFDa0IsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNoRDVILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDaUMsaUJBQWlCLENBQUMsQ0FBQ2lCLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDbEQ1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ2tDLGdCQUFnQixDQUFDLENBQUNpQixtQkFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDN0Q3SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ3NDLFlBQVksQ0FBQyxDQUFDYSxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDekQ3SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQ3dDLE9BQU8sQ0FBQyxDQUFDVSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQUU1SCxNQUFNLENBQUNzRSxJQUFJLENBQUNJLFFBQVEsQ0FBQzBDLE1BQU0sQ0FBQyxDQUFDUSxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzNFNUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUNJLEdBQUcsQ0FBQzVCLEtBQUssQ0FBQyxDQUFDNEUsc0JBQXNCLENBQUMsRUFBRSxDQUFDO0VBQzFEOUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUNJLEdBQUcsQ0FBQ3pCLE1BQU0sQ0FBQyxDQUFDeUUsc0JBQXNCLENBQUMsRUFBRSxDQUFDO0VBQzNEOUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDSSxRQUFRLENBQUNFLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQyxDQUFDMEUsZUFBZSxDQUFDLENBQUMsQ0FBQztFQUNwRC9ILE1BQU0sQ0FBQ3NFLElBQUksQ0FBQ0ksUUFBUSxDQUFDSyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUM2QyxJQUFJLENBQUNuRCxLQUFLLENBQUM7RUFDL0MsS0FBSyxNQUFNdkMsTUFBTSxJQUFJd0MsUUFBUSxDQUFDaUIsT0FBTyxFQUFFO0lBQ3JDM0YsTUFBTSxDQUFDc0UsSUFBSSxDQUFDcEMsTUFBTSxDQUFDa0UsWUFBWSxFQUFFLGlFQUFpRSxDQUFDLENBQUN3QixJQUFJLENBQUMsS0FBSyxDQUFDO0lBQy9HNUgsTUFBTSxDQUFDc0UsSUFBSSxDQUFDcEMsTUFBTSxDQUFDbUUsYUFBYSxFQUFFLHlFQUF5RSxDQUFDLENBQUN1QixJQUFJLENBQUMsS0FBSyxDQUFDO0VBQzFIO0VBQ0EsT0FBT2xELFFBQVE7QUFDakI7QUFFQSxLQUFLLE1BQU1zRCxNQUFNLElBQUksQ0FBQyxJQUFJLEVBQUMsT0FBTyxDQUFDLEVBQVcsS0FBSyxNQUFNdkQsS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFDLElBQUksQ0FBQyxFQUFFO0VBQzlFeEUsSUFBSSxDQUFDLDZCQUE2QitILE1BQU0sVUFBVUMsTUFBTSxDQUFDeEQsS0FBSyxDQUFDLEVBQUUsRUFBRSxPQUFPO0lBQUUxRCxJQUFJO0lBQUVtSDtFQUFRLENBQUMsRUFBRTNILElBQUksS0FBSztJQUNwRyxNQUFNbUIsT0FBTyxHQUFHc0csTUFBTSxLQUFLLElBQUk7SUFDL0IsTUFBTUcsTUFBZ0IsR0FBRyxFQUFFO0lBQzNCcEgsSUFBSSxDQUFDcUgsRUFBRSxDQUFDLFdBQVcsRUFBRUMsS0FBSyxJQUFJRixNQUFNLENBQUNHLElBQUksQ0FBQ0QsS0FBSyxDQUFDRSxPQUFPLENBQUMsQ0FBQztJQUN6RHhILElBQUksQ0FBQ3FILEVBQUUsQ0FBQyxTQUFTLEVBQUVHLE9BQU8sSUFBSTtNQUFFLElBQUlBLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUlELE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUVMLE1BQU0sQ0FBQ0csSUFBSSxDQUFDLEdBQUdDLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLENBQUMsS0FBS0QsT0FBTyxDQUFDcEMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZKLE1BQU1wRixJQUFJLENBQUMwSCxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzVCLE1BQU16SSxNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTWpCLElBQUksQ0FBQzBILElBQUksQ0FBQyxHQUFHLENBQUM7SUFDcEIsTUFBTXpJLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNakIsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQy9DLE1BQU1uQixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDOUQsTUFBTWpCLElBQUksQ0FBQ0csV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUNDLEtBQUssQ0FBQyxDQUFDO0lBQ2pELE1BQU1YLElBQUksR0FBR2tCLE9BQU8sR0FBRyxrQkFBa0IsR0FBRyxHQUFHLENBQUNnSCxNQUFNLENBQUMsRUFBRSxDQUFDO0lBQzFELE1BQU0zSCxJQUFJLENBQUNHLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDYSxJQUFJLENBQUN2QixJQUFJLENBQUM7SUFDekQsTUFBTU8sSUFBSSxDQUFDRyxXQUFXLENBQUMscUJBQXFCLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLENBQUM7SUFDckQsTUFBTW5CLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQ3lILFdBQVcsQ0FBQyxDQUFDO0lBQzNELE1BQU14SSxLQUFLLENBQUNZLElBQUksRUFBQyxVQUFVLENBQUM7SUFDNUIsTUFBTTZILFFBQVEsR0FBRzdILElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsRUFBRTtNQUFFcEIsSUFBSSxFQUFFa0IsT0FBTyxHQUFHLFNBQVMsR0FBRyxNQUFNO01BQUVHLEtBQUssRUFBRTtJQUFLLENBQUMsQ0FBQztJQUM5RixNQUFNK0csUUFBUSxDQUFDekgsS0FBSyxDQUFDLENBQUM7SUFDdEIsTUFBTW5CLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQyxDQUFDQyxlQUFlLENBQUMsY0FBYyxFQUFDLE1BQU0sQ0FBQztJQUM3RCxNQUFNQyxLQUFLLEdBQUcsTUFBTWhJLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDO0lBQ2hDZixNQUFNLENBQUM4SSxLQUFLLENBQUNDLE1BQU0sQ0FBQ3ZJLElBQUksQ0FBQyxDQUFDb0gsSUFBSSxDQUFDcEgsSUFBSSxDQUFDO0lBQ3BDLE1BQU13SSxRQUFxQixHQUFHO01BQUUsR0FBR0YsS0FBSztNQUFFQyxNQUFNLEVBQUU7UUFBRSxHQUFHRCxLQUFLLENBQUNDLE1BQU07UUFBRUUsS0FBSyxFQUFFLEVBQUU7UUFBRUMsV0FBVyxFQUFFLENBQUM7UUFDNUZDLFdBQVcsRUFBRTtVQUFFLHFCQUFxQixFQUFFO1FBQUUsQ0FBQztRQUFFQyxVQUFVLEVBQUUsQ0FBQyw0QkFBNEI7TUFBRSxDQUFDO01BQ3ZGQyxJQUFJLEVBQUU7UUFBRSxHQUFHUCxLQUFLLENBQUNPLElBQUk7UUFBRUMsU0FBUyxFQUFFO1VBQUUsR0FBR1IsS0FBSyxDQUFDTyxJQUFJLENBQUNDLFNBQVM7VUFBRUMsVUFBVSxFQUFFQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDO1VBQ2pGQyxnQkFBZ0IsRUFBRWpGLEtBQUssR0FBRyxHQUFHLEdBQUcsQ0FBQztVQUFFa0YsMEJBQTBCLEVBQUVsRixLQUFLLEdBQUcsSUFBSSxHQUFHO1FBQUU7TUFBRTtJQUFFLENBQUM7SUFDekYsTUFBTWpELFVBQVUsQ0FBQ1QsSUFBSSxFQUFFaUksUUFBUSxFQUFFdEgsT0FBTyxDQUFDO0lBQ3pDLE1BQU1wQixNQUFNLENBQUNDLElBQUksRUFBRSx5QkFBeUIsRUFBRXlJLFFBQVEsQ0FBQztJQUV2RCxLQUFLLE1BQU1ZLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBQyxVQUFVLEVBQUMsUUFBUSxDQUFDLEVBQUU7TUFDaEQsTUFBTXpKLEtBQUssQ0FBQ1ksSUFBSSxFQUFFNkksS0FBSyxDQUFDO01BQ3hCLE1BQU01SixNQUFNLENBQUNlLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUNjLFdBQVcsQ0FBQyxDQUFDLENBQUM7TUFDOUQsTUFBTWhDLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQzJJLG9CQUFvQixDQUFDLElBQUlDLE1BQU0sQ0FBQ3RKLElBQUksQ0FBQyxDQUFDO01BQ3RGLE1BQU1GLE1BQU0sQ0FBQ0MsSUFBSSxFQUFFLFNBQVNxSixLQUFLLEVBQUUsRUFBRSxNQUFNcEYsTUFBTSxDQUFDekQsSUFBSSxFQUFDMEQsS0FBSyxDQUFDLENBQUM7SUFDaEU7SUFDQSxNQUFNc0YsS0FBSyxHQUFHaEosSUFBSSxDQUFDRyxXQUFXLENBQUMsb0JBQW9CLENBQUM7SUFDcEQsTUFBTUgsSUFBSSxDQUFDRyxXQUFXLENBQUMsY0FBY2QsT0FBTyxFQUFFLENBQUMsQ0FBQ2UsS0FBSyxDQUFDLENBQUM7SUFDdkQsTUFBTTZJLE9BQU8sR0FBR0QsS0FBSyxDQUFDbkksU0FBUyxDQUFDLFNBQVMsRUFBRTtNQUFFcEIsSUFBSSxFQUFFa0IsT0FBTyxHQUFHLG1CQUFtQixHQUFHLE1BQU07TUFBRUcsS0FBSyxFQUFFO0lBQUssQ0FBQyxDQUFDO0lBQ3pHLE1BQU1vSSxRQUFRLEdBQUdGLEtBQUssQ0FBQ25JLFNBQVMsQ0FBQyxRQUFRLENBQUM7SUFDMUMsTUFBTXNJLFdBQVcsR0FBR0gsS0FBSyxDQUFDSSxPQUFPLENBQUMseUJBQXlCLENBQUM7SUFDNUQsTUFBTUMsT0FBTyxHQUFHLEVBQUU7SUFDbEIsS0FBSyxNQUFNLENBQUNsSCxLQUFLLEVBQUNHLE1BQU0sQ0FBQyxJQUFJaEQsS0FBSyxFQUFFO01BQ2xDLE1BQU1VLElBQUksQ0FBQ3NKLGVBQWUsQ0FBQztRQUFFbkgsS0FBSztRQUFDRztNQUFPLENBQUMsQ0FBQztNQUM1QyxNQUFNNkcsV0FBVyxDQUFDL0Ysc0JBQXNCLENBQUMsQ0FBQztNQUMxQyxNQUFNbUcsZ0JBQWdCLEdBQUcsTUFBTTlGLE1BQU0sQ0FBQ3pELElBQUksRUFBQzBELEtBQUssQ0FBQztNQUNqRCxJQUFJdkIsS0FBSyxLQUFLLEdBQUcsSUFBSUcsTUFBTSxLQUFLLEdBQUcsRUFBRTtRQUNuQ3JELE1BQU0sQ0FBQ3NFLElBQUksQ0FBQyxNQUFNdkQsSUFBSSxDQUFDb0osT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDaEksUUFBUSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ2tGLFNBQVMsQ0FBQyxFQUFFLHFDQUFxQyxDQUFDLENBQUNTLGVBQWUsQ0FBQyxDQUFDLENBQUM7TUFDcEk7TUFDQSxNQUFNeEgsSUFBSSxDQUFDRCxNQUFNLENBQUMsVUFBVTJILE1BQU0sQ0FBQy9FLEtBQUssQ0FBQyxJQUFJK0UsTUFBTSxDQUFDNUUsTUFBTSxDQUFDLEVBQUUsRUFBRTtRQUFFM0MsSUFBSSxFQUFFLE1BQU1LLElBQUksQ0FBQ3dKLFVBQVUsQ0FBQyxDQUFDO1FBQUUxSixXQUFXLEVBQUU7TUFBWSxDQUFDLENBQUM7TUFDM0gsTUFBTTJKLFdBQVcsR0FBRyxNQUFNdEcsV0FBVyxDQUFDOEYsT0FBTyxFQUFDLEdBQUcvQixNQUFNLENBQUMvRSxLQUFLLENBQUMsSUFBSStFLE1BQU0sQ0FBQzVFLE1BQU0sQ0FBQyxVQUFVLENBQUM7TUFDM0YsTUFBTW9ILFVBQVUsR0FBRyxNQUFNdkcsV0FBVyxDQUFDK0YsUUFBUSxFQUFDLEdBQUdoQyxNQUFNLENBQUMvRSxLQUFLLENBQUMsSUFBSStFLE1BQU0sQ0FBQzVFLE1BQU0sQ0FBQyxXQUFXLENBQUM7TUFDNUYsSUFBSSxDQUFDM0IsT0FBTyxJQUFJd0IsS0FBSyxLQUFLLEdBQUcsRUFBRTtRQUM3QixNQUFNd0gsR0FBRyxHQUFHLE1BQU14QyxPQUFPLENBQUN5QyxhQUFhLENBQUM1SixJQUFJLENBQUM7UUFDN0MsSUFBSTtVQUNGLE1BQU0ySixHQUFHLENBQUNFLElBQUksQ0FBQyxZQUFZLENBQUM7VUFBRSxNQUFNRixHQUFHLENBQUNFLElBQUksQ0FBQyxZQUFZLENBQUM7VUFDMUQsTUFBTXJILFFBQVEsR0FBRyxNQUFNbUgsR0FBRyxDQUFDRSxJQUFJLENBQUMsaUJBQWlCLENBQUM7VUFDbEQsTUFBTXhJLElBQUksR0FBRyxNQUFNc0ksR0FBRyxDQUFDRSxJQUFJLENBQUMsbUJBQW1CLEVBQUM7WUFBRUMsTUFBTSxFQUFFdEgsUUFBUSxDQUFDdUgsSUFBSSxDQUFDRCxNQUFNO1lBQUVFLFFBQVEsRUFBRTtVQUE2RCxDQUFDLENBQUM7VUFDekosTUFBTUMsS0FBSyxHQUFHLE1BQU1OLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLDZCQUE2QixFQUFDO1lBQUVDLE1BQU0sRUFBRXpJLElBQUksQ0FBQ3lJO1VBQU8sQ0FBQyxDQUFDO1VBQ25GN0ssTUFBTSxDQUFDZ0wsS0FBSyxDQUFDQSxLQUFLLENBQUNDLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNDLFVBQVUsS0FBSyxrQkFBa0IsSUFBSUQsSUFBSSxDQUFDRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUM7VUFDMUcsTUFBTXRILE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLCtCQUErQixFQUFDeUssS0FBSyxDQUFDO1FBQzFELENBQUMsU0FBUztVQUFFLE1BQU1OLEdBQUcsQ0FBQ1csTUFBTSxDQUFDLENBQUM7UUFBRTtNQUNsQztNQUNBakIsT0FBTyxDQUFDOUIsSUFBSSxDQUFDO1FBQUVwRixLQUFLO1FBQUNHLE1BQU07UUFBQ2lILGdCQUFnQjtRQUFDRSxXQUFXO1FBQUNDO01BQVcsQ0FBQyxDQUFDO0lBQ3hFO0lBQ0EsTUFBTW5LLE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLG1CQUFtQixFQUFDNkosT0FBTyxDQUFDO0lBRTlDLE1BQU1ySixJQUFJLENBQUNzSixlQUFlLENBQUM7TUFBRW5ILEtBQUssRUFBQyxHQUFHO01BQUNHLE1BQU0sRUFBQztJQUFJLENBQUMsQ0FBQztJQUNwRCxNQUFNNkcsV0FBVyxDQUFDL0Ysc0JBQXNCLENBQUMsQ0FBQztJQUMxQyxNQUFNbkUsTUFBTSxDQUFDaUssUUFBUSxDQUFDLENBQUNxQixVQUFVLENBQUM1SixPQUFPLEdBQUcsVUFBVSxHQUFHLElBQUksQ0FBQztJQUM5RCxNQUFNdUksUUFBUSxDQUFDOUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3hCLE1BQU1uQixNQUFNLENBQUMrSixLQUFLLENBQUMsQ0FBQ3dCLGFBQWEsQ0FBQzdKLE9BQU8sR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDO0lBQ25FLE1BQU04SixLQUFLLEdBQUcsTUFBTTFLLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDO0lBQ2hDZixNQUFNLENBQUN3TCxLQUFLLENBQUN6QyxNQUFNLENBQUMsQ0FBQzBDLE9BQU8sQ0FBQztNQUFFLEdBQUd6QyxRQUFRLENBQUNELE1BQU07TUFBRUcsV0FBVyxFQUFDLENBQUM7TUFDOURDLFdBQVcsRUFBQztRQUFFLHFCQUFxQixFQUFDLENBQUM7UUFBQyw2QkFBNkIsRUFBQztNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQzVFLE1BQU1oSixLQUFLLENBQUNZLElBQUksRUFBQyxRQUFRLENBQUM7SUFDMUIsTUFBTUEsSUFBSSxDQUFDRyxXQUFXLENBQUMsY0FBY2QsT0FBTyxFQUFFLENBQUMsQ0FBQ2UsS0FBSyxDQUFDLENBQUM7SUFDdkQsTUFBTUosSUFBSSxDQUFDc0osZUFBZSxDQUFDO01BQUVuSCxLQUFLLEVBQUMsR0FBRztNQUFDRyxNQUFNLEVBQUM7SUFBSSxDQUFDLENBQUM7SUFDcEQsSUFBSXFJLE9BQU8sR0FBRyxLQUFLO0lBQ25CLEtBQUssSUFBSUMsSUFBSSxHQUFDLENBQUMsRUFBQ0EsSUFBSSxHQUFDLEdBQUcsRUFBQ0EsSUFBSSxFQUFFLEVBQUU7TUFDL0IsTUFBTTVLLElBQUksQ0FBQzZLLFFBQVEsQ0FBQ0MsS0FBSyxDQUFDLEtBQUssQ0FBQztNQUNoQyxJQUFJLE1BQU01QixRQUFRLENBQUM5SCxRQUFRLENBQUNDLElBQUksSUFBSUEsSUFBSSxLQUFLbUIsUUFBUSxDQUFDdUksYUFBYSxDQUFDLEVBQUU7UUFBRUosT0FBTyxHQUFDLElBQUk7UUFBQztNQUFPO0lBQzlGO0lBQ0ExTCxNQUFNLENBQUMwTCxPQUFPLENBQUMsQ0FBQzlELElBQUksQ0FBQyxJQUFJLENBQUM7SUFDMUIsTUFBTTVILE1BQU0sQ0FBQ2dLLE9BQU8sQ0FBQyxDQUFDckIsV0FBVyxDQUFDLENBQUM7SUFDbkMsTUFBTTNJLE1BQU0sQ0FBQ2lLLFFBQVEsQ0FBQyxDQUFDcUIsVUFBVSxDQUFDNUosT0FBTyxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDOUQsTUFBTTFCLE1BQU0sQ0FBQ2lLLFFBQVEsQ0FBQyxDQUFDOEIsV0FBVyxDQUFDLENBQUM7SUFBRSxNQUFNL0wsTUFBTSxDQUFDaUssUUFBUSxDQUFDLENBQUMrQixXQUFXLENBQUMsQ0FBQztJQUMxRSxNQUFNOUgsV0FBVyxDQUFDK0YsUUFBUSxFQUFDLGlCQUFpQixDQUFDO0lBQzdDLE1BQU1sSixJQUFJLENBQUM2SyxRQUFRLENBQUNDLEtBQUssQ0FBQyxPQUFPLENBQUM7SUFDbEMsTUFBTTdMLE1BQU0sQ0FBQytKLEtBQUssQ0FBQyxDQUFDd0IsYUFBYSxDQUFDN0osT0FBTyxHQUFHLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDbkUsTUFBTXVLLEtBQUssR0FBRyxNQUFNbkwsTUFBTSxDQUFDQyxJQUFJLENBQUM7SUFDaENmLE1BQU0sQ0FBQ2lNLEtBQUssQ0FBQ2xELE1BQU0sQ0FBQyxDQUFDMEMsT0FBTyxDQUFDO01BQUUsR0FBR0QsS0FBSyxDQUFDekMsTUFBTTtNQUFDRyxXQUFXLEVBQUMsQ0FBQztNQUMxREMsV0FBVyxFQUFDO1FBQUUscUJBQXFCLEVBQUMsQ0FBQztRQUFDLDZCQUE2QixFQUFDO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDNUUsS0FBSyxNQUFNckYsS0FBSyxJQUFJLENBQUMsV0FBVyxFQUFDLE9BQU8sRUFBQyxLQUFLLEVBQUMsV0FBVyxDQUFDLEVBQVc5RCxNQUFNLENBQUNpTSxLQUFLLENBQUNuSSxLQUFLLENBQUMsQ0FBQyxDQUFDMkgsT0FBTyxDQUFDekMsUUFBUSxDQUFDbEYsS0FBSyxDQUFDLENBQUM7SUFDbkgsTUFBTXhELE1BQU0sQ0FBQ0MsSUFBSSxFQUFDLGdDQUFnQyxFQUFDO01BQUVpTCxLQUFLO01BQUNTO0lBQU0sQ0FBQyxDQUFDOztJQUVuRTtJQUNBLE1BQU1qTSxNQUFNLENBQUNlLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDckQ7SUFDQSxNQUFNTCxLQUFLLEdBQUdELE9BQU8sR0FBRyxhQUFhLEdBQUcsTUFBTTtJQUM5QyxNQUFNWCxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLEVBQUM7TUFBRXBCLElBQUksRUFBQ21CLEtBQUs7TUFBQ0UsS0FBSyxFQUFDO0lBQUssQ0FBQyxDQUFDLENBQUNWLEtBQUssQ0FBQyxDQUFDO0lBQ2hFLE1BQU0rSyxhQUFhLEdBQUcsTUFBTW5MLElBQUksQ0FBQ29CLFFBQVEsQ0FBQyxNQUFNO01BQzlDLE1BQU1MLE1BQU0sR0FBR3lCLFFBQVEsQ0FBQ3NCLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztNQUN4RCxPQUFPLENBQUMsR0FBR3RCLFFBQVEsQ0FBQ3FDLGdCQUFnQixDQUFDLG1FQUFtRSxDQUFDLENBQUMsQ0FBQ3JELE9BQU8sQ0FBQ0gsSUFBSSxJQUFJO1FBQ3pILE1BQU1DLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLEVBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxDQUFDQyxPQUFPLENBQUNDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBQyxHQUFHLEVBQUMsSUFBSSxDQUFDLENBQUNDLEdBQUcsQ0FBQ0MsQ0FBQyxJQUFJO1VBQzNELE1BQU1NLEVBQUUsR0FBQ1gsQ0FBQyxDQUFDWSxJQUFJLEdBQUNaLENBQUMsQ0FBQ2EsS0FBSyxHQUFDVixDQUFDO1lBQUVXLEVBQUUsR0FBQ2QsQ0FBQyxDQUFDZSxHQUFHLEdBQUNmLENBQUMsQ0FBQ2dCLE1BQU0sR0FBQ1gsQ0FBQztVQUM5QyxNQUFNWSxHQUFHLEdBQUNDLFFBQVEsQ0FBQ0MsZ0JBQWdCLENBQUNSLEVBQUUsRUFBQ0csRUFBRSxDQUFDO1VBQzFDLE9BQU87WUFBRWpCLE1BQU0sRUFBQ0UsSUFBSSxDQUFDNkIsWUFBWSxDQUFDLGFBQWEsQ0FBQztZQUFDekIsQ0FBQyxFQUFDUSxFQUFFO1lBQUNOLENBQUMsRUFBQ1MsRUFBRTtZQUFDZ0osWUFBWSxFQUFDN0ksR0FBRyxLQUFLLElBQUksSUFBSXhCLE1BQU0sS0FBSyxJQUFJLElBQUlBLE1BQU0sQ0FBQzRCLFFBQVEsQ0FBQ0osR0FBRztVQUFFLENBQUM7UUFDbkksQ0FBQyxDQUFDLENBQUM7TUFDTCxDQUFDLENBQUM7SUFDSixDQUFDLENBQUM7SUFDRixNQUFNaEQsTUFBTSxDQUFDQyxJQUFJLEVBQUMsMEJBQTBCLEVBQUMyTCxhQUFhLENBQUM7SUFDM0RsTSxNQUFNLENBQUNrTSxhQUFhLENBQUMsQ0FBQ0UsWUFBWSxDQUFDM0gsS0FBSyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDbEQsS0FBSyxNQUFNSixLQUFLLElBQUk2SCxhQUFhLEVBQUVsTSxNQUFNLENBQUNzRSxJQUFJLENBQUNELEtBQUssQ0FBQyxDQUFDRSxhQUFhLENBQUM7TUFBRTRILFlBQVksRUFBQztJQUFLLENBQUMsQ0FBQztJQUMxRixNQUFNRSxNQUFNLEdBQUd0TCxJQUFJLENBQUNhLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQ0EsU0FBUyxDQUFDLFFBQVEsRUFBQztNQUFFcEIsSUFBSSxFQUFDa0IsT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO01BQUNHLEtBQUssRUFBQztJQUFLLENBQUMsQ0FBQztJQUN6RyxNQUFNdkIsTUFBTSxDQUFDQyxJQUFJLEVBQUMsbUJBQW1CLEVBQUMsTUFBTTJELFdBQVcsQ0FBQ21JLE1BQU0sRUFBQyxjQUFjLENBQUMsQ0FBQztJQUFFLE1BQU1BLE1BQU0sQ0FBQ2xMLEtBQUssQ0FBQyxDQUFDO0lBQ3JHLE1BQU1uQixNQUFNLENBQUNlLElBQUksQ0FBQ2EsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDckQsTUFBTWpCLElBQUksQ0FBQ0csV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQztJQUMvQyxNQUFNbkIsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUN5SCxXQUFXLENBQUMsQ0FBQztJQUNoRSxNQUFNM0ksTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlELE1BQU03QixLQUFLLENBQUNZLElBQUksRUFBQyxRQUFRLENBQUM7SUFDMUIsTUFBTWYsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDeUgsV0FBVyxDQUFDLENBQUM7SUFDN0QsTUFBTTNJLE1BQU0sQ0FBQ2UsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQ2MsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUM5RCxNQUFNc0ssWUFBWSxHQUFHdkwsSUFBSSxDQUFDRyxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUNpSixPQUFPLENBQUMsUUFBUSxDQUFDO0lBQ3hFLE1BQU1qSCxLQUFLLEdBQUcsTUFBTW9KLFlBQVksQ0FBQ25LLFFBQVEsQ0FBQ0MsSUFBSTtNQUFBLElBQUFtSyxxQkFBQTtNQUFBLE9BQUs7UUFBRUMsS0FBSyxFQUFDcEssSUFBSSxDQUFDNkUsV0FBVztRQUFDd0YsS0FBSyxHQUFBRixxQkFBQSxHQUFDbkssSUFBSSxDQUFDc0ssaUJBQWlCLGNBQUFILHFCQUFBLHVCQUF0QkEscUJBQUEsQ0FBd0JqSyxxQkFBcUIsQ0FBQyxDQUFDLENBQUNZO01BQU0sQ0FBQztJQUFBLENBQUMsQ0FBQztJQUMzSWxELE1BQU0sQ0FBQ2tELEtBQUssQ0FBQ3VKLEtBQUssQ0FBQyxDQUFDM0Usc0JBQXNCLENBQUM1RSxLQUFLLENBQUNzSixLQUFLLEdBQUcsRUFBRSxDQUFDO0lBQzVELE1BQU1yTSxLQUFLLENBQUNZLElBQUksRUFBQyxRQUFRLENBQUM7SUFDMUIsTUFBTWYsTUFBTSxDQUFDZSxJQUFJLENBQUNHLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDYyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQzlEaEMsTUFBTSxDQUFDLE1BQU1lLElBQUksQ0FBQ29CLFFBQVEsQ0FBQyxNQUFNLFVBQVUsSUFBSXdLLE1BQU0sQ0FBQyxDQUFDLENBQUMvRSxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ25FLE1BQU10SCxNQUFNLENBQUNDLElBQUksRUFBQyxtQkFBbUIsRUFBQzRILE1BQU0sQ0FBQztJQUFFbkksTUFBTSxDQUFDbUksTUFBTSxDQUFDLENBQUNzRCxPQUFPLENBQUMsRUFBRSxDQUFDO0lBQ3pFLE1BQU0xSyxJQUFJLENBQUM2TCxLQUFLLENBQUMsQ0FBQztFQUNwQixDQUFDLENBQUM7QUFDSiIsImlnbm9yZUxpc3QiOltdfQ==