from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent
before=json.loads((root/'post-full.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
index={}
for record in subprocess.check_output(['git','ls-tree','-r','-z','HEAD']).split(b'\0'):
 if not record: continue
 meta,path=record.split(b'\t',1)
 mode,kind,oid=meta.split()
 assert kind==b'blob'
 index[path.decode()]=oid.decode()
assert all(path in index for path in before['sources'])
requests=''.join(index[path]+'\n' for path in before['sources']).encode()
output=subprocess.check_output(['git','cat-file','--batch'],input=requests)
pos=0;checked={}
for path,expected in before['sources'].items():
 end=output.index(b'\n',pos)
 oid,kind,size=output[pos:end].split();assert kind==b'blob'
 pos=end+1;size=int(size);blob=output[pos:pos+size];pos+=size+1
 assert sha(blob)==expected,(path,'blob')
 assert sha(Path(path).read_bytes())==expected,(path,'disk')
 checked[path]={'sha256':expected,'gitBlob':oid.decode()}
assert pos==len(output)
assert sha(__import__('gzip').decompress(Path('docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))==before['genuine']
out={'pass':True,'validatedInputHead':before['head'],'committedHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'sourceFiles':len(checked),'files':checked,'genuineSha256':before['genuine']}
(root/'committed-source-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='files'},indent=2))
