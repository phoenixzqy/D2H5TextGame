from pathlib import Path
import json
p=Path(__file__).parent
b=p/'browser-corrected'
r=json.loads((b/'browser-report.json').read_text())
assert len(r['cases'])==4 and all(c['pass'] and not c['errors'] for c in r['cases']) and not r['failures']
assert len(r['geometry'])==20
slugs=['firestorm','molten-boulder','fissure','volcano','armageddon']
pairs=[]
for before in sorted(b.glob('*-rank*-before-*.json')):
 prefix=before.name.rsplit('-before-',1)[0]
 after=list(b.glob(prefix+'-after-*.json'));assert len(after)==1
 a=json.loads(before.read_text());z=json.loads(after[0].read_text())
 assert a['version']==z['version']==22
 for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==z[domain],(prefix,domain)
 rank=1 if '-rank1' in prefix else 2
 assert z['player']['skillLevels']=={'druid.'+slug.replace('-','_'):rank for slug in slugs}
 assert z['player']['skillPoints']==(5 if rank==1 else 0)
 assert z['player']['comboOrder']==(['druid.firestorm'] if rank==1 else ['skills-druid-armageddon'])
 pairs.append({'label':prefix,'before':before.name,'after':after[0].name,'fiveDomainsExact':True,'rank':rank})
assert len(pairs)==8
assert sum(len(c['combat']) for c in r['cases'])==20
out={'pass':True,'cases':4,'combatEntries':20,'geometry':20,'pairs':pairs,'scope':'Disclosed synthetic L30 fixtures only; root audit, not independent QA or earned progress.'}
(p/'browser-attachment-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':True,'cases':4,'combatEntries':20,'geometry':20,'fiveDomainPairs':8}))
