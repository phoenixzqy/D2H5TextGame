from pathlib import Path
import json,os,signal
p=Path(__file__).resolve().parent
r=json.loads((p/'server-process.json').read_text())
assert r['pid']==257541 and r['port']==4478
proc=Path('/proc')/str(r['pid'])
assert str(p/'serve.py').encode() in (proc/'cmdline').read_bytes()
os.kill(r['pid'],signal.SIGTERM)
print(json.dumps({'stoppedExactOwnedPid':r['pid']}))
