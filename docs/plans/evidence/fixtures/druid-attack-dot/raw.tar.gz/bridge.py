from pathlib import Path
import re,json
root=Path(__file__).resolve().parent
patterns=[r'__GAME__',r'\bseedItem\b',r'\bseedMerc\b',r'\binstallTestBridge\b',r'[,{]flushSave:']
chunks=sorted((root/'build-final/assets').glob('*.js'))
assert len(chunks)==4
for chunk in chunks:
 text=chunk.read_text()
 for pattern in patterns: assert not re.search(pattern,text),(chunk.name,pattern)
print(json.dumps({'pass':True,'chunks':len(chunks),'forbiddenPatterns':patterns}))
