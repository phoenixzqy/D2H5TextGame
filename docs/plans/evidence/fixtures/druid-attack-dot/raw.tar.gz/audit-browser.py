from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
sources=[('browser-current-'+label+('-recovered' if label=='en-360' else ''),[label]) for label in ['en-1280','en-360','zh-CN-1280','zh-CN-360']]
for label in ['en-1280','en-360','zh-CN-1280','zh-CN-360']:
 receipt=p/('browser-current-'+label+('-recovered' if label=='en-360' else '')+'.json')
 assert json.loads(receipt.read_text())['exit']==0
slugs=['werewolf-maul','rabies','fire-claws']
prerequisites={'druid.werewolf':1,'druid.lycanthropy':1,'druid.werebear':1,'druid.feral_rage':1}
accepted=[];pairs=[];geometry=[];screens=[]
for directory,labels in sources:
 b=p/directory;r=json.loads((b/'browser-report.json').read_text())
 assert not r['failures']
 for label in labels:
  case=[c for c in r['cases'] if c['label']==label];assert len(case)==1 and case[0]['pass'] and not case[0]['errors']
  assert [c['slug'] for c in case[0]['combat']]==slugs
  assert all(c['periodicLog'] and c['damagedLivingEnemy'] for c in case[0]['combat'])
  accepted.append({'directory':directory,**case[0]})
  g=[x for x in r['geometry'] if x['label']==label];assert len(g)==5 and all(x['overflow']<=0 and x['allocate']['width']>=44 and x['allocate']['height']>=44 for x in g);geometry.extend(g)
  for rank in [1,2]:
   prefix=label+'-rank'+str(rank)
   before=list(b.glob(prefix+'-before-*.json'));after=list(b.glob(prefix+'-after-*.json'));assert len(before)==len(after)==1
   a=json.loads(before[0].read_text());z=json.loads(after[0].read_text());assert a['version']==z['version']==22
   for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==z[domain],(prefix,domain)
   assert z['player']['skillLevels']=={**prerequisites,**{'druid.'+slug.replace('-','_'):rank for slug in slugs}}
   assert z['player']['skillPoints']==(3 if rank==1 else 0)
   assert z['player']['comboOrder']==(['druid.werewolf_maul'] if rank==1 else ['skills-druid-fire-claws'])
   pairs.append({'label':prefix,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p)),'fiveDomainsExact':True,'rank':rank})
  for name in [*(label+'-'+slug+'-details.png' for slug in slugs),label+'-rabies-combat.png']:
   f=b/name;assert f.is_file();screens.append({'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
assert len(accepted)==4 and len(pairs)==8 and len(geometry)==20 and len(screens)==16
out={'pass':True,'cases':accepted,'combatEntries':12,'geometry':geometry,'pairs':pairs,'screenshots':screens,'scope':'Disclosed synthetic L30 fixtures; all four accepted cases have actual terminal exit0 against the final build, including the separately tracked English mobile recovery. Earlier pre-correction and current English mobile exit143 records are retained. Root audit only, not independent QA or earned progress.'}
(p/'browser-attachment-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':True,'cases':4,'combatEntries':12,'geometry':20,'fiveDomainPairs':8,'screenshots':16}))
