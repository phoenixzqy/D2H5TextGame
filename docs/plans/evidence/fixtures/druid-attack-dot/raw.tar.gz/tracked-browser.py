from pathlib import Path
import json,os,subprocess,sys,time,signal
r=Path(__file__).resolve().parent;label='browser-current-en-360-recovered'
cmd=['node',str(r/'browser-current.cjs')];start=time.monotonic()
def interrupted(signum,frame):
 (r/(label+'-signal.json')).write_text(json.dumps({'signal':signum,'pid':os.getpid(),'seconds':time.monotonic()-start}))
 raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,interrupted)
(r/(label+'-process.json')).write_text(json.dumps({'pid':os.getpid(),'cmd':cmd,'cwd':str(Path.cwd()),'started':time.time()}))
try:
 with (r/(label+'.log')).open('w') as out:
  result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=150)
 code=result.returncode;timeout=False
except subprocess.TimeoutExpired:
 code=124;timeout=True
record={'argv':cmd,'cwd':str(Path.cwd()),'pid':os.getpid(),'exit':code,'timedOut':timeout,'seconds':round(time.monotonic()-start,3),'finished':time.time()}
(r/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
sys.exit(code)
