from pathlib import Path
import hashlib,json,socket,subprocess,tarfile,time

root=Path(__file__).resolve().parent
expected=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-fire-i1zfnxeg')
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert root==expected and not root.is_symlink()
assert Path.cwd()==repo
out=repo/'docs/plans/evidence/fixtures/druid-fire'
assert out.is_dir() and not out.is_symlink()
assert json.loads((root/'full.json').read_text())['exit']==0
assert json.loads((root/'full-freeze-verification.json').read_text())['pass']
assert json.loads((root/'committed-source-verification.json').read_text())['pass']
terminal=json.loads((root/'server-terminal.json').read_text())
assert terminal['pid']==78408 and terminal['closed']
with socket.socket() as s: assert s.connect_ex(('127.0.0.1',4477))!=0
for proc in Path('/proc').iterdir():
 if proc.name.isdigit():
  try: cmd=(proc/'cmdline').read_bytes()
  except (OSError,PermissionError): continue
  assert not (str(root/'run.py').encode() in cmd or str(root/'serve.py').encode() in cmd), proc.name
sha=lambda b:hashlib.sha256(b).hexdigest()
allpaths=sorted(root.rglob('*'))
assert all(not p.is_symlink() and p.resolve().is_relative_to(root) for p in allpaths)
files=[p for p in allpaths if p.is_file()]
raw=[p for p in files if not p.is_relative_to(root/'build-final')]
build=[p for p in files if p.is_relative_to(root/'build-final')]
frozen=json.loads((root/'post-full.json').read_text())
assert {str(p.relative_to(root/'build-final')):sha(p.read_bytes()) for p in build}==frozen['build']
records={str(p.relative_to(root)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in raw}
archive=out/'raw.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in raw: t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers()
 assert {m.name for m in members}==set(records)
 assert all(m.isfile() for m in members)
 for m in members:
  f=t.extractfile(m); assert f is not None
  b=f.read(); assert sha(b)==records[m.name]['sha256'] and len(b)==records[m.name]['bytes']
receipts={}
for p in raw:
 if p.parent==root and p.suffix=='.json':
  r=json.loads(p.read_text())
  if isinstance(r,dict) and 'argv' in r and 'exit' in r: receipts[p.name]=r
manifest={'scope':'Five Druid fire spells, local synthetic verification; independent QA and earned balance remain open.',
 'owner':'root','session':'01a1577a-5af4-70e3-8699-50a906877d8f', 'worktree':str(repo),
 'base':json.loads((root/'ownership.json').read_text())['head'],
 'runtime':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'archiveSha256':sha(archive.read_bytes()),'rawFiles':len(raw),'files':records,'commandReceipts':receipts,
 'fullFreeze':json.loads((root/'full-freeze-verification.json').read_text()),
 'genuineSha256':frozen['genuine'],'buildFiles':len(build),
 'omitted':'Only disposable production build bytes; all 760 build hashes retained in frozen snapshots.',
 'independentAcceptance':False,'earnedCampaignActions':False}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
removed=[]
for p in files:
 rel=str(p.relative_to(root))
 if p in raw: assert sha(p.read_bytes())==records[rel]['sha256']
 else: assert sha(p.read_bytes())==frozen['build'][str(p.relative_to(root/'build-final'))]
 p.unlink(); removed.append(str(p))
for p in sorted((p for p in allpaths if p.is_dir()),key=lambda p:len(p.parts),reverse=True):p.rmdir()
root.rmdir()
with socket.socket() as s: closed=s.connect_ex(('127.0.0.1',4477))!=0
receipt={'root':str(root),'time':time.time(),'rawFilesByteVerified':len(raw),'terminalCommandReceipts':len(receipts),
 'removedFiles':len(removed),'removedPaths':removed,'rootAbsent':not root.exists(),'port4477Closed':closed,
 'remainingPaths':[] if not root.exists() else [str(p) for p in root.rglob('*')],'failures':[],
 'preserved':'Source/history/deliverables, shared caches, umbrella worktree and required earlier campaign evidence.'}
(out/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert receipt['rootAbsent'] and closed
print(json.dumps({k:v for k,v in receipt.items() if k!='removedPaths'},indent=2))
