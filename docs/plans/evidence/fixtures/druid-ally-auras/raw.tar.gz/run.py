import json,subprocess,time,sys
from pathlib import Path
p=Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
start=time.time()
with (p/(name+'.log')).open('w') as f:
 result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
receipt={'command':command,'exit':result.returncode,'seconds':time.time()-start}
(p/(name+'.result.json')).write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
print((p/(name+'.log')).read_text()[-9000:])
sys.exit(result.returncode)
