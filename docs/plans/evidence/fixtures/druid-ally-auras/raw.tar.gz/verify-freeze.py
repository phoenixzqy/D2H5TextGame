from pathlib import Path
import json,re,subprocess,sys

root=Path(__file__).resolve().parent
result=json.loads((root/'full-verified.result.json').read_text())
assert result['exit']==0
subprocess.run([sys.executable,str(root/'snapshot.py'),'full-verified-after'],check=True)
before=json.loads((root/'full-verified-before.json').read_text())
after=json.loads((root/'full-verified-after.json').read_text())
checks={key:before[key]==after[key] for key in ['sources','build','genuine','head','status']}
log=(root/'full-verified.log').read_text()
summary=[line.strip() for line in log.splitlines() if re.match(r'\s*(Test Files|Tests|Duration)\s',line)]
assert any(line.startswith('Test Files') for line in summary)
assert any(line.startswith('Tests') for line in summary)
out={'pass':all(checks.values()),'head':before['head'],'checks':checks,
 'sourceFiles':len(before['sources']),'buildFiles':len(before['build']),
 'genuineSha256':before['genuine'],'fullWallSeconds':result['seconds'],'summary':summary}
(root/'full-freeze-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
assert out['pass']
