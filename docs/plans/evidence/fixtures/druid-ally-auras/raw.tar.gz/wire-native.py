from pathlib import Path
p=Path('src/stores/combatHelpers.ts');s=p.read_text()
s=s.replace('composeDruidShapeshifting, refreshDruidForm, withoutDruidFormLife', 'composeDruidShapeshifting, refreshDruidFormState, druidFormLifeBonus')
s=s.replace("import { composeStatAura } from '@/engine/skills/stat-auras';", "import { activeStatAura, composeStatAura } from '@/engine/skills/stat-auras';\nimport { activeDruidAllyAuras, composeDruidAllyAuras, DRUID_ALLY_AURA_DEFINITIONS } from '@/engine/skills/druid-ally-auras';\nimport { projectLifeCapacity, withoutTemporaryLifeCapacity } from '@/engine/combat/life-capacity';")
s=s.replace("  const summonPassives = currentPlayer?.id === run.playerUnit.id", "  const druidAllyAuras = currentPlayer?.id === run.playerUnit.id\n    ? composeDruidAllyAuras(currentPlayer, run.fieldedMercCombatId) : undefined;\n  const summonPassives = currentPlayer?.id === run.playerUnit.id")
s=s.replace('  const playerTeam = carryPlayerTeam.map(carried => {\n    const unit = withoutVigorLife(withoutDruidFormLife(carried));', '  const refreshedTeam = carryPlayerTeam.map(carried => {\n    const unit = withoutTemporaryLifeCapacity(carried);')
s=s.replace('life: Math.min(unit.life, vigorLifeMax(freshMerc.stats.lifeMax, statAura?.bonuses.lifePct ?? 0)),','life: unit.life,')
s=s.replace('const refreshed = refreshDruidForm({ ...unit, level: fresh.level, stats: fresh.stats,','const refreshed = refreshDruidFormState({ ...unit, level: fresh.level, stats: fresh.stats,')
s=s.replace('life: unit.druidForm !== undefined ? unit.life : Math.min(unit.life, vigorLifeMax(fresh.stats.lifeMax, statAura?.bonuses.lifePct ?? 0)),','life: unit.life,')
needle='  // Qualification comes from the filtered Player configuration'
assert needle in s
s=s.replace(needle,'''  // Settle the final combined cap once, after fresh authority and all original party identities exist.
  const party = new Map([...refreshedTeam, ...enemies].map(unit => [unit.id, unit]));
  const playerTeam = refreshedTeam.map(unit => {
    const oakRank = activeDruidAllyAuras(druidAllyAuras, unit, party)?.oakRank ?? 0;
    const aura = activeStatAura(statAura, unit.id, party);
    const vigor = aura?.selectedAuraId === 'paladin.vigor' ? aura.bonuses.lifePct ?? 0 : 0;
    return projectLifeCapacity(unit, druidFormLifeBonus(unit), [
      ...(oakRank ? [{ coefficient: DRUID_ALLY_AURA_DEFINITIONS.oak.lifePerRank, rank: oakRank }] : []),
      ...(vigor ? [{ coefficient: vigor, rank: 1 }] : [])
    ]);
  });

'''+needle)
s=s.replace('...(statAura ? { statAura } : {}),','...(statAura ? { statAura } : {}),\n      ...(druidAllyAuras ? { druidAllyAuras } : {}),')
lines=s.splitlines();lines=[l for l in lines if not ('import ' in l and 'vigorLifeMax' in l)]
p.write_text('\n'.join(lines)+'\n')
