from pathlib import Path
import hashlib,json,os,socket,tarfile,time
root=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert root==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-druid-forms-97wnsuki')
owner=json.loads((root/'ownership.json').read_text());assert owner['owner']=='root' and owner['worktree']==str(repo)
assert json.loads((root/'server-terminal.json').read_text())['closed']
freeze=json.loads((root/'full-freeze-verification.json').read_text());assert freeze['pass']
assert json.loads((root/'browser-attachment-audit.json').read_text())['pass']
with socket.socket() as s:
 s.settimeout(1);assert s.connect_ex(('127.0.0.1',4474))!=0
excluded={'build-before-ownership','build-before-wording','build-before-badge','build-final'}
all_paths=sorted(root.rglob('*'))
assert all(not p.is_symlink() for p in all_paths)
files=[p for p in all_paths if p.is_file() and p.relative_to(root).parts[0] not in excluded]
sha=lambda b:hashlib.sha256(b).hexdigest()
entries={str(p.relative_to(root)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in files}
fixture=repo/'docs/plans/evidence/fixtures/druid-shapeshifting'
assert not fixture.exists();fixture.mkdir()
archive=fixture/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert sorted(t.getnames())==sorted(entries)
 for name,meta in entries.items():
  f=t.extractfile(name);assert f is not None
  data=f.read();assert sha(data)==meta['sha256'] and len(data)==meta['bytes']
results=[p for p in files if p.name.endswith('.result.json')]
manifest={'scope':'Local synthetic Druid shapeshifting verification; independent and earned acceptance remain open.',
 'owner':owner,'session':'01a1577a-5af4-70e3-8699-50a906877d8f','runtime':freeze['head'],
 'archiveSha256':sha(archive.read_bytes()),'files':entries,'rawFileCount':len(files),'terminalResults':len(results),
 'allArchivedBytesVerified':True,'excludedDisposableBuildDirectories':sorted(excluded),'fullFreeze':freeze}
(fixture/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
removed=[];failures=[]
# Every path below was enumerated in the verified task-only directory; never follow symlinks.
for p in sorted(all_paths,key=lambda p:len(p.parts),reverse=True):
 try:
  if p.is_file():p.unlink();removed.append(str(p))
  elif p.is_dir():p.rmdir()
  else:raise RuntimeError('Unexpected non-file path: '+str(p))
 except Exception as e:failures.append({'path':str(p),'error':str(e)})
try:root.rmdir()
except Exception as e:failures.append({'path':str(root),'error':str(e)})
remaining=[str(p) for p in root.rglob('*')] if root.exists() else []
with socket.socket() as s:
 s.settimeout(1);port_closed=s.connect_ex(('127.0.0.1',4474))!=0
receipt={'scratch':str(root),'scratchAbsent':not root.exists(),'removedFileCount':len(removed),'removedFiles':removed,
 'remainingPaths':remaining,'failures':failures,'port4474Closed':port_closed,'time':time.time(),
 'preserved':'Repository source/history/deliverables, shared caches, umbrella worktree and earlier required evidence.'}
(fixture/'cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='removedFiles'}))
print(json.dumps({'rawFiles':len(files),'terminalResults':len(results),'archiveBytesVerified':True,'fixture':str(fixture)}))
assert not failures and not remaining and not root.exists() and port_closed
