from pathlib import Path
p=Path('src/engine/combat/combat.ts');s=p.read_text()
s=s.replace("import { vigorLifeMax, withoutVigorLife } from '../skills/vigor';", "import { projectLifeCapacity } from './life-capacity';\nimport { activeDruidAllyAuras, copyDruidAllyAuras, DRUID_ALLY_AURA_DEFINITIONS, type DruidAllyAuraProjection } from '../skills/druid-ally-auras';")
s=s.replace('matchesDruidForm, refreshDruidForm, selectedDruidForm', 'matchesDruidForm, refreshDruidFormState, druidFormLifeBonus, selectedDruidForm')
s=s.replace('readonly statAura?: StatAuraProjection;', 'readonly statAura?: StatAuraProjection;\n  readonly druidAllyAuras?: DruidAllyAuraProjection;')
s=s.replace('hasVigorLife','hasTemporaryLife').replace('reconcileVigorLife','reconcileLifeCapacities')
s=s.replace('const shaped = refreshDruidForm(copied);','const shaped = refreshDruidFormState(copied);')
s=s.replace("  const defenderAura = activeStatAura(state.statAura, defender.id, state.units);", "  const defenderAura = activeStatAura(state.statAura, defender.id, state.units);\n  const heartRank = activeDruidAllyAuras(state.druidAllyAuras, attacker, state.units)?.heartRank ?? 0;")
s=s.replace('(attackerAura?.bonuses.attackPct ?? 0)) * effect.attackDamagePct', '(attackerAura?.bonuses.attackPct ?? 0) + heartRank * DRUID_ALLY_AURA_DEFINITIONS.heart.attackPerRank) * effect.attackDamagePct')
s=s.replace('critChance: stats.critChance,','critChance: stats.critChance + heartRank * DRUID_ALLY_AURA_DEFINITIONS.heart.critPerRank,')
s=s.replace("(activeStatAura(state.statAura, actorId, state.units)?.bonuses.attackPct ?? 0);", "(activeStatAura(state.statAura, actorId, state.units)?.bonuses.attackPct ?? 0) +\n    (activeDruidAllyAuras(state.druidAllyAuras, actor, state.units)?.heartRank ?? 0) * DRUID_ALLY_AURA_DEFINITIONS.heart.attackPerRank;")
a=s.index('function reconcileLifeCapacities(state: State): void {');b=s.index('/** Close and mark',a)
s=s[:a]+'''function reconcileLifeCapacities(state: State, forceFormId?: string): void {
  if (!state.hasTemporaryLife) return;
  for (const unit of state.units.values()) {
    const oakRank = activeDruidAllyAuras(state.druidAllyAuras, unit, state.units)?.oakRank ?? 0;
    const aura = activeStatAura(state.statAura, unit.id, state.units);
    const vigor = aura?.selectedAuraId === 'paladin.vigor' ? aura.bonuses.lifePct ?? 0 : 0;
    const druid = unit.druidShapeRanks !== undefined || unit.druidForm !== undefined || unit.druidFormLife !== undefined;
    if (!druid && !oakRank && !vigor && unit.vigorLife === undefined) continue;
    const next = projectLifeCapacity(unit, druidFormLifeBonus(unit), [
      ...(oakRank ? [{ coefficient: DRUID_ALLY_AURA_DEFINITIONS.oak.lifePerRank, rank: oakRank }] : []),
      ...(vigor ? [{ coefficient: vigor, rank: 1 }] : [])
    ]);
    state.units.set(unit.id, next);
    if (unit.stats.lifeMax !== next.stats.lifeMax || unit.life !== next.life || forceFormId === unit.id) {
      emit(state, { kind: 'life-capacity', target: unit.id, lifeMax: next.stats.lifeMax, life: next.life,
        ...(next.vigorLife ? { vigorBaseLifeMax: next.vigorLife.baseLifeMax } : {}),
        ...(druid ? { druidFormState: { ...(next.druidForm ? { druidForm: next.druidForm } : {}),
          ...(next.druidFormLife ? { druidFormLife: next.druidFormLife } : {}) } } : {}) });
    }
  }
}

'''+s[b:]
a=s.index('        const next = refreshDruidForm(actor, effect.druidForm);');b=s.index("        emit(state, { kind: 'buff'",a)
s=s[:a]+'''        state.units.set(actorId, refreshDruidFormState(actor, effect.druidForm));
        reconcileLifeCapacities(state, actorId);
'''+s[b:]
s=s.replace("  emit(state, { kind: 'summon', owner: owner.id, summonId: templateId, unit: positionedSummon });", "  reconcileLifeCapacities(state);\n  const committed = state.units.get(positionedSummon.id) ?? positionedSummon;\n  emit(state, { kind: 'summon', owner: owner.id, summonId: templateId, unit: committed });")
s=s.replace('  return positionedSummon;\n}', '  return committed;\n}')
s=s.replace('  const statAura = copyStatAuraProjection(snapshot.statAura);', '  const statAura = copyStatAuraProjection(snapshot.statAura);\n  const druidAllyAuras = copyDruidAllyAuras(snapshot.druidAllyAuras);')
s=s.replace("hasTemporaryLife: statAura?.selectedAuraId === 'paladin.vigor' ||\n      [...snapshot.playerTeam, ...snapshot.enemyTeam].some(unit => unit.vigorLife !== undefined),", "hasTemporaryLife: statAura?.selectedAuraId === 'paladin.vigor' || druidAllyAuras !== undefined ||\n      [...snapshot.playerTeam, ...snapshot.enemyTeam].some(unit => unit.vigorLife !== undefined || unit.druidShapeRanks !== undefined || unit.druidForm !== undefined || unit.druidFormLife !== undefined),\n    ...(druidAllyAuras ? { druidAllyAuras } : {}),")
a=s.index('  // Preserve the required complete initial-status prefix');b=s.index('  reconcileLifeCapacities(state);',a)
s=s[:a]+s[b:]
p.write_text(s)
