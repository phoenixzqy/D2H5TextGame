from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,json,signal,time
root=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(root/'build-final'),**kwargs)
 def do_GET(self):
  if not Path(self.translate_path(self.path)).exists(): self.path='/index.html'
  super().do_GET()
def stop(*args): raise SystemExit(0)
signal.signal(signal.SIGTERM,stop)
server=ThreadingHTTPServer(('127.0.0.1',4474),Handler)
(root/'server-process.json').write_text(json.dumps({'pid':os.getpid(),'port':4474,'host':'127.0.0.1','started':time.time()}))
print('Task production server PID '+str(os.getpid())+' at 127.0.0.1:4474',flush=True)
try: server.serve_forever()
finally:
 server.server_close()
 (root/'server-terminal.json').write_text(json.dumps({'pid':os.getpid(),'closed':True,'time':time.time()}))
