import pathlib, json, hashlib, tarfile, io, datetime
scratch=pathlib.Path(__file__).resolve().parent
assert str(scratch)=='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-actives-8zm0aycd'
wd=pathlib.Path.cwd()
assert str(wd)=='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2'
assert json.loads((scratch/'paladin-final-full.json').read_text())['exit']==0
assert json.loads((scratch/'post-full-freeze-audit.json').read_text())['all_exact']
assert json.loads((scratch/'committed-source-audit.json').read_text())['all_exact']
dest=wd/'docs/plans/evidence/fixtures/paladin-active-attacks'
assert not dest.exists();dest.mkdir()
def digest(data): return hashlib.sha256(data).hexdigest()
files=[f for f in sorted(scratch.rglob('*')) if f.is_file() and 'production-dist' not in f.relative_to(scratch).parts]
assert all(not f.is_symlink() and f.resolve().is_relative_to(scratch) for f in files)
manifest={str(f.relative_to(scratch)):{'size':f.stat().st_size,'sha256':digest(f.read_bytes())} for f in files}
archive=dest/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for f in files:tf.add(f,arcname=str(f.relative_to(scratch)),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(manifest)
 for member in tf.getmembers():
  assert member.isfile();body=tf.extractfile(member).read()
  assert len(body)==manifest[member.name]['size'] and digest(body)==manifest[member.name]['sha256']
receipts=[]
for f in files:
 if f.suffix!='.json':continue
 v=json.loads(f.read_text())
 if isinstance(v,dict) and all(key in v for key in ['argv','exit','seconds','finished']):
  receipts.append({'path':str(f.relative_to(scratch)),'sha256':manifest[str(f.relative_to(scratch))]['sha256'],**v})
(dest/'terminal-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
for name in ['frozen-inputs.json','post-full-freeze-audit.json','committed-source-audit.json','browser-evidence-audit.json','author-review.json','inventory-reconciliation.json','build-audit.json']:
 (dest/name).write_bytes((scratch/name).read_bytes())
for source,name in [('browser-en-360/en-360-vengeance-details.png','vengeance-en-mobile.png'),('browser-zh-CN-360/zh-CN-360-vengeance-details.png','vengeance-zh-mobile.png')]:
 (dest/name).write_bytes((scratch/source).read_bytes())
packet={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':'raw.tar.gz','sha256':digest(archive.read_bytes()),'raw_files':len(files),'terminal_receipts':len(receipts),'all_members_byte_verified':True,'files':manifest,'omitted':'Disposable production-dist bytes; complete build hash map retained in frozen-inputs.json. No trace or screenshot omitted.'}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({k:v for k,v in packet.items() if k!='files'}))
