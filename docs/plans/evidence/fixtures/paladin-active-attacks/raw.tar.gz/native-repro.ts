import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import type { CombatUnit, ActiveStatus } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
import { useInventoryStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/inventoryStore';
import { useMapStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/mapStore';
import { useFormationStore } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/formationStore';
import authored from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/data/skills/paladin.json';
const hold=(at=0):ActiveStatus=>({id:'stun',stacks:1,remaining:-1,sourceId:'synthetic-hold',appliedAtMs:at});
function fixture(slug:string,rank:number,mr=0){
 useInventoryStore.getState().reset();useMapStore.getState().reset();useFormationStore.getState().reset();
 const id='paladin.'+slug.replaceAll('-','_');
 const native=playerToCombatUnit({...createMockPlayer('Synthetic native Paladin probe','paladin'),id:'probe-hero',level:30,skillLevels:{...Object.fromEntries(authored.filter(s=>s.trigger==='active').map(s=>['paladin.'+s.id.replace('skills-paladin-','').replaceAll('-','_'),1])),[id]:rank},comboOrder:['skills-paladin-'+slug]});
 const mana=slug==='holy-bolt'?15:slug==='blessed-hammer'?25:30;
 const hero:CombatUnit={...native,life:5000,mana,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,manaRegenCarry:0,manaRegenCompensation:0,manaRegenExactCarry:'0',statuses:[hold(1701)],stats:{...native.stats,life:10000,lifeMax:10000,mana:100,manaMax:100,attack:1,attackSpeed:100,critChance:0}};
 const enemy:CombatUnit={...hero,id:'probe-target',side:'enemy',kind:'monster',life:100000,mana:0,statuses:[hold()],skillOrder:[],skillLevels:{},increasedDamagePct:{},stats:{...hero.stats,life:100000,lifeMax:100000,defense:0,magicResist:mr,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,poison:0,arcane:0}}};
 return {id,native,mana,input:{seed:7,playerTeam:[hero],enemyTeam:[enemy]}};
}
const cases=[];
for(const rank of [1,20])for(const slug of ['holy-bolt','blessed-hammer','vengeance']){
 const f=fixture(slug,rank,slug==='blessed-hammer'?30:0),before=structuredClone(f.input),out=runBattleRecorded(f.input);
 const attacks=out.events.filter(e=>e.kind==='damage'&&e.source===f.native.id&&e.simClockMs===1700);
 const actions=out.events.filter(e=>e.kind==='action'&&e.actor===f.native.id);
 const controls={nativeSelection:f.native.skillOrder.length===1&&f.native.skillOrder[0]==='skills-paladin-'+slug,onePaidCast:actions.length===1&&actions[0]?.skillId===f.id,positiveDamage:attacks.some(e=>e.kind==='damage'&&e.amount>0),payment:out.result.playerTeam[0]?.mana===0,immutable:true,replay:true};
 assert.deepEqual(f.input,before);assert.deepEqual(runBattleRecorded(f.input),out);
 assert.ok(Object.values(controls).every(Boolean),JSON.stringify({slug,rank,controls,actions,attacks}));
 const observations:Record<string,unknown>={attacks,heals:out.events.filter(e=>e.kind==='heal'),statuses:out.events.filter(e=>e.kind==='status'),heroLife:out.result.playerTeam[0]?.life,enemyLife:out.result.enemyTeam[0]?.life};
 const requirements:Record<string,boolean>={};
 if(slug==='holy-bolt'){
  const removed=100000-(out.result.enemyTeam[0]?.life??100000),expected=Math.floor(removed*.5);
  observations.expectedRecovery=expected;requirements.actualCasterRecovery=out.result.playerTeam[0]?.life===5000+expected&&out.events.some(e=>e.kind==='heal'&&e.target===f.native.id&&e.amount===expected);
 }
 if(slug==='blessed-hammer'){
  const clean=fixture(slug,rank,0),control=runBattleRecorded(clean.input);
  const cleanAttacks=control.events.filter(e=>e.kind==='damage'&&e.source===clean.native.id&&e.simClockMs===1700);observations.withoutMagicResist=cleanAttacks;
  requirements.ignoresMagicResist=JSON.stringify(attacks)===JSON.stringify(cleanAttacks);
 }
 if(slug==='vengeance'){
  requirements.threeActualDamageTypes=['fire','cold','lightning'].every(type=>attacks.some(e=>e.kind==='damage'&&e.damageType===type&&e.amount>0));
  requirements.allAdvertisedStatuses=['burn','chill','paralyze'].every(status=>out.events.some(e=>e.kind==='status'&&e.statusId===status));
 }
 cases.push({slug,rank,controls,requirements,observations});
}
const failures=cases.flatMap(c=>Object.entries(c.requirements).filter(([,pass])=>!pass).map(([requirement])=>({slug:c.slug,rank:c.rank,requirement})));
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-actives-8zm0aycd/native-red-result.json',JSON.stringify({fixture:'Synthetic native L30 Paladin, seed7; future actor hold after first real action, permanent target hold; no ordinary regeneration or gear; exact first-cast MP. No earned campaign.',cases,failures},null,2)+'\n');
console.log(JSON.stringify({cases:cases.length,controls:cases.length*6,failures,observations:cases.map(c=>({slug:c.slug,rank:c.rank,...c.observations}))},null,2));
assert.deepEqual(failures,[],'Advertised native Paladin effects must have actual combat consequences');
