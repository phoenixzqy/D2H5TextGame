import { writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRng } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/rng';
import { resolveDamage, type DamageInput } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/damage';
const rows=[];
for (const type of ['physical','fire','cold','lightning','poison','arcane','thorns'] as const)
 for (let profile=0;profile<4;profile++)for(let seed=1;seed<=16;seed++){
  const input:DamageInput={baseMin:profile===1?99.5:profile===2?240:90,baseMax:profile===1?180.2:profile===2?120:150,flatBonus:profile===2?-30:3,increasedPct:profile===3?.7:.15,comboMult:1.3,type,critChance:profile===3?1.3:.2,critMult:1.5,defenderResistances:{physical:30,fire:60,cold:-20,lightning:10,poison:80,arcane:40},defenderArmor:7,defenderMagicResist:13,defenderDodge:profile===2?.9:.1,hitChancePenalty:profile===2?.2:0,...(profile===1?{ignoreDodge:true}:{}),resistPenalty:profile===3?40:0};
  const rng=createRng(seed),outcome=resolveDamage(input,rng);rows.push({type,profile,seed,input,outcome,next:[rng.next(),rng.next(),rng.next()]});
 }
const content=JSON.stringify(rows);const file=process.argv[2];if(!file)throw new Error('Require distinct corpus output path');writeFileSync(file,content+'\n');console.log(JSON.stringify({rows:rows.length,sha256:createHash('sha256').update(content).digest('hex')}));
