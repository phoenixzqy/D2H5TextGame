import pathlib,json,re,hashlib,socket,os
p=pathlib.Path(__file__).parent
spells=['holy-bolt','blessed-hammer','vengeance']
cases=[]
for locale,width in [('en',1280),('en',360),('zh-CN',1280),('zh-CN',360)]:
 label='browser-'+locale+'-'+str(width); d=p/label; name=locale+'-'+str(width)
 report=json.loads((d/'browser-report.json').read_text()); assert report['failures']==[]
 assert len(report['cases'])==1
 case=report['cases'][0];assert case['pass'] is True and case['errors']==[] and case['pairs']==['rank1','rank2']
 assert [x['slug'] for x in case['combat']]==spells
 assert {(x['width'],x['height']) for x in report['geometry']}=={(360,640),(412,915),(640,360),(1280,800),(1920,1080)}
 assert all(x['overflow']==0 and x['allocate']['width']>=44 and x['allocate']['height']>=44 for x in report['geometry'])
 pairs=[]
 for rank in [1,2]:
  before,after=[list(d.glob(name+'-rank'+str(rank)+'-'+stage+'-*.json')) for stage in ['before','after']]
  assert len(before)==len(after)==1
  a,b=[json.loads(x.read_text()) for x in [before[0],after[0]]]
  for domain in ['player','inventory','map','mercs','formation']: assert a[domain]==b[domain]
  expected={'paladin.sacrifice':1,'paladin.zeal':1,**{'paladin.'+slug.replace('-','_'):rank for slug in spells}}
  assert b['player']['skillLevels']==expected and b['player']['skillPoints']==(3 if rank==1 else 0)
  pairs.append({'rank':rank,'five_domains_exact':True,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p))})
 heal=case['combat'][0]['log']
 hp=re.compile(r'PaladinCheck recovers ([1-9]\d*) HP' if locale=='en' else r'PaladinCheck 恢复了 ([1-9]\d*) 点生命')
 positive_heals=[int(m.group(1)) for line in heal if (m:=hp.search(line))]
 assert positive_heals
 cases.append({'label':label,'public_positive_entries':3,'positive_holy_bolt_heals':positive_heals,'save_pairs':pairs,
  'geometry':report['geometry'],'screenshots':len(list(d.glob('*.png'))),'errors':[]})
inspected=['browser-en-360/en-360-vengeance-details.png','browser-en-360/en-360-holy-bolt-combat.png',
 'browser-en-1280/en-1280-blessed-hammer-details.png','browser-en-1280/en-1280-vengeance-combat.png',
 'browser-zh-CN-1280/zh-CN-1280-holy-bolt-details.png','browser-zh-CN-1280/zh-CN-1280-blessed-hammer-combat.png',
 'browser-zh-CN-360/zh-CN-360-vengeance-details.png','browser-zh-CN-360/zh-CN-360-vengeance-combat.png']
processes=[]
for owner in p.glob('browser-*-server-owner.json'):
 data=json.loads(owner.read_text());assert not pathlib.Path('/proc',str(data['pid'])).exists(),data
 processes.append(data)
assert len(processes)==4
try:
 with socket.create_connection(('127.0.0.1',4482),timeout=.5): raise AssertionError('Task preview port is still open')
except ConnectionRefusedError:pass
result={'cases':cases,'public_positive_entries':12,'five_domain_pairs':8,'geometry_samples':20,'screenshots':24,
        'visual_inspection':[{'path':name,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest()} for name in inspected],
        'server_processes_stopped':processes,'port_4482_closed':True,'synthetic_fixture':True,
        'earned_campaign_or_balance_acceptance':False}
out=p/'browser-audit.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['cases','visual_inspection','server_processes_stopped']}))
