# D05 — Actual Spirit of Barbs

Runtime `61ec0c1` creates the advertised support spirit; `ffae4ea` adds truthful
bilingual details, base preview and positive-chip playback under
[BUG189](../../../production/bugs/BUG-189-spirit-of-barbs-missing-spirit.md)
and the [local contract](../decisions/D05-spirit-of-barbs-v1.md).
Only Spirit of Barbs receives bounded local functional credit after the final
checks below. Independent design/QA and earned build/balance acceptance remain
open. The umbrella full-v1 goal is unfinished.

## Result

Authored Druid unlock30, cap20, Oak→Heart prerequisites, reflection4% per rank and
summon Defense2% per rank remain unchanged. A copied native wave projection uses
exact aliases/MAX once and rejects malformed allocation, wrong class or unlock.
At nonterminal wave entry a living original hero automatically creates one real
owned, targetable `spirit_of_barbs` without mana, an ordinary action or a combo
slot. The battle stores its newly committed identity privately; a preloaded body
or raw marker cannot attest authority. The spirit never schedules ordinary
attacks and is not replaced after death in that wave. Its free death cannot
refund an unrelated summoning skill or clear that skill's cooldown.

Both original source and actual spirit must live. Original living hero/fielded
merc/source-owned summons reflect physical HP actually lost on a survived hit.
The existing reflection/thorns mitigation, flooring and no-recursion path is
shared with independent reflection sources. Defense bonuses affect only owned
summons, including the spirit, during damage reads without rewriting base stats.
Death/orphan closure removes derived effects before later damage or recovery.
Stun alone does not disable the effect. Existing Oak/Heart projections benefit
the real spirit; increased life capacity does not heal.

The actual JSON-owned template baseline is Life80/Attack0/Defense10. Life80 and
Defense10 reuse the existing generic summon baseline as explicit provisional
tuning, not earned balance. No new art, save version, persistent capability or
migration is introduced. Save22 persists allocations only. Native configuration
changes apply next wave; original-resource replay does not duplicate income.
The UI normalizes exact allocation aliases, explains scaling/lifecycle/source
requirements, previews base stats before combat bonuses and localizes the real
summon and positive aura chip in en/zh-CN. Actual playback removes the chip on
owner death.

## Verification

At unchanged `aca09a8`, native causal RED has2 missing-summon failures/4 passing
controls. Engine causal RED has3 failures/2 controls: missing rank1/20 spirits
and missing independent-plus-Barbs reflection. Pure definition/schema checks and
that same native causal reproduction now pass. The later UI RED has6 failing
component cases; preview RED has2 missing-cap/template cases. Those original
logs and fixtures are retained.

Final focused compatibility is97 tests/11 files, including rank1/20, actual
reflection/damage/Defense, source/spirit death, no action/replacement/refund,
foreign/bench/preloaded controls, invalid factory refusal, magical/lethal hits,
independent reflection/no recursion, native upgrades/reset/replay, exact five-domain
Save22 import, bilingual current/next/MAX/cap and actual chip-removal playback.
The unchanged43 native Might/Vigor cases and existing Druid aura tests pass.
Final engine is6682 tests/234 files. Types, standard lint, final-test correction
lint, explicit `VITE_E2E=false` production build and four-chunk bridge scan pass.

@@FULL@@

Public-control production browser cases pass4/4: en/zh-CN ×1280×800/360×640.
They create a character, export/import a disclosed synthetic L30/rank19/large-gear
fixture, inspect rank19/20 values, allocate the last rank, enter combat and show
the actual localized spirit/positive chip. All four actual spirit HP strips read
97.56% (Life80/capacity82 with Oak1), without inferring healing or exact damage
from pixels. Eight separately audited Save-close-new-page-Continue pairs preserve
player/inventory/map/mercs/formation exactly, version22, skill points, allocations
and empty combo. Twenty geometry samples cover360,412,640landscape,1280,1920 widths
with no horizontal overflow and allocation controls ≥44px. All8 retained screenshots
were inspected. Browser fixtures earn no campaign progress or class-balance credit.

No new test is skipped and no assertion or timeout is weakened for this change. Initial module/schema/type errors,
incorrect survivor/death-time/refund reason expectations, dodged foreign-hit and
mixed magical/ordinary-attack fixture errors, canonical allocation-key mismatch
and later optional-property/raw-JSON type errors remain retained. Corrections
use actual event timing, repeated controlled all-target attacks, magic-hit timing,
canonical saved keys and schema-validated typed rows. They do not change authored
coefficients, relax strict validation or raise test timeouts.

Existing small-screen header/navigation occlusion, icon/font fallback, below-fold
details and the spirit's deliberate text-avatar fallback remain visible. The
build still warns about large chunks, an oversized unprecached generated manifest
and stale Browserslist data. These checks do not establish PWA, full UX/accessibility,
real-device performance, test-duration budgets, independent QA or earned balance.

## Scope and continuation

Only one inventory row gains bounded functional credit. All213 IDs/order remain:
146 unverified,65 bounded-functional,one bounded-engine-functional,one review-needed.
The remaining unverified rows are active skills; proof scopes differ and must not
be presented as whole-game acceptance.

Genuine Ancients401 decompressed SHA256
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`
is unchanged: L33/XP149261/23682gear/nextNormal402/Nightmare0, Ancients/Rite claimed,
Baal uncleared. No genuine campaign, remote publication or deployment action is
part of this batch. C2–C4, all213 skills, earned builds/economy/pacing/endgame,
PWA/performance/accessibility, independent QA and fullG0–G7 remain unfinished.
Root remains sole writer; the existing umbrella worktree/branch/claim and full-v1
goal remain active.

## Retention and cleanup

[Manifest](fixtures/spirit-of-barbs/manifest.json),
[raw archive](fixtures/spirit-of-barbs/raw.tar.gz) and
[cleanup receipt](fixtures/spirit-of-barbs/cleanup.json) retain the original failures,
fixtures/scripts, terminal results, browser exports/screenshots, frozen inputs,
source self-review and committed-source proof. Root self-review is not independent
acceptance. Every archived file is byte/hash verified before exact task-owned
source/build disposal. The exact owned production server PID4090375 was verified
by command line and stopped; port4476 is closed. Shared caches, source/history,
umbrella checkout and earlier required campaign evidence are preserved.

@@CLEANUP@@
