from pathlib import Path
import json,subprocess,sys,time
r=Path(__file__).resolve().parent
label=sys.argv[1];cmd=sys.argv[2:]
assert not (r/(label+'.log')).exists()
started=time.time()
with (r/(label+'.log')).open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
result={'command':cmd,'exit':p.returncode,'seconds':time.time()-started}
(r/(label+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
print((r/(label+'.log')).read_text()[-11000:])
sys.exit(p.returncode)
