from pathlib import Path
import collections,csv,io,json,subprocess
r=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert Path.cwd()==repo
freeze=json.loads((r/'full-freeze-verification.json').read_text());assert freeze['pass']
assert json.loads((r/'browser-attachment-audit.json').read_text())['pass']
assert json.loads((r/'committed-source-verification.json').read_text())['pass']
full='Final standard `npm test` passes: '+ '; '.join(freeze['summary'])+'. Wrapper wall time '+str(round(freeze['fullWallSeconds'],3))+'s. All '+str(freeze['sourceFiles'])+' source/test/config hashes, '+str(freeze['buildFiles'])+' build hashes, HEAD, Git status and genuine-save digest match before/after the full run. Every committed source blob independently matches the validated snapshot. Existing skips and the documented test-duration budget breach remain disclosed; this pass is not performance acceptance.'
p=repo/'docs/plans/evidence/d05-spirit-of-barbs.md';assert not p.exists()
p.write_text((r/'evidence-draft.md').read_text().replace('@@FULL@@',full).replace('@@CLEANUP@@','Retention and exact cleanup are pending; the final receipt will replace this sentence.'))
p=repo/'docs/plans/skill-inventory.csv';original=list(csv.DictReader(p.open()));columns=list(original[0]);before=[row.copy() for row in original]
for row in original:
 if row['data_id']=='skills-druid-spirit-of-barbs':
  assert row['behavior_verification']=='unverified'
  row['behavior_verification']='bounded-functional;independent-acceptance-open'
  row['contract_evidence']='docs/plans/evidence/d05-spirit-of-barbs.md'
  row['adapter_route']='automatic-living-spirit+party-reflection+summon-defense'
  row['declared_statuses']='spirit-of-barbs'
  row['risk_flags']='provisional-spirit-template-balance-open|earned-class-build-balance-open'
assert sum(a!=b for a,b in zip(before,original))==1
assert len(original)==213
f=io.StringIO(newline='');writer=csv.DictWriter(f,fieldnames=columns,lineterminator='\n');writer.writeheader();writer.writerows(original);p.write_text(f.getvalue())
p=repo/'docs/design/skills-spec.md';s=p.read_text();old='Spirit of Barbs still requires its advertised summoned spirit; earned balance and independent acceptance remain open.';assert old in s;s=s.replace(old,'Spirit of Barbs follows the [actual support-spirit contract](../plans/decisions/D05-spirit-of-barbs-v1.md): one free targetable nonattacking spirit per wave, living source/spirit requirements, 4% reflection and 2% summon Defense per rank, no same-wave replacement or death refund. Earned balance and independent acceptance remain open.');p.write_text(s)
p=repo/'production/bugs/BUG-189-spirit-of-barbs-missing-spirit.md';s=p.read_text().replace('Severity: High. Status: reproduced; implementation pending.','Severity: High. Status: locally fixed and verified; independent/earned acceptance open.');s+='\n## Local resolution\n\nRuntime `61ec0c1` and presentation `ffae4ea` implement the actual passive spirit.\n[Verification and limits](../../docs/plans/evidence/d05-spirit-of-barbs.md) retain\nthe causal RED and final checks. Save22 and genuine progression are unchanged.\nRoot will archive and remove the exact scratch named above before final handoff;\nthe evidence cleanup receipt records its terminal disposition.\n';p.write_text(s)
counts=collections.Counter(row['behavior_verification'].split(';')[0] for row in original)
assert counts=={'unverified':146,'bounded-functional':65,'bounded-engine-functional':1,'review-needed':1},counts
(r/'inventory-credit-verification.json').write_text(json.dumps({'pass':True,'changedRows':['skills-druid-spirit-of-barbs'],'idsAndOrderPreserved':True,'counts':dict(counts)},indent=2))
print(json.dumps({'localEvidence':str(repo/'docs/plans/evidence/d05-spirit-of-barbs.md'),'counts':dict(counts)}))
