import { afterEach, beforeEach, expect, it } from 'vitest';
import { runBattleRecorded, type CombatSnapshot } from './combat';
import type { CombatUnit } from './types';
import type { SpiritOfBarbsProjection } from '../skills/spirit-of-barbs';
import { loadDefaultSkills, registerSkill, resetRegistry } from '../skills/registry';

const hold = { id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1 };
function unit(id: string, kind: CombatUnit['kind'] = 'hero'): CombatUnit {
  return { id, name: id, side: kind === 'monster' ? 'enemy' : 'player', kind,
    level: 30, tier: 'trash', life: 1000, mana: 100,
    stats: { life: 1000, lifeMax: 1000, mana: 100, manaMax: 100, attack: 100,
      defense: 100, magicResist: 0, attackSpeed: 100, critChance: 0, critDamage: 1.5,
      physDodge: 0, magicDodge: 0, magicFind: 0, goldFind: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } },
    statuses: [hold], skillOrder: [], activeBuffIds: [], cooldowns: {}, enraged: false };
}
function input(rank = 20): CombatSnapshot & { readonly spiritOfBarbs: SpiritOfBarbsProjection } {
  const enemy = unit('enemy', 'monster');
  return { seed: 7, playerTeam: [unit('hero'), unit('merc', 'merc'),
    { ...unit('owned', 'summon'), summon: true, summonOwnerId: 'hero', ownerId: 'hero' }],
    enemyTeam: [{ ...enemy, life: 1000000, stats: { ...enemy.stats, lifeMax: 1000000, defense: 0 },
      statuses: [], skillOrder: ['fixture.sweep'] }],
    spiritOfBarbs: { sourceHeroId: 'hero', fieldedMercCombatId: 'merc', rank } };
}
function record(snapshot: CombatSnapshot) {
  const before = structuredClone(snapshot), out = runBattleRecorded(snapshot);
  expect(snapshot).toEqual(before);
  expect(runBattleRecorded(snapshot)).toEqual(out);
  return out;
}
function damage(out: ReturnType<typeof record>, source: string, target: string, type = 'physical') {
  const event = out.events.find(e => e.kind === 'damage' && e.source === source && e.target === target && e.damageType === type);
  if (event?.kind !== 'damage') throw new Error(`Missing actual ${type} damage from ${source} to ${target}`);
  return event.amount;
}
beforeEach(() => {
  resetRegistry(); loadDefaultSkills();
  registerSkill({ id: 'fixture.sweep', archetype: 'fixture', trigger: 'active', target: 'all-enemies',
    minLevel: 1, cooldown: 60, manaCost: 0,
    effects: [{ kind: 'damage', damageType: 'physical', base: [300, 300] }] });
});
afterEach(() => { resetRegistry(); loadDefaultSkills(); });

it.each([1, 20])('rank%s real spirit supplies reflection and owned-summon Defense with no ordinary action', rank => {
  const out = record(input(rank));
  const spawns = out.events.filter(e => e.kind === 'summon' && e.summonId === 'spirit_of_barbs');
  expect(spawns).toHaveLength(1);
  const spawn = spawns[0];
  if (spawn?.kind !== 'summon') throw new Error('Missing real passive spirit');
  expect(spawn).toMatchObject({ owner: 'hero', simClockMs: 0,
    unit: { kind: 'summon', summon: true, summonOwnerId: 'hero', summonTemplateId: 'spirit_of_barbs',
      life: 80, stats: { lifeMax: 80, attack: 0, defense: 10 } } });
  expect(out.events.slice(0, 4).every(e => e.kind === 'status-state' && e.initial)).toBe(true);
  expect(damage(out, 'enemy', 'hero')).toBe(200);
  expect(damage(out, 'enemy', 'merc')).toBe(200);
  expect(damage(out, 'enemy', 'owned')).toBe(rank === 1 ? 198 : 160);
  expect(damage(out, 'hero', 'enemy', 'thorns')).toBe(rank === 1 ? 8 : 160);
  expect(damage(out, 'merc', 'enemy', 'thorns')).toBe(rank === 1 ? 8 : 160);
  expect(out.events.some(e => e.kind === 'action' && e.actor === spawn.unit.id)).toBe(false);
  expect(out.events.some(e => e.kind === 'action' && e.skillId === 'druid.spirit_of_barbs')).toBe(false);
  expect(out.result.playerTeam.find(u => u.id === 'owned')?.stats.defense).toBe(100);
  const death = out.events.findIndex(e => e.kind === 'death' && e.target === spawn.unit.id);
  expect(death).toBeGreaterThan(0);
  expect(out.events.slice(death + 1).some(e => e.kind === 'summon' && e.summonId === 'spirit_of_barbs')).toBe(false);
  const views = out.events.filter(e => e.kind === 'status-state' && e.target === 'hero');
  expect(views.some(e => e.kind === 'status-state' && e.statuses.some(s => s.id === 'spirit-of-barbs'))).toBe(true);
  expect(views.at(-1)).toMatchObject({ statuses: [] }); // later hero death clears presentation
});

it('adds to independent reflection without recursion and never refunds a passive spirit as another summon spell', () => {
  const snapshot = input();
  const hero = snapshot.playerTeam[0];
  if (!hero) throw new Error('Missing owner');
  const out = record({ ...snapshot, playerTeam: [
    { ...hero, physicalReflectionPct: 0.5, skillOrder: ['druid.raven'], skillLevels: { 'druid.raven': 1 } },
    ...snapshot.playerTeam.slice(1)
  ] });
  expect(damage(out, 'hero', 'enemy', 'thorns')).toBe(260);
  expect(out.events.some(e => e.kind === 'mana' && e.reason === 'refund')).toBe(false);
  expect(out.events.filter(e => e.kind === 'summon' && e.summonId === 'spirit_of_barbs')).toHaveLength(1);
});

it('does not create a spirit for an initially terminal wave or dead/foreign source', () => {
  const snapshot = input();
  for (const altered of [
    { ...snapshot, enemyTeam: [] },
    { ...snapshot, playerTeam: snapshot.playerTeam.map(u => u.id === 'hero' ? { ...u, life: 0 } : u) },
    { ...snapshot, spiritOfBarbs: { sourceHeroId: 'missing', rank: 20 } },
    { ...snapshot, spiritOfBarbs: { sourceHeroId: 'merc', rank: 20 } }
  ]) expect(record(altered).events.some(e => e.kind === 'summon' && e.summonId === 'spirit_of_barbs')).toBe(false);
});

it('preloaded matching bodies and passive markers do not authenticate a spirit aura', () => {
  const { spiritOfBarbs: _p, ...snapshot } = input();
  const out = record({ ...snapshot, playerTeam: [
    ...snapshot.playerTeam.map(u => ({ ...u, statuses: [...u.statuses, { ...hold, id: 'spirit-of-barbs' }] })),
    { ...unit('preloaded', 'summon'), summon: true, summonOwnerId: 'hero', summonTemplateId: 'spirit_of_barbs' }
  ] });
  expect(out.events.some(e => e.kind === 'damage' && e.damageType === 'thorns')).toBe(false);
  expect(damage(out, 'enemy', 'owned')).toBe(200);
});
