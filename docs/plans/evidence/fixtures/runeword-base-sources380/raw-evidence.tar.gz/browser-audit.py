"""Recheck retained diagnostic browser attachments; never executes gameplay."""
import base64, gzip, hashlib, json, re
from pathlib import Path
root = Path(__file__).resolve().parent
report = json.loads((root / 'browser-report.json').read_text())
rows = []

def walk(suite):
    for spec in suite.get('specs', []):
        match = re.search(r'(en|zh-CN) (360x640|1280x800)$', spec['title'])
        assert match
        content = {}
        for test in spec.get('tests', []):
            for result in test.get('results', []):
                assert result['status'] == 'passed' and result['retry'] == 0
                for attachment in result.get('attachments', []):
                    if attachment['contentType'] == 'application/json':
                        content[attachment['name']] = json.loads(base64.b64decode(attachment['body']))
        input_state = content['constructed-input-and-native-drop']
        source = input_state['acquisition']['item']
        crafted, refused, continued, removed = [content[name] for name in (
            'crafted-native-save', 'level40-equip-refused', 'equipped-native-continued', 'removed-native-save')]
        assert source['rarity'] == 'normal' and source['socketCapacity'] == 5
        assert source['baseId'] == 'items/base/wp2h-battle-scythe'
        expected = {**source, 'rarity': 'runeword', 'runewordId': 'runewords/obedience',
                    'socketContents': [{'kind': 'rune', 'id': 'runes/' + rune} for rune in ['hel', 'ko', 'thul', 'eth', 'fal']]}
        assert crafted['player']['level'] == 40 and crafted['inventory']['backpack'] == [expected]
        assert input_state['fixture']['inventory']['materials'] == {r['id']: 1 for r in expected['socketContents']}
        assert crafted['inventory']['materials'] == {} and crafted['inventory']['materialActionOrdinal'] == 5
        assert crafted['inventory'] == refused['inventory'] and crafted['player'] == refused['player']
        assert continued['player']['level'] == 41
        assert continued['inventory']['equipped']['weapon'] == {**expected, 'equipped': True}
        assert continued['player']['derivedStats']['attack'] == 385 + source['baseRolls']['attack']
        assert removed['inventory']['backpack'] == [expected] and removed['player']['derivedStats']['attack'] == 115
        for final in [continued, removed]:
            assert final['inventory']['materials'] == {} and final['inventory']['materialActionOrdinal'] == 5
            assert final['player']['derivedStats']['life'] == 13 and final['player']['derivedStats']['mana'] == 17
            for key in ['map', 'mercs', 'formation']:
                assert final[key] == crafted[key]
        rows.append({'case': '-'.join(match.groups()), 'pass': True})
    for child in suite.get('suites', []):
        walk(child)

for suite in report['suites']:
    walk(suite)
assert len(rows) == 4
repo = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
save = repo / 'docs/plans/evidence/fixtures/earned-tyrael-and-river-through379/retained-final.json.gz'
sha = hashlib.sha256(gzip.decompress(save.read_bytes())).hexdigest()
assert sha == 'b0972bad81133bba925939ed6c412307e2338df2e65795a2f6b48fa70735a64f'
print(json.dumps({'cases': rows, 'nativeExports': 16, 'earnedFinalUnchanged': sha}))
