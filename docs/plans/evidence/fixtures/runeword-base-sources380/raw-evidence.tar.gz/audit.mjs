import { createServer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/obedience-base380';
const prior=p=>JSON.parse(execFileSync('git',['show',`b596c88:${p}`],{cwd:repo,encoding:'utf8'}));
const current=async p=>JSON.parse(await readFile(`${repo}/${p}`,'utf8'));
const oldBases=prior('src/data/items/bases.json'),newBases=await current('src/data/items/bases.json');
for(const old of oldBases)assert.deepEqual(newBases.find(b=>b.id===old.id),old);
assert.deepEqual(newBases.filter(b=>!oldBases.some(o=>o.id===b.id)).map(b=>b.id),['items/base/wp2h-battle-scythe']);
assert.deepEqual(prior('src/data/items/runewords.json'),await current('src/data/items/runewords.json'));
const oldTables=prior('src/data/loot/treasure-classes.json'),newTables=await current('src/data/loot/treasure-classes.json');
const added=[];
assert.equal(oldTables.length,newTables.length);
for(const old of oldTables){const next=newTables.find(t=>t.id===old.id);assert(next);const {entries:a,...am}=old,{entries:b,...bm}=next;assert.deepEqual(am,bm);let offset=0;for(const pick of b){if(offset<a.length&&JSON.stringify(pick)===JSON.stringify(a[offset]))offset++;else added.push({table:old.id,pick});}assert.equal(offset,a.length);}
assert.equal(added.length,2);
const server=await createServer({root:repo,configFile:false,cacheDir:root+'/audit-vite-cache',server:{middlewareMode:true,hmr:false,ws:false},resolve:{alias:{'@':repo+'/src'}}});
try{
 const {loadItemBases,loadTreasureClasses}=await server.ssrLoadModule('/src/data/loaders/loot.ts');
 const {socketRunewords}=await server.ssrLoadModule('/src/data/loaders/socket-effects.ts');
 const {matchRuneword,recipeFromData}=await server.ssrLoadModule('/src/engine/loot/runeword.ts');
 const {resolveChallengeWavePlan}=await server.ssrLoadModule('/src/engine/combat/sub-area-run.ts');
 const {subAreas,monsters}=await server.ssrLoadModule('/src/data/index.ts');
 const {createRng}=await server.ssrLoadModule('/src/engine/rng.ts');
 const {rollDrops,pickTcBase}=await server.ssrLoadModule('/src/engine/loot/drop-roller.ts');
 const {rollItem}=await server.ssrLoadModule('/src/engine/loot/rollItem.ts');
 const tables=loadTreasureClasses(),bases=loadItemBases(),sources=new Map();let plans=0;
 for(const subArea of subAreas)for(let ordinal=0;ordinal<13;ordinal++){
  const plan=resolveChallengeWavePlan({subArea,fallbackArchetypeId:monsters[0].id,fallbackLevel:subArea.areaLevel,seed:0,challengeOrdinal:ordinal,mode:'manual'});plans++;
  for(const wave of plan.waves){const table=tables.get(wave.lootTable??plan.defaultLootTable);for(const spawn of wave.spawns)for(const pick of table?.picks??[]){if(pick.type!=='item'||pick.rarity!=='normal'||pick.weight<=0||!pick.baseId||spawn.level<pick.qlvlMin||spawn.level>pick.qlvlMax)continue;if(!sources.has(pick.baseId))sources.set(pick.baseId,{area:subArea.id,ordinal,wave:wave.id,table:table.id,monsterLevel:spawn.level,pick});}}
 }
 const words=socketRunewords.map(word=>({word:word.id,sockets:word.sockets,witnesses:[...bases.values()].filter(base=>(base.maxSockets??0)>=word.sockets&&matchRuneword({baseType:base.type,slot:base.slot,weaponType:base.weaponType,sockets:word.sockets,runes:word.runes,isWhiteBase:true},[recipeFromData(word)])===word.id).map(base=>({base:base.id,baseRequiredLevel:base.reqLevel,wordRequiredLevel:word.reqLevel,equipLevel:Math.max(base.reqLevel,word.reqLevel),maxSockets:base.maxSockets,normalSource:sources.get(base.id)??null}))}));
 assert.equal(words.length,35);assert(words.every(w=>w.witnesses.some(b=>b.normalSource)));
 const samples=[];
 for(const [id,tableId,low,high] of [['items/base/wp2h-battle-scythe','loot/trash-act4',41,81],['items/base/wp2h-thunder-maul','loot/trash-act5',62,102]]){
  const tc=tables.get(tableId),pick=tc.picks.find(p=>p.baseId===id&&p.rarity==='normal');assert(pick);assert.equal(pickTcBase({id:tc.id,picks:[pick]},low-1,createRng(1)),undefined);assert.equal(pickTcBase({id:tc.id,picks:[pick]},high+1,createRng(1)),undefined);
  for(const level of [low,high]){const capacityCounts={},seeds=4096;let acquired=0,equipment=0;for(let seed=1;seed<=seeds;seed++){const rng=createRng(seed);for(const drop of rollDrops({tc,tier:'trash',monsterLevel:level,magicFind:0},rng)){if(drop.kind!=='item')continue;equipment++;if(drop.baseId!==id)continue;const item=rollItem(drop,{bases,affixes:[]},rng);assert(item);assert.equal(item.rarity,'normal');assert.equal(item.runewordId,undefined);acquired++;capacityCounts[item.socketCapacity]=(capacityCounts[item.socketCapacity]??0)+1;}}
  assert.equal(Object.keys(capacityCounts).length,bases.get(id).maxSockets+1);
  const eligible=tc.picks.filter(p=>p.weight>0&&level>=p.qlvlMin&&level<=p.qlvlMax);const total=eligible.reduce((a,p)=>a+p.weight,0);
  samples.push({base:id,table:tableId,level,seeds,equipment,acquired,capacityCounts,eligibleWeightTotal:total,addedPickWeight:pick.weight,selectionShare:pick.weight/total,existingPickProbabilityMultiplier:(total-pick.weight)/total});}
 }
 const files=['src/data/items/bases.json','src/data/loot/treasure-classes.json','src/data/items/runewords.json','src/i18n/locales/en/items.json','src/i18n/locales/zh-CN/items.json'];const hashes={};for(const path of files)hashes[path]=createHash('sha256').update(await readFile(`${repo}/${path}`)).digest('hex');
 const report={kind:'root self-audit; native diagnostic acquisition, no earned fight/material spending or campaign acceptance',baseline:'b596c88',baseCount:bases.size,unchangedHistoricalBases:oldBases.length,unchangedRecipes:35,added,plans,areas:subAreas.length,all35HaveReachableNormalSource:true,words,samples,hashes};
 await writeFile(root+'/catalog-and-acquisition-audit.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 process.stdout.write(JSON.stringify({bases:bases.size,recipes:words.length,plans,all35:true,samples})+'\n');
}finally{await server.close();}
