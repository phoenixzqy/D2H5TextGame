# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: runeword-bases.spec.ts >> Obedience ordered crafting equip and Continue en 360x640
- Location: tests/pwa/runeword-bases.spec.ts:62:3

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.click: Test timeout of 120000ms exceeded.
Call log:
  - waiting for locator('a[href="/settings"]').first()
    - locator resolved to <a href="/settings" class="flex flex-col items-center justify-center gap-1 min-h-[56px] md:min-h-[64px] px-1 py-2 text-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-d2-gold text-d2-white/70 hover:text-d2-gold hover:bg-black/20">…</a>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button data-testid="inv-discard-action" class="px-6 py-3 rounded font-serif font-bold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed bg-red-900 text-d2-white border-2 border-red-700 hover:bg-red-800 active:scale-95 min-h-[44px] flex-1">Discard</button> from <div class="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">…</div> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <button data-testid="inv-discard-action" class="px-6 py-3 rounded font-serif font-bold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed bg-red-900 text-d2-white border-2 border-red-700 hover:bg-red-800 active:scale-95 min-h-[44px] flex-1">Discard</button> from <div class="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">…</div> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    207 × waiting for element to be visible, enabled and stable
        - element is visible, enabled and stable
        - scrolling into view if needed
        - done scrolling
        - <button data-testid="inv-discard-action" class="px-6 py-3 rounded font-serif font-bold transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed bg-red-900 text-d2-white border-2 border-red-700 hover:bg-red-800 active:scale-95 min-h-[44px] flex-1">Discard</button> from <div class="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">…</div> subtree intercepts pointer events
      - retrying click action
        - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "Main navigation" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "Town" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: Town
      - listitem [ref=e10]:
        - link "Map" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: Map
      - listitem [ref=e14]:
        - link "Combat" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: Combat
      - listitem [ref=e18]:
        - link "Inventory" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: Inventory
      - listitem [ref=e22]:
        - link "Skills" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: Skills
      - listitem [ref=e26]:
        - link "Mercs" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: Mercs
      - listitem [ref=e30]:
        - link "Quests" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: Quests
      - listitem [ref=e34]:
        - link "Settings" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: Settings
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e40]: Inventory
      - button "Obedience QA · Level 40. Open character sheet." [ref=e42] [cursor=pointer]:
        - generic [ref=e44]: "40"
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: Obedience QA
            - generic [ref=e48]: Level 40
          - generic [ref=e49]:
            - generic [ref=e50]: HP
            - progressbar "HP" [ref=e51]
          - generic [ref=e53]:
            - generic [ref=e54]: MP
            - progressbar "MP" [ref=e55]
          - generic [ref=e57]:
            - generic [ref=e58]: XP
            - progressbar "XP" [ref=e59]
    - main [ref=e60]:
      - generic [ref=e61]:
        - region "Materials" [ref=e62]:
          - generic [ref=e63]:
            - heading "Materials" [level=2] [ref=e64]
            - paragraph [ref=e65]: Materials do not use equipment slots. Rune-shards and gem-shards are separate currencies.
            - group "Materials" [ref=e66]:
              - button "Owned materials" [pressed] [ref=e67] [cursor=pointer]
              - button "All materials" [ref=e68] [cursor=pointer]
            - paragraph [ref=e69]: No materials yet. Win battles and claim eligible quest rewards to collect runes and gems.
            - paragraph [ref=e70]: Preview crafting and socket actions below before spending materials.
        - region "Crafting & sockets" [ref=e71]:
          - generic [ref=e72]:
            - heading "Crafting & sockets" [level=2] [ref=e73]
            - paragraph [ref=e74]: "Rune fusion uses your highest unlocked act and selected difficulty: Act I–V caps are rune 8 / 15 / 19 / 21 / 33, with a maximum of 22 outside Hell. Gem fusion can exceed the gem drop cap."
            - generic [ref=e75]:
              - generic [ref=e76]:
                - generic [ref=e77]: Action
                - combobox "Action" [ref=e78]:
                  - option "Fuse runes" [selected]
                  - option "Fuse gems"
                  - option "Dismantle gems"
                  - option "Insert a rune or gem"
                  - option "Roll armor sockets"
                  - option "Clear sockets"
                  - option "Craft a caster amulet"
                  - option "Salvage equipment"
                  - option "Recover preserved v18 gear"
              - generic [ref=e79]:
                - generic [ref=e80]: Recipe
                - combobox "Recipe" [ref=e81]:
                  - option "Rune fusion · El → Eld" [selected]
                  - option "Rune fusion · Eld → Tir"
                  - option "Rune fusion · Tir → Nef"
                  - option "Rune fusion · Nef → Eth"
                  - option "Rune fusion · Eth → Ith"
                  - option "Rune fusion · Ith → Tal"
                  - option "Rune fusion · Tal → Ral"
                  - option "Rune fusion · Ral → Ort"
                  - option "Rune fusion · Ort → Thul"
                  - option "Rune fusion · Thul → Amn"
                  - option "Rune fusion · Amn → Sol"
                  - option "Rune fusion · Sol → Shael"
                  - option "Rune fusion · Shael → Dol"
                  - option "Rune fusion · Dol → Hel"
                  - option "Rune fusion · Hel → Io"
                  - option "Rune fusion · Io → Lum"
                  - option "Rune fusion · Lum → Ko"
                  - option "Rune fusion · Ko → Fal"
                  - option "Rune fusion · Fal → Lem"
                  - option "Rune fusion · Lem → Pul"
                  - option "Rune fusion · Pul → Um"
                  - option "Rune fusion · Um → Mal"
                  - option "Rune fusion · Mal → Ist"
                  - option "Rune fusion · Ist → Gul"
                  - option "Rune fusion · Gul → Vex"
                  - option "Rune fusion · Vex → Ohm"
                  - option "Rune fusion · Ohm → Lo"
                  - option "Rune fusion · Lo → Sur"
                  - option "Rune fusion · Sur → Ber"
                  - option "Rune fusion · Ber → Jah"
                  - option "Rune fusion · Jah → Cham"
                  - option "Rune fusion · Cham → Zod"
              - paragraph [ref=e82]: Exchange three identical runes for the next rune. The output must be unlocked.
              - generic [ref=e83]:
                - paragraph [ref=e84]: Costs
                - list [ref=e85]:
                  - listitem [ref=e86]: "El × 3 · Owned: 0"
              - button "Preview action" [ref=e87] [cursor=pointer]
        - generic [ref=e88]:
          - heading "Quest items" [level=2] [ref=e89]
          - paragraph [ref=e90]: Bound to this character. Does not use backpack or stash space.
          - paragraph [ref=e91]: No quest items yet.
          - status
        - generic [ref=e92]:
          - tablist [ref=e93]:
            - tab "Backpack (1/100)" [selected] [ref=e94] [cursor=pointer]
            - tab "Stash (0/500)" [ref=e95] [cursor=pointer]
            - tab "Equipment" [ref=e96] [cursor=pointer]
          - tabpanel "Backpack (1/100)" [ref=e97]:
            - generic [ref=e98]:
              - generic [ref=e99]:
                - button "Discard all Normal(0)" [disabled] [ref=e100]:
                  - text: Discard all Normal
                  - generic [ref=e101]: (0)
                - button "Discard all Magic(0)" [disabled] [ref=e102]:
                  - text: Discard all Magic
                  - generic [ref=e103]: (0)
                - button "Discard all Rare(0)" [disabled] [ref=e104]:
                  - text: Discard all Rare
                  - generic [ref=e105]: (0)
                - button "Discard all below equipped tier(0)" [disabled] [ref=e106]:
                  - text: Discard all below equipped tier
                  - generic [ref=e107]: (0)
              - generic [ref=e108]:
                - listbox "Items" [ref=e110]:
                  - listitem [ref=e111]:
                    - button "Battle Scythe · item" [pressed] [ref=e114] [cursor=pointer]:
                      - img "Battle Scythe" [ref=e116]
                      - generic: ⚔️
                  - listitem [ref=e117]:
                    - generic "Empty slot" [ref=e118]
                  - listitem [ref=e119]:
                    - generic "Empty slot" [ref=e120]
                  - listitem [ref=e121]:
                    - generic "Empty slot" [ref=e122]
                  - listitem [ref=e123]:
                    - generic "Empty slot" [ref=e124]
                  - listitem [ref=e125]:
                    - generic "Empty slot" [ref=e126]
                  - listitem [ref=e127]:
                    - generic "Empty slot" [ref=e128]
                  - listitem [ref=e129]:
                    - generic "Empty slot" [ref=e130]
                  - listitem [ref=e131]:
                    - generic "Empty slot" [ref=e132]
                  - listitem [ref=e133]:
                    - generic "Empty slot" [ref=e134]
                  - listitem [ref=e135]:
                    - generic "Empty slot" [ref=e136]
                  - listitem [ref=e137]:
                    - generic "Empty slot" [ref=e138]
                  - listitem [ref=e139]:
                    - generic "Empty slot" [ref=e140]
                  - listitem [ref=e141]:
                    - generic "Empty slot" [ref=e142]
                  - listitem [ref=e143]:
                    - generic "Empty slot" [ref=e144]
                  - listitem [ref=e145]:
                    - generic "Empty slot" [ref=e146]
                  - listitem [ref=e147]:
                    - generic "Empty slot" [ref=e148]
                  - listitem [ref=e149]:
                    - generic "Empty slot" [ref=e150]
                  - listitem [ref=e151]:
                    - generic "Empty slot" [ref=e152]
                  - listitem [ref=e153]:
                    - generic "Empty slot" [ref=e154]
                  - listitem [ref=e155]:
                    - generic "Empty slot" [ref=e156]
                  - listitem [ref=e157]:
                    - generic "Empty slot" [ref=e158]
                  - listitem [ref=e159]:
                    - generic "Empty slot" [ref=e160]
                  - listitem [ref=e161]:
                    - generic "Empty slot" [ref=e162]
                  - listitem [ref=e163]:
                    - generic "Empty slot" [ref=e164]
                  - listitem [ref=e165]:
                    - generic "Empty slot" [ref=e166]
                  - listitem [ref=e167]:
                    - generic "Empty slot" [ref=e168]
                  - listitem [ref=e169]:
                    - generic "Empty slot" [ref=e170]
                  - listitem [ref=e171]:
                    - generic "Empty slot" [ref=e172]
                  - listitem [ref=e173]:
                    - generic "Empty slot" [ref=e174]
                  - listitem [ref=e175]:
                    - generic "Empty slot" [ref=e176]
                  - listitem [ref=e177]:
                    - generic "Empty slot" [ref=e178]
                  - listitem [ref=e179]:
                    - generic "Empty slot" [ref=e180]
                  - listitem [ref=e181]:
                    - generic "Empty slot" [ref=e182]
                  - listitem [ref=e183]:
                    - generic "Empty slot" [ref=e184]
                  - listitem [ref=e185]:
                    - generic "Empty slot" [ref=e186]
                  - listitem [ref=e187]:
                    - generic "Empty slot" [ref=e188]
                  - listitem [ref=e189]:
                    - generic "Empty slot" [ref=e190]
                  - listitem [ref=e191]:
                    - generic "Empty slot" [ref=e192]
                  - listitem [ref=e193]:
                    - generic "Empty slot" [ref=e194]
                  - listitem [ref=e195]:
                    - generic "Empty slot" [ref=e196]
                  - listitem [ref=e197]:
                    - generic "Empty slot" [ref=e198]
                  - listitem [ref=e199]:
                    - generic "Empty slot" [ref=e200]
                  - listitem [ref=e201]:
                    - generic "Empty slot" [ref=e202]
                  - listitem [ref=e203]:
                    - generic "Empty slot" [ref=e204]
                  - listitem [ref=e205]:
                    - generic "Empty slot" [ref=e206]
                  - listitem [ref=e207]:
                    - generic "Empty slot" [ref=e208]
                  - listitem [ref=e209]:
                    - generic "Empty slot" [ref=e210]
                  - listitem [ref=e211]:
                    - generic "Empty slot" [ref=e212]
                  - listitem [ref=e213]:
                    - generic "Empty slot" [ref=e214]
                  - listitem [ref=e215]:
                    - generic "Empty slot" [ref=e216]
                  - listitem [ref=e217]:
                    - generic "Empty slot" [ref=e218]
                  - listitem [ref=e219]:
                    - generic "Empty slot" [ref=e220]
                  - listitem [ref=e221]:
                    - generic "Empty slot" [ref=e222]
                  - listitem [ref=e223]:
                    - generic "Empty slot" [ref=e224]
                  - listitem [ref=e225]:
                    - generic "Empty slot" [ref=e226]
                  - listitem [ref=e227]:
                    - generic "Empty slot" [ref=e228]
                  - listitem [ref=e229]:
                    - generic "Empty slot" [ref=e230]
                  - listitem [ref=e231]:
                    - generic "Empty slot" [ref=e232]
                  - listitem [ref=e233]:
                    - generic "Empty slot" [ref=e234]
                  - listitem [ref=e235]:
                    - generic "Empty slot" [ref=e236]
                  - listitem [ref=e237]:
                    - generic "Empty slot" [ref=e238]
                  - listitem [ref=e239]:
                    - generic "Empty slot" [ref=e240]
                  - listitem [ref=e241]:
                    - generic "Empty slot" [ref=e242]
                  - listitem [ref=e243]:
                    - generic "Empty slot" [ref=e244]
                  - listitem [ref=e245]:
                    - generic "Empty slot" [ref=e246]
                  - listitem [ref=e247]:
                    - generic "Empty slot" [ref=e248]
                  - listitem [ref=e249]:
                    - generic "Empty slot" [ref=e250]
                  - listitem [ref=e251]:
                    - generic "Empty slot" [ref=e252]
                  - listitem [ref=e253]:
                    - generic "Empty slot" [ref=e254]
                  - listitem [ref=e255]:
                    - generic "Empty slot" [ref=e256]
                  - listitem [ref=e257]:
                    - generic "Empty slot" [ref=e258]
                  - listitem [ref=e259]:
                    - generic "Empty slot" [ref=e260]
                  - listitem [ref=e261]:
                    - generic "Empty slot" [ref=e262]
                  - listitem [ref=e263]:
                    - generic "Empty slot" [ref=e264]
                  - listitem [ref=e265]:
                    - generic "Empty slot" [ref=e266]
                  - listitem [ref=e267]:
                    - generic "Empty slot" [ref=e268]
                  - listitem [ref=e269]:
                    - generic "Empty slot" [ref=e270]
                  - listitem [ref=e271]:
                    - generic "Empty slot" [ref=e272]
                  - listitem [ref=e273]:
                    - generic "Empty slot" [ref=e274]
                  - listitem [ref=e275]:
                    - generic "Empty slot" [ref=e276]
                  - listitem [ref=e277]:
                    - generic "Empty slot" [ref=e278]
                  - listitem [ref=e279]:
                    - generic "Empty slot" [ref=e280]
                  - listitem [ref=e281]:
                    - generic "Empty slot" [ref=e282]
                  - listitem [ref=e283]:
                    - generic "Empty slot" [ref=e284]
                  - listitem [ref=e285]:
                    - generic "Empty slot" [ref=e286]
                  - listitem [ref=e287]:
                    - generic "Empty slot" [ref=e288]
                  - listitem [ref=e289]:
                    - generic "Empty slot" [ref=e290]
                  - listitem [ref=e291]:
                    - generic "Empty slot" [ref=e292]
                  - listitem [ref=e293]:
                    - generic "Empty slot" [ref=e294]
                  - listitem [ref=e295]:
                    - generic "Empty slot" [ref=e296]
                  - listitem [ref=e297]:
                    - generic "Empty slot" [ref=e298]
                  - listitem [ref=e299]:
                    - generic "Empty slot" [ref=e300]
                  - listitem [ref=e301]:
                    - generic "Empty slot" [ref=e302]
                  - listitem [ref=e303]:
                    - generic "Empty slot" [ref=e304]
                  - listitem [ref=e305]:
                    - generic "Empty slot" [ref=e306]
                  - listitem [ref=e307]:
                    - generic "Empty slot" [ref=e308]
                  - listitem [ref=e309]:
                    - generic "Empty slot" [ref=e310]
                  - listitem [ref=e311]:
                    - generic "Empty slot" [ref=e312]
                  - listitem [ref=e313]:
                    - generic "Empty slot" [ref=e314]
                - dialog [ref=e317]:
                  - generic [ref=e318]:
                    - generic [ref=e319]:
                      - img "Battle Scythe" [ref=e321]
                      - generic [ref=e322]:
                        - generic [ref=e323]: Battle Scythe
                        - generic [ref=e324]: Weapon · Weapon · iLvl 42
                      - button "Close" [ref=e325] [cursor=pointer]: ×
                    - generic [ref=e326]:
                      - heading "Required" [level=3] [ref=e327]
                      - list [ref=e328]:
                        - listitem [ref=e329]: Lvl 41
                    - generic [ref=e330]:
                      - heading "Base Stats" [level=3] [ref=e331]
                      - list [ref=e332]:
                        - listitem [ref=e333]: Damage 52–52
                    - generic [ref=e334]:
                      - heading "Sockets" [level=3] [ref=e335]
                      - generic [ref=e336]:
                        - generic [ref=e337]: "[Hel]"
                        - generic [ref=e338]: "[Ko]"
                        - generic [ref=e339]: "[Thul]"
                        - generic [ref=e340]: "[Eth]"
                        - generic [ref=e341]: "[Fal]"
                    - generic [ref=e342]:
                      - heading "Special Stats" [level=3] [ref=e343]
                      - list [ref=e344]:
                        - listitem [ref=e345]: +5 Strength
                        - listitem [ref=e346]: +5 Dexterity
                        - listitem [ref=e347]: +10 Dexterity
                        - listitem [ref=e348]: +10 Cold Resist
                        - listitem [ref=e349]: +18 Attack
                        - listitem [ref=e350]: +40 Attack
                        - listitem [ref=e351]: +10 Strength
                        - listitem [ref=e352]: +10 Strength
                        - listitem [ref=e353]: +10 Dexterity
                        - listitem [ref=e354]: +30 Fire Resist
                        - listitem [ref=e355]: +30 Cold Resist
                        - listitem [ref=e356]: +30 Lightning Resist
                        - listitem [ref=e357]: +30 Poison Resist
                        - listitem [ref=e358]: +30 Arcane Resist
                        - listitem [ref=e359]: +200 Attack
                    - generic [ref=e360]:
                      - button "Equip" [active] [ref=e361] [cursor=pointer]
                      - button "Transfer" [ref=e362] [cursor=pointer]
                      - button "Discard" [ref=e363] [cursor=pointer]
```

# Test source

```ts
  1   | /**
  2   |  * Shared E2E helpers — character creation, storage cleanup, navigation.
  3   |  *
  4   |  * All helpers assume `baseURL` from `playwright.config.ts`. They never use
  5   |  * wall-clock waits unless absolutely necessary.
  6   |  */
  7   | import type { Page, Locator } from '@playwright/test';
  8   | import { expect } from '@playwright/test';
  9   | 
  10  | export type CharacterClass =
  11  |   | 'barbarian'
  12  |   | 'sorceress'
  13  |   | 'necromancer'
  14  |   | 'paladin'
  15  |   | 'amazon'
  16  |   | 'druid'
  17  |   | 'assassin';
  18  | 
  19  | /**
  20  |  * Wipe localStorage + IndexedDB save so each test gets a virgin state.
  21  |  * Safe to call before any `page.goto`.
  22  |  */
  23  | export async function clearGameStorage(page: Page): Promise<void> {
  24  |   // Load a static same-origin page first so the app/Dexie connection is not open
  25  |   // while IndexedDB is deleted.
  26  |   await page.goto('/e2e-reset.html');
  27  |   await page.evaluate(async () => {
  28  |     try {
  29  |       localStorage.clear();
  30  |     } catch {
  31  |       /* ignore */
  32  |     }
  33  |     try {
  34  |       sessionStorage.clear();
  35  |     } catch {
  36  |       /* ignore */
  37  |     }
  38  |     if (typeof indexedDB !== 'undefined') {
  39  |       const deleteDb = (name: string) =>
  40  |         new Promise<void>((resolve) => {
  41  |           const req = indexedDB.deleteDatabase(name);
  42  |           const done = () => { resolve(); };
  43  |           req.onsuccess = done;
  44  |           req.onerror = done;
  45  |           req.onblocked = done;
  46  |           setTimeout(done, 1_000);
  47  |         });
  48  |       await Promise.all([deleteDb('D2H5TextGame'), deleteDb('d2h5-game')]);
  49  |     }
  50  |   });
  51  |   await page.goto('/');
  52  |   await expect(page.getByTestId('home-screen')).toBeVisible({ timeout: 10_000 });
  53  | }
  54  | 
  55  | /**
  56  |  * Create a character end-to-end and land in the Town screen.
  57  |  * Throws via Playwright if any expected element is missing.
  58  |  */
  59  | export async function createCharacter(
  60  |   page: Page,
  61  |   opts: { class: CharacterClass; name: string }
  62  | ): Promise<void> {
  63  |   await expect(page.getByTestId('home-screen')).toBeVisible({ timeout: 10000 });
  64  |   await page.getByTestId('home-new-game').click();
  65  |   await expect(page.getByTestId('character-create')).toBeVisible();
  66  |   await page.getByTestId(`class-${opts.class}`).click();
  67  |   await page.getByTestId('character-name-input').fill(opts.name);
  68  |   await page.getByTestId('character-start-btn').click();
  69  |   await expect(page.getByTestId('town-screen')).toBeVisible({ timeout: 10000 });
  70  | }
  71  | 
  72  | /**
  73  |  * Click a bottom-nav link by route segment ('town' | 'map' | …).
  74  |  * Resilient to locale because it uses the href instead of aria-name.
  75  |  */
  76  | export async function navTo(page: Page, route: string): Promise<void> {
  77  |   const link = page.locator(`a[href="/${route}"]`).first();
> 78  |   await link.click();
      |              ^ Error: locator.click: Test timeout of 120000ms exceeded.
  79  | }
  80  | 
  81  | /** Return to town from combat, regardless of whether the run is mid-fight or resolved. */
  82  | export async function returnToTownFromCombat(page: Page): Promise<void> {
  83  |   const postRunTown = page.getByTestId('return-to-town');
  84  |   if (await postRunTown.isVisible({ timeout: 500 }).catch(() => false)) {
  85  |     await postRunTown.click();
  86  |   } else {
  87  |     await page.getByRole('button', { name: /逃跑|Flee/i }).click();
  88  |   }
  89  | 
  90  |   if (!(await page.getByTestId('town-screen').isVisible({ timeout: 1_000 }).catch(() => false))) {
  91  |     await page.evaluate(() => {
  92  |       window.__GAME__?.combat.getState().endCombat();
  93  |     }).catch(() => undefined);
  94  |     await page.goto('/town');
  95  |   }
  96  | 
  97  |   await expect
  98  |     .poll(
  99  |       async () => {
  100 |         if (await page.getByTestId('town-screen').isVisible().catch(() => false)) return true;
  101 |         const continueButton = page.getByTestId('home-continue');
  102 |         if (await continueButton.isVisible().catch(() => false)) {
  103 |           await continueButton.click().catch(() => undefined);
  104 |         }
  105 |         return page.getByTestId('town-screen').isVisible().catch(() => false);
  106 |       },
  107 |       { timeout: 10_000, intervals: [250, 500, 1_000] }
  108 |     )
  109 |     .toBe(true);
  110 | }
  111 | 
  112 | /**
  113 |  * Wait for the combat screen to resolve. The current engine resolves the
  114 |  * entire battle synchronously on mount, so the "wins!" / "draw" log line
  115 |  * appears almost immediately. We give it up to `timeoutMs` anyway.
  116 |  *
  117 |  * Returns `{ playerWon, lootItems }` describing the outcome.
  118 |  * Throws if neither a victory nor a draw is detected within the budget.
  119 |  */
  120 | export async function waitForBattleResolution(
  121 |   page: Page,
  122 |   timeoutMs = 30_000
  123 | ): Promise<{ playerWon: boolean; lootItems: Locator | null }> {
  124 |   await expect(page.getByTestId('combat-screen')).toBeVisible({ timeout: 10_000 });
  125 | 
  126 |   // Auto-mode is engine-driven; toggle on if not already, defensively.
  127 |   const autoCheckbox = page.locator('input[type="checkbox"]').first();
  128 |   if (await autoCheckbox.count()) {
  129 |     const checked = await autoCheckbox.isChecked().catch(() => false);
  130 |     if (!checked) {
  131 |       await autoCheckbox.check().catch(() => undefined);
  132 |     }
  133 |   }
  134 | 
  135 |   await expect
  136 |     .poll(
  137 |       async () => {
  138 |         const victoryVisible = await page.getByTestId('victory-panel').isVisible().catch(() => false);
  139 |         const defeatVisible = await page.getByTestId('defeat-panel').isVisible().catch(() => false);
  140 |         const logText = (await page.getByTestId('combat-log').textContent().catch(() => '')) ?? '';
  141 |         return victoryVisible || defeatVisible || /wins|draw|victory|defeat|胜利|失败|倒下/i.test(logText);
  142 |       },
  143 |       { timeout: timeoutMs, intervals: [250, 500, 1_000] }
  144 |     )
  145 |     .toBe(true);
  146 | 
  147 |   const log = page.getByTestId('combat-log');
  148 |   const logText = (await log.textContent()) ?? '';
  149 |   const victoryVisible = await page.getByTestId('victory-panel').isVisible().catch(() => false);
  150 |   const playerWon = victoryVisible || /player side wins|victory|胜利/i.test(logText);
  151 | 
  152 |   // If the player won, the loot-summary panel appears (when any reward rolls).
  153 |   const summary = page.getByTestId('loot-summary');
  154 |   const summaryVisible = await summary.isVisible().catch(() => false);
  155 |   if (summaryVisible) {
  156 |     const items = page.getByTestId('loot-items');
  157 |     return {
  158 |       playerWon,
  159 |       lootItems: (await items.count()) > 0 ? items : null,
  160 |     };
  161 |   }
  162 |   return { playerWon, lootItems: null };
  163 | }
  164 | 
  165 | /** Returns the bounding box of a locator, or null if not present. */
  166 | export async function bbox(loc: Locator): Promise<{
  167 |   x: number;
  168 |   y: number;
  169 |   width: number;
  170 |   height: number;
  171 | } | null> {
  172 |   return loc.boundingBox();
  173 | }
  174 | 
  175 | /** True if two axis-aligned rects intersect. */
  176 | export function rectsIntersect(
  177 |   a: { x: number; y: number; width: number; height: number },
  178 |   b: { x: number; y: number; width: number; height: number }
```