# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: runeword-bases.spec.ts >> Obedience ordered crafting equip and Continue zh-CN 360x640
- Location: tests/pwa/runeword-bases.spec.ts:62:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByTestId('crafting-output-item')
Expected substring: "符文之语：遵从"
Received string:    "结果物品 · #it-665q-4战斗镰刀武器 · 武器槽伤害: 52–52物品等级 42 · 插槽 ×5需求等级 41+5 力量+5 敏捷+10 敏捷+10 冰冷抗性+18 攻击+40 攻击+10 力量+10 力量+10 敏捷+30 火焰抗性+30 冰冷抗性+30 闪电抗性+30 毒素抗性+30 奥术抗性+200 攻击镶嵌孔数：5镶嵌顺序海尔符文寇符文瑟尔符文依夫符文法尔符文符文之语：服从"
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByTestId('crafting-output-item')
    9 × locator resolved to <div class="space-y-2" data-testid="crafting-output-item">…</div>
      - unexpected value "结果物品 · #it-665q-4战斗镰刀武器 · 武器槽伤害: 52–52物品等级 42 · 插槽 ×5需求等级 41+5 力量+5 敏捷+10 敏捷+10 冰冷抗性+18 攻击+40 攻击+10 力量+10 力量+10 敏捷+30 火焰抗性+30 冰冷抗性+30 闪电抗性+30 毒素抗性+30 奥术抗性+200 攻击镶嵌孔数：5镶嵌顺序海尔符文寇符文瑟尔符文依夫符文法尔符文符文之语：服从"

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "主导航" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "营地" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: 营地
      - listitem [ref=e10]:
        - link "地图" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: 地图
      - listitem [ref=e14]:
        - link "战斗" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: 战斗
      - listitem [ref=e18]:
        - link "背包" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: 背包
      - listitem [ref=e22]:
        - link "技能" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: 技能
      - listitem [ref=e26]:
        - link "佣兵" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: 佣兵
      - listitem [ref=e30]:
        - link "任务" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: 任务
      - listitem [ref=e34]:
        - link "设置" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: 设置
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e40]: 背包
      - button "Obedience QA · 等级 40。点击查看角色面板。" [ref=e42] [cursor=pointer]:
        - generic [ref=e44]: "40"
        - generic [ref=e45]:
          - generic [ref=e46]:
            - generic [ref=e47]: Obedience QA
            - generic [ref=e48]: 等级 40
          - generic [ref=e49]:
            - generic [ref=e50]: HP
            - progressbar "HP" [ref=e51]
          - generic [ref=e53]:
            - generic [ref=e54]: MP
            - progressbar "MP" [ref=e55]
          - generic [ref=e57]:
            - generic [ref=e58]: XP
            - progressbar "XP" [ref=e59]
    - main [ref=e60]:
      - generic [ref=e61]:
        - region "材料" [ref=e62]:
          - generic [ref=e63]:
            - heading "材料" [level=2] [ref=e64]
            - paragraph [ref=e65]: 材料不占装备栏位。符文碎片与宝石碎片是独立货币。
            - group "材料" [ref=e66]:
              - button "已持有材料" [pressed] [ref=e67] [cursor=pointer]
              - button "全部材料" [ref=e68] [cursor=pointer]
            - generic [ref=e70]:
              - heading "符文" [level=3] [ref=e71]
              - generic [ref=e72]:
                - generic [ref=e73]:
                  - term [ref=e74]: 获取途径
                  - definition [ref=e75]: 战斗胜利掉落及部分任务奖励。
                - generic [ref=e76]:
                  - term [ref=e77]: 用途
                  - definition [ref=e78]: 镶嵌、符文之语、符文合成与配方制作。
              - list [ref=e79]:
                - listitem [ref=e80]:
                  - generic [ref=e81]: 法尔符文
                  - generic [ref=e82]: 持有：1
            - paragraph [ref=e83]: 可在下方预览制作与镶嵌操作，再确认消耗材料。
        - region "制作与镶嵌" [ref=e84]:
          - generic [ref=e85]:
            - heading "制作与镶嵌" [level=2] [ref=e86]
            - paragraph [ref=e87]: 符文合成取决于最高已解锁章节与当前所选难度：第一至五幕上限分别为第 8 / 15 / 19 / 21 / 33 号符文，非地狱难度最高为第 22 号。宝石合成可以超过宝石掉落品质上限。
            - generic [ref=e88]:
              - generic [ref=e89]:
                - generic [ref=e90]: 操作
                - combobox "操作" [ref=e91]:
                  - option "合成符文"
                  - option "合成宝石"
                  - option "分解宝石"
                  - option "镶嵌符文或宝石" [selected]
                  - option "重置护甲孔数"
                  - option "清空镶嵌孔"
                  - option "制作施法者项链"
                  - option "分解装备"
                  - option "恢复保留的 v18 装备"
              - paragraph [ref=e92]: 选择背包中一件未装备且有空孔的武器或护甲，材料按顺序填入下一个孔。符文顺序、底材、部位与孔数必须完全匹配才能形成符文之语，其他组合保留普通镶嵌效果。
              - generic [ref=e93]:
                - generic [ref=e94]: 镶嵌材料
                - combobox "镶嵌材料" [ref=e95]:
                  - option "艾尔符文 · 持有：0"
                  - option "艾尔德符文 · 持有：0"
                  - option "泰尔符文 · 持有：0"
                  - option "奈夫符文 · 持有：0"
                  - option "依夫符文 · 持有：0"
                  - option "伊司符文 · 持有：0"
                  - option "塔尔符文 · 持有：0"
                  - option "莱尔符文 · 持有：0"
                  - option "欧特符文 · 持有：0"
                  - option "瑟尔符文 · 持有：0"
                  - option "安姆符文 · 持有：0"
                  - option "索尔符文 · 持有：0"
                  - option "夏尔符文 · 持有：0"
                  - option "多尔符文 · 持有：0"
                  - option "海尔符文 · 持有：0"
                  - option "尤符文 · 持有：0"
                  - option "卢姆符文 · 持有：0"
                  - option "寇符文 · 持有：0"
                  - option "法尔符文 · 持有：1" [selected]
                  - option "莱姆符文 · 持有：0"
                  - option "普尔符文 · 持有：0"
                  - option "乌姆符文 · 持有：0"
                  - option "马尔符文 · 持有：0"
                  - option "伊斯特符文 · 持有：0"
                  - option "古尔符文 · 持有：0"
                  - option "维克斯符文 · 持有：0"
                  - option "欧姆符文 · 持有：0"
                  - option "罗符文 · 持有：0"
                  - option "瑟符文 · 持有：0"
                  - option "比尔符文 · 持有：0"
                  - option "迦符文 · 持有：0"
                  - option "查姆符文 · 持有：0"
                  - option "卓德符文 · 持有：0"
                  - option "碎裂的紫宝石 · 持有：0"
                  - option "裂开的紫宝石 · 持有：0"
                  - option "普通的紫宝石 · 持有：0"
                  - option "无瑕疵的紫宝石 · 持有：0"
                  - option "完美的紫宝石 · 持有：0"
                  - option "碎裂的钻石 · 持有：0"
                  - option "裂开的钻石 · 持有：0"
                  - option "普通的钻石 · 持有：0"
                  - option "无瑕疵的钻石 · 持有：0"
                  - option "完美的钻石 · 持有：0"
                  - option "碎裂的绿宝石 · 持有：0"
                  - option "裂开的绿宝石 · 持有：0"
                  - option "普通的绿宝石 · 持有：0"
                  - option "无瑕疵的绿宝石 · 持有：0"
                  - option "完美的绿宝石 · 持有：0"
                  - option "碎裂的红宝石 · 持有：0"
                  - option "裂开的红宝石 · 持有：0"
                  - option "普通的红宝石 · 持有：0"
                  - option "无瑕疵的红宝石 · 持有：0"
                  - option "完美的红宝石 · 持有：0"
                  - option "碎裂的蓝宝石 · 持有：0"
                  - option "裂开的蓝宝石 · 持有：0"
                  - option "普通的蓝宝石 · 持有：0"
                  - option "无瑕疵的蓝宝石 · 持有：0"
                  - option "完美的蓝宝石 · 持有：0"
                  - option "碎裂的骷髅 · 持有：0"
                  - option "裂开的骷髅 · 持有：0"
                  - option "普通的骷髅 · 持有：0"
                  - option "无瑕疵的骷髅 · 持有：0"
                  - option "完美的骷髅 · 持有：0"
                  - option "碎裂的黄宝石 · 持有：0"
                  - option "裂开的黄宝石 · 持有：0"
                  - option "普通的黄宝石 · 持有：0"
                  - option "无瑕疵的黄宝石 · 持有：0"
                  - option "完美的黄宝石 · 持有：0"
              - group "目标装备" [ref=e96]:
                - generic [ref=e97]: 目标装备
                - generic [ref=e98]: 搜索装备
                - searchbox "搜索装备" [ref=e99]
                - status [ref=e100]: 已选择：1
                - list [ref=e101]:
                  - listitem [ref=e102]:
                    - generic [ref=e103] [cursor=pointer]:
                      - 'checkbox "战斗镰刀 · #it-665q-4 背包" [checked] [ref=e104]'
                      - generic [ref=e105]:
                        - text: "战斗镰刀 · #it-665q-4"
                        - generic [ref=e106]: 背包
              - button "预览操作" [ref=e107] [cursor=pointer]
          - dialog "预览操作" [ref=e108]:
            - generic [ref=e109]:
              - heading "预览操作" [level=2] [ref=e110]
              - generic [ref=e111]:
                - generic [ref=e112]:
                  - heading "消耗" [level=3] [ref=e113]
                  - list [ref=e114]:
                    - listitem [ref=e115]: 法尔符文 × 1
                - generic [ref=e116]:
                  - heading "所选物品" [level=3] [ref=e117]
                  - list [ref=e118]:
                    - listitem [ref=e119]:
                      - group [ref=e120]:
                        - 'generic "战斗镰刀 · #it-665q-4 · 背包" [ref=e121] [cursor=pointer]'
                - generic [ref=e122]:
                  - heading "结果" [level=3] [ref=e123]
                  - list
                  - generic [ref=e124]:
                    - paragraph [ref=e125]: "结果物品 · #it-665q-4"
                    - 'tooltip "战斗镰刀 武器 · 武器槽 战斗镰刀 伤害: 52–52 物品等级 42 · 插槽 ×5 需求 等级 41 +5 力量 +5 敏捷 +10 敏捷 +10 冰冷抗性 +18 攻击 +40 攻击 +10 力量 +10 力量 +10 敏捷 +30 火焰抗性 +30 冰冷抗性 +30 闪电抗性 +30 毒素抗性 +30 奥术抗性 +200 攻击" [ref=e126]':
                      - generic [ref=e127]:
                        - generic [ref=e128]: 战斗镰刀
                        - generic [ref=e129]: 武器 · 武器槽
                      - img "战斗镰刀" [ref=e132]
                      - generic [ref=e133]: "伤害: 52–52"
                      - generic [ref=e134]: 物品等级 42 · 插槽 ×5
                      - generic [ref=e135]:
                        - generic [ref=e136]: 需求
                        - generic [ref=e138]: 等级 41
                      - list [ref=e139]:
                        - listitem [ref=e140]: +5 力量
                        - listitem [ref=e141]: +5 敏捷
                        - listitem [ref=e142]: +10 敏捷
                        - listitem [ref=e143]: +10 冰冷抗性
                        - listitem [ref=e144]: +18 攻击
                        - listitem [ref=e145]: +40 攻击
                        - listitem [ref=e146]: +10 力量
                        - listitem [ref=e147]: +10 力量
                        - listitem [ref=e148]: +10 敏捷
                        - listitem [ref=e149]: +30 火焰抗性
                        - listitem [ref=e150]: +30 冰冷抗性
                        - listitem [ref=e151]: +30 闪电抗性
                        - listitem [ref=e152]: +30 毒素抗性
                        - listitem [ref=e153]: +30 奥术抗性
                        - listitem [ref=e154]: +200 攻击
                    - generic [ref=e155]:
                      - paragraph [ref=e156]: 镶嵌孔数：5
                      - paragraph [ref=e157]: 镶嵌顺序
                      - list [ref=e158]:
                        - listitem [ref=e159]: 海尔符文
                        - listitem [ref=e160]: 寇符文
                        - listitem [ref=e161]: 瑟尔符文
                        - listitem [ref=e162]: 依夫符文
                        - listitem [ref=e163]: 法尔符文
                      - paragraph [ref=e164]: 符文之语：服从
                - generic [ref=e165]:
                  - button "确认" [ref=e166] [cursor=pointer]
                  - button "取消" [active] [ref=e167] [cursor=pointer]
        - generic [ref=e168]:
          - heading "任务物品" [level=2] [ref=e169]
          - paragraph [ref=e170]: 与当前角色绑定，不占用背包或仓库空间。
          - paragraph [ref=e171]: 尚无任务物品。
          - status
        - generic [ref=e172]:
          - tablist [ref=e173]:
            - tab "背包 (1/100)" [selected] [ref=e174] [cursor=pointer]
            - tab "仓库 (0/500)" [ref=e175] [cursor=pointer]
            - tab "装备" [ref=e176] [cursor=pointer]
          - tabpanel "背包 (1/100)" [ref=e177]:
            - generic [ref=e178]:
              - generic [ref=e179]:
                - button "丢弃所有普通(1)" [ref=e180] [cursor=pointer]:
                  - text: 丢弃所有普通
                  - generic [ref=e181]: (1)
                - button "丢弃所有魔法(0)" [disabled] [ref=e182]:
                  - text: 丢弃所有魔法
                  - generic [ref=e183]: (0)
                - button "丢弃所有稀有(0)" [disabled] [ref=e184]:
                  - text: 丢弃所有稀有
                  - generic [ref=e185]: (0)
                - button "丢弃所有低于当前装备等级(0)" [disabled] [ref=e186]:
                  - text: 丢弃所有低于当前装备等级
                  - generic [ref=e187]: (0)
              - listbox "物品" [ref=e190]:
                - listitem [ref=e191]:
                  - button "战斗镰刀 · item" [ref=e194] [cursor=pointer]:
                    - img "战斗镰刀" [ref=e196]
                    - generic: ⚔️
                - listitem [ref=e197]:
                  - generic "空槽位" [ref=e198]
                - listitem [ref=e199]:
                  - generic "空槽位" [ref=e200]
                - listitem [ref=e201]:
                  - generic "空槽位" [ref=e202]
                - listitem [ref=e203]:
                  - generic "空槽位" [ref=e204]
                - listitem [ref=e205]:
                  - generic "空槽位" [ref=e206]
                - listitem [ref=e207]:
                  - generic "空槽位" [ref=e208]
                - listitem [ref=e209]:
                  - generic "空槽位" [ref=e210]
                - listitem [ref=e211]:
                  - generic "空槽位" [ref=e212]
                - listitem [ref=e213]:
                  - generic "空槽位" [ref=e214]
                - listitem [ref=e215]:
                  - generic "空槽位" [ref=e216]
                - listitem [ref=e217]:
                  - generic "空槽位" [ref=e218]
                - listitem [ref=e219]:
                  - generic "空槽位" [ref=e220]
                - listitem [ref=e221]:
                  - generic "空槽位" [ref=e222]
                - listitem [ref=e223]:
                  - generic "空槽位" [ref=e224]
                - listitem [ref=e225]:
                  - generic "空槽位" [ref=e226]
                - listitem [ref=e227]:
                  - generic "空槽位" [ref=e228]
                - listitem [ref=e229]:
                  - generic "空槽位" [ref=e230]
                - listitem [ref=e231]:
                  - generic "空槽位" [ref=e232]
                - listitem [ref=e233]:
                  - generic "空槽位" [ref=e234]
                - listitem [ref=e235]:
                  - generic "空槽位" [ref=e236]
                - listitem [ref=e237]:
                  - generic "空槽位" [ref=e238]
                - listitem [ref=e239]:
                  - generic "空槽位" [ref=e240]
                - listitem [ref=e241]:
                  - generic "空槽位" [ref=e242]
                - listitem [ref=e243]:
                  - generic "空槽位" [ref=e244]
                - listitem [ref=e245]:
                  - generic "空槽位" [ref=e246]
                - listitem [ref=e247]:
                  - generic "空槽位" [ref=e248]
                - listitem [ref=e249]:
                  - generic "空槽位" [ref=e250]
                - listitem [ref=e251]:
                  - generic "空槽位" [ref=e252]
                - listitem [ref=e253]:
                  - generic "空槽位" [ref=e254]
                - listitem [ref=e255]:
                  - generic "空槽位" [ref=e256]
                - listitem [ref=e257]:
                  - generic "空槽位" [ref=e258]
                - listitem [ref=e259]:
                  - generic "空槽位" [ref=e260]
                - listitem [ref=e261]:
                  - generic "空槽位" [ref=e262]
                - listitem [ref=e263]:
                  - generic "空槽位" [ref=e264]
                - listitem [ref=e265]:
                  - generic "空槽位" [ref=e266]
                - listitem [ref=e267]:
                  - generic "空槽位" [ref=e268]
                - listitem [ref=e269]:
                  - generic "空槽位" [ref=e270]
                - listitem [ref=e271]:
                  - generic "空槽位" [ref=e272]
                - listitem [ref=e273]:
                  - generic "空槽位" [ref=e274]
                - listitem [ref=e275]:
                  - generic "空槽位" [ref=e276]
                - listitem [ref=e277]:
                  - generic "空槽位" [ref=e278]
                - listitem [ref=e279]:
                  - generic "空槽位" [ref=e280]
                - listitem [ref=e281]:
                  - generic "空槽位" [ref=e282]
                - listitem [ref=e283]:
                  - generic "空槽位" [ref=e284]
                - listitem [ref=e285]:
                  - generic "空槽位" [ref=e286]
                - listitem [ref=e287]:
                  - generic "空槽位" [ref=e288]
                - listitem [ref=e289]:
                  - generic "空槽位" [ref=e290]
                - listitem [ref=e291]:
                  - generic "空槽位" [ref=e292]
                - listitem [ref=e293]:
                  - generic "空槽位" [ref=e294]
                - listitem [ref=e295]:
                  - generic "空槽位" [ref=e296]
                - listitem [ref=e297]:
                  - generic "空槽位" [ref=e298]
                - listitem [ref=e299]:
                  - generic "空槽位" [ref=e300]
                - listitem [ref=e301]:
                  - generic "空槽位" [ref=e302]
                - listitem [ref=e303]:
                  - generic "空槽位" [ref=e304]
                - listitem [ref=e305]:
                  - generic "空槽位" [ref=e306]
                - listitem [ref=e307]:
                  - generic "空槽位" [ref=e308]
                - listitem [ref=e309]:
                  - generic "空槽位" [ref=e310]
                - listitem [ref=e311]:
                  - generic "空槽位" [ref=e312]
                - listitem [ref=e313]:
                  - generic "空槽位" [ref=e314]
                - listitem [ref=e315]:
                  - generic "空槽位" [ref=e316]
                - listitem [ref=e317]:
                  - generic "空槽位" [ref=e318]
                - listitem [ref=e319]:
                  - generic "空槽位" [ref=e320]
                - listitem [ref=e321]:
                  - generic "空槽位" [ref=e322]
                - listitem [ref=e323]:
                  - generic "空槽位" [ref=e324]
                - listitem [ref=e325]:
                  - generic "空槽位" [ref=e326]
                - listitem [ref=e327]:
                  - generic "空槽位" [ref=e328]
                - listitem [ref=e329]:
                  - generic "空槽位" [ref=e330]
                - listitem [ref=e331]:
                  - generic "空槽位" [ref=e332]
                - listitem [ref=e333]:
                  - generic "空槽位" [ref=e334]
                - listitem [ref=e335]:
                  - generic "空槽位" [ref=e336]
                - listitem [ref=e337]:
                  - generic "空槽位" [ref=e338]
                - listitem [ref=e339]:
                  - generic "空槽位" [ref=e340]
                - listitem [ref=e341]:
                  - generic "空槽位" [ref=e342]
                - listitem [ref=e343]:
                  - generic "空槽位" [ref=e344]
                - listitem [ref=e345]:
                  - generic "空槽位" [ref=e346]
                - listitem [ref=e347]:
                  - generic "空槽位" [ref=e348]
                - listitem [ref=e349]:
                  - generic "空槽位" [ref=e350]
                - listitem [ref=e351]:
                  - generic "空槽位" [ref=e352]
                - listitem [ref=e353]:
                  - generic "空槽位" [ref=e354]
                - listitem [ref=e355]:
                  - generic "空槽位" [ref=e356]
                - listitem [ref=e357]:
                  - generic "空槽位" [ref=e358]
                - listitem [ref=e359]:
                  - generic "空槽位" [ref=e360]
                - listitem [ref=e361]:
                  - generic "空槽位" [ref=e362]
                - listitem [ref=e363]:
                  - generic "空槽位" [ref=e364]
                - listitem [ref=e365]:
                  - generic "空槽位" [ref=e366]
                - listitem [ref=e367]:
                  - generic "空槽位" [ref=e368]
                - listitem [ref=e369]:
                  - generic "空槽位" [ref=e370]
                - listitem [ref=e371]:
                  - generic "空槽位" [ref=e372]
                - listitem [ref=e373]:
                  - generic "空槽位" [ref=e374]
                - listitem [ref=e375]:
                  - generic "空槽位" [ref=e376]
                - listitem [ref=e377]:
                  - generic "空槽位" [ref=e378]
                - listitem [ref=e379]:
                  - generic "空槽位" [ref=e380]
                - listitem [ref=e381]:
                  - generic "空槽位" [ref=e382]
                - listitem [ref=e383]:
                  - generic "空槽位" [ref=e384]
                - listitem [ref=e385]:
                  - generic "空槽位" [ref=e386]
                - listitem [ref=e387]:
                  - generic "空槽位" [ref=e388]
                - listitem [ref=e389]:
                  - generic "空槽位" [ref=e390]
                - listitem [ref=e391]:
                  - generic "空槽位" [ref=e392]
                - listitem [ref=e393]:
                  - generic "空槽位" [ref=e394]
```

# Test source

```ts
  1   | /** Constructed acquisition/crafting proof; never an earned campaign or pacing claim. */
  2   | import { expect, test, type Locator, type Page } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import { fileURLToPath } from 'node:url';
  5   | import { createServer } from 'vite';
  6   | import type { Item } from '../../src/engine/types/items';
  7   | import type { SaveCurrent } from '../../src/engine/types/save';
  8   | import { createCharacter, navTo } from '../e2e/_helpers';
  9   | 
  10  | const runes = ['runes/hel', 'runes/ko', 'runes/thul', 'runes/eth', 'runes/fal'];
  11  | async function acquiredScythe(): Promise<{ seed: number; item: Item }> {
  12  |   const repo = fileURLToPath(new URL('../..', import.meta.url));
  13  |   // Production modules use Vite JSON imports; load them through that same transformer.
  14  |   const server = await createServer({ root: repo, configFile: false,
  15  |     cacheDir: `${process.env.CRAFTING_UI_ROOT!}/vite-ssr-cache`,
  16  |     server: { middlewareMode: true, hmr: false }, resolve: { alias: { '@': `${repo}/src` } } });
  17  |   try {
  18  |     const { loadItemBases, loadTreasureClasses } = await server.ssrLoadModule('/src/data/loaders/loot.ts') as typeof import('../../src/data/loaders/loot');
  19  |     const { createRng } = await server.ssrLoadModule('/src/engine/rng.ts') as typeof import('../../src/engine/rng');
  20  |     const { rollDrops } = await server.ssrLoadModule('/src/engine/loot/drop-roller.ts') as typeof import('../../src/engine/loot/drop-roller');
  21  |     const { rollItem } = await server.ssrLoadModule('/src/engine/loot/rollItem.ts') as typeof import('../../src/engine/loot/rollItem');
  22  |     const tc = loadTreasureClasses().get('loot/trash-act4');
  23  |     if (!tc) throw new Error('Missing authored source');
  24  |     for (let seed = 1; seed <= 2048; seed++) {
  25  |       const rng = createRng(seed);
  26  |       for (const drop of rollDrops({ tc, tier: 'trash', monsterLevel: 42, magicFind: 0 }, rng)) {
  27  |         if (drop.kind !== 'item' || drop.baseId !== 'items/base/wp2h-battle-scythe') continue;
  28  |         const item = rollItem(drop, { bases: loadItemBases(), affixes: [] }, rng);
  29  |         if (item?.socketCapacity === 5) return { seed, item };
  30  |       }
  31  |     }
  32  |     throw new Error('No ordinary five-socket scythe materialized in the diagnostic sample');
  33  |   } finally { await server.close(); }
  34  | }
  35  | async function backup(page: Page): Promise<SaveCurrent> {
  36  |   await navTo(page, 'settings');
  37  |   const pending = page.waitForEvent('download'); await page.getByTestId('export-save-button').click();
  38  |   const download = await pending;
  39  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  40  |   finally { await download.delete(); }
  41  | }
  42  | async function imported(page: Page, save: SaveCurrent, en: boolean) {
  43  |   await navTo(page, 'settings');
  44  |   const label = en ? 'Import Save' : '导入存档';
  45  |   await page.getByRole('button', { name: label, exact: true }).click();
  46  |   await page.getByRole('dialog').getByRole('textbox').fill(JSON.stringify(save));
  47  |   await page.getByRole('dialog').getByRole('button', { name: label, exact: true }).click();
  48  |   await expect(page.getByRole('dialog')).toHaveCount(0);
  49  | }
  50  | async function layout(page: Page, scope: Locator) {
  51  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  52  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  53  |   expect(await scope.evaluate(node => node.scrollWidth <= node.clientWidth)).toBe(true);
  54  |   for (const control of await scope.locator('button,select').all()) {
  55  |     if (!(await control.isVisible())) continue;
  56  |     const box = await control.boundingBox();
  57  |     expect(box?.height).toBeGreaterThanOrEqual(44); expect(box?.width).toBeGreaterThanOrEqual(44);
  58  |   }
  59  | }
  60  | 
  61  | for (const locale of ['en', 'zh-CN'] as const) for (const [width, height] of [[360, 640], [1280, 800]]) {
  62  |   test(`Obedience ordered crafting equip and Continue ${locale} ${String(width)}x${String(height)}`, async ({ page: initial, context }, info) => {
  63  |     const en = locale === 'en', errors: string[] = [];
  64  |     const observe = (current: Page) => {
  65  |       current.on('pageerror', error => errors.push(error.message));
  66  |       current.on('console', entry => { if (entry.type() === 'error' || entry.type() === 'warning') errors.push(entry.text()); });
  67  |     };
  68  |     let page = initial; observe(page); await page.setViewportSize({ width: width!, height: height! });
  69  |     await page.goto('/'); await createCharacter(page, { class: 'sorceress', name: 'Obedience QA' });
  70  |     await navTo(page, 'settings'); await page.getByRole('button', { name: en ? 'English' : '简体中文', exact: true }).click();
  71  |     const fresh = await backup(page), acquisition = await acquiredScythe(), item = acquisition.item;
  72  |     const fixture: SaveCurrent = { ...fresh,
  73  |       player: { ...fresh.player, level: 40, coreStats: { strength: 50, dexterity: 50, vitality: 50, energy: 50 },
  74  |         equipment: [], derivedStats: { ...fresh.player.derivedStats, life: 13, mana: 17 } },
  75  |       inventory: { ...fresh.inventory, backpack: [item], stash: [], equipped: {},
  76  |         materials: Object.fromEntries(runes.map(rune => [rune, 1])) } };
  77  |     await info.attach('constructed-input-and-native-drop', { body: JSON.stringify({ acquisition, fixture }), contentType: 'application/json' });
  78  |     await imported(page, fixture, en); await navTo(page, 'inventory');
  79  |     const panel = page.getByTestId('crafting-panel');
  80  |     await panel.getByLabel(en ? 'Action' : '操作', { exact: true }).selectOption('socket-insert');
  81  |     await panel.getByLabel(new RegExp(`#${item.id}\\s`)).check();
  82  |     for (let index = 0; index < runes.length; index++) {
  83  |       await panel.getByLabel(en ? 'Socket material' : '镶嵌材料').selectOption(runes[index]!);
  84  |       await panel.getByRole('button', { name: en ? 'Preview action' : '预览操作', exact: true }).click();
  85  |       const dialog = page.getByRole('dialog'); await layout(page, dialog);
  86  |       const output = page.getByTestId('crafting-output-item');
  87  |       if (index === 4) {
> 88  |         await expect(output).toContainText(en ? 'Runeword: Obedience' : '符文之语：遵从');
      |                              ^ Error: expect(locator).toContainText(expected) failed
  89  |         await expect(output).toContainText(en ? '+200 Attack' : '+200 攻击');
  90  |         await info.attach('completed-word-preview', { body: await page.screenshot(), contentType: 'image/png' });
  91  |       } else await expect(output).not.toContainText(en ? 'Runeword: Obedience' : '符文之语：遵从');
  92  |       await dialog.getByRole('button', { name: en ? 'Confirm' : '确认', exact: true }).click({ clickCount: 2 });
  93  |       await expect(dialog.getByRole('status')).toHaveText(en ? 'Completed' : '已完成');
  94  |       await dialog.getByRole('button', { name: en ? 'Close' : '关闭', exact: true }).click();
  95  |     }
  96  |     const crafted = await backup(page);
  97  |     const word = { ...item, rarity: 'runeword', runewordId: 'runewords/obedience',
  98  |       socketContents: runes.map(id => ({ kind: 'rune', id })) };
  99  |     expect(crafted.inventory.backpack).toEqual([word]);
  100 |     expect(crafted.inventory.materials).toEqual({}); expect(crafted.inventory.materialActionOrdinal).toBe(5);
  101 |     expect(crafted.inventory.currencies).toEqual(fresh.inventory.currencies);
  102 |     await info.attach('crafted-native-save', { body: JSON.stringify(crafted), contentType: 'application/json' });
  103 |     await navTo(page, 'inventory'); await page.getByTestId(`inv-item-${item.id}`).click();
  104 |     await page.mouse.move(0, 0); await layout(page, page.getByTestId('inv-detail-panel'));
  105 |     await page.getByTestId('inv-primary-action').click();
  106 |     const refused = await backup(page);
  107 |     expect(refused.player).toEqual(crafted.player); expect(refused.inventory).toEqual(crafted.inventory);
  108 |     await info.attach('level40-equip-refused', { body: JSON.stringify(refused), contentType: 'application/json' });
  109 |     await imported(page, { ...refused, player: { ...refused.player, level: 41 } }, en);
  110 |     await navTo(page, 'inventory'); await page.getByTestId(`inv-item-${item.id}`).click();
  111 |     await page.mouse.move(0, 0); await page.getByTestId('inv-primary-action').click();
  112 |     const equipped = await backup(page);
  113 |     expect(equipped.inventory.equipped.weapon).toEqual({ ...word, equipped: true });
  114 |     expect(equipped.inventory.backpack).toEqual([]);
  115 |     expect(equipped.player.derivedStats.attack).toBe(385 + item.baseRolls!.attack!);
  116 |     expect(equipped.player.derivedStats.resistances).toMatchObject({ fire: 30, cold: 40, lightning: 30, poison: 30, arcane: 30 });
  117 |     expect([equipped.player.derivedStats.life, equipped.player.derivedStats.mana]).toEqual([13, 17]);
  118 |     await page.getByRole('button', { name: en ? 'Save' : '保存', exact: true }).click();
  119 |     await expect(page.getByRole('status')).toHaveText(en ? 'Saved' : '已保存'); await page.close();
  120 |     page = await context.newPage(); observe(page); await page.setViewportSize({ width: width!, height: height! });
  121 |     await page.goto('/'); await page.getByTestId('home-continue').click();
  122 |     const continued = await backup(page);
  123 |     for (const key of ['player', 'inventory', 'map', 'mercs', 'formation'] as const) expect(continued[key]).toEqual(equipped[key]);
  124 |     await info.attach('equipped-native-continued', { body: JSON.stringify(continued), contentType: 'application/json' });
  125 |     await navTo(page, 'inventory'); await page.getByRole('tab', { name: en ? 'Equipment' : '装备', exact: true }).click();
  126 |     await page.getByTestId('equip-slot-weapon').getByRole('button', { name: en ? 'Unequip' : '卸下', exact: true }).click();
  127 |     const removed = await backup(page);
  128 |     expect(removed.inventory.backpack).toEqual([word]); expect(removed.player.derivedStats.attack).toBe(115);
  129 |     expect(removed.player.derivedStats.resistances).toMatchObject({ fire: 0, cold: 0, lightning: 0, poison: 0, arcane: 0 });
  130 |     expect([removed.player.derivedStats.life, removed.player.derivedStats.mana]).toEqual([13, 17]);
  131 |     await info.attach('removed-native-save', { body: JSON.stringify(removed), contentType: 'application/json' });
  132 |     await page.close(); expect(errors).toEqual([]);
  133 |   });
  134 | }
  135 | 
```