from pathlib import Path
import json,hashlib,tarfile,stat,datetime
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
r=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-armor-melt-jcabtz3k')
dest=w/'docs/plans/evidence/fixtures/p08a08-meteor-armor-melt'
next_raw=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((dest/'packet.json').read_text())
assert sha((dest/'packet.json').read_bytes())=='b4c5b263083aaccc263e6f8f5b1f741a31cc77ab95fee289b0d2cbdce4fccb42'
assert sha((dest/'raw.tar.gz').read_bytes())==p['archive']['sha256']
review=json.loads((dest/'final-review.json').read_text())
assert review['allReadersReleased'] and review['producer']=='APPROVE' and review['QA']=='APPROVE'
assert r.resolve()==r and not r.is_symlink()
actual=[]
for f in r.rglob('*'):
 m=f.lstat().st_mode
 assert not stat.S_ISLNK(m),f
 if not stat.S_ISDIR(m):
  assert stat.S_ISREG(m),f
  actual.append(str(f.relative_to(r)))
assert set(actual)=={x['path'] for x in p['records']}
with tarfile.open(dest/'raw.tar.gz') as tar:
 for row in p['records']:
  b=(r/row['path']).read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256']
  assert sha(tar.extractfile(row['path']).read())==row['sha256']
for row in json.loads((r/'process-audit.json').read_text())['identities']:
 try:
  f=Path(f"/proc/{row['pid']}/stat").read_text().rsplit(')',1)[1].split()
  assert int(f[19])!=row['startTicks'] or f[0]=='Z',row
 except FileNotFoundError:pass
expected={str(r):p['records']}
for group in json.loads((r/'final-owned-output.json').read_text()):expected[group['root']]=group['records']
result={'card':'P08a08','implementation':'4ab0c14','owner':'root','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'allReadersReleased':True,'archiveRawVerified':True,'nonliveProcessIdentities':p['processIdentityCount'],'signals':[],'removed':[],'nextRaw':str(next_raw),'preserved':['pre-existing empty coverage','installed tools/dependencies/browser','shared caches','source/history/durable evidence','umbrella worktree']}
for root in [r,w/'dist',w/'node_modules/.vite']:
 assert root.resolve()==root and root.is_dir() and not root.is_symlink()
 files=[];dirs=[]
 for f in root.rglob('*'):
  m=f.lstat().st_mode;assert not stat.S_ISLNK(m),f
  if stat.S_ISDIR(m):dirs.append(f)
  else:
   assert stat.S_ISREG(m),f
   b=f.read_bytes();files.append({'path':str(f.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
 assert {x['path']:(x['bytes'],x['sha256']) for x in files}=={x['path']:(x['bytes'],x['sha256']) for x in expected[str(root)]}
 for row in files:
  f=root/row['path'];assert sha(f.read_bytes())==row['sha256'];f.unlink()
 for d in sorted(dirs,key=lambda x:len(x.parts),reverse=True):d.rmdir()
 root.rmdir();assert not root.exists()
 result['removed'].append({'root':str(root),'files':len(files),'records':files,'absenceVerified':True})
assert (w/'coverage').is_dir() and not list((w/'coverage').iterdir())
(dest/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
(next_raw/'meteor-cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'removed':[{k:x[k] for k in ['root','files','absenceVerified']} for x in result['removed']],'nonliveProcessIdentities':p['processIdentityCount'],'coveragePreservedEmpty':True}))
