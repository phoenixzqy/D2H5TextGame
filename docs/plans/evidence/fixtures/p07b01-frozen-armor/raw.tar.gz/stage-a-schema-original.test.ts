import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import sorceressSkills from '../../data/skills/sorceress.json';
import skillSchema from '../../data/schema/skill.schema.json';

const authored = () => {
  const row = sorceressSkills.find(row => row.id === 'skills-sorceress-frozen-armor');
  if (!row) throw new Error('Missing authored player Frozen Armor');
  return structuredClone(row);
};
const validate = new Ajv2020({ strict: true, allErrors: true }).compile(skillSchema);

describe('P07b01 exact player Frozen Armor schema', () => {
  it('preserves the current authored tuning and active self identity', () => {
    const row = authored();
    expect(validate(row)).toBe(true);
    expect(row).toMatchObject({ id: 'skills-sorceress-frozen-armor', trigger: 'active',
      target: 'self', requiredLevel: 1, minLevel: 1, maxLevel: 20,
      cooldown: 4, cost: { mana: 7 }, appliesStatus: ['frozen-armor'],
      scaling: { cooldownPerLevel: -0.05, costPerLevel: -0.1,
        passiveStatsPerLevel: { defensePct: 0.03 } } });
  });

  it.each([0, 0.125, 3])('permits finite nonnegative defense coefficient %s', defensePct => {
    const row = authored();
    row.scaling.passiveStatsPerLevel = { defensePct };
    expect(validate(row)).toBe(true);
  });

  it('permits alternative valid authored cap, cost and cooldown tuning', () => {
    const row = { ...authored(), maxLevel: 31, cooldown: 0.5, cost: { mana: 0 } };
    expect(validate(row)).toBe(true);
  });

  it.each([
    { scaling: undefined }, { scaling: {} }, { scaling: { passiveStatsPerLevel: {} } },
    ...[-0.01, NaN, Infinity, -Infinity, '0.03', null].map(defensePct =>
      ({ scaling: { passiveStatsPerLevel: { defensePct } } })),
    { cost: undefined }, { cost: {} },
    ...[-1, NaN, Infinity, '7', null].map(mana => ({ cost: { mana } })),
    ...[0, -1, 1.5, NaN, Infinity, '20', null].map(maxLevel => ({ maxLevel })),
    { trigger: 'passive' }, { target: 'single-enemy' }, { passive: true },
    { cooldown: 0 }, { cooldown: Infinity },
    { appliesStatus: undefined }, { appliesStatus: [] }, { appliesStatus: ['chill'] },
    { appliesStatus: ['frozen-armor', 'chill'] },
    { damage: { min: 1, max: 1, breakdown: { cold: 1 } } }, { damageType: 'cold' }
  ])('rejects malformed exact player row %j', fields => {
    expect(validate({ ...authored(), ...fields })).toBe(false);
  });

  it('does not impose player Frozen Armor requirements on a distinct skill', () => {
    const row = { ...authored(), id: 'mskill-frozen-armor', scaling: undefined, cost: undefined,
      appliesStatus: ['merc-frozen-armor'] };
    expect(validate(row)).toBe(true);
  });
});
