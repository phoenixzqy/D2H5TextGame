# P07b01 player Frozen Armor — proposed bounded contract

GD-DESIGN-REVIEW / TD-ARCH-REVIEW APPROVE proposed defaults 2026-10-21.
Root owns all writes/execution in existing claimed umbrella worktree.

Only exact player skills-sorceress-frozen-armor / sorceress.frozen_armor.
Actual eligible positive-rank cast grants immutable combat-only snapshot
{rank,defensePct}; no learning/imported combo/bare marker power. JSON owns
existing defensePct0.03 per rank, max20, active/self, level1, mana7/CD4 and
existing cost/CD scaling. Rank resolution is shared by cast eligibility and native boundary invalidation:
accept only finite positive integers under either exact alias, take their maximum
valid value (matching Warmth), then clamp to the authored cap. Missing/zero/negative/
fractional/nonfinite values do not allocate the skill. Clamp cast rank to authored cap; snapshot survives
positive rank changes and combo removal. Independently copied immutable
primitive definition must not observe mutable registry/catalog edits.

Native-run indefinite lifetime, no active recast/stack. Qualified wave carry
retains paid snapshot. New run/repeat/stop/flee/death/reload grants no carry into
another run. At each existing playWave boundary including replay, fresh
zero/unlearned rank removes exact marker+snapshot from new input only; preserve
stored replay baseline/recording. Current fresh equipment stats determine base
defense, multiplied by1+snapshot bonus, then Melt/InnerSight factors with no
intermediate floor. MagicResist/HP/MP/authoritative stats/periodic unchanged.
Legacy bare marker must not block eligible first paid cast or grant any effect.

Each landed direct positive-damage hit chills living attacker once, all damage
types including directthorns; exclude periodic/reflection callbacks. Eligibility
uses pre-hit armor; lethal wearer still retaliates. Order directdamage→existing
offensive statuses→armor Chill→ordinary deaths. Deterministic/no extra RNG;
canonical Chill2s/50%/half-open/refresh/source/boss/scheduler policy once, no
copied tuning, retaliation damage/recursion/heal/resurrection. Merc variant
separate; physical is not melee classification.

Stages≤5 writable repository files, root only. Read-only independent plan/test/
source/evidence reviews; no test/build during source fingerprint holds.
A: schema exactFrozenArmor constraints; new skills/frozen-armor.ts; new module
schema/definition tests; combat/types.ts optional readonly snapshot; final D05
controlling decision. No runtime enabling. Schema domains: finite nonnegative
defense coefficient and positive integer rank cap, without invented upper balance
limits. Current .03/20/7/4/scaling are regression controls; alternative valid tuning
must flow from JSON. Safe collection sequence: independently freeze schema-only
new test file without module import, run genuine schema RED against unchanged
schema, preserve original, then independently freeze appended definition/rank
tests and module import. Record missing-module capability failure separately;
implement without changing frozen schema test block. Snapshot shape rank+
defensePct, combat-only.
Separate two-file fixture prerequisite before B freeze: combat/combat.test.ts
and combat/warmth.test.ts existing positive FrozenArmor controls receive explicit
rank1 only, retaining all original cast/count/mana/stats assertions. Preserve
originals and validate this prerequisite independently; missing/zero-rank
behavioral RED lives in new B tests.
B: skills/effects.ts exact optional FrozenArmor metadata; dataCatalog.ts exact
adapter; combat.ts coherent eligibility/bare-marker clearing/paid snapshot/shared
defense+retaliation; registry.test.ts; new combat/frozen-armor.test.ts.
C: combatHelpers.ts new-input zero-rank invalidation; dedicated integration tests;
ordinary frozen browser spec/evidence separately if needed≤5files. FullP07b01
acceptance waits C, even if B engine passes. Structured BUG after behavioral RED
before any runtime edits, as separate docs prerequisite.

Freeze concrete tests before changes. Required controls: real JSON/registry/
recorded cast, ranks1/20/cap/aliases, missing/zero invalid cast, insufficientMP,
no passive defense, no duplicate cast/cost, marker-only firstcast, paid snapshot
vs subsequent allocations, defense/MR/InnerSight+Melt fractional composition,
no resource refill/stats mutation, qualifying hit/miss/zero/DoT/dead attacker/
lethal wearer/status order/RNG, canonical Chill scheduler+boss+refresh, replay/
immutability, complete unaffected recording captured prepatch/frozen equality.
Native C: boundary carry/rank up+down/zero/respec/combo removal/equipment refresh,
repeated replay baseline no mutation, new run clears and no HP/MP refill.

Bounds unchanged: focused30/E120/U120/T90/L90/B210seconds+2ownedcleanup,
32MiB/log/report and64MiBRAW/dist/.vite. Sequential commands; requiredE/U/T/L/
cleanproductionbridgebuild. Exact old taskdist removal before build, so monitor
cannot race bridgeguard cleanup. Preserve originals/failures, archive/independent
review/exact taskowned cleanup. Pre-existing emptycoverage/tools/sharedcaches
preserved. No gameplay retry/seedsearch/recipe tuning/remote action. No global
buffframework, timedbuffexpiry, merc variant or fullcampaign/balance acceptance.
