# P07b01 Stage C native plan

QA-C-PLAN: APPROVE — bounded native slice only; no B/C final acceptance.

Owner: root, claimed umbrella worktree. Reviewers read-only.
Writable files: src/stores/combatHelpers.ts; new src/stores/combatHelpers.frozen-armor.test.ts.
At playWave use shared rank resolver on fresh player configuration. Zero/unlearned
allocation strips frozenArmor and exactly skills-sorceress-frozen-armor,
sorceress.frozen_armor, frozen-armor from new input. Preserve unrelated markers,
merc variant, stored carry baseline and prior recording.

Fixture: real area/registered player Frozen Armor/fixed seed+ordinal, explicit
equipped fixture gear and registered finisher; actual start/drain/advance. No
injected paid snapshot or winning outcome. This is integration scaffolding, not
earned progression/campaign or balance evidence.

- Genuine rank20 paid cast, cost5, next-wave captured rank20/defensePct0.6 and no recast.
- Lower positive rank, restore rank, remove combo: paid potency retained.
- Actual equipment refreshes base defense, preserves potency, deterministic direct damage; account for actual XP level-up.
- Zero/missing allocation at next-wave and explicit replay strips snapshot and all exact markers; ancillary marker-only fixture may add representations without fabricating a paid snapshot.
- Replay zero then positive returns original paid baseline, including after completed playback and temporary lower maxima.
- Ordinary config changes preserve installed recording. New HP/MP/recovery carry matches baseline with existing clamps only: no refill, cumulative clamp or duplicate rewards.
- Fresh start, real all-wave victory/repeat, stop/flee/death: no carry into new run, disable armor combo to expose leakage. Native stop/flee proof may execute exact abort/idle-reset/endCombat sequence; actual clicks/timed repeat require browser proof.
- Reload: save omission + real persistence through fresh module graph; live hydrateFromSave is not a reload proxy. Reserve actual page.reload proof for browser slice if native fresh-module setup is disproportionate.

Required separate D/M route: docs/plans/work-plan.md lines26–31 and P07b row45.
Ordinary imported-fixture UI import/equip/combat/save/reload can prove observable
casting/retaliation/stop/flee/repeat/persistence; cannot expose internal snapshot
or claim earned progression. No bridge, campaign retry or seed search. Browser
commands require separate producer/QA review of route, bounds and artifact ownership.

All QA readers released; no QA writes, execution, artifacts or processes.
