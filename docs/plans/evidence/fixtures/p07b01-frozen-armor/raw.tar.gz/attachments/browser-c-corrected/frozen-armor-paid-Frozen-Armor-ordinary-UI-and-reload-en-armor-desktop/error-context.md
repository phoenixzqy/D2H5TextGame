# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: frozen-armor.spec.ts >> paid Frozen Armor ordinary UI and reload en
- Location: tests/pwa/frozen-armor.spec.ts:60:3

# Error details

```
Error: locator.click: Target page, context or browser has been closed
Call log:
  - waiting for locator('a[href="/inventory"]').first()
    - locator resolved to <a href="/inventory" class="flex flex-col items-center justify-center gap-1 min-h-[56px] md:min-h-[64px] px-1 py-2 text-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-d2-gold text-d2-white/70 hover:text-d2-gold hover:bg-black/20">…</a>
  - attempting click action
    - waiting for element to be visible, enabled and stable

```

```
Error: write EPIPE
```