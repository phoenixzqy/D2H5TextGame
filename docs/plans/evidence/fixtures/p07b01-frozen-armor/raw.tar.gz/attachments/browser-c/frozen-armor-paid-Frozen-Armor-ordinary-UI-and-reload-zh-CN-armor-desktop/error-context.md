# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: frozen-armor.spec.ts >> paid Frozen Armor ordinary UI and reload zh-CN
- Location: tests/pwa/frozen-armor.spec.ts:60:3

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: getByTestId('combat-log').getByText('Paid Armor 施放了 冰封装甲。', { exact: true })
Expected: attached
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeAttached" with timeout 5000ms
  - waiting for getByTestId('combat-log').getByText('Paid Armor 施放了 冰封装甲。', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - navigation "主导航" [ref=e4]:
    - list [ref=e5]:
      - listitem [ref=e6]:
        - link "营地" [ref=e7] [cursor=pointer]:
          - /url: /town
          - generic [ref=e8]: 🏰
          - generic [ref=e9]: 营地
      - listitem [ref=e10]:
        - link "地图" [ref=e11] [cursor=pointer]:
          - /url: /map
          - generic [ref=e12]: 🗺️
          - generic [ref=e13]: 地图
      - listitem [ref=e14]:
        - link "战斗" [ref=e15] [cursor=pointer]:
          - /url: /combat
          - generic [ref=e16]: ⚔️
          - generic [ref=e17]: 战斗
      - listitem [ref=e18]:
        - link "背包" [ref=e19] [cursor=pointer]:
          - /url: /inventory
          - generic [ref=e20]: 🎒
          - generic [ref=e21]: 背包
      - listitem [ref=e22]:
        - link "技能" [ref=e23] [cursor=pointer]:
          - /url: /skills
          - generic [ref=e24]: ✨
          - generic [ref=e25]: 技能
      - listitem [ref=e26]:
        - link "佣兵" [ref=e27] [cursor=pointer]:
          - /url: /mercs
          - generic [ref=e28]: 🛡️
          - generic [ref=e29]: 佣兵
      - listitem [ref=e30]:
        - link "任务" [ref=e31] [cursor=pointer]:
          - /url: /quests
          - generic [ref=e32]: 📜
          - generic [ref=e33]: 任务
      - listitem [ref=e34]:
        - link "设置" [ref=e35] [cursor=pointer]:
          - /url: /settings
          - generic [ref=e36]: ⚙️
          - generic [ref=e37]: 设置
  - generic [ref=e38]:
    - banner [ref=e39]:
      - generic [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]: 第 1 波 / 共 3 波 · 血腥旷野 · 普通波
          - generic [ref=e44]: 第 1 章 · 罗格营地
        - generic [ref=e45]:
          - button "布阵" [ref=e46] [cursor=pointer]
          - button "暂停" [ref=e47] [cursor=pointer]
          - button "速度" [ref=e48] [cursor=pointer]: 1x
          - button "跳过" [ref=e49] [cursor=pointer]
          - generic [ref=e50] [cursor=pointer]:
            - checkbox "自动" [checked] [ref=e51]
            - text: 自动
          - button "逃跑" [ref=e52] [cursor=pointer]
    - main [ref=e53]:
      - generic [ref=e54]:
        - heading "战场" [level=2] [ref=e55]
        - group "法力" [ref=e56]:
          - generic [ref=e57]:
            - generic [ref=e58]:
              - generic [ref=e59]: 法力
              - generic [ref=e60]: 102 / 102
            - progressbar [ref=e62]
        - generic [ref=e63]:
          - region "我方" [ref=e64]:
            - generic [ref=e65]: 我方
            - generic [ref=e66]:
              - generic [ref=e68]: 无单位
              - generic [ref=e70]: 无单位
              - generic [ref=e72]: 无单位
              - generic [ref=e74]: 无单位
              - generic "Paid Armor" [ref=e78]:
                - img "Paid Armor" [ref=e80]
                - generic [ref=e82]: Paid Armor
              - generic [ref=e86]: 无单位
              - generic [ref=e88]: 无单位
              - generic [ref=e90]: 无单位
              - generic [ref=e92]: 无单位
          - generic [ref=e93]:
            - generic [ref=e94]:
              - generic [ref=e95]: 波次
              - generic [ref=e96]: 1/3
            - generic [ref=e98]: 交锋
          - region "敌人" [ref=e99]:
            - generic [ref=e100]: 敌人
            - generic [ref=e101]:
              - generic "堕落者 E" [ref=e105]:
                - img "堕落者 E" [ref=e107]
                - generic [ref=e109]: 堕落者 E
              - generic "堕落者 B" [ref=e115]:
                - img "堕落者 B" [ref=e117]
                - generic [ref=e119]: 堕落者 B
              - generic "堕落者 F" [ref=e125]:
                - img "堕落者 F" [ref=e127]
                - generic [ref=e129]: 堕落者 F
              - generic "堕落者 C" [ref=e135]:
                - img "堕落者 C" [ref=e137]
                - generic [ref=e139]: 堕落者 C
              - generic [ref=e143]:
                - generic "堕落者 A" [ref=e145]:
                  - img "堕落者 A" [ref=e147]
                  - generic [ref=e149]: 堕落者 A
                - generic: 倒下
              - generic "尖刺鼠 A" [ref=e154]:
                - img "尖刺鼠 A" [ref=e156]
                - generic [ref=e158]: 尖刺鼠 A
              - generic "尖刺鼠 B" [ref=e164]:
                - img "尖刺鼠 B" [ref=e166]
                - generic [ref=e168]: 尖刺鼠 B
              - generic "堕落者 D" [ref=e174]:
                - img "堕落者 D" [ref=e176]
                - generic [ref=e178]: 堕落者 D
              - generic [ref=e182]: 没有敌人
      - generic [ref=e184]:
        - heading "战斗日志" [level=2] [ref=e185]
        - log [ref=e186]:
          - generic [ref=e187]: 02:00:00第 1 回合开始
          - generic [ref=e188]: 02:00:00Paid Armor 施放了 寒冰甲。
          - generic [ref=e189]: 02:00:00Paid Armor 获得增益：frozen-armor。
          - generic [ref=e190]: 02:00:00尖刺鼠 A 施放了 弱近战。
          - generic [ref=e191]: 02:00:00尖刺鼠 A 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e192]: 02:00:00尖刺鼠 A 进入【chill】状态。
          - generic [ref=e193]: 02:00:00尖刺鼠 B 施放了 弱近战。
          - generic [ref=e194]: 02:00:00尖刺鼠 B 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e195]: 02:00:00尖刺鼠 B 进入【chill】状态。
          - generic [ref=e196]: 02:00:00堕落者 C 施放了 弱近战。
          - generic [ref=e197]: 02:00:00堕落者 C 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e198]: 02:00:00堕落者 C 进入【chill】状态。
          - generic [ref=e199]: 02:00:00堕落者 B 施放了 弱近战。
          - generic [ref=e200]: 02:00:00堕落者 B 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e201]: 02:00:00堕落者 B 进入【chill】状态。
          - generic [ref=e202]: 02:00:00堕落者 D 施放了 弱近战。
          - generic [ref=e203]: 02:00:00Paid Armor 闪避了 堕落者 D 的攻击！
          - generic [ref=e204]: 02:00:00堕落者 E 施放了 弱近战。
          - generic [ref=e205]: 02:00:00堕落者 E 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e206]: 02:00:00堕落者 E 进入【chill】状态。
          - generic [ref=e207]: 02:00:00堕落者 F 施放了 弱近战。
          - generic [ref=e208]: 02:00:00Paid Armor 闪避了 堕落者 F 的攻击！
          - generic [ref=e209]: 02:00:00堕落者 A 施放了 弱近战。
          - generic [ref=e210]: 02:00:00堕落者 A 普攻 Paid Armor，造成 1 点物理伤害。
          - generic [ref=e211]: 02:00:00堕落者 A 进入【chill】状态。
          - generic [ref=e212]: 02:00:00Paid Armor 准备出招。
          - generic [ref=e213]: 02:00:00Paid Armor 普攻 堕落者 A，造成 110012 点物理伤害。
          - generic [ref=e214]: 02:00:00堕落者 A 倒下了。
```

# Test source

```ts
  35  |   await navTo(page, 'skills');
  36  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  37  |   for (let slot = 1; slot <= 9; slot++) {
  38  |     const select = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(slot)}`, exact: true });
  39  |     await select.selectOption(armor && slot === 1 ? AUTHORED : '');
  40  |   }
  41  | }
  42  | async function enter(page: Page, english: boolean, idle = false): Promise<void> {
  43  |   await navTo(page, 'map');
  44  |   if (idle) await page.getByTestId('farm-here-a1-blood-moor').click();
  45  |   else await page.getByTestId('sub-area-row-a1-blood-moor')
  46  |     .getByRole('button', { name: english ? 'Enter' : '进入', exact: true }).click();
  47  |   await expect(page.getByTestId('combat-screen')).toBeVisible();
  48  | }
  49  | async function stop(page: Page, english: boolean, idle = false): Promise<void> {
  50  |   await page.getByRole('button', { name: idle ? (english ? 'Stop Farm' : '停止挂机') : (english ? 'Flee' : '逃跑'), exact: true }).click();
  51  |   await expect(page.getByTestId('map-screen')).toBeVisible();
  52  | }
  53  | async function wave(page: Page): Promise<number> {
  54  |   const value = /^\D*(\d+)/.exec(await page.getByTestId('wave-counter').innerText())?.[1];
  55  |   if (!value) throw new Error('Missing wave counter');
  56  |   return Number(value);
  57  | }
  58  | 
  59  | for (const locale of ['en', 'zh-CN'] as const) {
  60  |   test(`paid Frozen Armor ordinary UI and reload ${locale}`, async ({ page }, info) => {
  61  |     const english = locale === 'en';
  62  |     const errors: string[] = [];
  63  |     page.on('pageerror', error => errors.push(error.message));
  64  |     page.on('console', message => {
  65  |       if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`);
  66  |     });
  67  |     await page.clock.setFixedTime(fixedTime); // Date only; native playback and repeat timers.
  68  |     await page.goto('/');
  69  |     await createCharacter(page, { class: 'sorceress', name: NAME });
  70  |     await navTo(page, 'settings');
  71  |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  72  |     const original = await backup(page);
  73  |     const oldCap: Item = { id: 'fixture-paid-armor-old-cap', baseId: 'items/base/helm-cap',
  74  |       rarity: 'rare', level: 1, identified: true, equipped: true, equipSlot: 'head',
  75  |       affixes: [{ affixId: 'fixture-imported-life', values: new Map([['statMods.life', 999_880]]) }] };
  76  |     const newCap: Item = { ...oldCap, id: CAP, equipped: false, affixes: [
  77  |       { affixId: 'fixture-imported-life-attack', values: new Map([
  78  |         ['statMods.life', 999_880], ['statMods.attack', 100_000]
  79  |       ]) }
  80  |     ] };
  81  |     // Two explicit synthetic caps permit actual equip without a temporary max-HP clamp.
  82  |     // Imported rank20 and cleared flag enable mechanic/idle routes, not earned acceptance.
  83  |     const incoming: SaveCurrent = { ...original, player: { ...original.player,
  84  |       comboOrder: [AUTHORED], skillLevels: { 'sorceress.frozen_armor': 20 },
  85  |       derivedStats: { ...original.player.derivedStats, life: 1_000_000, lifeMax: 1_000_000, defense: 27 } },
  86  |       inventory: { ...original.inventory, backpack: [newCap],
  87  |         equipped: { ...original.inventory.equipped, head: oldCap } },
  88  |       map: { ...original.map, clearedSubAreas: [AREA] } };
  89  |     const importLabel = english ? 'Import Save' : '导入存档';
  90  |     await page.getByRole('button', { name: importLabel, exact: true }).click();
  91  |     const dialog = page.getByRole('dialog');
  92  |     await dialog.getByRole('textbox').fill(JSON.stringify(incoming, (_key, value: unknown) => value instanceof Map ? [...value] : value));
  93  |     await dialog.getByRole('button', { name: importLabel, exact: true }).click();
  94  |     await expect(dialog).toHaveCount(0);
  95  |     await navTo(page, 'inventory');
  96  |     await page.getByTestId(`inv-item-${CAP}`).click();
  97  |     await page.getByTestId('inv-primary-action').click();
  98  |     const prepared = await backup(page);
  99  |     expect(prepared.inventory.equipped.head).toMatchObject({ id: CAP, equipped: true });
  100 |     expect(prepared.player.derivedStats).toMatchObject({ life: 1_000_000, lifeMax: 1_000_000, attack: 100_022, defense: 27 });
  101 |     expect(prepared.player.skillLevels).toEqual({ 'sorceress.frozen_armor': 20 });
  102 |     expect(prepared.player.comboOrder).toEqual([AUTHORED]);
  103 |     noCombatSave(prepared);
  104 |     await attach(info, '01-imported-equipped-fixture', prepared);
  105 | 
  106 |     const cast = english ? `${NAME} casts Frozen Armor.` : `${NAME} 施放了 冰封装甲。`;
  107 |     const buff = english ? `${NAME} gains buff: frozen-armor.` : `${NAME} 获得增益：frozen-armor。`;
  108 |     const observer = await page.evaluateHandle(mpLabel => {
  109 |       const frames: Frame[] = [];
  110 |       let previous = '';
  111 |       let overflow = false;
  112 |       const sample = (): void => {
  113 |         const root = document.querySelector('[data-testid="combat-screen"]');
  114 |         if (!root) return;
  115 |         const frame: Frame = {
  116 |           mp: Number(root.querySelector(`[role="group"][aria-label="${mpLabel}"] [role="progressbar"]`)?.getAttribute('aria-valuenow')),
  117 |           logs: Array.from(root.querySelectorAll('[data-testid="combat-log"] > div > span:last-child'), node => node.textContent ?? '').slice(-8),
  118 |           enemies: Array.from(root.querySelectorAll<HTMLElement>('[data-testid="enemies-grid"] [data-testid^="unit-card-"]'), node => ({
  119 |             name: node.querySelector('[title]')?.getAttribute('title') ?? '',
  120 |             hp: Number.parseFloat(node.querySelector<HTMLElement>('.bg-red-600')?.style.width ?? 'NaN')
  121 |           }))
  122 |         };
  123 |         const next = JSON.stringify(frame);
  124 |         if (next === previous) return;
  125 |         previous = next;
  126 |         if (frames.length === 256) { overflow = true; return; }
  127 |         frames.push(frame);
  128 |       };
  129 |       const changes = new MutationObserver(sample);
  130 |       changes.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });
  131 |       return { read: () => ({ frames, overflow }), disconnect: () => changes.disconnect() };
  132 |     }, english ? 'MP' : '法力');
  133 |     try {
  134 |       await enter(page, english);
> 135 |       await expect(page.getByTestId('combat-log').getByText(cast, { exact: true })).toBeAttached();
      |                                                                                     ^ Error: expect(locator).toBeAttached() failed
  136 |       await expect(page.getByTestId('combat-log').locator('div > span:last-child').filter({ hasText: /\[chill\]|【chill】/ }).first()).toBeAttached();
  137 |       await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click();
  138 |       const observed = await observer.evaluate(handle => handle.read());
  139 |       expect(observed.overflow).toBe(false);
  140 |       expect(observed.frames.some(frame => frame.logs.includes(cast) && frame.mp === prepared.player.derivedStats.manaMax - 5)).toBe(true);
  141 |       const witness = observed.frames.find(frame => frame.enemies.some(enemy => {
  142 |         const chilled = english ? `${enemy.name} is afflicted with [chill].` : `${enemy.name} 进入【chill】状态。`;
  143 |         const status = frame.logs.indexOf(chilled);
  144 |         if (!(enemy.hp > 0) || status < 0) return false;
  145 |         return frame.logs.slice(0, status).some(line => english
  146 |           ? new RegExp(`^(CRITICAL! )?${enemy.name} (attacks|hits) ${NAME} for [1-9][0-9]* `).test(line)
  147 |           : new RegExp(`^(暴击！)?${enemy.name} (普攻 ${NAME}，造成 |对 ${NAME} 造成 )[1-9][0-9]* `).test(line));
  148 |       }));
  149 |       expect(witness).toBeDefined();
  150 |       expect(observed.frames.some(frame => frame.logs.includes(buff))).toBe(true);
  151 |       await attach(info, '02-cast-debit-hit-chill', { observed, witness });
  152 |       await production(page);
  153 |       await info.attach('03-paid-armor-viewport', { body: await page.screenshot(), contentType: 'image/png' });
  154 |     } finally {
  155 |       await observer.evaluate(handle => handle.disconnect());
  156 |       await observer.dispose();
  157 |     }
  158 |     await stop(page, english);
  159 | 
  160 |     await slots(page, false, english);
  161 |     await enter(page, english);
  162 |     await page.getByTestId('skip-button').click();
  163 |     await expect(page.getByTestId('combat-log').getByText(cast, { exact: true })).toHaveCount(0);
  164 |     await expect(page.getByTestId('combat-log').getByText(buff, { exact: true })).toHaveCount(0);
  165 |     await stop(page, english);
  166 | 
  167 |     await slots(page, true, english);
  168 |     await enter(page, english, true);
  169 |     await expect(page.getByTestId('idle-loop-panel')).toBeVisible();
  170 |     await expect(page.getByTestId('combat-log').getByText(cast, { exact: true })).toBeAttached();
  171 |     const total = Number(/\/\D*(\d+)/.exec(await page.getByTestId('wave-counter').innerText())?.[1]);
  172 |     expect(total).toBeGreaterThan(1);
  173 |     expect(total).toBeLessThanOrEqual(10);
  174 |     for (let index = 1; index <= total; index++) {
  175 |       expect(await wave(page)).toBe(index);
  176 |       await page.getByTestId('skip-button').click();
  177 |       if (index < total) await expect.poll(() => wave(page), { intervals: [50] }).toBe(index + 1);
  178 |     }
  179 |     await expect(page.getByTestId('victory-panel')).toBeVisible();
  180 |     await expect.poll(() => wave(page), { intervals: [50] }).toBe(1); // Actual1500ms auto-repeat, no button/timer override.
  181 |     await expect(page.getByTestId('combat-log').getByText(cast, { exact: true })).toBeAttached();
  182 |     await attach(info, '04-native-idle-repeat-log', await page.getByTestId('combat-log').innerText());
  183 |     await stop(page, english, true);
  184 |     const stopped = await backup(page);
  185 |     expect(stopped.meta.idleState).not.toHaveProperty('idleTarget');
  186 |     noCombatSave(stopped);
  187 |     await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  188 |     await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  189 |     await page.reload();
  190 |     await expect(page.getByTestId('export-save-button')).toBeVisible();
  191 |     const reloaded = await backup(page);
  192 |     expect(reloaded.player).toEqual(stopped.player);
  193 |     expect(reloaded.inventory).toEqual(stopped.inventory);
  194 |     expect(reloaded.map).toEqual(stopped.map);
  195 |     expect(reloaded.meta.idleState).not.toHaveProperty('idleTarget');
  196 |     noCombatSave(reloaded);
  197 |     await attach(info, '05-stop-save-reload', { stopped, reloaded });
  198 |     await enter(page, english);
  199 |     await expect(page.getByTestId('combat-log').getByText(cast, { exact: true })).toBeAttached();
  200 |     await stop(page, english);
  201 |     await production(page);
  202 |     await attach(info, '06-browser-errors', errors);
  203 |     expect(errors).toEqual([]);
  204 |   });
  205 | }
  206 | 
```