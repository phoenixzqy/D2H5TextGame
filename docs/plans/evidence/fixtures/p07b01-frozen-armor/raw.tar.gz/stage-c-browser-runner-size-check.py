from pathlib import Path
import ast,json,stat,types,hashlib
r=Path(__file__).resolve().parent
candidate=r/'stage-c-browser-runner-candidate2.py'
module=ast.parse(candidate.read_text())
function=next(node for node in module.body if isinstance(node,ast.FunctionDef) and node.name=='size')
namespace={'stat':stat}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(candidate),'exec'),namespace)
size=namespace['size']
class Entry:
    def __init__(self,mode=stat.S_IFREG,count=0,children=(),error=None):
        self.mode=mode;self.count=count;self.children=children;self.error=error;self.calls=0
    def lstat(self):
        self.calls+=1
        if self.error:raise self.error
        if self.calls>1:raise AssertionError('Repeated stat revives TOCTOU')
        return types.SimpleNamespace(st_mode=self.mode,st_size=self.count)
    def rglob(self,_pattern):return iter(self.children)
checks=[]
def verify(name,result):
    assert result,name
    checks.append(name)
verify('missing root is zero',size(Entry(error=FileNotFoundError()))==0)
verify('regular file counted by single no-follow stat',size(Entry(count=42))==42)
verify('vanished child does not discard surviving siblings',size(Entry(mode=stat.S_IFDIR,children=[Entry(count=9),Entry(error=FileNotFoundError()),Entry(count=11)]))==20)
verify('per-file over32MiB remains visible',size(Entry(count=32*1024**2+1))>32*1024**2)
verify('aggregate over64MiB remains visible',size(Entry(mode=stat.S_IFDIR,children=[Entry(count=32*1024**2),Entry(count=32*1024**2+1)]))>64*1024**2)
for name,entry,error in [('root link rejected',Entry(mode=stat.S_IFLNK),RuntimeError),('child link rejected',Entry(mode=stat.S_IFDIR,children=[Entry(mode=stat.S_IFLNK)]),RuntimeError),('permission error is not swallowed',Entry(error=PermissionError()),PermissionError)]:
    try:size(entry)
    except error:checks.append(name)
    else:raise AssertionError(name)
result={'runnerSHA256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'checks':checks,'passed':len(checks),'scope':'only artifact-size helper; no browser/product command executed, caps and process ownership code unchanged'}
with (r/'stage-c-browser-runner-size-check.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
