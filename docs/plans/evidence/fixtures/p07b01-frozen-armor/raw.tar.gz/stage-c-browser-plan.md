# P07b01 ordinary browser route (proposal)

Root owns writes/execution in the already claimed umbrella worktree. This is
explicit imported-fixture integration proof, never earned progression, campaign,
balance, RNG-seed search or internal paid-snapshot proof.

Separate increment after native C commit; own only
- tests/pwa/frozen-armor.spec.ts
- tests/pwa/frozen-armor.config.ts

Run the real production bundle after current native U/T/L/bridge/build. No
VITE_E2E, test bridge, app/store API injection, engine skill override or timer
acceleration. Existing UI helper createCharacter/navTo only (no broad reset).
Fresh isolated Playwright context per case, fixed Date only for reproducibility;
native timers/playback and auto-repeat delay continue normally. Known localhost
preview URL only. Read-only page evaluate permitted for overflow, absence of
bridge, rendered DOM observers, optional read-only IndexedDB evidence; never
credential access or app state mutation. Imports/equipment/combos/save all via UI.

Matrix: en and zh-CN at1280x800desktop and360x640mobile,4cases, sequential,
workers1/retries0, each50s budget; one complete command ceiling240s+2s exact
child cleanup. Choose a free strict loopback port without killing occupants.
Playwright webServer owns preview lifecycle and uses already validated dist,
never rebuilding over retained output. No video/trace; failure screenshot and
one normal viewport screenshot/case, bounded DOM/save/console JSON attachments.
32MiB per log/report,64MiB aggregate RAW+dist+.vite; all outputs inside existing
root RAW attachment subdirectory. Preserve failed outputs. Existing unit/build
runner unchanged; separate browser wrapper will use the same process-identity
tracking/ancestry/cleanup/caps with explicit240s browser limit.

Concrete route:
1. Create Sorceress through UI; choose locale. Export valid save. Construct
   disclosed fixture from that export: allocation FrozenArmor20, combo Armor
   only, uncapped ordinary MP, large life/attack fixture cap in backpack;
   BloodMoor cleared only to enable idle UI. No paid buff/snapshot/save field.
2. Import JSON through Settings dialog and equip cap through Inventory UI.
   Export preparation and assert exact imported/equipped state, no frozenArmor.
3. Enter ordinary manual BloodMoor. DOM observer catches Armor cast, MP debit,
   buff marker, positive enemy damage followed by living attacker Chill. Pause,
   capture visible log/screenshot/overflow and bridge absence. Flee through UI.
4. Remove Armor from combo through Skills UI, keeping learned allocation.
   Enter a fresh manual run; observe clean initial hero marker and drain via
   native Skip control; recording contains no Armor cast. Flee/return as UI
   permits. (Native tests own internal snapshot checks.)
5. Restore Armor combo through Skills UI, enter idle farm via Map. Capture paid
   first-wave cast; use native Skip to complete actual waves without outcome
   injection. Observe actual final victory followed by native1500ms auto-repeat
   starting newWave1 and a new paid cast. Stop via actual UI button and verify
   map/idle target omission in exported save. No additional gameplay attempts.
6. Save through Settings, verify committed/exported save omits combat snapshot,
   reload page, compare restored player/gear/skills/combos/map save fields, and
   enter fresh manual run to observe a fresh paid cast. Capture no browser errors.

If first bounded route fails, preserve failure and diagnose test-vs-runtime;
no stronger preparation, gameplay retry or recipe/seed search. Additional
browser execution requires reviewed correction keeping the same gameplay recipe.

Exact selectors, imported gear shape and event witnesses still need concrete
spec review before the command. UI route cannot prove internal captured potency
or earned preparation; native engine/store tests own potency/invalidation proof.
