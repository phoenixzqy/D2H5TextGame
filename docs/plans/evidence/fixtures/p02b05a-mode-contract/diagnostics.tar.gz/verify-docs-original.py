from pathlib import Path
import re,subprocess,json,hashlib
r=Path(__file__).parent;w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
files=['docs/plans/decisions/D07-D11-first-act-route-v1.md','docs/plans/decisions/D07-active-mode-measurement-v1.md','docs/design/maps-spec.md']
links=[]
for name in files:
 p=w/name
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in target or target.startswith('#'):continue
  path=target.split('#')[0];assert (p.parent/path).is_file(),(name,target);links.append([name,target])
 for path in re.findall(r'`((?:src|tests)/[^`]+\.(?:ts|tsx|json))(?::[0-9]+)?`',p.read_text()):assert (w/path).is_file(),path
out=subprocess.check_output(['git','status','--short','--untracked-files=all'],cwd=w,text=True)
assert all(line[3:] in files for line in out.splitlines()),out
assert not subprocess.check_output(['git','diff','HEAD','--','src','tests','scripts','package.json','package-lock.json','vite.config.ts','vitest.config.ts'],cwd=w,text=True)
subprocess.run(['git','diff','--check'],cwd=w,check=True)
record={'task':'P02b05a','inputHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'files':{n:hashlib.sha256((w/n).read_bytes()).hexdigest() for n in files},'localLinks':links,'runtimeTestsScriptsPackageConfigChanged':False,'gameplayRuns':0,'checks':'links/source paths/scopedstatus/gitdiffcheck pass; no new tests/build; P02b04U/T/L historical only'}
(r/'document-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
