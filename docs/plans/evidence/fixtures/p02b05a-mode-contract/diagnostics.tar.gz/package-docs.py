from pathlib import Path
import json,hashlib,tarfile,subprocess,stat
r=Path(__file__).parent;w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');d=w/'docs/plans/evidence/fixtures/p02b05a-mode-contract';d.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();v=json.loads((r/'document-verification.json').read_text())
for name,h in v['files'].items():
 assert sha((w/name).read_bytes())==h
 p=r/'documents'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((w/name).read_bytes())
paths=sorted(p for p in r.rglob('*') if p.is_file());assert all(not p.is_symlink() and stat.S_ISREG(p.stat().st_mode) for p in paths)
records=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths]
a=d/'diagnostics.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=9) as t:
 for p in paths:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
p={'task':'P02b05a','inputHead':v['inputHead'],'scope':'three documentation files only; no new runtime/test/gameplay; later executable freeze/RED remains required','verification':v,'commands':[json.loads(p.read_text()) for p in sorted(r.glob('*.meta.json'))],'reviews':{'designTechnicalPlan':'ready;GDAPPROVE/TDAPPROVE','concreteInitial':'GDAPPROVE/TDCONCERNS property/lifecycleprecision, bothcorrectedbeforecommit','final':'GDAPPROVE/TDAPPROVE/producerAPPROVE/QAAPPROVE; allreleased'},'archive':{'file':a.name,'bytes':a.stat().st_size,'sha256':sha(a.read_bytes()),'files':records},'cleanup':{'owner':'root','state':'pendingpacketreview; closingledgerrecordresult','paths':[str(r)],'noNewBuildOrCache':True,'installedTools':'preserved','overallWorktree':'retainedforactivefullv1'},'limitations':['HistoricalP02b04U/T/L notnewruntimevalidation','Documentcheck originalfailedonpreexistingglob thenabsentschemahandofftarget; narrowedsourcepathcheck to newdocs, all3links/scopedstatusstillverified; noauthoringtextorassertionchanged','No earnedclear/UIidle/Den/Andariel/campaign/pacing/C/G/fullv1acceptance','No newcode/test/run or executableRED; nextcardmustfreezeownbounds/tests']}
(d/'packet.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'packetSha':sha((d/'packet.json').read_bytes()),'archiveSha':p['archive']['sha256'],'records':len(records),'bytes':a.stat().st_size,'commands':len(p['commands'])}))
