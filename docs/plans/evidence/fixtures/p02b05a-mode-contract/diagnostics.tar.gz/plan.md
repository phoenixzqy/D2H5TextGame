# P02b05a — first-act route and active-mode diagnostic contract

Original full private-v1 objective remains active; C0-C4/G0-G7 unaccepted.
Root alone edits/executes; producer/design/QA read-only review. P02b04 closes
feature/evidence then cleanup/closing ledger before repository edits for this
child. This child changes documentation only; no gameplay, data, test, code,
package, config, schema, dependency or lock edits. No new gameplay attempt.

## Scope / <=3 outcome criteria

1. New scoped D07/D11 first-act route decision records act-wide Act1 access,
Den quest/skill-point role, exact current Act2questORCatacombs gate. Reconcile
maps-spec12 sequential previous-area/waypoint wording for this first-act route
with GDD7.3 and scoped D11talk/claim safety; retain later-act detail/fullD11 as
open rather than assert source alone is authority. Do not remove legacy quest
unlocks fields or alter engine/data. Explain Den->ColdPlains metadata does not
produce an additional runtime unlock under the chosen access rule. Preserve
canonical Den quest/boss/campaign acceptance. Alternative sequential gating is
a future explicit progression change, not a fallback after recipe failure.

2. New D07 active-mode measurement contract uses separately tagged, test-owned
restored synthetic baseline for one manual/idle pair, explicit act1BloodMoor,
clock/seed/ordinal/pity. Exact same complete domain/resource/meta tuple+anchor,
no active run; store methods/data/Date/pity isolation. No arbitrary external
snapshot importer; strict accepted manual-only v1/v2 unchanged. Report baseline
synthetic nature and synthetic clear marker if inserted for routing; never
call it earned eligibility or new-character campaign evidence. Low-level idle
start bypasses UI clear gate unless a real full clear is earned. Define actual
production path CombatScreen/startSubAreaRun/advanceWaveOrFinish; dormant ticker
excluded. Compare actual encounter inputs first; if same require seeded battle
match; if different report planner difference/downstream outcomes. Both modes
currently retain forced elite guards, idle additionally rolls unforced waves
and pity. Treat these as observed diagnosed mode differences, not implicit
ratification of all idle design. Record qualification, pity-before-award,
partial rewards/carry, finalclear, raw IDs and semantic reward comparison,
stop/repeat lifecycle scope. No assertion of victory/equality as result oracle.

3. Freeze next executable card's bounded scope and verifier, not its unreviewed
results: additive restored-baseline diagnostic (<=5writable source/test files per
child; expand if needed), genuine missing-capability/real-production RED probes,
isolation success/error/early-refusal, normalpity/hardpity11, presentation/roster/
recording/award/domain differences separately observed. Nativeplayback stops
firstterminalnonwin, no automaticrepeat or arbitrary state importer. Report
source/frozen baseline provenance. Document separate future fresh-earned first
BloodMoorfullclear requirement (3nativewaves, manual; legally earned resources,
finite predeclared prep/attempt/time before execution) and no-promise failure
disposition. No new farm/seed/build search here. Actual fullclear precedes any
claim of earned idle access. Firstact routing/idle measurement does not accept
P11/fullidle/campaign/C1; Den/Andariel/UI/save/mobile remain open.

## Files and verification

Own new docs/plans/decisions/D07-D11-first-act-route-v1.md,
new docs/plans/decisions/D07-active-mode-measurement-v1.md,
docs/design/maps-spec.md12 narrow annotation, and execution-ledger link/status.
Use independently reviewed concrete prose before committing. Root applies only
after plan ready and P02b04 closes. No tests merely mirroring docs; verify links,
exact source claims, scoped diff/check and no runtime bytes changed. Previous
P02b04 U/T/L remains explicitly historical; no fresh gameplay/build validation
claimed. If executable code becomes necessary, stop this doc child and freeze
its own RED/plan first. Feature/contract commit then separate closing-ledger
after consumers release and exact ownedRAW cleanup. Preserve installed tools;
no push/PR/merge/deploy or worktree release while fullv1 active.
