from pathlib import Path
import json,hashlib,gzip,os,socket
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
p=Path(__file__).parent
out=root/'docs/plans/evidence/fixtures/barbarian-basic-aoe';out.mkdir(parents=True,exist_ok=True)
def write(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
def one(folder,pattern):
 files=list(folder.glob(pattern));assert len(files)==1,(folder,pattern,files);return files[0]
def domains(value):return {key:value[key] for key in ['player','inventory','map','mercs','formation']}
pairs=[];cases=[];geometry=[]
for folder in sorted(p.glob('browser-*')):
 if not folder.is_dir():continue
 r=json.loads((folder/'browser-report.json').read_text());assert not r['failures'];assert len(r['cases'])==4
 for c in r['cases']:
  label=c['label'];assert c['pass'] and not c['errors'] and c['pairs']==['rank1','rank2'];assert c['offlineContinue']=={'pass':True,'exactDomains':['player','inventory','map','mercs','formation'],'freshPage':True,'networkOffline':True}
  cases.append(c)
  for rank in ['rank1','rank2']:
   a=one(folder,label+'-'+rank+'-before-*.json');b=one(folder,label+'-'+rank+'-after-*.json');da=json.loads(a.read_text());db=json.loads(b.read_text());assert da['version']==db['version']==22;assert domains(da)==domains(db)
   pairs.append({'label':label,'kind':rank,'before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
  a=one(folder,label+'-rank2-after-*.json');b=one(folder,label+'-offline-continued-*.json');assert domains(json.loads(a.read_text()))==domains(json.loads(b.read_text()))
  pairs.append({'label':label,'kind':'offline-fresh-page','before':str(a.relative_to(p)),'after':str(b.relative_to(p)),'exactDomains':['player','inventory','map','mercs','formation']})
 geometry.extend(r['geometry'])
assert len(cases)==16 and len(geometry)==80 and len(pairs)==48
for g in geometry:assert g['overflow']==0 and g['allocate']['width']>=44 and g['allocate']['height']>=44
write('browser-audit.json',{'cases':cases,'geometry':geometry,'consolePageErrors':[],'screenshots':len(list(p.glob('browser-*/*.png'))),'individuallyInspected':['browser-en-360/en-360-bash-current-next.png','browser-en-360/en-360-whirlwind-current-next.png','browser-zh-CN-360/zh-CN-360-leap-attack-current-next.png','browser-en-1280/en-1280-war-cry-current-next.png'],'limits':'Synthetic imported L30/resources/helmet and fixed Date.now; no earned campaign or balance claim. Geometry covers selected skill allocation control; no full accessibility audit.'})
write('save-pairs-audit.json',{'ordinaryPairs':32,'offlinePairs':16,'pairs':pairs,'saveVersion':22,'pass':True})
f=json.loads((p/'frozen.json').read_text())
for key,base in [('source',root),('build',p/'build')]:
 drift=[name for name,sha in f[key].items() if not (base/name).is_file() or hashlib.sha256((base/name).read_bytes()).hexdigest()!=sha];assert not drift,(key,drift)
sha=hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest();assert sha==f['genuine']
write('freeze-audit.json',{'sourceCount':len(f['source']),'buildCount':len(f['build']),'sourceDrift':[],'buildDrift':[],'genuine':sha,'pass':True})
write('author-review.json', {'reviewer':'root author only; independent acceptance open',
 'security':{'verdict':'pass','scope':'Local presentation/tests and synthetic browser/native evidence','findings':[], 'constraints':['No dependency, saved-data schema or external action','No genuine campaign action','No runtime engine or game-data edits']},
 'planReview':{'verdict':'ready','contract':'docs/plans/decisions/D04-barbarian-basic-aoe-v1.md','requirements':['Existing single/all-hostile Physical attacks','Independent per-target HP loss with one payment','Exact on-hit ordinary/boss Stun and actual action interruption','Native authority/allocation/wave carry/save roundtrip','Bilingual current/next/MAX and mobile/desktop public flows']},
 'codeReview':{'verdict':'no blocking author finding','axes':{
 'correctness':'Inspected 48 causal, eight native and 32 UI cases. Literal contract damage ranges/costs, actual HP/MP, replay/playback, dead/friendly targets, criticals/Defense/resistance, lethal reflection, exact control/expiry/resumption and native ownership/aliases are checked. Whirlwind exercises shared Chill/Burn/boss combo factors. War Cry prerequisite passives change next-wave stats without refilling current HP/MP.',
 'readability':'One bounded dynamic-description branch uses existing computed display stats and i18n; test fixtures state synthetic provenance. No new runtime abstraction.',
 'architecture':'Existing pure engine/targeting/mitigation/control paths are verified without replacing formulas. No game data/schema, persistence or save-version changes.',
 'security':'Description keys come from an exact four-ID allowlist. No eval/network/credentials/dependencies; browser imports are explicit synthetic saves via public controls.',
 'performance':'Production code adds one bounded four-ID check. No broad performance-budget claim; existing large-bundle/art-manifest warnings remain.'}},
 'retainedFailures':['32 presentation REDs','Four fixture failures incorrectly assuming a merc cannot receive enemy damage; corrected to actual hostile HP accounting while asserting no friendly targets','Eight template-expression lint errors corrected with String()','One optional skillLevels type error corrected with an explicit fixture guard','First full suite stopped on the exact owned Vitest PID and is not a pass'],
 'limits':['Independent design/QA and earned balance remain open','No earned builds, 30–50-hour pacing, complete campaign/endgame or C2–C4/full G0–G7 claim','Howl/Taunt probes intentionally fail and receive no credit']})
print('Verified 16cases / 32ordinary pairs / 16offline pairs / 80geometry; source/build/genuine hashes exact.')
