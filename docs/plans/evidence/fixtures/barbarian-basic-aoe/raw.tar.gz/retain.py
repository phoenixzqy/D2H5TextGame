from pathlib import Path
import json,hashlib,tarfile,re,gzip
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');p=Path(__file__).parent
out=root/'docs/plans/evidence/fixtures/barbarian-basic-aoe';out.mkdir(parents=True,exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(file,value):file.write_text(json.dumps(value,indent=2)+'\n')
labels=['types-corrected','lint-final','full-corrected','precache-final','build-final','corrected-focused','lint-corrected-focused','browser-en-360','browser-zh-CN-360','browser-en-1280','browser-zh-CN-1280','helper-lifecycle']
receipts={label:json.loads((p/(label+'-result.json')).read_text()) for label in labels}
for label,r in receipts.items():assert r['exitCode']==0,(label,r)
full=(p/'full-corrected.log').read_text(errors='replace');m=re.search(r'Test Files\s+(\d+) passed.*?Tests\s+(\d+) passed\s*\|\s*(\d+) skipped',full,re.S);assert m,m
fullFiles,fullTests,skips=map(int,m.groups());assert (fullFiles,fullTests,skips)==(703,15329,2),(fullFiles,fullTests,skips)
f=json.loads((p/'frozen.json').read_text())
for key,base in [('source',root),('build',p/'build')]:
 for name,want in f[key].items():assert sha((base/name).read_bytes())==want,(key,name)
assert sha(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))==f['genuine']
failed={label:json.loads((p/(label+'-result.json')).read_text()) for label in ['presentation-red','causal-controls','lint-focused','types-final','full-final','next-warcries','next-warcries-active-caster']}
dump(out/'terminal-results.json',{'finalPass':receipts,'fullTests':fullTests,'fullFiles':fullFiles,'existingSkips':skips,'failedOrStopped':failed,'collectorTermination':json.loads((p/'browser-collector-observation.json').read_text()),'engine':'No engine/game-data edits. Existing engine cases are included in the full suite; no new separate engine run is claimed.'})
files=[file for file in sorted(p.rglob('*')) if file.is_file() and not file.is_symlink() and not file.is_relative_to(p/'build')]
archive=out/'raw.tar.gz';index=[]
with tarfile.open(archive,'w:gz') as tar:
 for file in files:
  name=str(file.relative_to(p));index.append({'path':name,'sha256':sha(file.read_bytes()),'bytes':file.stat().st_size});tar.add(file,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for member in index:
  stream=tar.extractfile(member['path']);assert stream is not None and sha(stream.read())==member['sha256']
dump(out/'packet.json',{'archive':'raw.tar.gz','archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'members':index,'excludedDisposable':{'build':'761 unchanged build assets represented by frozen hashes; no duplicate build copy'},'receiptNote':'Only finalPass entries are terminal passes. Initial collector terminated with143 after16case reports; rerun per-group receipts are retained separately. The initial type failure/stopped full and intentional warcry failures are not passes.','verification':{'archiveMembers':len(index),'allMemberHashesMatch':True,'sourceFiles':len(f['source']),'buildFiles':len(f['build']),'fullFiles':fullFiles,'fullTests':fullTests,'skips':skips}})
print(json.dumps({'archiveMembers':len(index),'archiveBytes':archive.stat().st_size,'fullFiles':fullFiles,'fullTests':fullTests,'skips':skips}))
