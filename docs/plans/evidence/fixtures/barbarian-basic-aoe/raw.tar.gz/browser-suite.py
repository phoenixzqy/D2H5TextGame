import os,subprocess
from pathlib import Path
p=Path(__file__).parent
for width in ['360','1280']:
 for locale in ['en','zh-CN']:
  env={**os.environ,'BROWSER_WIDTH':width,'BROWSER_LOCALE':locale,'BROWSER_RUN':'browser-'+locale+'-'+width}
  subprocess.run(['node',str(p/'browser.cjs')],env=env,check=True)
