import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { playerToCombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/stores/combatHelpers';
import { runBattleRecorded } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/combat';
import { resetRegistry, loadDefaultSkills } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/skills/registry';
import type { CombatUnit } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/combat/types';
resetRegistry();loadDefaultSkills();const observations=[];
for(const slug of ['howl','taunt'])for(const rank of [1,2,20])for(const seed of [7,19,41,97]){
 const id='skills-barbarian-'+slug;
 const levels=slug==='howl'?{[id]:rank}:{'skills-barbarian-howl':1,[id]:rank};
 const native=playerToCombatUnit({...createMockPlayer('Synthetic warcry probe','barbarian'),id:'hero',level:30,skillLevels:levels,comboOrder:[id]});assert.deepEqual(native.skillOrder,[id]);
 const hero:CombatUnit={...native,life:1000000,mana:100,manaRegenPerSecond:0,manaRegenBaselinePerSecond:0,
 statuses:[{id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:1701}],
 stats:{...native.stats,lifeMax:1000000,manaMax:100,attack:200,attackSpeed:100,defense:100,magicResist:0,critChance:0,physDodge:0,magicDodge:0,resistances:{physical:0,fire:0,cold:0,lightning:0,arcane:0,poison:0}}};
 const ally:CombatUnit={...hero,id:'ally',kind:'merc',skillOrder:[],skillLevels:{},statuses:[{id:'stun',sourceId:'synthetic-hold',stacks:1,remaining:-1,appliedAtMs:0}],stats:{...hero.stats,attackSpeed:50}};
 const enemy:CombatUnit={...ally,id:'enemy',side:'enemy',kind:'monster',statuses:[]};
 const input={seed,playerTeam:[hero,ally],enemyTeam:[enemy]},before=structuredClone(input),out=runBattleRecorded(input);assert.deepEqual(input,before);assert.deepEqual(runBattleRecorded(input),out);
 const cost=Math.max(0,Math.round((slug==='howl'?4:3)-.05*(rank-1)));assert.equal(out.result.playerTeam[0]?.mana,100-cost);assert.equal(out.events.filter(e=>e.kind==='mana'&&e.reason==='cast').length,1);
 const marker=out.events.filter(e=>e.kind==='status'&&e.statusId===slug);assert.equal(marker.length,1);
 const during=out.events.filter(e=>e.simClockMs>=1700&&e.simClockMs<2700&&(e.kind==='action'&&e.actor==='enemy'||e.kind==='damage'&&e.source==='enemy'));
 observations.push({slug,rank,seed,cost,marker,during,violatesAdvertisedEffect:during.some(e=>slug==='howl'?e.kind==='action':e.kind==='damage'&&e.target==='ally')});
}
const output={synthetic:true,base:'3bef78ad plus frozen basic/AOE presentation/tests; Howl and Taunt unchanged',observations};
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-basic-aoe-v0124dxi/warcry-observations.json',JSON.stringify(output,null,2));console.log(JSON.stringify(output,null,2));
assert.ok(observations.every(o=>!o.violatesAdvertisedEffect),'Paid warcry markers do not prevent hostile actions or force attacks to the caster.');
