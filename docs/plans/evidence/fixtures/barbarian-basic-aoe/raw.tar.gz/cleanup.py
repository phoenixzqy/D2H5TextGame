from pathlib import Path
import json,hashlib,tarfile,socket,os
p=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-barbarian-basic-aoe-v0124dxi')
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=root/'docs/plans/evidence/fixtures/barbarian-basic-aoe'
assert p.is_dir() and not p.is_symlink() and p.resolve()==p
packet=json.loads((out/'packet.json').read_text());frozen=json.loads((p/'frozen.json').read_text());record=json.loads((p/'recorded-processes.json').read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest()
assert sha((out/'raw.tar.gz').read_bytes())==packet['archiveSha256']
expected={m['path']:m['sha256'] for m in packet['members']}
expected.update({'build/'+name:want for name,want in frozen['build'].items()})
files=[q for q in p.rglob('*') if q.is_file()];assert not any(q.is_symlink() for q in p.rglob('*'))
assert {str(q.relative_to(p)) for q in files}==set(expected)
for q in files:assert q.resolve().is_relative_to(p) and sha(q.read_bytes())==expected[str(q.relative_to(p))],str(q)
with tarfile.open(out/'raw.tar.gz','r:gz') as tar:
 assert set(tar.getnames())=={m['path'] for m in packet['members']}
 for m in packet['members']:
  raw=tar.extractfile(m['path']);assert raw is not None and sha(raw.read())==m['sha256']
alive=[r['pid'] for r in record['processes'] if Path('/proc',str(r['pid'])).exists()];assert not alive,alive
ports={}
for port in [4504,4505]:
 with socket.socket() as s:
  s.settimeout(0.3);ports[str(port)]='closed' if s.connect_ex(('127.0.0.1',port))!=0 else 'open'
assert all(value=='closed' for value in ports.values()),ports
profile=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/playwright_chromiumdev_profile-drzuLt');assert not profile.exists()
removed=[];failures=[]
for q in files:
 try:q.unlink();removed.append(str(q.relative_to(p)))
 except OSError as exc:failures.append({'path':str(q),'error':str(exc)})
for q in sorted([q for q in p.rglob('*') if q.is_dir()],key=lambda q:len(q.parts),reverse=True):
 try:q.rmdir()
 except OSError as exc:failures.append({'path':str(q),'error':str(exc)})
try:p.rmdir()
except OSError as exc:failures.append({'path':str(p),'error':str(exc)})
remaining=[str(q) for q in p.rglob('*')] if p.exists() else []
result={'scratch':str(p),'archiveMembersVerified':len(packet['members']),'buildFilesVerified':len(frozen['build']),'removedFiles':len(removed),'removedPaths':removed,'recordedPidCount':len(record['processes']),'allRecordedPidsAbsent':not alive,'ports':ports,'toolManagedProfileAbsent':str(profile),'scratchAbsent':not p.exists(),'remaining':remaining,'failures':failures,'preserved':['Source and Git history','Retained evidence','Shared caches and installed tools','Active umbrella worktree/branch/claim']}
(out/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='removedPaths'}));assert not failures and not remaining and not p.exists()
