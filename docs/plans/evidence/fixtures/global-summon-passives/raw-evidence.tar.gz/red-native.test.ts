import { mockSyntheticEntryPools } from '@/test/fixtures/synthetic-entry-pools';
// Imported levels, points, survival gear, wait and finisher are unearned integration
// scaffolding. Real stores, production wave staging and engine; only disk I/O mocked.
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
vi.mock('./save-adapter', () => ({ hasSave: vi.fn(), loadSave: vi.fn(),
  saveSave: vi.fn(() => Promise.resolve(undefined)), deleteSave: vi.fn() }));
import { createMockPlayer } from '@/features/character/createMockPlayer';
import { deriveStats } from '@/engine/progression/stats';
import { loadDefaultSkills, registerSkill, resetRegistry } from '@/engine/skills/registry';
import type { Item } from '@/engine/types/items';
import { abortSubAreaRun, advanceWaveOrFinish, refreshActivePlayerCombatConfig,
  resetIdleElitePity, startSubAreaRun } from './combatHelpers';
import { inspectRecordedWaves } from './recordedWaveReceipt';
import { armIronGolemSelection, useIronGolemSelectionStore } from './ironGolemSelectionStore';
import { __resetPersistenceForTests } from './persistence';
import { useCombatStore } from './combatStore';
import { usePlayerStore } from './playerStore';
import { useInventoryStore } from './inventoryStore';
import { useMapStore } from './mapStore';
import { useMercStore } from './mercStore';
import { useFormationStore } from './formationStore';
import { useMetaStore } from './metaStore';
import { useHydrationStore } from './hydrationStore';
const CLAY = 'necromancer.clay_golem', MASTERY = 'necromancer.golem_mastery';
const WAIT = 'fixture.golem-native-wait', FINISH = 'fixture.golem-native-finisher';
const stores = [useCombatStore, usePlayerStore, useInventoryStore, useMapStore,
  useMercStore, useFormationStore, useMetaStore] as const;
function required<T>(value: T | undefined | null): T {
  if (value === undefined || value === null) throw new Error('Missing native Golem fixture');
  return value;
}
const player = () => required(usePlayerStore.getState().player);
const published = () => required(inspectRecordedWaves().currentPublished);
// candidateRun is a live lifecycle cursor; compare only frozen battle evidence.
function frozenWave(binding: ReturnType<typeof published>['binding']) {
  return { input: binding.engineInput, recording: binding.recording, publication: binding.publication };
}
function reset(): void {
  __resetPersistenceForTests(); abortSubAreaRun(); resetIdleElitePity();
  for (const store of stores) store.getState().reset();
}
function arrange(mastery: number): void {
  const coreStats = { strength: 15, dexterity: 25, vitality: 20, energy: 21 };
  usePlayerStore.getState().setPlayer({ ...createMockPlayer('Unearned Golem waves', 'necromancer'),
    id: 'golem-native-hero', level: 30, coreStats, derivedStats: deriveStats(coreStats, 30),
    skillPoints: 4, skillLevels: { [CLAY]: 1, ...(mastery ? { [MASTERY]: mastery } : {}) },
    comboOrder: [CLAY, WAIT, FINISH] });
  const cap: Item = { id: 'fixture-golem-native-cap', baseId: 'items/base/helm-cap',
    rarity: 'rare', level: 1, identified: true, equipped: false,
    affixes: [{ affixId: 'fixture-imported-golem-survival', values: new Map([
      ['statMods.life', 1000000], ['statMods.defense', 1000000], ['statMods.mana', 1000],
      ['statMods.attackSpeed', -63], ['statMods.attack', -79], ['statMods.critChance', -0.05]
    ]) }] };
  useInventoryStore.getState().addItem(cap);
  expect(useInventoryStore.getState().equipItem(cap)).toEqual({ ok: true });
  usePlayerStore.getState().setPlayer({ ...player(), derivedStats: {
    ...player().derivedStats, life: 1000, mana: 100 } });
}
function start(): void {
  expect(startSubAreaRun({ act: 1, subAreaId: 'areas/act1-blood-moor', mode: 'manual',
    runSeed: 7, challengeOrdinal: 0 })?.totalWaves).toBeGreaterThan(2);
  expect(published().binding.recording.outcome.winner).toBe('player');
}
function drain(): void {
  const count = useCombatStore.getState().recordedEvents.length;
  for (let i = 0; i < count; i++) useCombatStore.getState().advanceEvent();
  expect(useCombatStore.getState().playbackComplete).toBe(true);
}
function golem() {
  const summons = published().binding.recording.events.filter(e => e.kind === 'summon');
  expect(summons).toHaveLength(1);
  return required(summons[0]);
}
beforeEach(() => {
  mockSyntheticEntryPools();
  reset(); resetRegistry(); loadDefaultSkills(); useHydrationStore.getState().setStatus('ready');
  vi.spyOn(Date, 'now').mockReturnValue(1792454400000);
  registerSkill({ id: WAIT, archetype: 'fixture', target: 'self', isBuff: false, cooldown: 4,
    manaCost: 0, minLevel: 1, effects: [{ kind: 'buff', id: WAIT, duration: -1 }] });
  registerSkill({ id: FINISH, archetype: 'fixture', target: 'all-enemies', cooldown: 1,
    manaCost: 0, minLevel: 1, effects: [{ kind: 'damage', damageType: 'physical', base: [100000, 100000] }] });
});
afterEach(() => {
  reset(); useHydrationStore.getState().setStatus('idle');
  resetRegistry(); loadDefaultSkills(); vi.restoreAllMocks();
});

it('applies learned global summon life, attack and all six resistances through native wave staging', () => {
  arrange(1);
  usePlayerStore.getState().setPlayer({ ...player(), skillLevels: { ...player().skillLevels,
    'necromancer.summon_mastery': 1, 'necromancer.summon_resist': 1 } });
  start();
  const event = golem();
  // 6% local +5% global, summed over the fresh rank-one 220 HP baseline.
  expect(event.unit.stats.lifeMax).toBeCloseTo(244.2, 12);
  expect(event.unit.stats.attack).toBeCloseTo(24.48, 12);
  expect(event.unit.stats.resistances).toEqual({ physical: 12, fire: 2, cold: 2,
    lightning: 2, arcane: 2, poison: 2 });
  expect(event.unit.life).toBe(event.unit.stats.lifeMax);
});

it('learns both passives for the next wave without mutating the current recording or refilling hero resources', () => {
  arrange(1); start();
  const previous = published().binding;
  const frozen = structuredClone(frozenWave(previous));
  const finalHero = required(previous.recording.outcome.finalPlayerTeam.find(u => u.id === player().id));
  expect(usePlayerStore.getState().allocateSkillPoint('skills-necromancer-summon-mastery')).toBe('ok');
  expect(usePlayerStore.getState().allocateSkillPoint('skills-necromancer-summon-resist')).toBe('ok');
  refreshActivePlayerCombatConfig();
  expect(published().binding).toBe(previous);
  expect(frozenWave(previous)).toEqual(frozen);
  drain(); expect(advanceWaveOrFinish()).toBe('next-wave');
  const current = published().binding;
  const hero = required(current.engineInput.playerTeam[0]);
  expect([hero.life, hero.mana, hero.manaRegenCarry, hero.manaRegenCompensation, hero.manaRegenExactCarry])
    .toEqual([finalHero.life, finalHero.mana, finalHero.manaRegenCarry, finalHero.manaRegenCompensation, finalHero.manaRegenExactCarry]);
  expect(golem().unit.stats.lifeMax).toBeCloseTo(244.2, 12);
  expect(golem().unit.stats.resistances.fire).toBe(2);
  expect(frozenWave(previous)).toEqual(frozen);
});
