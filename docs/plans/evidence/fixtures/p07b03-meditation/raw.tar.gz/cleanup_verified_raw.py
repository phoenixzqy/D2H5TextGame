from pathlib import Path
import json,hashlib,tarfile,subprocess,datetime,stat
wt=Path.cwd().resolve();raw=Path(__file__).resolve().parent
packetpath=wt/'docs/plans/evidence/fixtures/p07b03-meditation/packet.json';packet=json.loads(packetpath.read_text());archive=packetpath.parent/'raw.tar.gz'
assert Path(packet['rawRoot'])==raw and raw.resolve()==raw and not raw.is_symlink()
assert packet['independentDurableReview']['verdict']=='APPROVE' and packet['independentDurableReview']['readersReleased']
assert subprocess.check_output(['git','show','HEAD:docs/plans/evidence/fixtures/p07b03-meditation/raw.tar.gz'])==archive.read_bytes()
assert hashlib.sha256(archive.read_bytes()).hexdigest()==packet['archive']['sha256']
manifest=packet['rawManifest'];assert set(x['path'] for x in manifest)==set(str(p.relative_to(raw)) for p in raw.rglob('*') if p.is_file())
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member,x in zip(members,manifest):
  assert member.isfile() and member.name==x['path'] and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
  body=tar.extractfile(member).read();p=raw/x['path'];assert p.resolve()==p and stat.S_ISREG(p.lstat().st_mode)
  assert len(body)==x['bytes']==p.stat().st_size and hashlib.sha256(body).hexdigest()==x['sha256']==hashlib.sha256(p.read_bytes()).hexdigest()
for x in packet['currentSources']:
 p=wt/x['path'];assert p.stat().st_size==x['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
union=json.loads((raw/packet['processUnion']['record']).read_text())
for pid,ticks in union['identities']:
 p=Path('/proc')/str(pid)/'stat'
 try:fields=p.read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=ticks
for p in raw.glob('*disposable-inventory.json'):
 v=json.loads(p.read_text());assert all(not Path(x['path']).exists() for x in v['files'])
assert not (wt/'dist').exists() and not (wt/'node_modules/.vite/vitest/results.json').exists()
assert not subprocess.check_output(['git','-C','/home/felixzhao/workspace/D2H5TextGame','status','--porcelain'],text=True)
dirs=sorted((p for p in raw.rglob('*') if p.is_dir()),key=lambda p:len(p.parts),reverse=True)
assert all(not p.is_symlink() and p.resolve()==p and p.is_relative_to(raw) for p in dirs)
for x in manifest:(raw/x['path']).unlink()
for p in dirs:p.rmdir()
assert raw.is_dir() and not list(raw.iterdir())
packet['rawCleanup']={'status':'complete','owner':'root','archiveCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'verifiedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freshChecks':'committed archive/allmembers/exactliveRAWset/currentSources/allprocessbirths/alldisposables/originalcheckout/readersreleased','removedFiles':len(manifest),'removedBytes':sum(x['bytes'] for x in manifest),'removedEmptyChildDirectories':len(dirs),'remainingFiles':0,'retainedEmptyRoot':str(raw),'failures':[]}
packetpath.write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps(packet['rawCleanup']))
