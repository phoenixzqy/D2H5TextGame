# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: meditation.spec.ts >> Meditation native selection, disk reload, layouts and additional cast zh-CN
- Location: tests/pwa/meditation.spec.ts:106:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  94  |       const cast = english ? `${NAME} casts Holy Bolt.` : `${NAME} 施放了 圣光弹。`;
  95  |       // Cast log precedes the separate payment event. Observe the real debit before pausing.
  96  |       await expect.poll(() => capture.evaluate(({ samples }, line) =>
  97  |         samples.some(sample => sample.mp === '0' && sample.log.includes(line)), cast),
  98  |       { timeout: 10_000, intervals: [20] }).toBe(true);
  99  |     }
  100 |     await pause(page, english);
  101 |     return await capture.evaluate(({ observer,samples }) => { observer.disconnect(); return samples; });
  102 |   } finally { await capture.evaluate(({ observer }) => { observer.disconnect(); }); await capture.dispose(); }
  103 | }
  104 | 
  105 | for (const locale of ['en','zh-CN'] as const) {
  106 |   test(`Meditation native selection, disk reload, layouts and additional cast ${locale}`, async ({ page: initial, context }, info) => {
  107 |     const english = locale === 'en', text = copy[locale];
  108 |     const errors: string[] = [];
  109 |     const watch = (p: Page): void => {
  110 |       p.on('pageerror', error => errors.push(error.message));
  111 |       p.on('console', message => { if (['warning','error'].includes(message.type())) errors.push(`${message.type()}: ${message.text()}`); });
  112 |     };
  113 |     let page = initial; watch(page);
  114 |     await page.clock.setFixedTime(fixedTime); // Date only; native simulation/playback timers run normally.
  115 |     await page.goto('/'); await createCharacter(page, { class: 'paladin', name: NAME });
  116 |     await navTo(page, 'settings');
  117 |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  118 |     const fresh = await backup(page);
  119 |     expect(fresh.player).toMatchObject({ class: 'paladin',level: 1,skillPoints: 1 });
  120 |     await detail(page);
  121 |     const group = () => page.getByRole('group', { name: text.aura, exact: true });
  122 |     const radio = (name: string) => group().getByRole('radio', { name,exact: true });
  123 |     await expect(radio(text.meditation)).toBeDisabled(); await expect(radio(text.none)).toBeChecked();
  124 |     await page.getByTestId('skill-node-skills-paladin-might').click();
  125 |     await page.getByTestId('skill-detail-panel').getByRole('button', { name: text.allocate,exact: true }).click();
  126 |     await expect(radio(text.might)).toBeEnabled(); await expect(radio(text.meditation)).toBeDisabled();
  127 |     await expect(radio(text.none)).toBeChecked();
  128 |     const nativeMight = await backup(page);
  129 |     expect(nativeMight.player.level).toBe(1); expect(nativeMight.player.skillPoints).toBe(0);
  130 |     expect(nativeMight.player.skillLevels?.['paladin.might']).toBe(1);
  131 |     expect(nativeMight.player).not.toHaveProperty('selectedAuraId');
  132 |     expect(nativeMight.player.derivedStats).toEqual(fresh.player.derivedStats);
  133 |     await attach(info,'00-native-fresh-Might-independent-unlock', { fresh,nativeMight });
  134 |     // Explicit imported eligibility and baseline4; no earned-unlock or campaign claim.
  135 |     const eligible: SaveCurrent = { ...fresh, player: { ...fresh.player,level: 24,skillPoints: 2,
  136 |       coreStats: { ...fresh.player.coreStats,energy: 20 },
  137 |       derivedStats: { ...fresh.player.derivedStats,life: 334,lifeMax: 334,mana: 6,manaMax: 172,
  138 |         attack: 68,defense: 89,attackSpeed: 120 },
  139 |       skillLevels: { 'paladin.holy_bolt': 1,'paladin.prayer': 1,'paladin.cleansing': 1,'paladin.might': 1 },
  140 |       comboOrder: [HOLY] } };
  141 |     await importSave(page,eligible,english);
  142 |     const prepared = await backup(page); expect(prepared.player).toEqual(eligible.player); durable(prepared);
  143 |     await attach(info,'01-explicit-imported-eligibility', { fresh,prepared });
  144 |     try {
  145 |       for (const rank of [1,2]) {
  146 |         const panel = await detail(page);
  147 |         await expect(radio(text.might)).toBeEnabled();
  148 |         await panel.getByRole('button', { name: text.allocate,exact: true }).click();
  149 |         await expect(radio(text.none)).toBeChecked(); // Learning/upgrading never selects.
  150 |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: text.current,exact: true }) });
  151 |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: text.next,exact: true }) });
  152 |         await expect(current.getByText(text.regen, { exact: true }).locator('+ dd')).toHaveText(`${String(rank*3)}%`);
  153 |         await expect(next.getByText(text.regen, { exact: true }).locator('+ dd')).toHaveText(`${String((rank+1)*3)}%(+3%)`);
  154 |         await expect(panel).toContainText(text.description);
  155 |       }
  156 |       const beforeSelection = await backup(page); await navTo(page,'skills');
  157 |       await expect(group().getByRole('radio')).toHaveCount(3);
  158 |       // Native radio keyboard behavior: focus None by ordinary click, then arrows wrap backward.
  159 |       await radio(text.none).click();
  160 |       for (const name of [text.meditation,text.might,text.none]) {
  161 |         await page.keyboard.press('ArrowLeft'); await expect(radio(name)).toBeFocused();
  162 |         await expect(radio(name)).toBeChecked();
  163 |         await expect(group().locator('input:checked')).toHaveCount(1);
  164 |       }
  165 |       const afterSelection = await backup(page); expect(afterSelection.player).toEqual(beforeSelection.player);
  166 |       expect(afterSelection.player).not.toHaveProperty('selectedAuraId');
  167 |       await attach(info,'02-keyboard-exclusive-no-resource-change', { beforeSelection,afterSelection });
  168 |       await navTo(page,'skills'); await radio(text.meditation).click();
  169 |       const panel = await detail(page); const metrics = [];
  170 |       for (const [width,height] of sizes) {
  171 |         await page.setViewportSize({ width,height });
  172 |         const controls = [];
  173 |         for (const name of [text.none,text.might,text.meditation]) {
  174 |           const label = radio(name).locator('..'); await label.scrollIntoViewIfNeeded();
  175 |           const bounds = await label.boundingBox(); expect(bounds).not.toBeNull();
  176 |           expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  177 |           controls.push({ name,bounds,hits: await hitGrid(label) });
  178 |         }
  179 |         await production(page);
  180 |         await info.attach(`aura-${String(width)}x${String(height)}`, { body: await page.screenshot(),contentType: 'image/png' });
  181 |         const description = panel.getByText(text.description, { exact: true }); await description.scrollIntoViewIfNeeded();
  182 |         const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  183 |         expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14); await expect(description).toBeVisible();
  184 |         const headingHits = await hitGrid(panel.getByRole('heading', { name: text.meditation,exact: true }));
  185 |         if (!english && width === 360) {
  186 |           const cdp = await context.newCDPSession(page);
  187 |           try {
  188 |             await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  189 |             const doc = await cdp.send('DOM.getDocument');
  190 |             const node = await cdp.send('DOM.querySelector', { nodeId: doc.root.nodeId,
  191 |               selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  192 |             const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  193 |             await attach(info,'03-actual-Chinese-fonts',fonts);
> 194 |             expect(fonts.fonts.some(f => f.familyName === 'Noto Sans CJK SC' && f.glyphCount > 0)).toBe(true);
      |                                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  195 |           } finally { await cdp.detach(); }
  196 |         }
  197 |         await info.attach(`detail-${String(width)}x${String(height)}`, { body: await page.screenshot(),contentType: 'image/png' });
  198 |         metrics.push({ width,height,font,controls,headingHits });
  199 |       }
  200 |       await attach(info,'03-finite-layout-metrics',metrics);
  201 |       await page.setViewportSize({ width: 1280,height: 800 });
  202 |       await navTo(page,'skills'); await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  203 |       for (let index=1;index<=9;index++) {
  204 |         const slot = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(index)}`,exact: true });
  205 |         await expect(slot).toHaveValue(index===1 ? HOLY : '');
  206 |         await expect(slot.locator(`option[value="${AURA}"],option[value="${NODE}"]`)).toHaveCount(0);
  207 |       }
  208 |       const saved = await backup(page); expect(saved.player.selectedAuraId).toBe(AURA);
  209 |       expect(saved.player.skillLevels?.[AURA]).toBe(2); expect(saved.player.skillPoints).toBe(0); durable(saved);
  210 |       expect(saved.player.derivedStats).toEqual(prepared.player.derivedStats);
  211 |       await page.getByRole('button', { name: english ? 'Save' : '保存',exact: true }).click();
  212 |       await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  213 |       await page.close(); page = await context.newPage(); watch(page); await page.clock.setFixedTime(fixedTime);
  214 |       await page.goto('/'); await page.getByTestId('home-continue').click(); await expect(page.getByTestId('town-screen')).toBeVisible();
  215 |       const loaded = await backup(page);
  216 |       expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
  217 |       expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
  218 |       expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta).toEqual(saved.meta);
  219 |       expect(loaded).toEqual(saved); durable(loaded);
  220 |       await attach(info,'04-explicit-save-close-newpage-continue', { saved,loaded });
  221 |       await navTo(page,'skills'); await expect(radio(text.meditation)).toBeChecked();
  222 |       // Paired low-mana input: rank20 is imported scaffolding, not native earned rank20.
  223 |       const { selectedAuraId: discarded, ...unselected } = loaded.player; expect(discarded).toBe(AURA);
  224 |       const paired: SaveCurrent = { ...loaded,player: { ...unselected,
  225 |         skillLevels: { ...loaded.player.skillLevels,[AURA]: 20 },
  226 |         derivedStats: { ...prepared.player.derivedStats,mana: 6 } } };
  227 |       const timelines: Record<string,DOMSample[]> = {};
  228 |       let originalEncounter: string[] | undefined;
  229 |       for (const selected of [false,true]) {
  230 |         // A full new page resets the native module-local challenge ordinal to zero.
  231 |         await page.close(); page = await context.newPage(); watch(page); await page.clock.setFixedTime(fixedTime);
  232 |         await page.goto('/'); await page.getByTestId('home-continue').click();
  233 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  234 |         const input: SaveCurrent = { ...paired,player: { ...paired.player,...(selected ? { selectedAuraId: AURA } : {}) } };
  235 |         await importSave(page,input,english); const verified = await backup(page);
  236 |         expect(verified.player).toEqual(input.player); await attach(info,`05-paired-input-${String(selected)}`,verified);
  237 |         await navTo(page,'map');
  238 |         await page.getByTestId('sub-area-row-a1-blood-moor').getByRole('button', { name: english ? 'Enter' : '进入',exact: true }).click();
  239 |         await expect(page.getByTestId('combat-screen')).toBeVisible(); await pause(page,english);
  240 |         const encounter = await page.getByTestId('combat-screen').locator('[data-testid^="unit-card-"]').allTextContents();
  241 |         expect(encounter.length).toBeGreaterThan(1);
  242 |         if (originalEncounter) expect(encounter).toEqual(originalEncounter); else originalEncounter = encounter;
  243 |         await attach(info,`05-first-native-encounter-${String(selected)}`, { fixedTime: fixedTime.toISOString(),encounter });
  244 |         const samples = await firstAction(page,english,selected); timelines[String(selected)] = samples;
  245 |         await attach(info,`06-first-action-${String(selected)}`,samples);
  246 |         const basic = english ? `${NAME} readies an attack.` : `${NAME} 准备出招。`;
  247 |         const cast = english ? `${NAME} casts Holy Bolt.` : `${NAME} 施放了 圣光弹。`;
  248 |         // 1540ms: None 6+floor(4*1.54)=12; Meditation20 6+floor(6.4*1.54)=15.
  249 |         const action = selected ? cast : basic, recovered = selected ? '15' : '12';
  250 |         const ready = samples.findIndex(s => s.mp===recovered && !s.log.some(line => line.startsWith(`${NAME} `)));
  251 |         expect(ready,`recovered ${recovered} before the first hero action`).toBeGreaterThanOrEqual(0);
  252 |         const acted = samples.findIndex((s,index) => index>ready && s.log.includes(action));
  253 |         expect(acted).toBeGreaterThan(ready);
  254 |         if (selected) expect(samples.some((s,index) => index>ready && s.mp==='0' && s.log.includes(cast))).toBe(true);
  255 |         else expect(samples.slice(0,acted+1).some(s => s.log.includes(cast))).toBe(false);
  256 |         await production(page);
  257 |         await page.getByRole('button', { name: english ? 'Flee' : '逃跑',exact: true }).click();
  258 |       }
  259 |       await attach(info,'07-paired-native-consequence',timelines);
  260 |       await attach(info,'08-console-errors',errors); expect(errors).toEqual([]); await production(page);
  261 |     } finally { await page.close(); }
  262 |   });
  263 | }
  264 | 
```