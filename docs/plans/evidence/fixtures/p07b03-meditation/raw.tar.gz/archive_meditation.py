from pathlib import Path
import json,hashlib,tarfile,gzip,io,subprocess,datetime,stat
raw=Path(__file__).resolve().parent;wt=Path.cwd().resolve()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
union=json.loads((raw/'meditation-all-process-union.json').read_text())
for pid,ticks in union['identities']:
 p=Path('/proc')/str(pid)/'stat'
 try:fields=p.read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=ticks
files=sorted(p for p in raw.rglob('*') if p.is_file())
assert all(not p.is_symlink() and p.resolve()==p for p in raw.rglob('*'))
manifest=[{'path':str(p.relative_to(raw)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
out=wt/'docs/plans/evidence/fixtures/p07b03-meditation';assert not out.exists();out.mkdir()
archive=out/'raw.tar.gz'
with archive.open('xb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in files:
  body=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(raw)));info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(manifest)
 for member,entry in zip(members,manifest):
  assert member.isfile() and member.name==entry['path'] and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  body=tar.extractfile(member).read();assert len(body)==entry['bytes'] and hashlib.sha256(body).hexdigest()==entry['sha256']
paths=subprocess.check_output(['git','diff','--name-only','a188810..HEAD'],text=True).splitlines()
paths=[p for p in paths if not p.startswith('docs/plans/evidence/') and p!='docs/plans/execution-ledger.md']
sources=[{'path':name,'bytes':(wt/name).stat().st_size,'sha256':hashlib.sha256((wt/name).read_bytes()).hexdigest()} for name in paths]
packet={'task':'P07b03 Meditation + BUG068','sourceHead':head,'browserSource':'72731b0','baseline':'a188810','createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'archive':{'path':'raw.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest),'originalBytes':sum(x['bytes'] for x in manifest),'roundtripVerified':True},
 'rawRoot':str(raw),'rawManifest':manifest,'currentSources':sources,
 'processUnion':{'record':'meditation-all-process-union.json','identityFields':['pid','startTicks'],'commandRecords':len(union['records']),'uniqueAbsent':union['uniqueAbsent'],'signals':union['signals']},
 'outputsCleanup':{name:json.loads((raw/name).read_text()) for name in ['stage-i-cleanup-receipt.json','stage-i-extra-disposable-cleanup.json']},
 'browser':{'report':'browser-i-attempt3-report.json','passed':2,'locales':['en','zh-CN'],'wrapperSeconds':42.232,'screenshots':36,'explicitSaveReloadCycles':2,'scaffolding':'imported L24/prerequisites/ranks/stats; not earned progression','consequence':'same initial6MP; None12/basic versus Meditation15/HolyBolt/payment0 before kill/orb'},
 'failures':'all actual capability/behavioral RED, failed green fixture corrections, lint and browser failures preserved; unexecuted draft corrections separated; stage-i-housekeeping-cap records transient postgate pretty union overflow and lossless compact repair',
 'independentReview':'GD/TD source, QA and producer whole stages APPROVE; QA visually viewed36images; transcriptions retained',
 'rawCleanup':{'status':'pending independent durable review and archive commit','owner':'root','scope':'manifest-verified exact files and derived empty childdirs only; preserve emptyRAWroot/sharedparents/source/history/fonts/tools'},
 'scopeLimit':'bounded schema/save/selection/exact combat/native/UI/finiteChromiumCSS/samecontextsave acceptance; no fullP07b/privatev1/C0-C4/G0-G7/earnedcampaign/browsermerc/balance/touch/allbrowser/fulla11y/performance acceptance'}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'originalBytes':packet['archive']['originalBytes'],'archiveBytes':packet['archive']['bytes'],'sources':len(sources),'absentBirths':union['uniqueAbsent']}))
