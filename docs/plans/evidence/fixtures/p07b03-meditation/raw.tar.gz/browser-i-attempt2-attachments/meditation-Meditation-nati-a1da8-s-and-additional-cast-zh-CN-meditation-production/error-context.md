# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: meditation.spec.ts >> Meditation native selection, disk reload, layouts and additional cast zh-CN
- Location: tests/pwa/meditation.spec.ts:106:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1   | /** Imported L24/prerequisites/ranks/stats are scaffolding, not earned campaign evidence. */
  2   | import { expect, test, type Page, type TestInfo, type Locator } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { createCharacter, navTo } from '../e2e/_helpers';
  6   | 
  7   | const AURA = 'paladin.meditation';
  8   | const NODE = 'skills-paladin-meditation';
  9   | const HOLY = 'skills-paladin-holy-bolt';
  10  | const NAME = 'Meditation Proof';
  11  | const fixedTime = new Date('2026-10-21T12:00:00.055Z');
  12  | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  13  | const copy = {
  14  |   en: { aura: 'Aura for next wave', none: 'None', might: 'Might', meditation: 'Meditation',
  15  |     allocate: 'Allocate', current: 'Current', next: 'Next Level', regen: 'Mana Regeneration',
  16  |     description: 'Selected aura: adds 3% of your normal mana regeneration per second per allocated rank to you and your living fielded mercenary (up to 60% at rank 20). Each recipient retains their own normal recovery. Unlocks at character level 24.' },
  17  |   'zh-CN': { aura: '下一波光环', none: '无', might: '力量', meditation: '冥想',
  18  |     allocate: '分配', current: '当前', next: '下一级', regen: '法力恢复',
  19  |     description: '选择此光环后：每投入1点技能点，每秒为自身与存活的上阵佣兵额外恢复相当于角色自身正常法力恢复速度3%的法力（最多20点，合计60%）。各自原有的正常恢复仍然生效。角色24级解锁。' }
  20  | } as const;
  21  | interface DOMSample { readonly mp: string | null; readonly log: string[] }
  22  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  23  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  24  | }
  25  | async function backup(page: Page): Promise<SaveCurrent> {
  26  |   await navTo(page, 'settings');
  27  |   const pending = page.waitForEvent('download');
  28  |   await page.getByTestId('export-save-button').click();
  29  |   const download = await pending;
  30  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  31  |   finally { await download.delete(); }
  32  | }
  33  | async function importSave(page: Page, save: SaveCurrent, english: boolean): Promise<void> {
  34  |   await navTo(page, 'settings');
  35  |   const label = english ? 'Import Save' : '导入存档';
  36  |   await page.getByRole('button', { name: label, exact: true }).click();
  37  |   const dialog = page.getByRole('dialog');
  38  |   await dialog.getByRole('textbox').fill(JSON.stringify(save));
  39  |   await dialog.getByRole('button', { name: label, exact: true }).click();
  40  |   await expect(dialog).toHaveCount(0);
  41  | }
  42  | async function production(page: Page): Promise<void> {
  43  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  44  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  45  | }
  46  | function durable(save: SaveCurrent): void {
  47  |   expect(JSON.stringify(save)).not.toMatch(/"meditationAura"|"sourceBaselinePerSecond"|"manaRegenPerSecond"|"manaRegenCarry"|"manaRegenExactCarry"|"manaRegenCompensation"|"carryPlayerTeam"|"mightAura"/);
  48  | }
  49  | async function detail(page: Page): Promise<Locator> {
  50  |   await navTo(page, 'skills');
  51  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  52  |   await page.getByTestId(`skill-node-${NODE}`).click();
  53  |   await page.mouse.move(1, 1);
  54  |   return page.getByTestId('skill-detail-panel');
  55  | }
  56  | async function hitGrid(target: Locator): Promise<unknown[]> {
  57  |   await target.scrollIntoViewIfNeeded();
  58  |   const points = await target.evaluate(node => {
  59  |     const b = node.getBoundingClientRect();
  60  |     return [0.05,0.5,0.95].flatMap(x => [0.05,0.5,0.95].map(y => {
  61  |       const hit = document.elementFromPoint(b.left+b.width*x, b.top+b.height*y);
  62  |       return { x,y,clear: hit !== null && node.contains(hit) };
  63  |     }));
  64  |   });
  65  |   for (const point of points) expect(point).toMatchObject({ clear: true });
  66  |   return points;
  67  | }
  68  | async function pause(page: Page, english: boolean): Promise<void> {
  69  |   await page.getByRole('button', { name: english ? 'Pause' : '暂停', exact: true }).click({ timeout: 500 });
  70  |   await expect(page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true }))
  71  |     .toHaveAttribute('aria-pressed', 'true');
  72  | }
  73  | /** Observe only rendered output. No game bridge, hidden state, timer mutation or DOM action injection. */
  74  | async function firstAction(page: Page, english: boolean, selected: boolean): Promise<DOMSample[]> {
  75  |   const capture = await page.getByTestId('combat-screen').evaluateHandle((screen, mpLabel) => {
  76  |     const samples: DOMSample[] = [];
  77  |     const sample = () => {
  78  |       const next = { mp: screen.querySelector(`[role="group"][aria-label="${mpLabel}"] [role="progressbar"]`)
  79  |         ?.getAttribute('aria-valuenow') ?? null,
  80  |         log: [...screen.querySelectorAll('[data-testid="combat-log"] > div > span:last-child')]
  81  |           .map(line => line.textContent ?? '') };
  82  |       if (JSON.stringify(samples.at(-1)) !== JSON.stringify(next)) samples.push(next);
  83  |     };
  84  |     sample(); const observer = new MutationObserver(sample);
  85  |     observer.observe(screen, { subtree: true, childList: true, attributes: true, characterData: true });
  86  |     return { observer,samples };
  87  |   }, english ? 'MP' : '法力');
  88  |   try {
  89  |     await page.getByRole('button', { name: english ? 'Resume' : '继续', exact: true }).click();
  90  |     await expect.poll(async () => (await page.getByTestId('combat-log')
  91  |       .locator(':scope > div > span:last-child').allTextContents()).some(line => line.startsWith(`${NAME} `)),
  92  |     { timeout: 10_000, intervals: [20] }).toBe(true);
  93  |     if (selected) {
  94  |       const cast = english ? `${NAME} casts Holy Bolt.` : `${NAME} 施放了 圣光弹。`;
  95  |       // Cast log precedes the separate payment event. Observe the real debit before pausing.
> 96  |       await expect.poll(() => capture.evaluate(({ samples }, line) =>
      |       ^ Error: expect(received).toBe(expected) // Object.is equality
  97  |         samples.some(sample => sample.mp === '0' && sample.log.includes(line)), cast),
  98  |       { timeout: 10_000, intervals: [20] }).toBe(true);
  99  |     }
  100 |     await pause(page, english);
  101 |     return await capture.evaluate(({ observer,samples }) => { observer.disconnect(); return samples; });
  102 |   } finally { await capture.evaluate(({ observer }) => { observer.disconnect(); }); await capture.dispose(); }
  103 | }
  104 | 
  105 | for (const locale of ['en','zh-CN'] as const) {
  106 |   test(`Meditation native selection, disk reload, layouts and additional cast ${locale}`, async ({ page: initial, context }, info) => {
  107 |     const english = locale === 'en', text = copy[locale];
  108 |     const errors: string[] = [];
  109 |     const watch = (p: Page): void => {
  110 |       p.on('pageerror', error => errors.push(error.message));
  111 |       p.on('console', message => { if (['warning','error'].includes(message.type())) errors.push(`${message.type()}: ${message.text()}`); });
  112 |     };
  113 |     let page = initial; watch(page);
  114 |     await page.clock.setFixedTime(fixedTime); // Date only; native simulation/playback timers run normally.
  115 |     await page.goto('/'); await createCharacter(page, { class: 'paladin', name: NAME });
  116 |     await navTo(page, 'settings');
  117 |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  118 |     const fresh = await backup(page);
  119 |     expect(fresh.player).toMatchObject({ class: 'paladin',level: 1,skillPoints: 1 });
  120 |     await detail(page);
  121 |     const group = () => page.getByRole('group', { name: text.aura, exact: true });
  122 |     const radio = (name: string) => group().getByRole('radio', { name,exact: true });
  123 |     await expect(radio(text.meditation)).toBeDisabled(); await expect(radio(text.none)).toBeChecked();
  124 |     await page.getByTestId('skill-node-skills-paladin-might').click();
  125 |     await page.getByTestId('skill-detail-panel').getByRole('button', { name: text.allocate,exact: true }).click();
  126 |     await expect(radio(text.might)).toBeEnabled(); await expect(radio(text.meditation)).toBeDisabled();
  127 |     await expect(radio(text.none)).toBeChecked();
  128 |     const nativeMight = await backup(page);
  129 |     expect(nativeMight.player.level).toBe(1); expect(nativeMight.player.skillPoints).toBe(0);
  130 |     expect(nativeMight.player.skillLevels?.['paladin.might']).toBe(1);
  131 |     expect(nativeMight.player).not.toHaveProperty('selectedAuraId');
  132 |     expect(nativeMight.player.derivedStats).toEqual(fresh.player.derivedStats);
  133 |     await attach(info,'00-native-fresh-Might-independent-unlock', { fresh,nativeMight });
  134 |     // Explicit imported eligibility and baseline4; no earned-unlock or campaign claim.
  135 |     const eligible: SaveCurrent = { ...fresh, player: { ...fresh.player,level: 24,skillPoints: 2,
  136 |       coreStats: { ...fresh.player.coreStats,energy: 20 },
  137 |       derivedStats: { ...fresh.player.derivedStats,life: 334,lifeMax: 334,mana: 6,manaMax: 172,
  138 |         attack: 68,defense: 89,attackSpeed: 120 },
  139 |       skillLevels: { 'paladin.holy_bolt': 1,'paladin.prayer': 1,'paladin.cleansing': 1,'paladin.might': 1 },
  140 |       comboOrder: [HOLY] } };
  141 |     await importSave(page,eligible,english);
  142 |     const prepared = await backup(page); expect(prepared.player).toEqual(eligible.player); durable(prepared);
  143 |     await attach(info,'01-explicit-imported-eligibility', { fresh,prepared });
  144 |     try {
  145 |       for (const rank of [1,2]) {
  146 |         const panel = await detail(page);
  147 |         await expect(radio(text.might)).toBeEnabled();
  148 |         await panel.getByRole('button', { name: text.allocate,exact: true }).click();
  149 |         await expect(radio(text.none)).toBeChecked(); // Learning/upgrading never selects.
  150 |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: text.current,exact: true }) });
  151 |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: text.next,exact: true }) });
  152 |         await expect(current.getByText(text.regen, { exact: true }).locator('+ dd')).toHaveText(`${String(rank*3)}%`);
  153 |         await expect(next.getByText(text.regen, { exact: true }).locator('+ dd')).toHaveText(`${String((rank+1)*3)}%(+3%)`);
  154 |         await expect(panel).toContainText(text.description);
  155 |       }
  156 |       const beforeSelection = await backup(page); await navTo(page,'skills');
  157 |       await expect(group().getByRole('radio')).toHaveCount(3);
  158 |       // Native radio keyboard behavior: focus None by ordinary click, then arrows wrap backward.
  159 |       await radio(text.none).click();
  160 |       for (const name of [text.meditation,text.might,text.none]) {
  161 |         await page.keyboard.press('ArrowLeft'); await expect(radio(name)).toBeFocused();
  162 |         await expect(radio(name)).toBeChecked();
  163 |         await expect(group().locator('input:checked')).toHaveCount(1);
  164 |       }
  165 |       const afterSelection = await backup(page); expect(afterSelection.player).toEqual(beforeSelection.player);
  166 |       expect(afterSelection.player).not.toHaveProperty('selectedAuraId');
  167 |       await attach(info,'02-keyboard-exclusive-no-resource-change', { beforeSelection,afterSelection });
  168 |       await navTo(page,'skills'); await radio(text.meditation).click();
  169 |       const panel = await detail(page); const metrics = [];
  170 |       for (const [width,height] of sizes) {
  171 |         await page.setViewportSize({ width,height });
  172 |         const controls = [];
  173 |         for (const name of [text.none,text.might,text.meditation]) {
  174 |           const label = radio(name).locator('..'); await label.scrollIntoViewIfNeeded();
  175 |           const bounds = await label.boundingBox(); expect(bounds).not.toBeNull();
  176 |           expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  177 |           controls.push({ name,bounds,hits: await hitGrid(label) });
  178 |         }
  179 |         await production(page);
  180 |         await info.attach(`aura-${String(width)}x${String(height)}`, { body: await page.screenshot(),contentType: 'image/png' });
  181 |         const description = panel.getByText(text.description, { exact: true }); await description.scrollIntoViewIfNeeded();
  182 |         const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  183 |         expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14); await expect(description).toBeVisible();
  184 |         const headingHits = await hitGrid(panel.getByRole('heading', { name: text.meditation,exact: true }));
  185 |         if (!english && width === 360) {
  186 |           const cdp = await context.newCDPSession(page);
  187 |           try {
  188 |             await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  189 |             const doc = await cdp.send('DOM.getDocument');
  190 |             const node = await cdp.send('DOM.querySelector', { nodeId: doc.root.nodeId,
  191 |               selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  192 |             const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  193 |             await attach(info,'03-actual-Chinese-fonts',fonts);
  194 |             expect(fonts.fonts.some(f => f.familyName === 'Noto Sans CJK SC' && f.glyphCount > 0)).toBe(true);
  195 |           } finally { await cdp.detach(); }
  196 |         }
```