from pathlib import Path
import sys,json,hashlib
raw=Path(__file__).resolve().parent
stage=sys.argv[1];names=sys.argv[2:]
frozen=json.loads((raw/(stage+'-source-v1-freeze.json')).read_text())
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in frozen['paths'])
commands=[]
for name in names:
 m=json.loads((raw/(name+'.meta.json')).read_text());entry={'name':name,**m}
 p=raw/(name+'-report.json')
 if p.exists():
  v=json.loads(p.read_text());entry['tests']={k:v.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']};entry['actualFiles']=len(v['testResults'])
 commands.append(entry)
(raw/(stage+'-final-verification.json')).write_text(json.dumps({'commands':commands,'frozenSourcesMatch':True,'warnings':['engine3s/full15s targets remain; no performance acceptance','existing Browserslist dataset/chunk>500kB/art manifest2.57MB precache warnings'],'scope':'bounded source increment only; final Meditation/browser/full-v1 acceptance pending'},indent=2)+'\n')
files=[];directories=[]
root=Path('dist')
if root.exists():
 for p in root.rglob('*'):
  assert not p.is_symlink()
  if p.is_file(): files.append({'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  elif p.is_dir(): directories.append(str(p.resolve()))
p=Path('node_modules/.vite/vitest/results.json')
if p.exists():
 assert not p.is_symlink()
 files.append({'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(raw/(stage+'-disposable-inventory.json')).write_text(json.dumps({'owner':'root','files':files,'directories':directories,'totalBytes':sum(x['bytes'] for x in files),'cleanup':'after sourcecommit and reader release, exact fresh verified files and empty task-owned dist dirs only; shared cache parents preserved'},indent=2)+'\n')
print(json.dumps({'verifiedSources':len(frozen['paths']),'disposableFiles':len(files),'disposableBytes':sum(x['bytes'] for x in files)}))
