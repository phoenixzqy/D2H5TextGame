import Ajv2020 from 'ajv/dist/2020';
import { describe, expect, it } from 'vitest';
import paladinSkills from '../../data/skills/paladin.json';
import skillSchema from '../../data/schema/skill.schema.json';
import sorceressSkills from '../../data/skills/sorceress.json';
import necromancerSkills from '../../data/skills/necromancer.json';
import barbarianSkills from '../../data/skills/barbarian.json';
import amazonSkills from '../../data/skills/amazon.json';
import assassinSkills from '../../data/skills/assassin.json';
import druidSkills from '../../data/skills/druid.json';
import mercenarySkills from '../../data/skills/mercenary.json';
import monsterSkills from '../../data/skills/monsters.json';

const authored = () => {
  const row = paladinSkills.find(row => row.id === 'skills-paladin-meditation');
  if (!row) throw new Error('Missing authored Meditation');
  return structuredClone(row);
};
const validate = new Ajv2020({ strict: true, allErrors: true }).compile(skillSchema);
const malformedRows = [
  { requiredLevel: undefined },
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '24', null].map(requiredLevel => ({ requiredLevel })),
  { maxLevel: undefined },
  ...[0, -1, 1.5, NaN, Infinity, -Infinity, '20', null].map(maxLevel => ({ maxLevel })),
  { scaling: undefined }, { scaling: {} }, { scaling: { passiveStatsPerLevel: {} } },
  ...[-0.01, NaN, Infinity, -Infinity, '0.03', null].map(value =>
    ({ scaling: { passiveStatsPerLevel: { manaRegenPct: value } } })),
  { aura: undefined }, { aura: false }, { trigger: 'active' }, { target: 'single-enemy' },
  { passive: false }, { summon: true },
  ...[1, -1, NaN, Infinity, -Infinity, '0', null].map(cooldown => ({ cooldown })),
  { cost: {} }, { cost: { mana: 0 } }, { cost: { life: 0 } },
  { damage: { min: 1, max: 1, breakdown: { physical: 1 } } }, { damageType: 'physical' },
  { appliesStatus: [] }, { appliesStatus: ['burn'] }, { statusEffect: { chance: 1 } },
  { additionalStatusEffects: { freeze: { chance: 1 } } },
  { appliesTags: [] }, { appliesTags: ['fire'] }, { synergies: {} }, { synergies: { fire: 1.2 } },
  { heal: { min: 1, max: 1, target: 'self' } }, { summonId: 'skeleton' },
  { aoeShape: 'single' }, { requires: {} }, { requires: { weaponType: ['staff'] } },
  { scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03, lifeRegenPct: 0.1 } } },
  { scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03, typo: 0.1 } } },
  ...['damagePerLevel', 'cooldownPerLevel', 'costPerLevel'].map(key =>
    ({ scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03 }, [key]: 0 } })),
  { scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03 }, summonStatsPerLevel: { attack: 1 } } },
  { scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03 }, summonMaxCount: { kind: 'first-three-then-every-three' } } },
  { scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03 }, typo: 1 } },
  { typo: 1 }
];

describe('P07b03A exact player Meditation schema', () => {
  it('preserves authored unlock24, Cleansing prerequisite, cap20 and aura coefficient.03', () => {
    const row = authored();
    expect(validate(row)).toBe(true);
    expect(row).toMatchObject({ id: 'skills-paladin-meditation', aura: true, trigger: 'passive',
      target: 'self', requiredLevel: 24, prerequisites: ['skills-paladin-cleansing'],
      minLevel: 1, maxLevel: 20, cooldown: 0, scaling: { passiveStatsPerLevel: { manaRegenPct: 0.03 } } });
    expect(row).not.toHaveProperty('cost'); expect(row).not.toHaveProperty('damage');
  });

  it.each([0, 0.125, 3, Number.MAX_VALUE])('accepts alternate finite nonnegative coefficient %s without a balance ceiling', coefficient => {
    expect(validate({ ...authored(), scaling: { passiveStatsPerLevel: { manaRegenPct: coefficient } } })).toBe(true);
  });

  it('permits alternate positive integer unlock/cap and optional passive classification', () => {
    expect(validate({ ...authored(), requiredLevel: 9, maxLevel: 31, passive: true, summon: false })).toBe(true);
  });

  it.each(malformedRows)('rejects malformed exact Meditation row %j', fields => {
    expect(validate({ ...authored(), ...fields })).toBe(false);
  });

  it('preserves every authored row across all seven classes, mercenaries and monsters', () => {
    for (const row of [...paladinSkills, ...sorceressSkills, ...necromancerSkills, ...barbarianSkills,
      ...amazonSkills, ...assassinSkills, ...druidSkills, ...mercenarySkills, ...monsterSkills]) {
      expect(validate(row), row.id).toBe(true);
    }
  });

  it('does not impose the exact player contract on another aura identity', () => {
    expect(validate({ ...authored(), id: 'mskill-aura-meditation', requiredLevel: undefined,
      scaling: undefined, cooldown: 1, cost: { mana: 1 } })).toBe(true);
  });
});
