from pathlib import Path
import sys,json,hashlib,stat,subprocess,datetime
raw=Path(__file__).resolve().parent
stage=sys.argv[1]
freeze=json.loads((raw/(stage+'-source-v1-freeze.json')).read_text())
assert all(hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'] for x in freeze['paths'])
verification=json.loads((raw/(stage+'-final-verification.json')).read_text())
identities=set()
for command in verification['commands']:
 data=json.loads((raw/(command['name']+'.processes.json')).read_text())
 assert not data['remainingNonZombie']
 for identity in data['observations']: identities.add((identity['pid'],identity['startTicks']))
for pid,ticks in identities:
 p=Path('/proc')/str(pid)/'stat'
 try: fields=p.read_text().rsplit(')',1)[1].split()
 except FileNotFoundError: continue
 assert int(fields[19])!=ticks, f'Process birth still present: {pid}/{ticks}'
inventory=json.loads((raw/(stage+'-disposable-inventory.json')).read_text())
wt=Path.cwd().resolve(); roots=[wt/'dist',wt/'node_modules/.vite']
for entry in inventory['files']:
 p=Path(entry['path'])
 assert p.is_absolute() and p.resolve()==p and any(p.is_relative_to(root) for root in roots)
 assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size==entry['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
for entry in inventory['files']: Path(entry['path']).unlink()
for name in sorted(inventory['directories'], key=lambda s:len(Path(s).parts), reverse=True):
 p=Path(name); assert p.resolve()==p and p.is_relative_to(wt/'dist'); p.rmdir()
dist=wt/'dist'
if dist.exists():dist.rmdir()
assert all(not Path(x['path']).exists() for x in inventory['files'])
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'removedFiles':len(inventory['files']),'removedBytes':inventory['totalBytes'],
 'removedChildDirectories':len(inventory['directories']),'removedDistRoot':not dist.exists(),
 'allExactFilesAbsent':True,'failedPaths':[],'freshFrozenSourceHashesMatch':True,
 'freshAbsentProcessBirths':len(identities),'owner':'root',
 'preserved':'RAW evidence, shared cache parents/dependencies/fonts/tools/source/history/originalcheckout',
 'remainingEvidencePath':str(raw),'reason':'retain until durable archive independent verification and exact cleanup'}
(raw/(stage+'-cleanup-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
