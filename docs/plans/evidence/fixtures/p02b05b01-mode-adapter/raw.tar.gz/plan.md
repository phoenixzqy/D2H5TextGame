# P02b05b01 — isolated restored-mode observation adapter

Original fullv1 objective remains active; C0-C4/G0-G7 unaccepted. P02b05a
contract91d756c/closingc30fbcf accepted. Root alone edits/executes; producer,
GD/TD and QA read-only reviews. Use TDD/incremental/root-cause/plan-review.
Own only new tests/sim/production/mode-adapter.ts and mode-adapter.test.ts,
plus bounded evidence/closingledger. No engine/game/data/config/package/lock
or accepted v1/v2 edits. Preserve all22P02b04 baseline bytes and3P02b05adocs.
No comparator/reportcodec/CLI in this child; later b02 adds those separately.

## Closed baseline and finite sample

Export a single runRestoredModeOnce(input) accepting strictly only a closed
mode manual|idle and idleEliteMisses0|11. Reject extra/invalid/missing options
and any pre-existing active production run BEFORE caller mutation. No external
snapshot importer, arbitrary stats/gear/seed/preps/action lists or repeat loop.
Fixed baseline metadata/tag is distinct from v1/v2: restored-test-baseline-v1;
synthetic diagnostic, not an earned-eligibility/campaign recipe.

Fixed source-backed baseline: clock1792497600000, canonicalAct1BloodMoor,
challengeOrdinal0, explicit runSeed2330410254. This is the previously frozen
P02b04 first-preparation handle seed, observed read-only in accepted archive
before this plan; chosen for the positiveW1 settlement control, not searched.
Create ordinary Sorceress at production defaults; native hire InnerSight
mercs/act1-rogue-inner-sight, native allocate1FireBolt, set combo[FireBolt]
with current authored learned/active/required-level eligibility. No farm,
quest, point/currency injection, stats/gear upgrade, refill or clear marker.
Reset7stores includingmeta under frozenDate, preserving tuple+anchor; location
Act1BloodMoor, idleTargetundefined for BOTH directservice modes. Thus initial
complete domains/combat/pity match for eachpair except declaredmode; actual
clear listempty, UIeligiblefalse, syntheticclearfalse, routingnotexercised.
Native hire/skill refusal retains complete partial baseline/actions and stops
with no run; structural exceptions retain originalerroridentity after cleanup.

For each normalpity0/hardpity11, one manual and one idle primary observation:
exactly4primary calls, max12attemptedwaves/12computedbattles, bounded3waves
per nativeBloodMoorrun, stop firstterminalnonwin. Unit tests may repeat these
SAME four closed cases for isolation/negative/qualification verification; no
seed/build/pity search. Freeze exact test invocation table beforeRED; target
<=24adapter calls/focused run, no arbitrary repeatproperty test. Fullsuite and
related checks repeatfrozen tests and are reported as validation, not additional
independent screening samples. No promised fullwin. Nativepositive W1known from
acceptedfirstprep can be a qualified-award control, not a fullclear oracle.

## <=3 outcomes

1. Isolated single-mode observer: all7stores/methods, Date, pity restored on
success/refusal/failure. Capture baselineaction results/states, completed or
baseline-refused status, synthetic/eligibility disclosures, sourceBefore/After,
exact options/fixedmetadata, baseline/terminal domains+combat, actual handle,
attemptedwaves/recordings/outcomes/rewards/carry and logical/UIhint/walltime.
Perwave pityBefore/After wraps existing playEarnedWave; source checks all7fields
via existing assertEarnedSourceStable. Reuse captureEarnedRestorers,resetEarnedStores,
observeEarnedState/observeStore,earnedDelta,startEarnedRun/playEarnedWave;
no mutation of acceptedhelpers and no duplicated reward/combat algorithms.
Reject invalidoptions/active-run before capture/reset; no persistence,
allocator/hiddenordinal reset, mocked positivegameplay or UIclaim.

2. Truthful bounded nativeplayback: play exactlyinstalled events then settle
once; no manualcarrywrite, assumedkill/reward/markclear. Stop native defeat or
victory. Record actuallyplayedwavepity before/after settlement (completed
nonwin maycommitpity), sourceidentity and fulloriginalIDs. Incomplete advance,
repeated terminal settlement, native nonwin and actual award controls are
verified without altering primary recordings. Mode-specific promotedinputs and
later planner RNG divergence are observations; no equality/fullwin oracle.
No preimportprovenance/reportemission claim in this low-level adapter; b02 must
collect sourcebefore dynamicimport for an eventualreport. Existing collector
includes newuntrackedadapter/test bytes; keep every source manifest.

3. Frozen tests and independent evidence: plan ready first; QA/GD review exact
testcontracts/negativepaths/invocationtable beforeRED. Preserve originaltests,
failures and independently approved setupcorrections. Initial missing-moduleRED
may execute0assertions and must be disclosed, never called a runtimebehavior
regression. Genuine capability/behavior assertions must execute against an
independently reviewed minimal boundary stage before the actual observer logic;
propose only exported type/signature plus throwing not-implemented stub after
missing-moduleRED to distinguish assertion failures from collection failure.
No new observation/gameplay logic before that frozen assertionRED. Existing
correctproductioncontrols may already pass and are labelledcontrols, not RED.
No confirmed runtimebug yet; any discovereddefect gets structuredbugreport and
its own regressionbeforepatch. No changes merely to make tests claim victory.

## Planned test groups / failure handling

- Exactbaseline4primarycases; source/currentmanifest including actual newfiles;
allnative actions/hire/skilllevel/combo, no stateinjection/clear/UIeligibility.
Pairbaseline dataequal, mode-only options; pity0vs11separate. Hardpity idlefirst
unforcedwave rareelite/plannedpity0, manualnotpromotion; forcedguards bothmodes
where actuallyinstalled. Never invent unattempted recordings.
- Independent qualifiedaward delta from actualnativeobservations; first W1
positivecontrol from historicalsamebaseline. Completeevents/endtime/cursor,
onecompletedsettlement, carry and no award on actualnonwin. Earlysettlement and
repeatedterminal no-ops may be instrumented using real start/advance functions;
synthetic draw/mutate controls separatelylabelled, not gameplayevidence.
- Caller sentinels across7stores/methods/nondefaultmetaanchor+pity+Date; exact
restoration aftersuccess/refusal and injected initialization/playback failure.
Preserve original exception identity; cleanupfailures aggregate without hiding
primaryfailure, attempt everyrestorer. Reject active-run leaving caller run
untouched. Invalidinputs no source/actions/mutation. Freeze counttable beforetest.
- Allaccepted strictmanualv1/v2 rejectiontests unchanged and rerun as controls.
Source drift before/after detected including Node/Vitest/manifest/policy, not
justSHA/data; injectedsource mismatches are syntheticcontrols.

## Verification / administrative bounds

Related npm run test:related -- tests/sim/production/mode-adapter.ts and focused
Vitestrun nonwatch, default pertest5s. Keep <=3nativewaves/call and declared
calltable. Record exactcommand/wall/exit and actualassertionstatuses. Use root
owned externalRAW output (thisdirectory); tests may emit full4primaryattempts
only when explicit externalout env is set, exclusivelynew via existing safe
outputpath/writeNewReport + losslessencodeObservation. That test-owned optional
spill is diagnostic evidence, not a productCLI; no package/script change.
If output/size/time concerns occur stop, retain fullerror/partialartifacts, no
raise cap/truncate/rerun gameplay to get a pass. Before firstfocused execution
freeze outercommand deadline30s (+2s separatelyrecorded exactownedPGID cleanup)
and outputsizeobservational; no encodeddata truncation. Fullunit final uses
existingnormalrunner (historical52s, unchanged15sbudget disclosed) as validation,
not30sprimaryreportcap. Keep enoughfreedisk, taskownedprocesses only.

Appropriate final related + U/T/L, enginepuritylint, guardedproductionbuild
onlyafter all source-fingerprint consumersrelease. No buildconcurrentwithsource
collection or tests. No browserclaim for test-onlyNodeobserver. Finaldurable
packet retains exactcommands/RED/stub/GREEN/source/testfreezes/fullprimaryobservations/
reviews, independentproducer/QA/GD audit, featurecommit then separateclosingledger
after allconsumersrelease and exactRAW/task.vite/dist cleanup/absenceverification.
Preserve installedtools/sharedcaches. Worktreeclaimcontinues; no push/PR/merge/
deploy. Next b02comparison/preimportreport/CLI separate reviewedslice; genuine
earnedBloodMoorfullclear/idleUI/Den/Andariel/campaign remainlater.
