# Independent exact test/boundary review before freeze

QA verdict revise: wrong authored FireBolt skill key (production canonical
sorceress.fire_bolt); require fullcreatedplayer+allocation/combo only and exact
canonicalmaplocation. Independently derive inventoryadditions/currencydiffs/
mercXP from observedbefore/after, use inferKind. Check installedW2/W3 forced
guardsinclafterAdvance. NondefaultcallerDate+independentteardown. Erroraggregate
assert length and eachtoBe, not onlytoEqual. Boundarythrow/calltable approved.
Consumers released, no tests/gameplay/edits.

GD-DESIGN-REVIEW CONCERNS; TD-ARCH-REVIEW APPROVE. Explicit idle11W1
isIdleElitetrue/plannedpity0/actualpity0 evennative-loss; absencemetadata retains
pityBefore (forcedguards). ManualW1 noidlepromotion. Source sub-area-run266–300,
combatHelpers516–529. Boundarytypes+throw and22calls<=36battles sound.
Consumers released, no tests/gameplay/edits.

Root revision1 implements all above before firstfreeze; no assertions removed.
Also adds optional acceptedexternalwriter assertion-count artifact for truthful
executedassertioncounts at boundaryRED/green. Independent finalre-reviewpending.
