# P02b05b01 frozen test contract candidate

22 adapter calls per successful complete focused run (under24cap):
- Primary:4, exactly manual0,idle0,manual11,idle11; <=12native waves.
- Invalid closed options:5, no sourcecollection/mutation/gameplay.
- Existing-run rejection:1adaptercall/no newrun; one separately declared native
  caller-run setup (manual/seed2330410254/ordinal0, callerbarbarian sentinel),
  one computed unplayed/unawarded W1 solely to prove noninterference.
- Expected native baseline refusals:2manual0; zero battles.
- Original initialization/playback failures:2manual0; initialization0,
  playback one computed installed W1 and fail first advanceEvent.
- Primary+cleanup failure:1manual0; one computed W1, no settlement.
- Seven source identity drift cases:7manual0; <=21waves; synthetic identity only.
Total22adaptercalls, <=35computedadapterbattles+1caller-setupbattle (<=36).
Only4primarycalls are screening observations; all others are fixed validation.
No seeds/builds/pity values outside the closed approved baseline are searched.
Normal manualW1positive160heroXP/120mercXP is historical fixedcontrol, not
fullwinoracle. Anyactualnonwin tested independently whenobserved; no defeat
injection or promise that every case loses. ForcedW3checked onlyifinstalled.
Pity uses full perwavebefore/after; idlehardopeningpromotioncontrol; expected
actualplanning divergence accepted. Nativeearly/repeatedadvance controls wrap
primary runs without modifyingrecordings. They mayalready pass existingcode.
Optionalfull4primaryspill is exclusiveexternal via accepted losslesscodec/writer.
Source/tool7fields each independently perturbed, source collection aftercleanup.
Initial missing-module collection RED mayexecute0assertions. Reviewed boundary
contains exportedtypes/signature and throwonly. Normal observe() wraps call in
not.toThrow (executedcapabilityassertion); refusal/negative/error assertions also
execute againststub. Deeper assertions cannotrun aftercapabilityfailure and are
neverclaimed RED individually. No productruntimebug asserted.

Focused command deadline30s with2s separatelyrecorded exactownedPGID grace.
Default testtimeout5s unchanged. Frozen tests must retainassertions; anysetup
correction independently reviewed and priorbytes retained. Fullsuite expected
historical52s uses normalrunner, original15sbudget disclosed.

Revision1 beforefreeze: QA/GD wrongcanonicalskillkey corrected; fullcreatedplayer+only
allocation/comboexpected, exactcanonicalmaplocation, independentlycomputed
items/currencies/mercXP, inferKind, installedW2/W3guardsinclafterAdvance, explicit
idle11planned+actualpity0/manualnopromotion/idleabsentmetadataretention. Nondefault
callerDatenow and independentteardown restoration. Aggregateerrorlength+each
identitytoBe. OptionalD2H5_MODE_ASSERT_OUT records pertest actualexpect
assertionCalls via afterEach/afterAll safeexclusiveexternalwriter; noextraadaptercalls.
