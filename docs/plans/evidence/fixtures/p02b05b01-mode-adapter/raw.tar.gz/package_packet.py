from pathlib import Path
import tarfile,hashlib,json,stat
raw=Path(__file__).parent.resolve()
wt=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=wt/'docs/plans/evidence/fixtures/p02b05b01-mode-adapter'
dest.mkdir(exist_ok=False)
records=[]
files=sorted(raw.iterdir(),key=lambda p:p.name)
for p in files:
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink(),p
 b=p.read_bytes();records.append({'path':p.name,'byteLength':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=dest/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as out:
 for p in files:out.add(p,arcname=p.name,recursive=False)
packet={'task':'P02b05b01','measuredParent':'c30fbcfe7e5ec968960a3a1288230d220656197b','archive':archive.name,'archiveByteLength':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'records':records,'recordCount':len(records),'uncompressedBytes':sum(r['byteLength'] for r in records),'commandMetadataCount':sum(r['path'].endswith('.meta.json') for r in records),'reportCount':sum(r['path'].endswith('.report.json') for r in records),'primaryObservationBytes':(raw/'primary.observation.json').stat().st_size,'note':'RAW preserved before exact cleanup; final audit/release recorded in reviews.md and closing ledger.'}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({k:v for k,v in packet.items() if k!='records'}));print('packetSha256='+hashlib.sha256((dest/'packet.json').read_bytes()).hexdigest())
