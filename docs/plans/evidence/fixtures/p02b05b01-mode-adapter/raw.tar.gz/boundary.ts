import type { EarnedState, EarnedCombatState } from './earned-state';
import type { EarnedRunHandle, EarnedWave } from './earned-playback';
import type { SourceState } from './provenance';

export interface RestoredModeOptions {
  readonly mode: 'manual' | 'idle';
  readonly idleEliteMisses: 0 | 11;
}
export interface ModeBaselineAction {
  readonly kind: 'hire-merc' | 'allocate-skill' | 'set-combo';
  readonly before: EarnedState;
  readonly after: EarnedState;
  readonly result: { readonly ok: boolean; readonly reason?: string; readonly productionResult?: unknown };
}
export interface RestoredModeAttempt {
  readonly baselineTag: 'restored-test-baseline-v1';
  readonly options: RestoredModeOptions;
  readonly clockEpochMs: number;
  readonly scope: { readonly synthetic: true; readonly uiEligible: false;
    readonly syntheticClear: false; readonly routingExercised: false };
  readonly status: 'completed' | 'baseline-refused';
  readonly refusal: { readonly actionIndex: number; readonly reason: string } | null;
  readonly created: EarnedState;
  readonly actions: readonly ModeBaselineAction[];
  readonly baseline: EarnedState;
  readonly baselineCombat: EarnedCombatState;
  readonly baselinePity: number;
  readonly handle: EarnedRunHandle | null;
  readonly waves: readonly (EarnedWave & { readonly pityBefore: number; readonly pityAfter: number })[];
  readonly terminal: EarnedState;
  readonly terminalCombat: EarnedCombatState;
  readonly terminalPity: number;
  readonly sourceBefore: SourceState;
  readonly sourceAfter: SourceState;
  readonly timings: { readonly logicalSimSeconds: number; readonly uiDelayHintSeconds: number;
    readonly wallSeconds: number };
}
/** Execute one closed synthetic diagnostic, restoring caller state on every exit. */
export function runRestoredModeOnce(_input: unknown): RestoredModeAttempt {
  throw new Error('Restored mode adapter not implemented');
}
