from pathlib import Path
import json,hashlib
raw=Path(__file__).parent
wt=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
x=json.loads((raw/'primary.observation.json').read_text())
fields=['sourceSha','sourceTreeHash','dataHash','nodeVersion','vitestVersion','collectionPolicy','manifest']
for file,digest in json.loads((raw/'preserved-baseline.json').read_text()).items():
 assert hashlib.sha256((wt/file).read_bytes()).hexdigest()==digest,file
freeze=json.loads((raw/'freeze.json').read_text())
assert hashlib.sha256((wt/'tests/sim/production/mode-adapter.test.ts').read_bytes()).hexdigest()==freeze['mode-adapter.test.ts']
assert len(x['attempts'])==4
rows=[]
for i,a in enumerate(x['attempts']):
 assert a['options']=={'mode':['manual','idle'][i%2],'idleEliteMisses':[0,11][i//2]}
 assert all(a['sourceBefore'][k]==a['sourceAfter'][k] for k in fields)
 for row in a['sourceBefore']['manifest']:
  b=(wt/row['path']).read_bytes();assert len(b)==row['byteLength'];assert hashlib.sha256(b).hexdigest()==row['sha256']
 assert a['handle']=={'challengeOrdinal':0,'runId':'areas/act1-blood-moor','runSeed':2330410254,'totalWaves':3}
 assert len(a['waves'])==2 and a['status']=='completed'
 assert a['baseline']['map']['clearedSubAreas']==[]
 assert a['terminal']['map']['clearedSubAreas']==[]
 logical=0.;ui=0.
 for j,w in enumerate(a['waves']):
  events=w['opening']['recordedEvents'];played=w['played'];outcome=w['opening']['outcome']
  assert played['eventCursor']==len(events) and played['playbackComplete']
  assert played['recordedEvents']==events and events[-1]['kind']=='end'
  assert events[-1]['simClockMs']==w['terminalSimClockMs']
  assert w['opening']['eventCursor']==0 and not w['opening']['playbackComplete']
  assert w['index']==j and w['opening']['currentWave']==j+1
  hero=w['beforeAward']['player']['player']['id']
  qualified=outcome['winner']=='player' and any(u['id']==hero and u['life']>0 for u in outcome['finalPlayerTeam'])
  assert qualified==(j==0)
  xp=0
  if qualified:
   for unit in outcome['finalEnemyTeam']:
    if unit['life']<=0 and unit['kind']!='summon':xp+=max(5,int(10*unit['level']+0.5))
  assert w['actualDelta']['xp']==xp
  bp=w['beforeAward']['player']['player'];ap=w['afterAward']['player']['player']
  # These observed runs go L1XP0 -> L2XP60 only; cumulative threshold L2=100.
  assert bp['level'] in [1,2] and ap['level'] in [1,2]
  assert (100 if ap['level']==2 else 0)+ap['experience']-((100 if bp['level']==2 else 0)+bp['experience'])==xp
  for key in set(w['beforeAward']['inventory']['currencies'])|set(w['afterAward']['inventory']['currencies']):
   assert w['actualDelta']['currencies'][key]==w['afterAward']['inventory']['currencies'].get(key,0)-w['beforeAward']['inventory']['currencies'].get(key,0)
  oldIds={v['id'] for v in w['beforeAward']['inventory']['backpack']}
  added=[v for v in w['afterAward']['inventory']['backpack'] if v['id'] not in oldIds]
  assert w['actualDelta']['addedItems']==added==w['rawRewardDelta']['items']
  if not qualified:
   assert w['afterAward']==w['beforeAward'] and w['advanceResult']=='defeat'
   assert w['afterAdvance']['runRewards']==played['runRewards']
  logical+=w['terminalSimClockMs']/1000
  waveui=0.
  for event in events:waveui+=event['uiDelayMs']/1000
  ui+=waveui
 assert a['timings']['logicalSimSeconds']==logical and a['timings']['uiDelayHintSeconds']==ui
 assert a['terminal']==a['waves'][-1]['afterAward'] and a['terminalCombat']==a['waves'][-1]['afterAdvance']
 rows.append({'options':a['options'],'waves':2,'clears':0,'logicalSeconds':logical,'uiHintSeconds':ui})
for offset in [0,2]:
 assert x['attempts'][offset]['baseline']==x['attempts'][offset+1]['baseline']
 assert x['attempts'][offset]['baselineCombat']==x['attempts'][offset+1]['baselineCombat']
assert x['attempts'][3]['waves'][0]['pityAfter']==0
assert x['attempts'][1]['waves'][0]['pityAfter']==1
result={'verified':True,'baselineHashes':25,'testFreeze':True,'sourceStates':8,'sourceFields':7,'manifestEntriesPerState':492,'actualSourceBytesExact':True,'primaryCalls':4,'playedComputedWaves':8,'qualifiedWins':4,'nonwins':4,'clears':0,'rows':rows}
(raw/'primary-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
