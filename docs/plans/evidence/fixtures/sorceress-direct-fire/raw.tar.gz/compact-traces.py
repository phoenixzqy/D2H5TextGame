from pathlib import Path
import json,hashlib,zipfile
p=Path(__file__).parent
paths=[p/'pilot-en-360/en-360-fire-bolt-failed-trace.zip',*[p/('browser-'+locale+'-'+str(width))/(locale+'-'+str(width)+'-meteor-failed-trace.zip') for locale in ['en','zh-CN'] for width in [360,1280]]]
rows=[]
for source in paths:
 assert source.is_file() and not source.is_symlink() and p.resolve() in source.resolve().parents
 original=hashlib.sha256(source.read_bytes()).hexdigest()
 target=source.with_name(source.stem+'-metadata.zip')
 inventory=[];kept={}
 with zipfile.ZipFile(source) as archive:
  for member in archive.infolist():
   data=archive.read(member)
   keep=member.filename.endswith(('.trace','.network','.stacks'))
   inventory.append({'name':member.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'retained':keep})
   if keep:kept[member.filename]=data
 assert kept and any(name.endswith('.trace') for name in kept)
 manifest={'originalSha256':original,'originalBytes':source.stat().st_size,'reason':'Retain raw trace events, DOM snapshots, console/network metadata, separate failure PNG, exact saves, error report and failing script; discard redundant downloaded asset bodies after root diagnosis. No other consumer remains.','members':inventory}
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as out:
  for name,data in kept.items():out.writestr(name,data)
  out.writestr('compaction-manifest.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(target) as out:
  for name,data in kept.items():assert out.read(name)==data
  assert json.loads(out.read('compaction-manifest.json'))==manifest
 rows.append({'source':str(source.relative_to(p)),'originalSha256':original,'originalBytes':source.stat().st_size,'retained':str(target.relative_to(p)),'retainedSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'retainedBytes':target.stat().st_size,'traceEntries':len(kept),'omittedAssetBodies':len(inventory)-len(kept)})
 source.unlink();assert not source.exists()
(p/'trace-compaction.json').write_text(json.dumps({'verified':True,'rows':rows},indent=2)+'\n')
print('Compacted',len(rows),'completed failure traces:',sum(r['originalBytes'] for r in rows),'to',sum(r['retainedBytes'] for r in rows),'bytes; events/network metadata exact.')
