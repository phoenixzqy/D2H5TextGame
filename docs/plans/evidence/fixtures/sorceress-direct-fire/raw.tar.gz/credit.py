from pathlib import Path
import csv, collections, io, json

p = Path(__file__).parent
root = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
target = root / 'docs/plans/skill-inventory.csv'
initial = json.loads((p / 'initial.json').read_text())['inventory']
assert target.read_bytes() == initial.encode()
lines = initial.splitlines(keepends=True)
fields = next(csv.reader([lines[0]]))
ids = ['skills-sorceress-fire-bolt', 'skills-sorceress-fire-ball', 'skills-sorceress-meteor']
changed = []
out = [lines[0]]
for line in lines[1:]:
    values = next(csv.reader([line]))
    row = dict(zip(fields, values, strict=True))
    if row['data_id'] in ids:
        assert row['behavior_verification'] == 'unverified'
        row['behavior_verification'] = 'bounded-functional;independent-acceptance-open'
        row['risk_flags'] = 'independent-design-qa-and-earned-balance-open'
        row['contract_evidence'] = 'docs/plans/decisions/D04-sorceress-direct-fire-v1.md;docs/plans/evidence/d04-sorceress-direct-fire.md'
        if row['data_id'] == 'skills-sorceress-meteor':
            row['adapter_route'] = 'damage+explicit-secondary-armor-melt'
            row['contract_evidence'] += ';production/bugs/BUG-229-meteor-misses-separated-and-overflow-enemies.md;production/bugs/BUG-230-meteor-armor-melt-log-is-untranslated.md'
        stream = io.StringIO()
        csv.writer(stream, lineterminator='\n').writerow([row[field] for field in fields])
        out.append(stream.getvalue())
        changed.append(row['data_id'])
    else:
        out.append(line)
assert set(changed) == set(ids) and len(changed) == 3
result = ''.join(out)
rows = list(csv.DictReader(io.StringIO(result)))
assert len(rows) == 213
assert [r['data_id'] for r in rows] == [r['data_id'] for r in csv.DictReader(io.StringIO(initial))]
assert sum(a == b for a, b in zip(lines[1:], out[1:], strict=True)) == 210
counts = collections.Counter(r['behavior_verification'] for r in rows)
bounded = sum(value for name, value in counts.items() if name.startswith('bounded-functional;'))
sorc = sum(r['class'] == 'sorceress' and r['behavior_verification'].startswith('bounded-functional;') for r in rows)
assert bounded == 131 and counts['unverified'] == 80 and sorc == 15
audit = {'changedIds': ids, 'otherRowsByteExact': 210, 'idsAndOrderUnchanged': True, 'total': 213,
         'boundedFunctional': bounded, 'unverified': counts['unverified'], 'engineOnly': 1,
         'reviewNeeded': counts['review-needed'], 'sorceressBounded': sorc,
         'independentAndEarnedAcceptance': 'open'}
target.write_bytes(result.encode())
(p / 'inventory-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit))
