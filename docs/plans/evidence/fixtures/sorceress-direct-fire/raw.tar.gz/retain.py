from pathlib import Path
import hashlib, json, tarfile

p = Path(__file__).parent
root = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out = root / 'docs/plans/evidence/fixtures/sorceress-direct-fire'
out.mkdir(parents=True, exist_ok=False)
assert json.loads((p / 'full-quiet-result.json').read_text())['exitCode'] == 0
final_labels = ['full-quiet', 'typecheck-verified', 'lint-verified', 'build-delivery', 'precache-delivery',
                'shared-prose-corrected', 'shared-prose-lint',
                'browser-delivery-en-360', 'browser-delivery-en-1280',
                'browser-delivery-zh-CN-360', 'browser-delivery-zh-CN-1280']
receipts = {}
for path in sorted(p.glob('*-result.json')):
    row = json.loads(path.read_text())
    if 'exitCode' in row:
        receipts[path.name.removesuffix('-result.json')] = row
assert all(receipts[name]['exitCode'] == 0 for name in final_labels)
terminal = {'finalPass': {name: receipts[name] for name in final_labels},
            'otherPass': {name: row for name, row in receipts.items() if row['exitCode'] == 0 and name not in final_labels},
            'failed': {name: row for name, row in receipts.items() if row['exitCode'] != 0},
            'browserGroups': json.loads((p / 'browser-delivery-groups-result.json').read_text()),
            'fullSuiteSummary': (p / 'full-quiet.log').read_text().split(' Test Files ')[-1],
            'limits': ['Author review only; independent and earned acceptance open.',
                       'Earlier engine and supplemental receipts precede final compatibility/localization edits; final quiet full covers final source.']}
(p / 'terminal-results.json').write_text(json.dumps(terminal, indent=2) + '\n')
for name in ['terminal-results.json', 'browser-audit.json', 'freeze-audit.json', 'save-pairs-audit.json',
             'source-delivered.json', 'inventory-audit.json', 'source-diff-audit.json',
             'author-review.json', 'recorded-processes.json', 'trace-compaction.json', 'cleanup.py']:
    (out / name).write_bytes((p / name).read_bytes())
files = []
for file in sorted(p.rglob('*')):
    assert not file.is_symlink(), str(file)
    if file.is_file() and file.relative_to(p).parts[0] != 'build':
        files.append(file)
manifest = [{'path': str(file.relative_to(p)), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
             'bytes': file.stat().st_size} for file in files]
archive = out / 'raw.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for file in files:
        tar.add(file, arcname=str(file.relative_to(p)), recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(manifest)
    for member, row in zip(tar.getmembers(), manifest, strict=True):
        assert member.isfile() and member.name == row['path'] and member.size == row['bytes']
        handle = tar.extractfile(member)
        assert handle is not None
        assert hashlib.sha256(handle.read()).hexdigest() == row['sha256'], row['path']
packet = {'archive': archive.name, 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'archiveBytes': archive.stat().st_size, 'members': manifest, 'membersVerified': len(manifest),
          'sourceCommit': json.loads((p / 'source-delivered.json').read_text())['commit'],
          'buildExcluded': 'Disposable production build; all 761 asset hashes retained in frozen.json.',
          'traceRetention': 'Five diagnosed failure trace ZIPs compacted: original trace/network/stacks bytes retained with per-member hashes; redundant asset bodies omitted. See trace-compaction.json.',
          'acceptance': 'Local bounded-functional only; independent/earned/full-v1 acceptance open.'}
(out / 'packet.json').write_text(json.dumps(packet, indent=2) + '\n')
print(json.dumps({'archiveMembersVerified': len(manifest), 'archiveBytes': archive.stat().st_size, 'terminalReceipts': len(receipts)}))
