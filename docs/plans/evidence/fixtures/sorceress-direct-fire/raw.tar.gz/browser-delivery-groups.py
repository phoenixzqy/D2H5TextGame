from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess, os, json, sys, time
p=Path(__file__).parent
start=time.monotonic()
def run(locale,width):
 label='browser-delivery-'+locale+'-'+str(width)
 env={**os.environ,'BROWSER_PORT':'4512','BROWSER_LOCALE':locale,'BROWSER_WIDTH':str(width),'BROWSER_RUN':label}
 env.pop('BROWSER_SKILL',None)
 child=subprocess.Popen([sys.executable,str(p/'run.py'),label,'node',str(p/'browser.cjs')],env=env)
 code=child.wait()
 row={'label':label,'wrapperPid':child.pid,'exitCode':code}
 print(json.dumps(row),flush=True)
 return row
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,locale,width) for locale in ['en','zh-CN'] for width in [360,1280]]
 rows=[future.result() for future in as_completed(futures)]
(p/'browser-delivery-groups-result.json').write_text(json.dumps({'groups':rows,'seconds':time.monotonic()-start},indent=2)+'\n')
assert len(rows)==4 and all(row['exitCode']==0 for row in rows)
