from pathlib import Path
import json,hashlib,gzip,re
p=Path(__file__).parent
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
frozen=json.loads((p/'frozen.json').read_text())
sourceDrift=[name for name,value in frozen['source'].items() if sha(root/name)!=value]
buildDrift=[name for name,value in frozen['build'].items() if sha(p/'build'/name)!=value]
assert not sourceDrift and not buildDrift
assert hashlib.sha256(gzip.decompress((root/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()==frozen['genuine']
freeze={'sourceFiles':len(frozen['source']),'buildFiles':len(frozen['build']),'sourceDrift':sourceDrift,'buildDrift':buildDrift,'genuineUnchanged':True}
(p/'freeze-audit.json').write_text(json.dumps(freeze,indent=2)+'\n')
groups=json.loads((p/'browser-delivery-groups-result.json').read_text())['groups']
assert len(groups)==4 and all(g['exitCode']==0 for g in groups)
browser={'groups':groups,'cases':[],'geometry':0,'screenshots':0};pairs=[];offline=[]
def domains(save):return {k:save[k] for k in ['player','inventory','map','mercs','formation']}
for group in groups:
 q=p/group['label'];report=json.loads((q/'browser-report.json').read_text())
 assert len(report['cases'])==3 and report['failures']==[] and len(report['geometry'])==15
 for row in report['cases']:
  assert row['pass'] and row['errors']==[] and row['pairs']==['rank1','rank2'] and row['offlineContinue']['pass']
  assert len(row['combat'])==1 and row['combat'][0]['publicCast']
  assert row['combat'][0]['enemyChips']
  label=row['label'];browser['cases'].append(label)
  for rank in ['rank1','rank2']:
   before=list(q.glob(label+'-'+rank+'-before-*.json'));after=list(q.glob(label+'-'+rank+'-after-*.json'))
   assert len(before)==len(after)==1
   a=json.loads(before[0].read_text());b=json.loads(after[0].read_text())
   assert a['version']==b['version']==22 and domains(a)==domains(b)
   pairs.append({'label':label,'rank':rank,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p)),'exactFiveDomains':True})
  saved=json.loads(after[0].read_text());files=list(q.glob(label+'-offline-continued-*.json'));assert len(files)==1
  continued=json.loads(files[0].read_text());assert domains(saved)==domains(continued)
  offline.append({'label':label,'file':str(files[0].relative_to(p)),'exactFiveDomains':True,'networkDisabled':True,'freshPage':True})
 for row in report['geometry']:
  assert row['overflow']==0 and row['allocate']['width']>=44 and row['allocate']['height']>=44
 browser['geometry']+=len(report['geometry']);browser['screenshots']+=len(list(q.glob('*.png')))
assert len(browser['cases'])==12 and len(pairs)==24 and len(offline)==12 and browser['geometry']==60 and browser['screenshots']==36
(p/'browser-audit.json').write_text(json.dumps(browser,indent=2)+'\n')
(p/'save-pairs-audit.json').write_text(json.dumps({'ordinaryPairs':pairs,'offlineContinues':offline},indent=2)+'\n')
print(json.dumps({'freeze':freeze,'browserCases':len(browser['cases']),'ordinaryPairs':len(pairs),'offlineContinues':len(offline),'geometry':browser['geometry'],'screenshots':browser['screenshots']}))
