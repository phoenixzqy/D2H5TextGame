from pathlib import Path
import gzip, hashlib, json, subprocess

p = Path(__file__).parent
root = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
frozen = json.loads((p / 'frozen.json').read_text())
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', '--show-object-format'], cwd=root, text=True).strip() == 'sha1'
tree = subprocess.check_output(['git', 'ls-tree', '-rz', '--full-tree', commit], cwd=root)
blobs = {}
for record in tree.split(b'\0'):
    if not record:
        continue
    metadata, name = record.split(b'\t', 1)
    blobs[name.decode()] = metadata.split()[2].decode()
for name, expected in frozen['source'].items():
    data = (root / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, name
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blobs.get(name), name
for name, expected in frozen['build'].items():
    assert hashlib.sha256((p / 'build' / name).read_bytes()).hexdigest() == expected, name
genuine = hashlib.sha256(gzip.decompress((root / 'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes())).hexdigest()
assert genuine == frozen['genuine']
receipt = {'commit': commit, 'sourceFiles': len(frozen['source']), 'committedSourceBlobsMatch': True,
           'buildFiles': len(frozen['build']), 'sourceDrift': [], 'buildDrift': [], 'genuine': genuine, 'pass': True}
(p / 'source-delivered.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
