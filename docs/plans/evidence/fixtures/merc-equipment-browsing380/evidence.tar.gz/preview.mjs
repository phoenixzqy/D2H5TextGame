import {preview} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
const server=await preview({root:'/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',build:{outDir:'/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/merc-picker380/dist'},preview:{host:'127.0.0.1',port:4441,strictPort:true}});
console.log('owned-preview pid='+process.pid+' http://127.0.0.1:4441');
process.on('SIGINT',()=>server.httpServer.close(()=>process.exit(0)));
