from pathlib import Path
import hashlib,json,tarfile,os
p=Path(__file__).parent.resolve()
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest=wd/'docs/plans/evidence/fixtures/fire-blast-cone';dest.mkdir(parents=True,exist_ok=True)
assert not (dest/'raw.tar.gz').exists() and not (dest/'packet.json').exists()
assert json.loads((p/'full.json').read_text())['exit_code']==0
assert json.loads((p/'post-full-freeze-audit.json').read_text())['exact']
assert json.loads((p/'committed-source-audit.json').read_text())['exact']
files=[]
for f in sorted(p.rglob('*')):
 assert not f.is_symlink(),str(f)
 if f.is_file() and f.relative_to(p).parts[0] not in ('production-dist',):files.append(f)
sha=lambda data:hashlib.sha256(data).hexdigest()
members=[{'path':'scratch/'+str(f.relative_to(p)),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in files]
with tarfile.open(dest/'raw.tar.gz','w:gz') as archive:
 for f in files:archive.add(f,arcname='scratch/'+str(f.relative_to(p)),recursive=False)
with tarfile.open(dest/'raw.tar.gz','r:gz') as archive:
 assert archive.getnames()==[m['path'] for m in members]
 for m in members:
  stream=archive.extractfile(m['path']);assert stream is not None
  raw=stream.read();assert sha(raw)==m['sha256'] and len(raw)==m['bytes']
receipts=[]
for f in files:
 if f.suffix!='.json':continue
 try:r=json.loads(f.read_text())
 except (ValueError,UnicodeError):continue
 if isinstance(r,dict) and all(k in r for k in ['command','exit_code','seconds']):receipts.append({'path':'scratch/'+str(f.relative_to(p)),'exit_code':r['exit_code']})
packet={'root':str(p),'members':members,'terminal_receipts':receipts,'member_hashes_verified':True,'raw_archive_sha256':sha((dest/'raw.tar.gz').read_bytes()),'build_hash_map':'scratch/frozen-inputs.json','final_evidence':['full.json','post-full-freeze-audit.json','browser-audit.json','visual-review.json','committed-source-audit.json'],'independent_acceptance_open':True}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
for name in ['committed-source-audit.json','inventory-reconciliation.json']:(dest/name).write_bytes((p/name).read_bytes())
print({'verified_raw_members':len(members),'terminal_receipts':len(receipts),'archive_sha256':packet['raw_archive_sha256']})
