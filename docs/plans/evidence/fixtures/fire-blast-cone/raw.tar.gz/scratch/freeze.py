from pathlib import Path
import hashlib,json,gzip,subprocess,sys
p=Path(__file__).parent
wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
keys=set(json.loads((p/'baseline-source.json').read_text())['source'])
keys.update(['src/engine/combat/grid.cone.test.ts','src/engine/skills/fire-blast.test.ts','src/stores/fire-blast-cone.causal.test.ts'])
def current():
 return {'source':{k:sha((wd/k).read_bytes()) for k in sorted(keys)},
  'design':{k:sha((wd/k).read_bytes()) for k in ['docs/design/skills-spec.md','docs/plans/decisions/D04-assassin-fire-v1.md','docs/plans/decisions/D04-fire-blast-cone-v1.md']},
  'build':{str(f.relative_to(p/'production-dist')):sha(f.read_bytes()) for f in sorted((p/'production-dist').rglob('*')) if f.is_file()},
  'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=wd,text=True).strip(),
  'genuine_decompressed_sha256':sha(gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))}
if sys.argv[1]=='snapshot':
 assert not (p/'frozen-inputs.json').exists()
 r=current();assert r['genuine_decompressed_sha256']=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577';assert len(r['source'])==1386 and len(r['build'])==760
 (p/'frozen-inputs.json').write_text(json.dumps(r,indent=2)+'\n');print({k:len(v) if isinstance(v,dict) else v for k,v in r.items()})
else:
 frozen=json.loads((p/'frozen-inputs.json').read_text());actual=current();assert frozen==actual,'Frozen inputs changed'
 r={'source_files':len(actual['source']),'design_files':len(actual['design']),'build_files':len(actual['build']),'exact':True,'head':actual['head'],'genuine_unchanged':True}
 (p/(sys.argv[2]+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(r)
