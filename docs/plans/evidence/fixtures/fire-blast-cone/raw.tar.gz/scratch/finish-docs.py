from pathlib import Path
import json,re,sys
p=Path(__file__).parent;r=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');runtime,ui=sys.argv[1:]
full=json.loads((p/'full.json').read_text());log=(p/'full.log').read_text();assert full['exit_code']==0
assert re.search(r'Test Files\s+654 passed',log) and re.search(r'Tests\s+14671 passed \| 2 skipped',log)
for n in ['post-full-freeze-audit.json','committed-source-audit.json']:assert json.loads((p/n).read_text())['exact']
assert json.loads((p/'inventory-reconciliation.json').read_text())['counts']['bounded-functional']==105
claw=json.loads((p/'dragon-claw-native-observed.json').read_text())['cases'];assert len(claw)==12 and all(len(c['hits'])==1 for c in claw)
vitest=re.search(r'Duration\s+([\d.]+)s',log).group(1)
(r/'docs/plans/evidence/d04-fire-blast-cone.md').write_text(f'''# D04 — Fire Blast's actual cone explosion

Fixed and verified locally: runtime/data `{runtime}`, presentation `{ui}`.
Root sole writer and author reviewer; independent design/QA and earned balance
remain open. [BUG207](../../../production/bugs/BUG-207-fire-blast-cross-instead-of-cone.md),
[original native reproduction](d04-fire-blast-cone-repro.md) and
[contract](../decisions/D04-fire-blast-cone-v1.md) precede implementation.

## Restored behavior

Fire Blast now authors `aoeShape:"cone-2"`, including its matching legacy
builder. The actual grid footprint is one apex cell `(r,c)` and three cells
`(r+1,c-1/c/c+1)`, with ordinary validity/clipping and no wrapping. The existing
densest occupied-anchor resolver chooses the most living hostile candidates,
ties by lower row then column, and returns row-major targets. Duplicate units
in a cell remain eligible: four cells is not a four-enemy cap. Existing default
positions, explicit overflow coordinates and missing-position fallback remain.
Other shapes and source skill identities retain their behavior.

The spec promises a thrown cone fire trap without numeric grid dimensions or
a persistent interval/lifetime. This explicit provisional adaptation resolves
one paid explosion; it preserves trap wording and adds no artificial persistent
entity. Wake/Death Sentry trap lifecycles and martial charge promises remain
open. Numeric cone tuning is not claimed to be approved or earned balance.

Preserve Fire50–70/+5rank,25MP,2s cooldown,unlock1/cap20/no prerequisites and
explicit10% mitigated-hit Burn,3s/cap5. Each target keeps its ordinary independent
hit/base/critical decision, mitigation, personal absorption and death. One
payment/action/cooldown per explosion, no weapon Attack scaling or save field/
version/dependency change. Schema restricts the preset to exact native Fire
Blast and requires its active area/Fire/Burn identity. React displays a pure
rank-model flag; it contains no geometry or target-selection logic.

## Actual native and test evidence

The rebuilt12-case native probe covers ranks1/2/20 ×seeds7/19/41/97. Every cast
selects IDs1,3,4,5 on the explicit row-major3×3grid, one25MP payment/action,
immutable exact replay and actual final-HP conservation. The old cross also
hitID7; it now remains untouched. Seed7 results:

| Rank | Direct HP loss | Periodic HP loss | Final HP, targets0–8 |
| --- | ---: | ---: | --- |
| 1 | 234 | 66 | 2000,1934,2000,1927,1917,1922,2000,2000,2000 |
| 2 | 254 | 72 | 2000,1929,2000,1919,1909,1917,2000,2000,2000 |
| 20 | 614 | 180 | 2000,1812,2000,1802,1792,1800,2000,2000,2000 |

The45new cases comprise10pure grid,8schema/catalog/display,19native causal and
8bilingual UI. They cover sparse/dense placement, clipping, input permutation
and ties, overflow, duplicate occupants, defaults/fallback, dead/friendly
exclusion, actual direct/periodic HP, independent criticals, no physical
reflection, finite shield absorption, lethal settlement, native authority and
unlearned/current/next/MAX presentation. Earlier Assassin Fire tests retain
all previous assertions with only Fire Blast's obsolete five-target expectation
updated to four; the historical cross proof remains archived.

Original preimplementation RED43failed/115passed is retained. First green
failed strict Ajv compilation because the new conditional required damage
without its local shared-property reference. Typecheck identified five event-
union narrowing errors; lint reported six consequences. Add the existing
schema reference and split kind/source/target predicates; do not weaken strict
mode or any expected geometry/HP. All failures and corrections remain retained.

Final focused compatibility200/8files, data compatibility830/16, engine7592/278,
strict types/lint/build PASS. Final full14671/654files/two existing skips,
{full['seconds']:.3f}s wrapper (Vitest{vitest}s), with no interrupt/restart.
Durations exceed repository test/type/lint budgets; performance gates remain open.

## Production browser and save

Four cases pass: en/zh-CN ×1280×800/360×640. Real public creation/import,
rank1Continue with empty priority, public rank2allocation/Active Skills selection,
actual selected Fire Blast cast and rank2Continue agree. Eight exact Save-close-
new-page-Continue pairs preserve player,inventory,map,mercs,formation at Save22.
SyntheticL30/resources/helmet and fixed Date.now with ordinary timers are
disclosed; no private store injection/test bridge or earned progression credit.

Twenty geometry samples across360×640/412×915/640×360/1280×800/1920×1080 have
no horizontal overflow and checked Allocate controls>=44px. Sixteen screenshots
retained; ten individually inspected: summaries/stat rows at both primary sizes
and locales plus both mobile real-cast logs. Main prose preserves thrown trap,
one explosion, rank damage, cone placement and independent hits; Current/Next
rows show actual shape/Burn/prices. Current rows are fully visible; ordinary
scrolling exposes later Next rows. Existing icon fallback/fixed bars and full
a11y/device/PWA/performance remain open. The isolated build has four bridge-free
JS chunks and all756precache URLs. Only the exact owned preview PID was stopped.

## Provenance and accounting

All1386source/test/config, three controlling design and760build hashes,
historical HEAD01548870 and genuine digest stay exact through the final full
run. Actual committed blobs/disk match the snapshot at `{ui}`; historical HEAD
is not claimed to include the patch. Only one inventory row changes, with
212others and213IDs/order exact:105bounded-functional/106unverified/one engine-
only/one review-needed. Assassin8/30 locally bounded; independent/earned class,
build and balance acceptance remain open.

The separate [Dragon Claw reproduction](d04-dragon-claw-repro.md) proves one
native attempt despite its paired-strike promise. This diagnostic exit1 grants
no functionality credit and is separate from the required passing suite.

Genuine claimed Ancients/Rite staysL33/XP149261/nextNormal402/Nightmare0,
Baal uncleared; decompressed SHA256 stays
`c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577`.
C0/C1 keep narrow exits; C2–C4/fullG0–G7/earned builds/30–50hour pacing/economy/
endgame/independent acceptance remain unfinished. No genuine campaign or remote
action. Full objective, active branch/worktree/claim remain preserved.

[Raw archive](fixtures/fire-blast-cone/raw.tar.gz),
[member manifest](fixtures/fire-blast-cone/packet.json),
[committed audit](fixtures/fire-blast-cone/committed-source-audit.json) and
[cleanup receipt](fixtures/fire-blast-cone/cleanup.json) retain exact evidence.
Archive/cleanup counts follow actual completion.
''')
f=r/'production/bugs/BUG-207-fire-blast-cross-instead-of-cone.md';s=f.read_text().replace('- Status: reproduced; cone contract/implementation and whole-skill credit open.','- Status: fixed and verified locally; independent design/QA and earned balance remain open.')
s+='\n## Local repair continuation\n\nThe explicit provisional two-row cone now uses a real triangular footprint,\nwith truthful bilingual thrown-trap/one-explosion details. Final full14671/654/\ntwo existing skips, types/lint/build and four public production cases pass.\nOnly Fire Blast receives bounded local functionality credit; earned balance\nand independent acceptance remain open. See [verification](../../docs/plans/evidence/d04-fire-blast-cone.md).\n';f.write_text(s)
f=r/'docs/plans/evidence/d04-fire-blast-cone-repro.md';s=f.read_text();s+='\n## Repair continuation\n\nThe original cross result above is historical. A real triangular preset and\ntruthful public details are now locally verified in [cone evidence](d04-fire-blast-cone.md).\nThe [explicit contract](../decisions/D04-fire-blast-cone-v1.md) records provisional\nnumeric geometry before implementation; independent/earned acceptance stays open.\n';f.write_text(s)
f=r/'docs/plans/evidence/d04-assassin-fire.md';s=f.read_text();s+='\n## Fire Blast targeting continuation\n\nThe cone mismatch listed above is now locally repaired and verified under the\n[separate targeting contract/evidence](d04-fire-blast-cone.md). Its additional\ncredit raises the inventory to105bounded/106unverified/one engine-only/one\nreview-needed. Charge, persistent-trap and earned/independent requirements stay open.\n';f.write_text(s)
(r/'production/bugs/BUG-208-dragon-claw-missing-paired-strikes.md').write_text('''# BUG-208 — Dragon Claw emits one attack instead of its promised pair

- Status: reproduced; repeated-strike/bonus-critical contract and repair open.
- Severity: High — the paid skill lacks an advertised second attack attempt.
- Environment: Node24.21.0, real default registry/native L30 Assassin.
- Owner: root; independent design/QA and earned balance remain open.

## Reproduction

1. Recursively learn actual Dragon Talon prerequisite and Dragon Claw ranks1/2/20.
2. Select only Dragon Claw; isolate one cast at seeds7/19/41/97 against a held
   synthetic2000HP target, zero defense/critical chance and later caster hold.
3. Assert one native action/20MP payment, immutable replay and final-HP conservation.
4. Require the two claw attempts promised by both locale descriptions.

Observed:12cases all emit one Physical damage attempt; nine are positive hits.
Seed7 at ranks1/2/20 removes71/78/204HP, final1929/1922/1796; mana100→80.
Registered effects are one ordinary Physical damage effect with no hitSequence.
The diagnostic retains every case then intentionally exits1 on the two-attempt
requirement. English promises a pair of swift claw strikes with bonus critical
chance; Chinese promises two consecutive claw attacks and extra critical chance.

Root cause: the actual row lacks repeated-attempt metadata/runtime opt-in.
The bonus-critical promise also lacks an explicit authored amount; this probe
proves the missing second attempt, not a numeric bonus-critical contract.
Record a faithful two-attempt/critical adaptation before implementation; do not
credit two attacks by merely doubling one scalar hit or waive the bonus promise.

See [native reproduction](../../docs/plans/evidence/d04-dragon-claw-repro.md).
No Dragon Claw code/data patch, functionality credit, genuine campaign or remote action.
''')
(r/'docs/plans/evidence/d04-dragon-claw-repro.md').write_text('''# D04 — Native Dragon Claw paired-strike reproduction

2026-10-25. Reproduced only; no repair or whole-skill credit.
[BUG208](../../../production/bugs/BUG-208-dragon-claw-missing-paired-strikes.md)
precedes any paired-strike/critical implementation.

The [Fire Blast packet](fixtures/fire-blast-cone/packet.json) retains
`scratch/dragon-claw-native-repro.ts`, `scratch/dragon-claw-native-observed.json`
and `scratch/next-dragon-claw-repro.{log,json}`.12actual native cases cover
ranks1/2/20 ×seeds7/19/41/97, real Dragon Talon prerequisite, one action/20MP
payment, immutable exact replay and actual final HP conservation. Every case
has one damage attempt, despite both locale descriptions promising two.
Nine hits are positive; seed7 direct71/78/204 leaves1929/1922/1796HP.

Resources, target and holds are synthetic; no earned build/balance claim.
The script retains observations before an intended exit1 asserting two attempts.
This is a separate diagnostic, not a required-suite failure. It runs against the
current frozen1386source snapshot, which remains exact through full verification.
A numeric bonus-critical design is also absent and needs an explicit contract;
this reproduction does not settle that percentage or waive martial build goals.
Genuine retainedL33/next402/Baal-uncleared digest remains unchanged.
''')
f=r/'docs/plans/execution-ledger.md';lines=f.read_text().splitlines()
for i,line in enumerate(lines):
 if line.startswith('| D04 Fire Blast cone / BUG207 |'):
  lines.pop(i);break
else:raise AssertionError('Missing BUG207 ledger card')
i=next(i for i,line in enumerate(lines) if line.startswith('| D04 Assassin Fire /'))
lines[i:i]=[f'| D04 Fire Blast cone / BUG207 | locally fixed/verified; earned and independent acceptance open | Runtime `{runtime}`, presentation `{ui}`: real two-row1+3-cell cone with preserved independent hits/Burn/payment; truthful thrown-trap one-explosion prose/shape rows.45new cases; full14671/654/two skips ({full["seconds"]:.3f}s), engine7592/278, types/lint/build PASS. Four production cases/eight exact five-domain Continue pairs/20geometry/16screenshots/10inspected. [Evidence](evidence/d04-fire-blast-cone.md).1386source/three design/760build exact; committed blobs verified. Only Fire Blast credited:105bounded/106unverified/one engine-only/one review-needed; Assassin8/30. GenuineL33/next402/Baal uncleared unchanged; C2-C4/fullG0-G7/privatev1 and earned balance/independent gates remain open. |','| D04 Dragon Claw / BUG208 | reproduced; paired-strike and bonus-critical contract/repair open | Native12cases/ranks1/2/20/seeds7/19/41/97 all have one attempt, one20MP payment and immutable exact replay/finalHP. [Reproduction](evidence/d04-dragon-claw-repro.md). Both locales promise two strikes/bonus critical; no numeric bonus contract or code patch/credit. |']
f.write_text('\n'.join(lines)+'\n')
review=json.loads((p/'author-review-initial.json').read_text());review.update({'verdict':'PASS within explicit cone functional scope','full_passed':14671,'full_files':654,'existing_skips':2,'source_commit':ui,'runtime_commit':runtime,'remaining_for_local_credit':[],'actual_committed_blobs_exact':True,'independent_acceptance_open':True})
(p/'author-review-final.json').write_text(json.dumps(review,indent=2)+'\n')
(p/'continuation-state.json').write_text(json.dumps({'classification_of_previous_goal_turn':'progress: Assassin Fire source/UI/evidence commits ee952d1d/6400adb0/01548870, final pass and cleanup','stage':'cone source committed; inventory/evidence updated; archive and cleanup next','runtime_commit':runtime,'UI_commit':ui,'full_terminal':True,'passed':14671,'files':654,'BUG207':'fixed locally','BUG208':'native paired-strike reproduction only; bonus-critical contract needed','goal':'active; full objective incomplete','worktree_branch_claim':'preserved'},indent=2)+'\n')
print('Wrote cone verification, historical continuations, BUG208/reproduction, current ledger and author review')
