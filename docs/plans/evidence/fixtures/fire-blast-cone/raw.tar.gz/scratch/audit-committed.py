from pathlib import Path
import hashlib,json,subprocess,gzip
p=Path(__file__).parent;wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
frozen=json.loads((p/'frozen-inputs.json').read_text());wanted=frozen['source']|frozen['design'];keys=sorted(wanted)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wd,text=True).strip()
blob=subprocess.run(['git','cat-file','--batch'],cwd=wd,input=''.join('HEAD:'+k+'\n' for k in keys).encode(),stdout=subprocess.PIPE,check=True).stdout
pos=0;sha=lambda raw:hashlib.sha256(raw).hexdigest();actual={}
for key in keys:
 end=blob.index(b'\n',pos);header=blob[pos:end].split();assert len(header)==3 and header[1]==b'blob',(key,header)
 size=int(header[2]);raw=blob[end+1:end+1+size];assert len(raw)==size;pos=end+1+size+1
 assert sha(raw)==wanted[key] and sha((wd/key).read_bytes())==wanted[key],key;actual[key]=sha(raw)
assert pos==len(blob)
raw=gzip.decompress((wd/'docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes());assert sha(raw)==frozen['genuine_decompressed_sha256']
result={'exact':True,'commit':head,'probed_precommit_head':frozen['head'],'source_files':len(frozen['source']),'design_files':len(frozen['design']),'actual_committed_blob_sha256':actual,'disk_matches':True,'genuine_unchanged':True,'native_Fire_Blast_cone_repaired':True}
(p/'committed-source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='actual_committed_blob_sha256'})
