from pathlib import Path
import csv,io,json,collections,hashlib
p=Path(__file__).parent;wd=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2');f=wd/'docs/plans/skill-inventory.csv'
assert json.loads((p/'full.json').read_text())['exit_code']==0
for name in ['post-full-freeze-audit.json','committed-source-audit.json']:assert json.loads((p/name).read_text())['exact']
old=f.read_bytes();reader=csv.DictReader(io.StringIO(old.decode()));fields=reader.fieldnames;before=list(reader);rows=[dict(r) for r in before]
for r in rows:
 if r['data_id']!='skills-assassin-fire-blast':continue
 assert r['behavior_verification']=='unverified'
 r['behavior_verification']='bounded-functional;independent-acceptance-open'
 r['adapter_route']='shaped-cone-damage+explicit-on-hit-burn'
 r['risk_flags']='cone-and-on-hit-burn-locally-repaired|independent-design-qa-and-earned-balance-open'
 links=r['contract_evidence'].replace(';','|').split('|')+['docs/plans/decisions/D04-fire-blast-cone-v1.md','docs/plans/evidence/d04-fire-blast-cone.md','production/bugs/BUG-207-fire-blast-cross-instead-of-cone.md']
 r['contract_evidence']='|'.join(dict.fromkeys(x for x in links if x))
assert len(rows)==213 and [r['data_id'] for r in rows]==[r['data_id'] for r in before]
changed=[a['data_id'] for a,b in zip(rows,before) if a!=b];assert changed==['skills-assassin-fire-blast']
counts=dict(collections.Counter(r['behavior_verification'].split(';')[0] for r in rows));assert counts=={'unverified':106,'bounded-functional':105,'bounded-engine-functional':1,'review-needed':1}
out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows);raw=out.getvalue().encode();f.write_bytes(raw)
r={'rows':213,'IDs_and_order_unchanged':True,'credited':['skills-assassin-fire-blast'],'changed_rows':changed,'other212rows_exact':True,'counts':counts,'baseline_sha256':hashlib.sha256(old).hexdigest(),'final_sha256':hashlib.sha256(raw).hexdigest()}
(p/'inventory-reconciliation.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
