from pathlib import Path
import json,hashlib
p=Path(__file__).parent
runs=['browser-en-desktop','browser-en-mobile','browser-zh-desktop','browser-zh-mobile']
cases=[];geometry=[];pairs=[]
for run in runs:
 root=p/run;report=json.loads((root/'browser-report.json').read_text());assert len(report['cases'])==1 and not report['failures']
 case=report['cases'][0];assert case['pass'] and case['errors']==[] and case['pairs']==['rank1','rank2'];cases.append({'run':run,**case});geometry+=report['geometry']
 for rank in ['rank1','rank2']:
  before=list(root.glob('*-'+rank+'-before-*.json'));after=list(root.glob('*-'+rank+'-after-*.json'));assert len(before)==len(after)==1
  a=json.loads(before[0].read_text());b=json.loads(after[0].read_text());assert a['version']==b['version']==22
  for domain in ['player','inventory','map','mercs','formation']:assert a[domain]==b[domain],(run,rank,domain)
  pairs.append({'run':run,'rank':rank,'before':str(before[0].relative_to(p)),'after':str(after[0].relative_to(p)),'domains_exact':['player','inventory','map','mercs','formation']})
assert len(cases)==4 and len(pairs)==8 and len(geometry)==20
screenshots=[str(f.relative_to(p)) for run in runs for f in sorted((p/run).glob('*.png'))];assert len(screenshots)==16
result={'cases':cases,'exact_continue_pairs':pairs,'geometry':geometry,'screenshots':screenshots,'cases_total':4,'exact_pairs_total':8,'geometry_total':20,'screenshot_count':16,'synthetic':True,'earned_progression_credit':False,'frozen_inputs':'frozen-inputs.json'}
(p/'browser-audit.json').write_text(json.dumps(result,indent=2)+'\n')
inspected=[]
for run,locale,width in [('browser-en-mobile','en',360),('browser-zh-mobile','zh-CN',360),('browser-en-desktop','en',1280),('browser-zh-desktop','zh-CN',1280)]:
 for suffix in ['description','cone-stats']:inspected.append(f'{run}/{locale}-{width}-fire-blast-{suffix}.png')
for run,locale in [('browser-en-mobile','en'),('browser-zh-mobile','zh-CN')]:inspected.append(f'{run}/{locale}-360-fire-blast-cast-visible.png')
assert all((p/f).is_file() for f in inspected) and len(inspected)==10
visual={'verdict':'PASS within the stated functional scope','individually_inspected':inspected,'individually_inspected_total':10,'findings':'Bilingual one-explosion cone prose and Current/Next shape/damage/Burn/cost rows are legible at both primary sizes. Mobile combat capture shows the real public cast and separate Fire hits/Burn. Fixed bars and existing icon fallback remain. Current rows fully visible; normal scrolling exposes remaining Next rows.','limits':'Full device/a11y/PWA/performance and earned build/balance acceptance remain open.'}
(p/'visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
native=json.loads((p/'fire-blast-cone-repaired.json').read_text());assert len(native['cases'])==12
for case in native['cases']:
 assert case['registered']['aoeShape']=='cone-2' and case['actualTargets']==['target-1','target-3','target-4','target-5']
 assert len(case['actions'])==len(case['payments'])==1 and case['finalMana']==75
 assert sum(t['life'] for t in case['targetFinalHP'])==18000-case['directHP']-case['periodicHP']
seed7=[{'rank':c['rank'],'directHP':c['directHP'],'periodicHP':c['periodicHP'],'finalHP':[u['life'] for u in c['targetFinalHP']]} for c in native['cases'] if c['seed']==7]
(p/'native-audit.json').write_text(json.dumps({'cases':12,'exact_target_ids_all_cases':True,'one_payment_action_all_cases':True,'input_replay_HP_conservation_asserted_by_native_script':True,'rank_seed7':seed7},indent=2)+'\n')
print({'browser_cases':len(cases),'exact_pairs':len(pairs),'geometry':len(geometry),'screenshots':len(screenshots),'individually_inspected':len(inspected),'native_cases':12,'seed7':seed7})
