from pathlib import Path
import os,subprocess,json,hashlib,datetime
r=Path(__file__).resolve().parent
p=r/'browser-temporary-v2';assert not p.exists();p.mkdir()
conf=r/'browser-fontconfig-v2.xml';assert not conf.exists()
conf.write_text('<fontconfig><dir>/usr/share/fonts</dir><dir>/usr/local/share/fonts</dir><dir>/home/felixzhao/.local/share/fonts</dir><cachedir>'+str(p/'fontconfig-cache')+'</cachedir><include>/etc/fonts/conf.d</include></fontconfig>\n')
font=Path('/home/felixzhao/.local/share/fonts/NotoSansCJKsc-Regular.otf');b=font.read_bytes();assert hashlib.sha256(b).hexdigest()=='2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b'
env=dict(os.environ);env.update({'TMPDIR':str(p),'FONTCONFIG_FILE':str(conf),'XDG_CONFIG_HOME':str(p/'config'),'XDG_DATA_HOME':'/home/felixzhao/.local/share','PWA_PORT':'4353','LIGHTNING_MASTERY_OUTPUT_DIR':str(r/'browser-attachments-v2'),'LIGHTNING_MASTERY_REPORT':str(r/'browser-lightning-v2-report.json')})
env.pop('VITE_E2E',None)
(r/'browser-environment-v2.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'temporary':str(p),'fontconfig':str(conf),'fontSHA256':hashlib.sha256(b).hexdigest(),'fontPreserved':True,'port':4353,'outputDir':str(r/'browser-attachments-v2'),'report':str(r/'browser-lightning-v2-report.json'),'temporaryCleanup':'root exact inventory after runner exits and process identities absent; no sharedcache purge'},indent=2)+'\n')
result=subprocess.run(['node','node_modules/@playwright/test/cli.js','test','--config=tests/pwa/lightning-mastery.config.ts'],env=env)
raise SystemExit(result.returncode)
