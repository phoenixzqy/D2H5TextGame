from pathlib import Path
import json,hashlib,tarfile,stat,subprocess,datetime,gzip
r=Path(__file__).resolve().parent;w=Path.cwd();out=w/'docs/plans/evidence/fixtures/p07a03-lightning-mastery'
assert not out.exists();out.mkdir(parents=True)
def fp(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
records=[]
for p in sorted(r.rglob('*')):
 mode=p.lstat().st_mode;assert not stat.S_ISLNK(mode)
 if stat.S_ISDIR(mode):continue
 assert stat.S_ISREG(mode);records.append({'path':str(p.relative_to(r)),**fp(p)})
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for row in records:t.add(r/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(records)
 for m,row in zip(members,records):
  assert m.name==row['path'] and m.isfile();b=t.extractfile(m).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];assert fp(r/row['path'])=={'bytes':row['bytes'],'sha256':row['sha256']}
for row in json.loads((r/'historical-report-compression.json').read_text())['records']:
 b=gzip.decompress((r/row['compressed']).read_bytes());assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
ids=set()
for p in r.glob('*.processes.json'):
 d=json.loads(p.read_text());assert not d['signals'] and not d['remainingNonZombie'];ids.update((v['pid'],v['startTicks']) for v in d['observations'])
for pid,birth in ids:
 try:fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=birth
changed=subprocess.check_output(['git','diff','--name-only','033e057','HEAD'],text=True).splitlines()
# The ledger/index will receive archive and actual cleanup links in later bounded commits.
sources={f:fp(w/f) for f in changed if f not in ['docs/plans/execution-ledger.md','docs/plans/evidence/p07a03-lightning-mastery.md']}
cleanup={n:json.loads((r/n).read_text()) for n in ['stage-a-output-cleanup.json','compat-output-cleanup.json','runtime-output-cleanup.json','native-output-cleanup.json','ui-output-cleanup.json','browser-first-temporary-cleanup.json','browser-second-temporary-cleanup.json','browser-final-temporary-cleanup.json']}
for row in json.loads((r/'ui-owned-output.json').read_text())['files']:assert not (w/row['path']).exists()
packet={'task':'P07a03 player Lightning Mastery','status':'bounded path accepted; umbrella incomplete','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'commits':{'authored':'993e305','compatibility':'2002326','runtime':'e5dc08d','native':'1818c22','ui':'cf8e9fc','browser':'b1bfab6','overlayReport':'71695a4'},'archive':{'path':'raw.tar.gz',**fp(archive),'records':len(records),'uncompressedRawBytes':sum(v['bytes'] for v in records),'allMembersVerified':True},'rawRoot':str(r),'records':records,'currentSourceFingerprints':sources,'fingerprintScope':'all Lightning changed source/bug/decision/spec/test paths through head; mutable ledger/index excluded for archive/cleanup updates','automatedGates':{n:json.loads((r/n).read_text()) for n in ['stage-a-final-gates.json','compat-final-gates.json','runtime-final-gates.json','native-final-gates.json','ui-final-gates.json']},'browser':json.loads((r/'browser-final-gates.json').read_text()),'processAudit':{'cumulativeIdentities':len(ids),'allAbsent':True,'signals':[]},'cleanup':{'completedRecords':cleanup,'rawRemoval':'pending wholepacket review/commit/readersrelease; exact manifest plan archived','rawOwner':'root','installedNotoPreserved':True},'reviews':{'source':'GD/TD/QA/producer approved bounded source/oracles/gates/docs; full review transcripts in archive','browser':'QA/producer APPROVE exact2files/narrowfunctionalacceptance; allreadersreleased; BUG063reported','wholePacket':'pending independent QA/producer review'},'limitations':['existing3sengine/15sfull timing targets missed; warnings retained','native5 immediatelyGREEN; disk write boundary mocked only, no nativeREDclaim','browser2locales9sizes/4explicitSettingsSaveNewPageContinue cycles; samecontext, notprocessrestart/autosave/earnedcampaign','readableChineseactualNoto39glyphs; screenshots scrolledsections; BUG063headeroverlap/iconboxes remain; nofullmobile/readability/a11y signoff','no realdevice/campaignbalance/coverage/performance/fullprivatev1/C0-C4/G0-G7 completion']}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'records':len(records),'rawBytes':packet['archive']['uncompressedRawBytes'],'archive':packet['archive'],'sourceFingerprints':len(sources),'absentIdentities':len(ids)}))
