from pathlib import Path, PurePosixPath
import json,hashlib,tarfile,stat,datetime
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
r=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-might-w1jtf6hl')
out=Path(__file__).resolve().parent/'might-raw-cleanup.json'
assert not out.exists() and r.resolve()==r and r.is_dir()
p=json.loads((w/'docs/plans/evidence/fixtures/p07b02-selected-might/packet.json').read_text())
a=w/'docs/plans/evidence/fixtures/p07b02-selected-might/raw.tar.gz'
assert len(a.read_bytes())==p['archive']['bytes']
assert hashlib.sha256(a.read_bytes()).hexdigest()==p['archive']['sha256']
records=p['records'];assert len(records)==731
expected={v['path']:v for v in records};assert len(expected)==731
with tarfile.open(a,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==732 and all(x.isfile() for x in members)
 assert {x.name for x in members}=={'manifest.json'}|{'raw/'+k for k in expected}
 assert json.load(tar.extractfile('manifest.json'))['records']==records
 for row in records:
  b=tar.extractfile('raw/'+row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
files=[];dirs=[]
for f in r.rglob('*'):
 mode=f.lstat().st_mode
 assert not stat.S_ISLNK(mode),f
 if stat.S_ISREG(mode):files.append(f)
 elif stat.S_ISDIR(mode):dirs.append(f)
 else:raise AssertionError(f)
assert {str(x.relative_to(r)) for x in files}==set(expected)
identities=set()
for f in files:
 row=expected[str(f.relative_to(r))];pp=PurePosixPath(row['path']);assert not pp.is_absolute() and '..' not in pp.parts and f.resolve()==f
 b=f.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 if f.name.endswith('.processes.json'):
  d=json.loads(b)
  for obs in d['observations']:identities.add((obs['pid'],obs['startTicks']))
assert len(identities)==9738,len(identities)
for pid,birth in identities:
 proc=Path('/proc')/str(pid)/'stat'
 try: current=proc.read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(current[19])!=birth,(pid,birth,current[0])
for f in files:f.unlink()
for d in sorted(dirs,key=lambda x:len(x.parts),reverse=True):d.rmdir()
assert not list(r.iterdir())
font=Path('/home/felixzhao/.local/share/fonts/NotoSansCJKsc-Regular.otf')
assert hashlib.sha256(font.read_bytes()).hexdigest()=='2c76254f6fc379fddfce0a7e84fb5385bb135d3e399294f6eeb6680d0365b74b'
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(a),'archiveSha256':p['archive']['sha256'],'removedManifestFiles':len(files),'removedBytes':sum(x['bytes'] for x in records),'removedEmptyChildDirectories':len(dirs),'processIdentitiesRecheckedAbsent':len(identities),'allFilesAbsent':True,'retainedEmptyRoot':str(r),'rootReason':'preserve RAW root and shared parents per approved cleanup scope','fontPreserved':str(font),'readersReleased':'producer/QA/GD/TD release recorded in committed packet','failures':[]}
out.write_text(json.dumps(result,indent=2)+'\n');print(out.read_text())
