# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lightning-mastery.spec.ts >> Lightning Mastery imported eligibility, bilingual layouts and disk reload en
- Location: tests/pwa/lightning-mastery.spec.ts:48:3

# Error details

```
Test timeout of 50000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 50000ms exceeded.
Call log:
  - waiting for getByTestId('skill-detail-panel').getByRole('button', { name: 'Allocate', exact: true })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "Main navigation" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "Town" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: Town
        - listitem [ref=e10]:
          - link "Map" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: Map
        - listitem [ref=e14]:
          - link "Combat" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: Combat
        - listitem [ref=e18]:
          - link "Inventory" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: Inventory
        - listitem [ref=e22]:
          - link "Skills" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: Skills
        - listitem [ref=e26]:
          - link "Mercs" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: Mercs
        - listitem [ref=e30]:
          - link "Quests" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: Quests
        - listitem [ref=e34]:
          - link "Settings" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: Settings
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]: Skills
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - generic [ref=e44]: "Skill Points: 2"
            - generic [ref=e45]: Level 30
          - generic [ref=e46]:
            - tablist [ref=e47]:
              - tab "Skill Tree" [selected] [ref=e48] [cursor=pointer]
              - tab "Active Skills" [ref=e49] [cursor=pointer]
            - tabpanel "Skill Tree" [ref=e50]:
              - generic [ref=e51]:
                - generic [ref=e52]:
                  - generic [ref=e53]:
                    - heading "Cold Spells" [level=2] [ref=e54]
                    - paragraph [ref=e55]: Hover, focus, or tap a node to preview its current and next-level power.
                    - generic [ref=e56]:
                      - img [ref=e57]
                      - button "Ice Bolt, level 0 of 20, available" [ref=e62] [cursor=pointer]:
                        - generic [ref=e63]:
                          - img [ref=e64]
                          - generic [ref=e65]: Ice Bolt
                        - generic [ref=e66]: Ice Bolt
                        - generic [ref=e67]: 0/20
                      - button "Frozen Armor, level 0 of 20, available" [ref=e68] [cursor=pointer]:
                        - generic [ref=e69]:
                          - img [ref=e70]
                          - generic [ref=e71]: Frozen Armor
                        - generic [ref=e72]: Frozen Armor
                        - generic [ref=e73]: 0/20
                      - button "Frost Nova, level 0 of 20, locked" [ref=e74] [cursor=pointer]:
                        - generic [ref=e75]:
                          - img [ref=e76]
                          - generic [ref=e77]: Frost Nova
                        - generic [ref=e78]: Frost Nova
                        - generic [ref=e79]: 🔒
                        - generic [ref=e80]: 0/20
                      - button "Ice Blast, level 0 of 20, locked" [ref=e81] [cursor=pointer]:
                        - generic [ref=e82]:
                          - img [ref=e83]
                          - generic [ref=e84]: Ice Blast
                        - generic [ref=e85]: Ice Blast
                        - generic [ref=e86]: 🔒
                        - generic [ref=e87]: 0/20
                      - button "Shiver Armor, level 0 of 20, locked" [ref=e88] [cursor=pointer]:
                        - generic [ref=e89]:
                          - img [ref=e90]
                          - generic [ref=e91]: Shiver Armor
                        - generic [ref=e92]: Shiver Armor
                        - generic [ref=e93]: 🔒
                        - generic [ref=e94]: 0/20
                      - button "Glacial Spike, level 0 of 20, locked" [ref=e95] [cursor=pointer]:
                        - generic [ref=e96]:
                          - img [ref=e97]
                          - generic [ref=e98]: Glacial Spike
                        - generic [ref=e99]: Glacial Spike
                        - generic [ref=e100]: 🔒
                        - generic [ref=e101]: 0/20
                      - button "Chilling Armor, level 0 of 20, locked" [ref=e102] [cursor=pointer]:
                        - generic [ref=e103]:
                          - img [ref=e104]
                          - generic [ref=e105]: Chilling Armor
                        - generic [ref=e106]: Chilling Armor
                        - generic [ref=e107]: 🔒
                        - generic [ref=e108]: 0/20
                      - button "Blizzard, level 0 of 20, locked" [ref=e109] [cursor=pointer]:
                        - generic [ref=e110]:
                          - img [ref=e111]
                          - generic [ref=e112]: Blizzard
                        - generic [ref=e113]: Blizzard
                        - generic [ref=e114]: 🔒
                        - generic [ref=e115]: 0/20
                      - button "Frozen Orb, level 0 of 20, locked" [ref=e116] [cursor=pointer]:
                        - generic [ref=e117]:
                          - img [ref=e118]
                          - generic [ref=e119]: Frozen Orb
                        - generic [ref=e120]: Frozen Orb
                        - generic [ref=e121]: 🔒
                        - generic [ref=e122]: 0/20
                      - button "Cold Mastery, level 0 of 20, available" [ref=e123] [cursor=pointer]:
                        - generic [ref=e124]:
                          - img [ref=e125]
                          - generic [ref=e126]: Cold Mastery
                        - generic [ref=e127]: Cold Mastery
                        - generic [ref=e128]: 0/20
                  - generic [ref=e129]:
                    - heading "Lightning Spells" [level=2] [ref=e130]
                    - paragraph [ref=e131]: Hover, focus, or tap a node to preview its current and next-level power.
                    - generic [ref=e132]:
                      - img [ref=e133]
                      - button "Charged Bolt, level 0 of 20, available" [ref=e137] [cursor=pointer]:
                        - generic [ref=e138]:
                          - img [ref=e139]
                          - generic [ref=e140]: Charged Bolt
                        - generic [ref=e141]: Charged Bolt
                        - generic [ref=e142]: 0/20
                      - button "Telekinesis, level 0 of 20, available" [ref=e143] [cursor=pointer]:
                        - generic [ref=e144]:
                          - img [ref=e145]
                          - generic [ref=e146]: Telekinesis
                        - generic [ref=e147]: Telekinesis
                        - generic [ref=e148]: 0/20
                      - button "Static Field, level 0 of 20, available" [ref=e149] [cursor=pointer]:
                        - generic [ref=e150]:
                          - img [ref=e151]
                          - generic [ref=e152]: Static Field
                        - generic [ref=e153]: Static Field
                        - generic [ref=e154]: 0/20
                      - button "Nova, level 0 of 20, locked" [ref=e155] [cursor=pointer]:
                        - generic [ref=e156]:
                          - img [ref=e157]
                          - generic [ref=e158]: Nova
                        - generic [ref=e159]: Nova
                        - generic [ref=e160]: 🔒
                        - generic [ref=e161]: 0/20
                      - button "Lightning, level 0 of 20, locked" [ref=e162] [cursor=pointer]:
                        - generic [ref=e163]:
                          - img [ref=e164]
                          - generic [ref=e165]: Lightning
                        - generic [ref=e166]: Lightning
                        - generic [ref=e167]: 🔒
                        - generic [ref=e168]: 0/20
                      - button "Teleport, level 0 of 20, locked" [ref=e169] [cursor=pointer]:
                        - generic [ref=e170]:
                          - img [ref=e171]
                          - generic [ref=e172]: Teleport
                        - generic [ref=e173]: Teleport
                        - generic [ref=e174]: 🔒
                        - generic [ref=e175]: 0/20
                      - button "Chain Lightning, level 0 of 20, locked" [ref=e176] [cursor=pointer]:
                        - generic [ref=e177]:
                          - img [ref=e178]
                          - generic [ref=e179]: Chain Lightning
                        - generic [ref=e180]: Chain Lightning
                        - generic [ref=e181]: 🔒
                        - generic [ref=e182]: 0/20
                      - button "Energy Shield, level 0 of 20, locked" [ref=e183] [cursor=pointer]:
                        - generic [ref=e184]:
                          - img [ref=e185]
                          - generic [ref=e186]: Energy Shield
                        - generic [ref=e187]: Energy Shield
                        - generic [ref=e188]: 🔒
                        - generic [ref=e189]: 0/20
                      - button "Thunder Storm, level 0 of 20, locked" [ref=e190] [cursor=pointer]:
                        - generic [ref=e191]:
                          - img [ref=e192]
                          - generic [ref=e193]: Thunder Storm
                        - generic [ref=e194]: Thunder Storm
                        - generic [ref=e195]: 🔒
                        - generic [ref=e196]: 0/20
                      - button "Lightning Mastery, level 0 of 20, available" [ref=e197] [cursor=pointer]:
                        - generic [ref=e198]:
                          - img [ref=e199]
                          - generic [ref=e200]: Lightning Mastery
                        - generic [ref=e201]: Lightning Mastery
                        - generic [ref=e202]: 0/20
                  - generic [ref=e203]:
                    - heading "Fire Spells" [level=2] [ref=e204]
                    - paragraph [ref=e205]: Hover, focus, or tap a node to preview its current and next-level power.
                    - generic [ref=e206]:
                      - img [ref=e207]
                      - button "Warmth, level 0 of 20, available" [ref=e212] [cursor=pointer]:
                        - generic [ref=e213]:
                          - img [ref=e214]
                          - generic [ref=e215]: Warmth
                        - generic [ref=e216]: Warmth
                        - generic [ref=e217]: 0/20
                      - button "Fire Bolt, level 1 of 20, learned" [ref=e218] [cursor=pointer]:
                        - generic [ref=e219]:
                          - img [ref=e220]
                          - generic [ref=e221]: Fire Bolt
                        - generic [ref=e222]: Fire Bolt
                        - generic [ref=e223]: 1/20
                      - button "Inferno, level 0 of 20, available" [ref=e224] [cursor=pointer]:
                        - generic [ref=e225]:
                          - img [ref=e226]
                          - generic [ref=e227]: Inferno
                        - generic [ref=e228]: Inferno
                        - generic [ref=e229]: 0/20
                      - button "Fire Ball, level 0 of 20, available" [ref=e230] [cursor=pointer]:
                        - generic [ref=e231]:
                          - img [ref=e232]
                          - generic [ref=e233]: Fire Ball
                        - generic [ref=e234]: Fire Ball
                        - generic [ref=e235]: 0/20
                      - button "Blaze, level 0 of 20, locked" [active] [ref=e236] [cursor=pointer]:
                        - generic [ref=e237]:
                          - img [ref=e238]
                          - generic [ref=e239]: Blaze
                        - generic [ref=e240]: Blaze
                        - generic [ref=e241]: 🔒
                        - generic [ref=e242]: 0/20
                      - button "Enchant, level 0 of 20, locked" [ref=e243] [cursor=pointer]:
                        - generic [ref=e244]:
                          - img [ref=e245]
                          - generic [ref=e246]: Enchant
                        - generic [ref=e247]: Enchant
                        - generic [ref=e248]: 🔒
                        - generic [ref=e249]: 0/20
                      - button "Fire Wall, level 0 of 20, locked" [ref=e250] [cursor=pointer]:
                        - generic [ref=e251]:
                          - img [ref=e252]
                          - generic [ref=e253]: Fire Wall
                        - generic [ref=e254]: Fire Wall
                        - generic [ref=e255]: 🔒
                        - generic [ref=e256]: 0/20
                      - button "Meteor, level 0 of 20, locked" [ref=e257] [cursor=pointer]:
                        - generic [ref=e258]:
                          - img [ref=e259]
                          - generic [ref=e260]: Meteor
                        - generic [ref=e261]: Meteor
                        - generic [ref=e262]: 🔒
                        - generic [ref=e263]: 0/20
                      - button "Hydra, level 0 of 20, locked" [ref=e264] [cursor=pointer]:
                        - generic [ref=e265]:
                          - img [ref=e266]
                          - generic [ref=e267]: Hydra
                        - generic [ref=e268]: Hydra
                        - generic [ref=e269]: 🔒
                        - generic [ref=e270]: 0/20
                      - button "Fire Mastery, level 0 of 20, available" [ref=e271] [cursor=pointer]:
                        - generic [ref=e272]:
                          - img [ref=e273]
                          - generic [ref=e274]: Fire Mastery
                        - generic [ref=e275]: Fire Mastery
                        - generic [ref=e276]: 0/20
                - generic [ref=e278]:
                  - generic [ref=e279]:
                    - generic [ref=e280]:
                      - heading "Blaze" [level=2] [ref=e281]
                      - paragraph [ref=e282]: Unlearned / 20 · Active
                    - button "Need Prereq" [disabled] [ref=e283]
                  - paragraph [ref=e284]: "Blaze: 60 ~ 85 Fire damage."
                  - generic [ref=e285]:
                    - generic [ref=e286]:
                      - heading "Not Learned" [level=3] [ref=e287]
                      - paragraph [ref=e288]: Spend a point to unlock current stats.
                    - generic [ref=e289]:
                      - heading "Learned at Lv. 1" [level=3] [ref=e290]
                      - generic [ref=e291]:
                        - generic [ref=e292]:
                          - term [ref=e293]: Fire attack
                          - definition [ref=e294]: 60 ~ 85
                        - generic [ref=e295]:
                          - term [ref=e296]: Mana Cost
                          - definition [ref=e297]: "22"
                        - generic [ref=e298]:
                          - term [ref=e299]: Cooldown
                          - definition [ref=e300]: 3 s
                        - generic [ref=e301]:
                          - term [ref=e302]: Applies
                          - definition [ref=e303]: Burn
                    - generic [ref=e304]:
                      - heading "Requirements" [level=3] [ref=e305]
                      - generic [ref=e306]:
                        - generic [ref=e307]:
                          - term [ref=e308]: Character Level
                          - definition [ref=e309]: Lv. 12Met
                        - generic [ref=e310]:
                          - term [ref=e311]: Prerequisites
                          - definition [ref=e312]: Inferno (missing)
  - button "Lightning Master · Level 30. Open character sheet." [ref=e313] [cursor=pointer]:
    - generic [ref=e315]: "30"
    - generic [ref=e316]:
      - generic [ref=e317]:
        - generic [ref=e318]: Lightning Master
        - generic [ref=e319]: Level 30
      - generic [ref=e320]:
        - generic [ref=e321]: HP
        - progressbar "HP" [ref=e322]
      - generic [ref=e324]:
        - generic [ref=e325]: MP
        - progressbar "MP" [ref=e326]
      - generic [ref=e328]:
        - generic [ref=e329]: XP
        - progressbar "XP" [ref=e330]
```

# Test source

```ts
  1   | /** Explicit imported L30 eligibility; production UI and actual Settings Save/disk reload only. */
  2   | import { expect, test, type Page, type TestInfo } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { createCharacter, navTo } from '../e2e/_helpers';
  6   | const MASTERY = 'skills-sorceress-lightning-mastery';
  7   | const BOLT = 'skills-sorceress-fire-bolt';
  8   | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  9   | const prose = {
  10  |   en: 'Passive: +4% direct lightning damage per allocated skill rank (up to +80% at rank 20). Unlocks at character level 30. Paralyze is unchanged.',
  11  |   'zh-CN': '被动：每投入1点技能点，直接闪电伤害+4%（最多20点，合计+80%）。角色30级解锁，麻痹效果不变。'
  12  | };
  13  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  14  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  15  | }
  16  | async function backup(page: Page): Promise<SaveCurrent> {
  17  |   await navTo(page, 'settings');
  18  |   const pending = page.waitForEvent('download');
  19  |   await page.getByTestId('export-save-button').click();
  20  |   const download = await pending;
  21  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  22  |   finally { await download.delete(); }
  23  | }
  24  | async function production(page: Page): Promise<void> {
  25  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  26  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  27  | }
  28  | function durable(save: SaveCurrent): void {
  29  |   expect(JSON.stringify(save)).not.toMatch(/"increasedDamagePct"|"manaRegenPerSecond"|"manaRegenCarry"|"manaRegenExactCarry"|"manaRegenCompensation"|"activeBuffIds"|"frozenArmor"|"carryPlayerTeam"/);
  30  | }
  31  | async function slots(page: Page, english: boolean): Promise<void> {
  32  |   await navTo(page, 'skills');
  33  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  34  |   for (let index = 1; index <= 9; index++) {
  35  |     const slot = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(index)}`, exact: true });
  36  |     await expect(slot).toHaveValue(index === 1 ? BOLT : '');
  37  |     await expect(slot.locator(`option[value="${MASTERY}"]`)).toHaveCount(0);
  38  |     await expect(slot.locator('option')).toHaveCount(2); // Empty and the only learned active, Fire Bolt.
  39  |   }
  40  | }
  41  | async function selectMastery(page: Page): Promise<void> {
  42  |   await navTo(page, 'skills');
  43  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  44  |   await page.getByTestId(`skill-node-${MASTERY}`).click();
  45  | }
  46  | 
  47  | for (const locale of ['en', 'zh-CN'] as const) {
  48  |   test(`Lightning Mastery imported eligibility, bilingual layouts and disk reload ${locale}`, async ({ page: initial, context }, info) => {
  49  |     const english = locale === 'en';
  50  |     const errors: string[] = [];
  51  |     const watch = (p: Page): void => {
  52  |       p.on('pageerror', error => errors.push(error.message));
  53  |       p.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  54  |     };
  55  |     let page = initial; watch(page);
  56  |     await page.goto('/');
  57  |     await createCharacter(page, { class: 'sorceress', name: 'Lightning Mastery' });
  58  |     await navTo(page, 'settings');
  59  |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  60  |     const fresh = await backup(page);
  61  |     expect(fresh.player).toMatchObject({ level: 1, skillPoints: 1, class: 'sorceress' });
  62  |     expect(fresh.player.comboOrder).toEqual(['sorceress.frost_nova', 'sorceress.ice_bolt']);
  63  |     await selectMastery(page);
  64  |     await expect(page.getByTestId('skill-detail-panel').getByRole('button', { name: english ? 'Requires Lv. 30' : '需要等级 30', exact: true })).toBeDisabled();
  65  |     await expect(page.getByTestId('skill-detail-panel')).toContainText(prose[locale]);
  66  |     const locked = await backup(page);
  67  |     // Existing first-visit sanitizer removes the locked Frost Nova and normalizes learned Ice Bolt.
  68  |     expect(locked.player).toEqual({ ...fresh.player, comboOrder: ['skills-sorceress-ice-bolt'] });
  69  |     await attach(info, '01-fresh-locked-control', locked);
  70  |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
  71  |       skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: [BOLT] } };
  72  |     const importLabel = english ? 'Import Save' : '导入存档';
  73  |     await page.getByRole('button', { name: importLabel, exact: true }).click();
  74  |     const dialog = page.getByRole('dialog');
  75  |     await dialog.getByRole('textbox').fill(JSON.stringify(incoming));
  76  |     await dialog.getByRole('button', { name: importLabel, exact: true }).click();
  77  |     await expect(dialog).toHaveCount(0);
  78  |     const prepared = await backup(page);
  79  |     expect(prepared.player).toEqual(incoming.player);
  80  |     expect(prepared.inventory).toEqual(fresh.inventory);
  81  |     expect(prepared.map).toEqual(fresh.map);
  82  |     durable(prepared);
  83  |     await attach(info, '02-explicit-imported-eligibility', prepared);
  84  |     try {
  85  |       for (const rank of [1, 2]) {
  86  |         await selectMastery(page);
  87  |         const panel = page.getByTestId('skill-detail-panel');
  88  |         const allocate = panel.getByRole('button', { name: english ? 'Allocate' : '分配', exact: true });
  89  |         // Native keyboard traversal from the selected tree node; no focus() or DOM click injection.
  90  |         let reached = false;
  91  |         for (let step = 0; step < 100; step++) {
  92  |           await page.keyboard.press('Tab');
> 93  |           if (await allocate.evaluate(node => node === document.activeElement)) { reached = true; break; }
      |                              ^ Error: locator.evaluate: Test timeout of 50000ms exceeded.
  94  |         }
  95  |         expect(reached).toBe(true);
  96  |         await expect(allocate).toBeFocused();
  97  |         await page.keyboard.press('Enter');
  98  |         await expect(panel).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  99  |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true }) });
  100 |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true }) });
  101 |         const label = english ? 'Lightning Damage' : '闪电伤害';
  102 |         await expect(current.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String(rank * 4)}%`);
  103 |         await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(new RegExp(`^${String((rank + 1) * 4)}%\\s*\\(\\+4%\\)$`));
  104 |         await expect(panel).toContainText(prose[locale]);
  105 |         if (rank === 1) {
  106 |           const metrics = [];
  107 |           for (const [width, height] of sizes) {
  108 |             await page.setViewportSize({ width, height });
  109 |             const control = panel.getByRole('button');
  110 |             await control.scrollIntoViewIfNeeded();
  111 |             const bounds = await control.boundingBox();
  112 |             expect(bounds).not.toBeNull();
  113 |             expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  114 |             await production(page);
  115 |             const description = panel.getByText(prose[locale], { exact: true });
  116 |             await description.scrollIntoViewIfNeeded();
  117 |             const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  118 |             expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14);
  119 |             await expect(description).toBeVisible();
  120 |             if (!english && width === 360) {
  121 |               const cdp = await context.newCDPSession(page);
  122 |               try {
  123 |                 await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  124 |                 const document = await cdp.send('DOM.getDocument');
  125 |                 const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId,
  126 |                   selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  127 |                 const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  128 |                 await attach(info, '03-actual-Chinese-platform-fonts', fonts);
  129 |                 expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
  130 |               } finally { await cdp.detach(); }
  131 |             }
  132 |             await info.attach(`layout-${String(width)}x${String(height)}`, { body: await page.screenshot(), contentType: 'image/png' });
  133 |             for (const section of [current, next]) {
  134 |               await section.scrollIntoViewIfNeeded(); await expect(section).toBeVisible();
  135 |             }
  136 |             metrics.push({ width, height, bounds, font });
  137 |           }
  138 |           await attach(info, '03-layout-metrics', metrics);
  139 |         }
  140 |         await slots(page, english);
  141 |         const saved = await backup(page);
  142 |         expect(saved.player.skillLevels).toEqual({ 'sorceress.fire_bolt': 1, 'sorceress.lightning_mastery': rank });
  143 |         expect(saved.player.skillPoints).toBe(2 - rank); expect(saved.player.comboOrder).toEqual([BOLT]);
  144 |         expect(saved.player.derivedStats).toEqual(fresh.player.derivedStats); durable(saved);
  145 |         await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  146 |         await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  147 |         await page.close(); page = await context.newPage(); watch(page);
  148 |         await page.goto('/'); await page.getByTestId('home-continue').click();
  149 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  150 |         const loaded = await backup(page);
  151 |         expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
  152 |         expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
  153 |         expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta.settings).toEqual(saved.meta.settings); durable(loaded);
  154 |         await attach(info, `04-rank${String(rank)}-actual-disk-reload`, { saved, loaded });
  155 |         await selectMastery(page); await expect(page.getByTestId('skill-detail-panel')).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  156 |         await production(page);
  157 |       }
  158 |       await attach(info, '05-console-errors', errors); expect(errors).toEqual([]);
  159 |     } finally { await page.close(); }
  160 |   });
  161 | }
  162 | 
```