# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: lightning-mastery.spec.ts >> Lightning Mastery imported eligibility, bilingual layouts and disk reload en
- Location: tests/pwa/lightning-mastery.spec.ts:48:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 1

@@ -1,11 +1,10 @@
  Object {
    "alive": true,
    "class": "sorceress",
    "comboOrder": Array [
-     "sorceress.frost_nova",
-     "sorceress.ice_bolt",
+     "skills-sorceress-ice-bolt",
    ],
    "cooldowns": Array [],
    "coreStats": Object {
      "dexterity": 25,
      "energy": 35,
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - generic [ref=e3]:
    - navigation "Main navigation" [ref=e4]:
      - list [ref=e5]:
        - listitem [ref=e6]:
          - link "Town" [ref=e7] [cursor=pointer]:
            - /url: /town
            - generic [ref=e8]: 🏰
            - generic [ref=e9]: Town
        - listitem [ref=e10]:
          - link "Map" [ref=e11] [cursor=pointer]:
            - /url: /map
            - generic [ref=e12]: 🗺️
            - generic [ref=e13]: Map
        - listitem [ref=e14]:
          - link "Combat" [ref=e15] [cursor=pointer]:
            - /url: /combat
            - generic [ref=e16]: ⚔️
            - generic [ref=e17]: Combat
        - listitem [ref=e18]:
          - link "Inventory" [ref=e19] [cursor=pointer]:
            - /url: /inventory
            - generic [ref=e20]: 🎒
            - generic [ref=e21]: Inventory
        - listitem [ref=e22]:
          - link "Skills" [ref=e23] [cursor=pointer]:
            - /url: /skills
            - generic [ref=e24]: ✨
            - generic [ref=e25]: Skills
        - listitem [ref=e26]:
          - link "Mercs" [ref=e27] [cursor=pointer]:
            - /url: /mercs
            - generic [ref=e28]: 🛡️
            - generic [ref=e29]: Mercs
        - listitem [ref=e30]:
          - link "Quests" [ref=e31] [cursor=pointer]:
            - /url: /quests
            - generic [ref=e32]: 📜
            - generic [ref=e33]: Quests
        - listitem [ref=e34]:
          - link "Settings" [ref=e35] [cursor=pointer]:
            - /url: /settings
            - generic [ref=e36]: ⚙️
            - generic [ref=e37]: Settings
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]: Settings
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - heading "Language" [level=2] [ref=e44]
            - generic [ref=e45]:
              - button "简体中文" [ref=e46] [cursor=pointer]
              - button "English" [pressed] [ref=e47] [cursor=pointer]
          - generic [ref=e48]:
            - generic [ref=e49] [cursor=pointer]:
              - generic [ref=e50]:
                - generic [ref=e51]: Stealth Mode
                - generic [ref=e52]: Hide icons and colors for workplace discretion
              - checkbox "Stealth Mode" [ref=e53]
            - generic [ref=e55] [cursor=pointer]:
              - generic [ref=e57]: Sound
              - checkbox "Sound" [checked] [ref=e58]
            - generic [ref=e60] [cursor=pointer]:
              - generic [ref=e62]: Music
              - checkbox "Music" [checked] [ref=e63]
          - generic [ref=e64]:
            - heading "Save Management" [level=2] [ref=e65]
            - generic [ref=e66]:
              - button "Save" [ref=e67] [cursor=pointer]
              - button "Export Save" [active] [ref=e68] [cursor=pointer]
              - button "Import Save" [ref=e69] [cursor=pointer]
              - button "Delete Save" [ref=e70] [cursor=pointer]
          - generic [ref=e71]:
            - link "☕ Buy me a coffee" [ref=e72] [cursor=pointer]:
              - /url: https://www.buymeacoffee.com/
            - generic [ref=e73]: "Version: 0.1.0"
        - status [ref=e74]: Save exported
  - button "Lightning Master · Level 1. Open character sheet." [ref=e75] [cursor=pointer]:
    - generic [ref=e77]: "1"
    - generic [ref=e78]:
      - generic [ref=e79]:
        - generic [ref=e80]: Lightning Master
        - generic [ref=e81]: Level 1
      - generic [ref=e82]:
        - generic [ref=e83]: HP
        - progressbar "HP" [ref=e84]
      - generic [ref=e86]:
        - generic [ref=e87]: MP
        - progressbar "MP" [ref=e88]
      - generic [ref=e90]:
        - generic [ref=e91]: XP
        - progressbar "XP" [ref=e92]
```

# Test source

```ts
  1   | /** Explicit imported L30 eligibility; production UI and actual Settings Save/disk reload only. */
  2   | import { expect, test, type Page, type TestInfo } from '@playwright/test';
  3   | import { readFile } from 'node:fs/promises';
  4   | import type { SaveCurrent } from '../../src/engine/types/save';
  5   | import { createCharacter, navTo } from '../e2e/_helpers';
  6   | const MASTERY = 'skills-sorceress-lightning-mastery';
  7   | const BOLT = 'skills-sorceress-fire-bolt';
  8   | const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
  9   | const prose = {
  10  |   en: 'Passive: +4% direct lightning damage per allocated skill rank (up to +80% at rank 20). Unlocks at character level 30. Paralyze is unchanged.',
  11  |   'zh-CN': '被动：每投入1点技能点，直接闪电伤害+4%（最多20点，合计+80%）。角色30级解锁，麻痹效果不变。'
  12  | };
  13  | async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  14  |   await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
  15  | }
  16  | async function backup(page: Page): Promise<SaveCurrent> {
  17  |   await navTo(page, 'settings');
  18  |   const pending = page.waitForEvent('download');
  19  |   await page.getByTestId('export-save-button').click();
  20  |   const download = await pending;
  21  |   try { return JSON.parse(await readFile(await download.path(), 'utf8')) as SaveCurrent; }
  22  |   finally { await download.delete(); }
  23  | }
  24  | async function production(page: Page): Promise<void> {
  25  |   expect(await page.evaluate(() => '__GAME__' in window)).toBe(false);
  26  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  27  | }
  28  | function durable(save: SaveCurrent): void {
  29  |   expect(JSON.stringify(save)).not.toMatch(/"increasedDamagePct"|"manaRegenPerSecond"|"manaRegenCarry"|"manaRegenExactCarry"|"manaRegenCompensation"|"activeBuffIds"|"frozenArmor"|"carryPlayerTeam"/);
  30  | }
  31  | async function slots(page: Page, english: boolean): Promise<void> {
  32  |   await navTo(page, 'skills');
  33  |   await page.locator('[role="tab"][aria-controls="tabpanel-active"]').click();
  34  |   for (let index = 1; index <= 9; index++) {
  35  |     const slot = page.getByRole('combobox', { name: `${english ? 'Slot' : '槽位'} ${String(index)}`, exact: true });
  36  |     await expect(slot).toHaveValue(index === 1 ? BOLT : '');
  37  |     await expect(slot.locator(`option[value="${MASTERY}"]`)).toHaveCount(0);
  38  |     await expect(slot.locator('option')).toHaveCount(2); // Empty and the only learned active, Fire Bolt.
  39  |   }
  40  | }
  41  | async function selectMastery(page: Page): Promise<void> {
  42  |   await navTo(page, 'skills');
  43  |   await page.locator('[role="tab"][aria-controls="tabpanel-tree"]').click();
  44  |   await page.getByTestId(`skill-node-${MASTERY}`).click();
  45  | }
  46  | 
  47  | for (const locale of ['en', 'zh-CN'] as const) {
  48  |   test(`Lightning Mastery imported eligibility, bilingual layouts and disk reload ${locale}`, async ({ page: initial, context }, info) => {
  49  |     const english = locale === 'en';
  50  |     const errors: string[] = [];
  51  |     const watch = (p: Page): void => {
  52  |       p.on('pageerror', error => errors.push(error.message));
  53  |       p.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
  54  |     };
  55  |     let page = initial; watch(page);
  56  |     await page.goto('/');
  57  |     await createCharacter(page, { class: 'sorceress', name: 'Lightning Mastery' });
  58  |     await navTo(page, 'settings');
  59  |     await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
  60  |     const fresh = await backup(page);
  61  |     expect(fresh.player).toMatchObject({ level: 1, skillPoints: 1, class: 'sorceress' });
  62  |     await selectMastery(page);
  63  |     await expect(page.getByTestId('skill-detail-panel').getByRole('button', { name: english ? 'Requires Lv. 30' : '需要等级 30', exact: true })).toBeDisabled();
  64  |     await expect(page.getByTestId('skill-detail-panel')).toContainText(prose[locale]);
  65  |     const locked = await backup(page);
> 66  |     expect(locked.player).toEqual(fresh.player);
      |                           ^ Error: expect(received).toEqual(expected) // deep equality
  67  |     await attach(info, '01-fresh-locked-control', locked);
  68  |     const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
  69  |       skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: [BOLT] } };
  70  |     const importLabel = english ? 'Import Save' : '导入存档';
  71  |     await page.getByRole('button', { name: importLabel, exact: true }).click();
  72  |     const dialog = page.getByRole('dialog');
  73  |     await dialog.getByRole('textbox').fill(JSON.stringify(incoming));
  74  |     await dialog.getByRole('button', { name: importLabel, exact: true }).click();
  75  |     await expect(dialog).toHaveCount(0);
  76  |     const prepared = await backup(page);
  77  |     expect(prepared.player).toEqual(incoming.player);
  78  |     expect(prepared.inventory).toEqual(fresh.inventory);
  79  |     expect(prepared.map).toEqual(fresh.map);
  80  |     durable(prepared);
  81  |     await attach(info, '02-explicit-imported-eligibility', prepared);
  82  |     try {
  83  |       for (const rank of [1, 2]) {
  84  |         await selectMastery(page);
  85  |         const panel = page.getByTestId('skill-detail-panel');
  86  |         const allocate = panel.getByRole('button', { name: english ? 'Allocate' : '分配', exact: true });
  87  |         // Native keyboard traversal from the selected tree node; no focus() or DOM click injection.
  88  |         let reached = false;
  89  |         for (let step = 0; step < 100; step++) {
  90  |           await page.keyboard.press('Tab');
  91  |           if (await allocate.evaluate(node => node === document.activeElement)) { reached = true; break; }
  92  |         }
  93  |         expect(reached).toBe(true);
  94  |         await expect(allocate).toBeFocused();
  95  |         await page.keyboard.press('Enter');
  96  |         await expect(panel).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  97  |         const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true }) });
  98  |         const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true }) });
  99  |         const label = english ? 'Lightning Damage' : '闪电伤害';
  100 |         await expect(current.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String(rank * 4)}%`);
  101 |         await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(new RegExp(`^${String((rank + 1) * 4)}%\\s*\\(\\+4%\\)$`));
  102 |         await expect(panel).toContainText(prose[locale]);
  103 |         if (rank === 1) {
  104 |           const metrics = [];
  105 |           for (const [width, height] of sizes) {
  106 |             await page.setViewportSize({ width, height });
  107 |             const control = panel.getByRole('button');
  108 |             await control.scrollIntoViewIfNeeded();
  109 |             const bounds = await control.boundingBox();
  110 |             expect(bounds).not.toBeNull();
  111 |             expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
  112 |             await production(page);
  113 |             const description = panel.getByText(prose[locale], { exact: true });
  114 |             await description.scrollIntoViewIfNeeded();
  115 |             const font = await description.evaluate(node => getComputedStyle(node).fontSize);
  116 |             expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14);
  117 |             await expect(description).toBeVisible();
  118 |             if (!english && width === 360) {
  119 |               const cdp = await context.newCDPSession(page);
  120 |               try {
  121 |                 await cdp.send('DOM.enable'); await cdp.send('CSS.enable');
  122 |                 const document = await cdp.send('DOM.getDocument');
  123 |                 const node = await cdp.send('DOM.querySelector', { nodeId: document.root.nodeId,
  124 |                   selector: '[data-testid="skill-detail-panel"] #skill-detail-panel > p' });
  125 |                 const fonts = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: node.nodeId });
  126 |                 await attach(info, '03-actual-Chinese-platform-fonts', fonts);
  127 |                 expect(fonts.fonts.some(font => font.familyName === 'Noto Sans CJK SC' && font.glyphCount > 0)).toBe(true);
  128 |               } finally { await cdp.detach(); }
  129 |             }
  130 |             await info.attach(`layout-${String(width)}x${String(height)}`, { body: await page.screenshot(), contentType: 'image/png' });
  131 |             for (const section of [current, next]) {
  132 |               await section.scrollIntoViewIfNeeded(); await expect(section).toBeVisible();
  133 |             }
  134 |             metrics.push({ width, height, bounds, font });
  135 |           }
  136 |           await attach(info, '03-layout-metrics', metrics);
  137 |         }
  138 |         await slots(page, english);
  139 |         const saved = await backup(page);
  140 |         expect(saved.player.skillLevels).toEqual({ 'sorceress.fire_bolt': 1, 'sorceress.lightning_mastery': rank });
  141 |         expect(saved.player.skillPoints).toBe(2 - rank); expect(saved.player.comboOrder).toEqual([BOLT]);
  142 |         expect(saved.player.derivedStats).toEqual(fresh.player.derivedStats); durable(saved);
  143 |         await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
  144 |         await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
  145 |         await page.close(); page = await context.newPage(); watch(page);
  146 |         await page.goto('/'); await page.getByTestId('home-continue').click();
  147 |         await expect(page.getByTestId('town-screen')).toBeVisible();
  148 |         const loaded = await backup(page);
  149 |         expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
  150 |         expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
  151 |         expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta.settings).toEqual(saved.meta.settings); durable(loaded);
  152 |         await attach(info, `04-rank${String(rank)}-actual-disk-reload`, { saved, loaded });
  153 |         await selectMastery(page); await expect(page.getByTestId('skill-detail-panel')).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
  154 |         await production(page);
  155 |       }
  156 |       await attach(info, '05-console-errors', errors); expect(errors).toEqual([]);
  157 |     } finally { await page.close(); }
  158 |   });
  159 | }
  160 | 
```