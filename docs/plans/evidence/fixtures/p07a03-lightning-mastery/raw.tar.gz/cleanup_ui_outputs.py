from pathlib import Path
import json,hashlib,stat,datetime
r=Path(__file__).resolve().parent;w=Path.cwd();out=r/'ui-output-cleanup.json';assert not out.exists()
d=json.loads((r/'ui-owned-output.json').read_text());assert Path(d['root'])==w
identities=set()
for p in r.glob('*.processes.json'):
 for row in json.loads(p.read_text())['observations']:identities.add((row['pid'],row['startTicks']))
assert len(identities)==7626
for pid,birth in identities:
 try:fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=birth
files=[];dirs=set()
for row in d['files']:
 p=w/row['path'];assert p.is_relative_to(w/'dist') or p==w/'node_modules/.vite/vitest/results.json';assert p.resolve()==p and stat.S_ISREG(p.lstat().st_mode)
 b=p.read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];files.append(p)
 for parent in p.parents:
  if parent in [w,w/'node_modules',w/'node_modules/.vite']:break
  dirs.add(parent)
for p in files:p.unlink()
removed=[]
for p in sorted(dirs,key=lambda x:len(x.parts),reverse=True):
 if not any(p.iterdir()):p.rmdir();removed.append(str(p.relative_to(w)))
assert all(not p.exists() for p in files)
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inventory':'ui-owned-output.json','removedFiles':len(files),'removedBytes':sum(x['bytes'] for x in d['files']),'removedEmptyDirectories':removed,'verifiedAllAbsent':True,'identitiesRecheckedAbsent':len(identities),'RAWPreserved':True,'sharedCachesPreserved':True,'sourceHistoryPreserved':True,'failures':[]}
out.write_text(json.dumps(result,indent=2)+'\n');print(out.read_text())
