from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
focused=['src/engine/progression/lightning-mastery-composition.test.ts','src/engine/combat/lightning-mastery.test.ts','src/engine/progression/warmth.test.ts','src/engine/progression/fire-mastery-composition.test.ts','src/engine/combat/fire-mastery.test.ts','src/engine/combat/warmth.test.ts','src/stores/warmth-composition.test.ts','src/stores/fire-mastery-composition.test.ts']
for name,args in [('focused-runtime-v2',['node','node_modules/vitest/vitest.mjs','run',*focused]),('engine-runtime-v2',['node','node_modules/vitest/vitest.mjs','run','--project','engine']),('unit-runtime-v2',['node','node_modules/vitest/vitest.mjs','run']),('types-runtime-v2',['npm','run','typecheck']),('lint-runtime-v2',['npm','run','lint']),('build-runtime-v2',['npm','run','check:test-bridge-shake'])]:
 if name.split('-')[0] in ['focused','engine','unit']:args+=['--reporter=json','--outputFile='+str(r/(name+'-report.json'))]
 result=subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*args])
 if result.returncode:sys.exit(result.returncode)
