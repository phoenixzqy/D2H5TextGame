from pathlib import Path
import re,json,hashlib,subprocess
r=Path(__file__).resolve().parent;w=Path.cwd()
paths=['src/engine/progression/warmth.test.ts','src/engine/progression/fire-mastery-composition.test.ts','src/stores/warmth-composition.test.ts','src/stores/fire-mastery-composition.test.ts','src/engine/combat/fire-mastery.test.ts']
helper='''/** Compare legacy fire output while permitting only an own, exact-zero Lightning projection. */
function fireDamageProjection(actual: Readonly<Partial<Record<string, number>>> | undefined) {
  if (!actual || !Object.prototype.hasOwnProperty.call(actual, 'lightning')) return actual;
  expect(actual.lightning).toBe(0);
  const { lightning: _zero, ...remaining } = actual;
  return remaining;
}
'''
recovery='''function fireRecoveryProjection(actual: ReturnType<typeof composeHeroRecovery>) {
  return { ...actual, increasedDamagePct: fireDamageProjection(actual.increasedDamagePct) };
}
'''
def close(s,start):
 depth=0;quote=None;escape=False
 for i in range(start,len(s)):
  c=s[i]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
   continue
  if c in "'\"`":quote=c;continue
  if c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return i
 raise AssertionError(start)
changes=[]
for p in paths:
 s=(w/p).read_text();(r/('compat-before-'+p.replace('/','__'))).write_text(s)
 edits=[]
 if p!='src/engine/combat/fire-mastery.test.ts':
  for m in re.finditer(r'\bexpect(?:\.soft)?\(',s):
   a=m.end()-1;b=close(s,a);rest=s[b+1:];tail=re.match(r'\s*\.toEqual\(',rest)
   if not tail:continue
   x=b+1+tail.end()-1;y=close(s,x);actual=s[a+1:b];expected=s[x+1:y].strip()
   if not expected.startswith('{'):continue
   if 'increasedDamagePct:' in expected:fn='fireRecoveryProjection'
   elif actual.strip().endswith('increasedDamagePct'):fn='fireDamageProjection'
   else:continue
   edits.append((a+1,b,fn+'('+actual+')'))
  for a,b,new in reversed(edits):s=s[:a]+new+s[b:]
  if p.endswith('fire-mastery-composition.test.ts') and '/progression/' in p:
   s=s.replace("it('does not infer an absent rank or compose another mastery or active buff'", "it('does not infer an absent rank from malformed mastery aliases or an active buff'")
   s=s.replace("'skills-sorceress-lightning-mastery': 20", "'skills-sorceress-lightning_mastery': 20")
  anchor='const DATA_ID' if p.endswith('/warmth.test.ts') else ('const AUTHORED' if '/progression/' in p else ('const MASTERY' if p.endswith('/fire-mastery-composition.test.ts') else 'const WARMTH'))
  insert=helper+(recovery if '/progression/' in p else '')+'\n'
  assert s.count(anchor)>=1;s=s.replace(anchor,insert+anchor,1)
 else:
  old='    expect(runBattleRecorded(snapshot(0, 1))).toEqual(expected);';assert s.count(old)==1
  s=s.replace(old,'''    const actual = runBattleRecorded(snapshot(0, 1));
    // Only the exact hero's optional zero field may differ; all events and other fields stay exact.
    expect({ ...actual, result: { ...actual.result, playerTeam: actual.result.playerTeam.map(hero =>
      hero.id === 'sorceress' ? { ...hero, increasedDamagePct: fireDamageProjection(hero.increasedDamagePct) } : hero
    ) } }).toEqual(expected);''')
  s=s.replace('const MASTERY',helper+'\nconst MASTERY',1)
 target='compat-proposed-'+p.replace('/','__');(r/target).write_text(s)
 changes.append({'path':p,'beforeSha256':hashlib.sha256((w/p).read_bytes()).hexdigest(),'proposed':target,'bytes':len(s.encode()),'sha256':hashlib.sha256(s.encode()).hexdigest(),'affectedComparisons':len(edits) if edits else 1})
proposal={'task':'P07a03 compatibility preparation','inputCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'paths':changes,'contract':'GD/TD approved test-only fivepath preparation. Normalize only affected exact-comparison boundaries, assert ownLightning exactly0 before fresh projection; keep raw constructors, immutability/reference/recordingfreeze oracles, literal historicalrecording, everyotherkey/value. Replace obsolete validLightning unrelatedfixture with malformedidentity. No product code/positiveLightning acceptance.','validation':'focused fivefiles + engine + full + types/lint/build serial bounded. Then independent review; <=5path commit.'}
(r/'compat-proposal.json').write_text(json.dumps(proposal,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k not in ['beforeSha256','sha256']} for x in changes]))
