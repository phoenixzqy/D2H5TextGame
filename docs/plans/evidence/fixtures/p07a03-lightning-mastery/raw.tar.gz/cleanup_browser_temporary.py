from pathlib import Path
import json,hashlib,stat,datetime,sys
r=Path(__file__).resolve().parent
name,process,out=sys.argv[1:];assert name in ['browser-temporary-v2','browser-temporary-v3'];assert process in ['browser-lightning-v2','browser-lightning-v3'];assert out in ['browser-second-temporary-cleanup.json','browser-final-temporary-cleanup.json']
base=r/name;assert base.resolve()==base and base.is_dir();assert not (r/out).exists()
d=json.loads((r/(process+'.processes.json')).read_text());assert not d['remainingNonZombie'] and not d['signals'];ids={(v['pid'],v['startTicks']) for v in d['observations']}
for pid,birth in ids:
 try:fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=birth
files=[];dirs=[]
for p in sorted(base.rglob('*')):
 mode=p.lstat().st_mode;assert not stat.S_ISLNK(mode)
 if stat.S_ISDIR(mode):dirs.append(p)
 else:
  assert stat.S_ISREG(mode);b=p.read_bytes();files.append({'path':str(p.relative_to(r)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
for row in files:
 p=r/row['path'];assert p.resolve()==p and p.is_relative_to(base);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink()
for p in sorted(dirs,key=lambda p:len(p.parts),reverse=True):assert not any(p.iterdir());p.rmdir()
assert not any(base.iterdir());base.rmdir();assert not base.exists()
(r/out).write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'removedFiles':len(files),'removedBytes':sum(x['bytes'] for x in files),'recheckedIdentitiesAbsent':len(ids),'verifiedAbsent':True,'allRawEvidencePreserved':True,'installedFontsSharedCachesPreserved':True,'failures':[]},indent=2)+'\n')
print('Removed exact temporary',len(files),sum(x['bytes'] for x in files),'bytes; processesabsent',len(ids))
