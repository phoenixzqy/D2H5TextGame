from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
focused=['src/stores/lightning-mastery-composition.test.ts','src/stores/fire-mastery-composition.test.ts','src/stores/warmth-composition.test.ts']
for name,args in [('focused-native',['node','node_modules/vitest/vitest.mjs','run',*focused]),('unit-native',['node','node_modules/vitest/vitest.mjs','run']),('types-native',['npm','run','typecheck']),('lint-native',['npm','run','lint']),('build-native',['npm','run','check:test-bridge-shake'])]:
 if name.split('-')[0] in ['focused','engine','unit']:args+=['--reporter=json','--outputFile='+str(r/(name+'-report.json'))]
 result=subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*args])
 if result.returncode:sys.exit(result.returncode)
