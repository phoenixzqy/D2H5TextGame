from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
focused=['src/features/skills/SkillsScreen.lightning-mastery.test.tsx','src/features/skills/SkillsScreen.test.tsx']
for name,args in [('focused-ui-v2',['node','node_modules/vitest/vitest.mjs','run',*focused]),('unit-ui-v2',['node','node_modules/vitest/vitest.mjs','run']),('types-ui-v2',['npm','run','typecheck']),('lint-ui-v2',['npm','run','lint']),('build-ui-v2',['npm','run','check:test-bridge-shake'])]:
 if name.split('-')[0] in ['focused','engine','unit']:args+=['--reporter=json','--outputFile='+str(r/(name+'-report.json'))]
 result=subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*args])
 if result.returncode:sys.exit(result.returncode)
