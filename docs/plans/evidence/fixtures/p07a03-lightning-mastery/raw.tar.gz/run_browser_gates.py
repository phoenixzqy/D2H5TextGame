from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
for name,args in [('types-browser',['npm','run','typecheck']),('lint-browser',['npm','run','lint']),('browser-lightning',['python3',str(r/'run_browser.py')])]:
 result=subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*args])
 if result.returncode:sys.exit(result.returncode)
