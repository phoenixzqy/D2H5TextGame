from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
fire=(w/'tests/pwa/fire-mastery.spec.ts').read_text()
start=fire.index('async function backup(');end=fire.index('\nfor (const locale')
helpers=fire[start:end].replace("const BOLT =", "const BOLT =")
# Retain ordinary UI/download/save helpers, no combat mutation/debug helpers.
helpers=helpers.replace('Fire Mastery', 'Lightning Mastery')
head='''/** Explicit imported L30 eligibility; production UI and actual Settings Save/disk reload only. */
import { expect, test, type Page, type TestInfo } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import type { SaveCurrent } from '../../src/engine/types/save';
import { createCharacter, navTo } from '../e2e/_helpers';
const MASTERY = 'skills-sorceress-lightning-mastery';
const BOLT = 'skills-sorceress-fire-bolt';
const sizes = [[360,640],[412,915],[640,360],[375,667],[393,851],[768,1024],[1280,800],[1920,1080],[915,412]] as const;
const prose = {
  en: 'Passive: +4% direct lightning damage per allocated skill rank (up to +80% at rank 20). Unlocks at character level 30. Paralyze is unchanged.',
  'zh-CN': '被动：每投入1点技能点，直接闪电伤害+4%（最多20点，合计+80%）。角色30级解锁，麻痹效果不变。'
};
async function attach(info: TestInfo, name: string, value: unknown): Promise<void> {
  await info.attach(name, { body: JSON.stringify(value, null, 2), contentType: 'application/json' });
}
'''
body='''
for (const locale of ['en', 'zh-CN'] as const) {
  test(`Lightning Mastery imported eligibility, bilingual layouts and disk reload ${locale}`, async ({ page: initial, context }, info) => {
    const english = locale === 'en';
    const errors: string[] = [];
    const watch = (p: Page): void => {
      p.on('pageerror', error => errors.push(error.message));
      p.on('console', message => { if (message.type() === 'error' || message.type() === 'warning') errors.push(`${message.type()}: ${message.text()}`); });
    };
    let page = initial; watch(page);
    await page.goto('/');
    await createCharacter(page, { class: 'sorceress', name: 'Lightning Mastery' });
    await navTo(page, 'settings');
    await page.getByRole('button', { name: english ? 'English' : '简体中文', exact: true }).click();
    const fresh = await backup(page);
    expect(fresh.player).toMatchObject({ level: 1, skillPoints: 1, class: 'sorceress' });
    await selectMastery(page);
    await expect(page.getByTestId('skill-detail-panel').getByRole('button', { name: english ? 'Requires Lv. 30' : '需要等级 30', exact: true })).toBeDisabled();
    await expect(page.getByTestId('skill-detail-panel')).toContainText(prose[locale]);
    const locked = await backup(page);
    expect(locked.player).toEqual(fresh.player);
    await attach(info, '01-fresh-locked-control', locked);
    const incoming: SaveCurrent = { ...fresh, player: { ...fresh.player, level: 30, skillPoints: 2,
      skillLevels: { 'sorceress.fire_bolt': 1 }, comboOrder: [BOLT] } };
    const importLabel = english ? 'Import Save' : '导入存档';
    await page.getByRole('button', { name: importLabel, exact: true }).click();
    const dialog = page.getByRole('dialog');
    await dialog.getByRole('textbox').fill(JSON.stringify(incoming));
    await dialog.getByRole('button', { name: importLabel, exact: true }).click();
    await expect(dialog).toHaveCount(0);
    const prepared = await backup(page);
    expect(prepared.player).toEqual(incoming.player);
    expect(prepared.inventory).toEqual(fresh.inventory);
    expect(prepared.map).toEqual(fresh.map);
    durable(prepared);
    await attach(info, '02-explicit-imported-eligibility', prepared);
    try {
      for (const rank of [1, 2]) {
        await selectMastery(page);
        const panel = page.getByTestId('skill-detail-panel');
        const allocate = panel.getByRole('button', { name: english ? 'Allocate' : '分配', exact: true });
        // Native keyboard traversal from the selected tree node; no focus() or DOM click injection.
        let reached = false;
        for (let step = 0; step < 100; step++) {
          await page.keyboard.press('Tab');
          if (await allocate.evaluate(node => node === document.activeElement)) { reached = true; break; }
        }
        expect(reached).toBe(true);
        await expect(allocate).toBeFocused();
        await page.keyboard.press('Enter');
        await expect(panel).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
        const current = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Current' : '当前', exact: true }) });
        const next = panel.locator('section').filter({ has: page.getByRole('heading', { name: english ? 'Next Level' : '下一级', exact: true }) });
        const label = english ? 'Lightning Damage' : '闪电伤害';
        await expect(current.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String(rank * 4)}%`);
        await expect(next.locator('dt').filter({ hasText: label }).locator('+ dd')).toHaveText(`${String((rank + 1) * 4)}% (+4%)`);
        await expect(panel).toContainText(prose[locale]);
        if (rank === 1) {
          const metrics = [];
          for (const [width, height] of sizes) {
            await page.setViewportSize({ width, height });
            const control = panel.getByRole('button');
            await control.scrollIntoViewIfNeeded();
            const bounds = await control.boundingBox();
            expect(bounds).not.toBeNull();
            expect(bounds?.width).toBeGreaterThanOrEqual(44); expect(bounds?.height).toBeGreaterThanOrEqual(44);
            await production(page);
            const description = panel.getByText(prose[locale], { exact: true });
            await description.scrollIntoViewIfNeeded();
            const font = await description.evaluate(node => getComputedStyle(node).fontSize);
            expect(Number.parseFloat(font)).toBeGreaterThanOrEqual(14);
            await expect(description).toBeVisible();
            await info.attach(`layout-${String(width)}x${String(height)}`, { body: await page.screenshot(), contentType: 'image/png' });
            for (const section of [current, next]) {
              await section.scrollIntoViewIfNeeded(); await expect(section).toBeVisible();
            }
            metrics.push({ width, height, bounds, font });
          }
          await attach(info, '03-layout-metrics', metrics);
        }
        await slots(page, english);
        const saved = await backup(page);
        expect(saved.player.skillLevels).toEqual({ 'sorceress.fire_bolt': 1, 'sorceress.lightning_mastery': rank });
        expect(saved.player.skillPoints).toBe(2 - rank); expect(saved.player.comboOrder).toEqual([BOLT]);
        expect(saved.player.derivedStats).toEqual(fresh.player.derivedStats); durable(saved);
        await page.getByRole('button', { name: english ? 'Save' : '保存', exact: true }).click();
        await expect(page.getByRole('status')).toHaveText(english ? 'Saved' : '已保存');
        await page.close(); page = await context.newPage(); watch(page);
        await page.goto('/'); await page.getByTestId('home-continue').click();
        await expect(page.getByTestId('town-screen')).toBeVisible();
        const loaded = await backup(page);
        expect(loaded.player).toEqual(saved.player); expect(loaded.inventory).toEqual(saved.inventory);
        expect(loaded.mercs).toEqual(saved.mercs); expect(loaded.map).toEqual(saved.map);
        expect(loaded.formation).toEqual(saved.formation); expect(loaded.meta.settings).toEqual(saved.meta.settings); durable(loaded);
        await attach(info, `04-rank${String(rank)}-actual-disk-reload`, { saved, loaded });
        await selectMastery(page); await expect(page.getByTestId('skill-detail-panel')).toContainText(english ? `Lv. ${String(rank)}/20` : `等级 ${String(rank)}/20`);
        await production(page);
      }
      await attach(info, '05-console-errors', errors); expect(errors).toEqual([]);
    } finally { await page.close(); }
  });
}
'''
(r/'lightning-mastery.spec.draft.ts').write_text(head+helpers+body)
config=(w/'tests/pwa/fire-mastery.config.ts').read_text().replace('4349','4353').replace('fire-mastery','lightning-mastery').replace('FIRE_MASTERY','LIGHTNING_MASTERY')
config=config.replace("{ name: 'mastery-mobile', use: { ...devices['Pixel 5'], viewport: { width: 360, height: 640 } } }", "")
(r/'lightning-mastery.config.draft.ts').write_text(config)
files=['lightning-mastery.spec.draft.ts','lightning-mastery.config.draft.ts']
(r/'browser-proposal.json').write_text(json.dumps({'drafts':{f:{'bytes':len((r/f).read_bytes()),'sha256':hashlib.sha256((r/f).read_bytes()).hexdigest()} for f in files},'scope':'production UI only; importedL30 eligibility, keyboard actual allocation, nine viewport CSS layouts perlocale, four explicit SettingsSave/coldpage/Continue disk cycles, passive absent from nine combo slots, no bridge; runtime damage/native wave evidence separate','limits':'not earned campaign, autosave, fulla11y, performance or realdevice certification','security':'local loopback preview and ordinary UI imports/exports only; download.delete; read-only DOM evaluation; no internal state injection/network/credentials','sequence':'review before installation/execution; after UI commit. existing clean production build preview; taskowned output and font cache under RAW; bounded runner/no overlapping gates'},indent=2)+'\n')
print((r/'browser-proposal.json').read_text())
