from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;w=Path.cwd()
base=(r/'lightning-control-capture.draft.v2.ts').read_text()
header=base[base.index("import { runBattleRecorded"):base.index("describe('prepatch")]
header=header.replace("import { runBattleRecorded }", "import { runBattle, runBattleRecorded, type CombatSnapshot }")
header=header.replace('loadDefaultSkills, resetRegistry','loadDefaultSkills, registerSkill, resetRegistry')
header=header.replace("type { DerivedStats }", "type { DamageType, DerivedStats }")
draft="import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';\n"+header+"import * as rngModule from '../rng';\nimport * as statusModule from './status';\n"
draft+='''
const MASTERY = 'skills-sorceress-lightning-mastery';
const SPELL = 'skills-sorceress-thunder-storm';
function snapshot(rank = 20): CombatSnapshot {
  const skillLevels = { [MASTERY]: rank, [SPELL]: 20 };
  const { increasedDamagePct } = composeHeroRecovery({ classId: 'sorceress', level: 40,
    effectiveEnergy: 20, skillLevels });
  return { seed: 7,
    playerTeam: [unit('sorceress', 'player', { kind: 'hero', mana: 30, skillLevels,
      increasedDamagePct, skillOrder: [SPELL], statuses: [hold(1701)] })],
    enemyTeam: [unit('target', 'enemy', { life: 500,
      stats: { ...stats, life: 500, lifeMax: 500 }, statuses: [hold()] })] };
}
const withHero = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, playerTeam: input.playerTeam.map(u => ({ ...u, ...fields })) });
const withTarget = (input: CombatSnapshot, fields: Partial<CombatUnit>): CombatSnapshot =>
  ({ ...input, enemyTeam: input.enemyTeam.map(u => ({ ...u, ...fields })) });
function fixed(type: DamageType, rank = 20) {
  registerSkill({ id: 'fixture.lightning-probe', archetype: 'fixture', target: 'single-enemy',
    manaCost: 0, cooldown: 0, minLevel: 1,
    effects: [{ kind: 'damage', damageType: type, base: [100, 100] }] });
  return withHero(snapshot(rank), { skillOrder: ['fixture.lightning-probe'] });
}
beforeEach(() => { resetRegistry(); loadDefaultSkills(); });
afterEach(() => { vi.restoreAllMocks(); resetRegistry(); loadDefaultSkills(); });

describe('P07a03B allocated Lightning Mastery direct damage', () => {
  it.each([{ rank: 0, hit: 205 }, { rank: 1, hit: 213 }, { rank: 10, hit: 287 },
    { rank: 20, hit: 369 }])('real Thunder Storm rank$rank hits$hit with unchanged Paralyze/resources', ({ rank, hit }) => {
    expect(getSkill(SPELL)).toMatchObject({ id: 'sorceress.thunder_storm', manaCost: 30,
      cooldown: 4, effects: [{ kind: 'damage', damageType: 'lightning', base: [70, 110],
        perRank: [7, 7], applyStatus: { id: 'paralyze' } }] });
    const input = snapshot(rank), before = structuredClone(input);
    const spell = structuredClone(getSkill(SPELL)), passive = structuredClone(getSkill(MASTERY));
    const result = runBattleRecorded(input);
    // Seed7 consumes hit then range:203+floor(.06195825757458806*41)=205.
    expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ source: 'sorceress', target: 'target', damageType: 'lightning',
        amount: hit, crit: false, dodged: false, simClockMs: 1700 })]);
    expect.soft(result.events.filter(e => e.kind === 'action')).toEqual([
      expect.objectContaining({ actor: 'sorceress', skillId: 'sorceress.thunder_storm', simClockMs: 1700 })]);
    expect.soft(result.events.filter(e => e.kind === 'status')).toEqual([
      expect.objectContaining({ target: 'target', statusId: 'paralyze', simClockMs: 1700 })]);
    expect(result.events.filter(e => e.kind === 'dot' || e.kind === 'buff')).toEqual([]);
    expect(result.result.enemyTeam[0]?.life).toBe(500 - hit);
    expect(result.result.playerTeam[0]?.mana).toBe(0);
    expect(result.result.playerTeam[0]?.life).toBe(200);
    expect(result.result.playerTeam[0]?.stats).toEqual(stats);
    expect(runBattle(input)).toEqual(result.result);
    expect(runBattleRecorded(input)).toEqual(result);
    expect(input).toEqual(before);
    expect(getSkill(SPELL)).toEqual(spell); expect(getSkill(MASTERY)).toEqual(passive);
  });

  it.each([{ rank: 1, hit: 104 }, { rank: 20, hit: 180 }])(
    'neutral fixed lightning100 at rank$rank gives$hit', ({ rank, hit }) => {
      const result = runBattleRecorded(fixed('lightning', rank));
      expect(result.events.filter(e => e.kind === 'damage')).toEqual([
        expect.objectContaining({ damageType: 'lightning', amount: hit, crit: false, dodged: false })]);
      expect(result.result.playerTeam[0]?.stats).toEqual(stats);
      expect(result.result.playerTeam[0]?.mana).toBe(30);
    });

  it.each(['fire', 'cold', 'arcane', 'poison', 'physical', 'thorns'] as const)(
    'leaves neutral fixed100 %s and authoritative Attack unchanged', type => {
      const result = runBattleRecorded(fixed(type));
      expect(result.events.filter(e => e.kind === 'damage')).toEqual([
        expect.objectContaining({ damageType: type, amount: 100, crit: false, dodged: false })]);
      expect(result.result.playerTeam[0]?.stats).toEqual(stats);
      expect(result.result.playerTeam[0]?.mana).toBe(30);
    });

  it('leaves the basic Attack100 hit and resources unchanged', () => {
    const result = runBattleRecorded(withHero(snapshot(), { skillOrder: [], stats: { ...stats, attack: 100 } }));
    expect(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ damageType: 'physical', amount: 100 })]);
    expect(result.result.playerTeam[0]?.stats.attack).toBe(100);
    expect(result.result.playerTeam[0]?.mana).toBe(30);
  });

  it('applies Lightning increase before chill combo, crit, resistance, magic mitigation and floor', () => {
    const input = withTarget(withHero(fixed('lightning'), { stats: { ...stats, critChance: 1, critDamage: 2 } }), {
      stats: { ...stats, life: 500, lifeMax: 500, defense: 999, magicResist: 7,
        resistances: { ...stats.resistances, lightning: 25 } },
      statuses: [hold(), { id: 'chill', sourceId: 'fixture', stacks: 1, remaining: -1 }] });
    // floor(100*1.8*1.3*2*.75-7)=344; ordinary defense999 must not affect lightning.
    expect(runBattleRecorded(input).events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ amount: 344, damageType: 'lightning', crit: true, dodged: false })]);
  });

  it.each([MASTERY, 'sorceress.lightning_mastery'])(
    'never executes passive%s or pays an action/resource/CD/marker', id => {
      expect(getSkill(id)).toMatchObject({ trigger: 'passive', manaCost: 0, cooldown: 0 });
      const result = runBattleRecorded(withHero(snapshot(), { skillOrder: [id, SPELL] }));
      expect.soft(result.events.filter(e => e.kind === 'action')).toEqual([
        expect.objectContaining({ skillId: 'sorceress.thunder_storm', simClockMs: 1700 })]);
      expect.soft(result.events.filter(e => e.kind === 'damage')).toEqual([expect.objectContaining({ amount: 369 })]);
      expect(result.events.filter(e => e.kind === 'buff')).toEqual([]);
      expect(result.result.playerTeam[0]?.activeBuffIds).toEqual([]);
      expect(result.result.playerTeam[0]?.cooldowns).toEqual({});
      expect(result.result.playerTeam[0]?.mana).toBe(0);
      expect(result.result.playerTeam[0]?.statuses).toEqual([hold(1701)]);
    });

  it.each([0, 20])('preserves exact hit/range/crit/status RNG stream at allocated%s', rank => {
    const random = rngModule.createRng(7);
    const range = vi.spyOn(random, 'nextInt'), chance = vi.spyOn(random, 'chance');
    vi.spyOn(rngModule, 'createRng').mockReturnValue(random);
    runBattleRecorded(snapshot(rank));
    expect(range.mock.calls).toEqual([[203, 243]]);
    expect(chance.mock.calls).toEqual([[0.85], [0], [1]]);
    expect(random.next()).toBe(0.5214452685322613);
  });

  it.each([0, 20])('preserves Paralyze initial timing, stacks and cooldown at allocated%s', rank => {
    const apply = vi.spyOn(statusModule, 'applyStatus');
    runBattleRecorded(snapshot(rank));
    expect(apply).toHaveBeenCalledTimes(1);
    expect(apply.mock.calls[0]?.[1]).toEqual({ id: 'paralyze', sourceId: 'sorceress', simClockMs: 1700, damageType: 'lightning' });
    expect(apply.mock.results[0]?.value.statuses).toEqual([hold(),
      { id: 'paralyze', stacks: 1, remaining: 1, sourceId: 'sorceress', appliedAtMs: 1700,
        expiresAtMs: 2700, damageType: 'lightning' },
      { id: 'paralyze-cd', stacks: 1, remaining: 5, sourceId: 'sorceress', appliedAtMs: 1700, expiresAtMs: 6700 }]);
  });

  it.each([0, 20])('preserves Paralyze reapplication failure and RNG at allocated%s', rank => {
    const cd: ActiveStatus = { id: 'paralyze-cd', stacks: 1, remaining: 100, sourceId: 'old', appliedAtMs: 0, expiresAtMs: 100000 };
    const apply = vi.spyOn(statusModule, 'applyStatus');
    const random = rngModule.createRng(7), chance = vi.spyOn(random, 'chance');
    vi.spyOn(rngModule, 'createRng').mockReturnValue(random);
    runBattleRecorded(withTarget(snapshot(rank), { statuses: [hold(), cd] }));
    expect(chance.mock.calls).toEqual([[0.85], [0], [1], [0.5]]);
    // Fifth seed7 draw .5214452685 fails the existing 50% reapplication check.
    expect(apply).toHaveBeenCalledTimes(1);
    expect(apply.mock.results[0]?.value).toBe(apply.mock.calls[0]?.[0]);
    expect(apply.mock.results[0]?.value.statuses).toEqual([hold(), cd]);
  });

  it('does not inherit the hero modifier on an allied real Thunder Storm', () => {
    const input = snapshot();
    const result = runBattleRecorded({ ...input, playerTeam: [...input.playerTeam,
      unit('ally', 'player', { kind: 'merc', mana: 30, stats: { ...stats, attackSpeed: 87 },
        skillOrder: [SPELL], skillLevels: { [SPELL]: 20 }, statuses: [hold(1805)] })],
      enemyTeam: input.enemyTeam.map(u => ({ ...u, life: 1000, stats: { ...u.stats, life: 1000, lifeMax: 1000 } })) });
    // Fifth seed draw hits; sixth .405521688 gives203+floor(.405521688*41)=219.
    expect(result.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ source: 'sorceress', amount: 369, simClockMs: 1700 }),
      expect.objectContaining({ source: 'ally', amount: 219, simClockMs: 1804 })]);
    expect(result.result.playerTeam[1]?.increasedDamagePct).toBeUndefined();
    expect(result.result.playerTeam.map(u => u.mana)).toEqual([0, 0]);
  });
});
'''
capture=json.loads((r/'unaffected-lightning-recording.json').read_text()); literal=json.dumps(capture['recording'],separators=(',',':'),ensure_ascii=False)
draft+="\n// Complete actual prepatch recording at2002326; fixed neutral consumer map, not current-composer output.\ndescribe('P07a03B unchanged full neutral Thunder Storm recording', () => {\n  it('preserves every event/delay/final field for the fixed explicit-zero control', () => {\n    const expected = "+literal+";\n    const input = "+json.dumps(capture['snapshot'],separators=(',',':'),ensure_ascii=False)+";\n    const before = structuredClone(input);\n    expect(runBattleRecorded(input)).toEqual(expected);\n    expect(input).toEqual(before);\n  });\n});\n"
p=r/'lightning-mastery-combat.test.draft.ts';assert not p.exists();p.write_text(draft)
source=(w/'src/engine/progression/warmth.ts').read_text()
source=source.replace("import type { DamageType }", "import { LIGHTNING_MASTERY_DEFINITION, resolveLightningMasteryRank } from '../skills/lightning-mastery';\nimport type { DamageType }")
source=source.replace('  const energy =', "  const lightningMasteryRank = input.classId === 'sorceress' && Number.isFinite(input.level) &&\n    input.level >= LIGHTNING_MASTERY_DEFINITION.requiredLevel\n    ? resolveLightningMasteryRank(input.skillLevels) : 0;\n  const energy =")
source=source.replace('FIRE_MASTERY_DEFINITION.fireDamagePctPerRank * masteryRank })', 'FIRE_MASTERY_DEFINITION.fireDamagePctPerRank * masteryRank,\n      lightning: LIGHTNING_MASTERY_DEFINITION.lightningDamagePctPerRank * lightningMasteryRank })')
(r/'warmth-runtime-proposed.ts').write_text(source)
proposal={'drafts':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'warmth-runtime-proposed.ts':{'bytes':len(source.encode()),'sha256':hashlib.sha256(source.encode()).hexdigest()}},'scope':'fourpaths runtime only, no native/UI closure','oracle':'literal205/213/287/369 realThunder; neutral100104/180; all other damage/Attack/resources; order344; passive/RNG/statusinitial/reapplyfail; ally219; fullactual87eventcontrol'}
(r/'runtime-combat-proposal.json').write_text(json.dumps(proposal,indent=2)+'\n');print(json.dumps(proposal))
