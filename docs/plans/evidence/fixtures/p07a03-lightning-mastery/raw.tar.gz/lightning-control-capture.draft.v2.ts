import { writeFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { runBattleRecorded } from './combat';
import type { ActiveStatus, CombatUnit } from './types';
import type { DerivedStats } from '../types/attributes';
import { composeHeroRecovery } from '../progression/warmth';
import { getSkill, loadDefaultSkills, resetRegistry } from '../skills/registry';

const stats: DerivedStats = {
  life: 200, lifeMax: 200, mana: 200, manaMax: 200, attack: 1, defense: 0, magicResist: 0,
  attackSpeed: 100, critChance: 0, critDamage: 1.5, physDodge: 0, magicDodge: 0,
  magicFind: 0, goldFind: 0,
  resistances: { fire: 0, cold: 0, lightning: 0, poison: 0, arcane: 0, physical: 0 }
};
const hold = (appliedAtMs = 0): ActiveStatus => ({
  id: 'stun', sourceId: 'fixture', stacks: 1, remaining: -1, appliedAtMs
});
const unit = (id: string, side: CombatUnit['side'], overrides: Partial<CombatUnit> = {}): CombatUnit =>
  ({ id, name: id, side, level: 40, tier: 'trash', stats, life: 200, mana: 200,
    statuses: [], cooldowns: {}, skillOrder: [], activeBuffIds: [], enraged: false, ...overrides });

describe('prepatch Lightning control capture only', () => {
  it('records one real Thunder Storm without Mastery and with a fixed explicit-zero damage map', () => {
    resetRegistry(); loadDefaultSkills();
    const spell = structuredClone(getSkill('skills-sorceress-thunder-storm'));
    expect(spell).toMatchObject({ id: 'sorceress.thunder_storm', manaCost: 30,
      effects: [{ kind: 'damage', damageType: 'lightning', base: [70, 110], perRank: [7, 7],
        applyStatus: { id: 'paralyze' } }] });
    // This stable neutral consumer control deliberately fixes both modifier fields before runtime work.
    // It is not an assertion that current hero composition already emits Lightning0.
    const increasedDamagePct = { fire: 0, lightning: 0 };
    const snapshot = { seed: 7,
      playerTeam: [unit('sorceress', 'player', { kind: 'hero', mana: 30,
        skillLevels: { 'skills-sorceress-thunder-storm': 20 }, increasedDamagePct,
        skillOrder: ['skills-sorceress-thunder-storm'], statuses: [hold(1701)] })],
      enemyTeam: [unit('target', 'enemy', { life: 500,
        stats: { ...stats, life: 500, lifeMax: 500 }, statuses: [hold()] })] };
    const before = structuredClone(snapshot);
    const recording = runBattleRecorded(snapshot);
    expect(recording.events.filter(e => e.kind === 'damage')).toEqual([
      expect.objectContaining({ source: 'sorceress', target: 'target', damageType: 'lightning',
        amount: 205, crit: false, dodged: false, simClockMs: 1700 })
    ]);
    expect(recording.events.filter(e => e.kind === 'status')).toEqual([
      expect.objectContaining({ target: 'target', statusId: 'paralyze', simClockMs: 1700 })
    ]);
    expect(snapshot).toEqual(before);
    expect(composeHeroRecovery({ classId: 'sorceress', level: 40, effectiveEnergy: 20,
      skillLevels: { 'skills-sorceress-lightning-mastery': 20 } }).increasedDamagePct.lightning).toBeUndefined();
    writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-lightning-mastery-6siwydfd/unaffected-lightning-recording.json',
      JSON.stringify({ snapshot, spell, recording }, null, 2) + '\n', { flag: 'wx' });
  });
});
