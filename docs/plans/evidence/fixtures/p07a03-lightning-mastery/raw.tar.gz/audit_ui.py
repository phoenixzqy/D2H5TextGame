from pathlib import Path
import json,hashlib,stat,datetime
r=Path(__file__).resolve().parent;w=Path.cwd()
freeze=json.loads((r/'ui-source-freeze.json').read_text())
for f,row in freeze.items():
 b=(w/f).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
names=['focused-ui-v2','unit-ui-v2','types-ui-v2','lint-ui-v2','build-ui-v2'];commands=[];lastEnd=0
for n in names:
 m=json.loads((r/(n+'.meta.json')).read_text());assert m['exitCode']==0 and m['stopReason'] is None and m['signals']==[]
 start=datetime.datetime.fromisoformat(m['started']).timestamp();assert start>=lastEnd;lastEnd=start+m['seconds'];entry={**m}
 report=r/(n+'-report.json')
 if report.exists():
  d=json.loads(report.read_text());assert d['success'] and d['numFailedTests']==0 and d['numPendingTests']==0
  entry['tests']={k:d[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']};entry['files']=len(d['testResults'])
 commands.append(entry)
identities=set()
for p in r.glob('*.processes.json'):
 d=json.loads(p.read_text());assert not d['remainingNonZombie'] and not d['signals']
 for v in d['observations']:identities.add((v['pid'],v['startTicks']))
for pid,birth in identities:
 try:fields=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:continue
 assert int(fields[19])!=birth,(pid,birth,fields[0])
files=[]
for base in [w/'dist',w/'node_modules/.vite']:
 for p in sorted(base.rglob('*')):
  mode=p.lstat().st_mode;assert not stat.S_ISLNK(mode)
  if stat.S_ISREG(mode):
   b=p.read_bytes();files.append({'path':str(p.relative_to(w)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(r/'ui-owned-output.json').write_text(json.dumps({'root':str(w),'ownership':'native exact output cleanup completed before UI; only current UI checks populated these files','files':files},indent=2)+'\n')
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFreeze':'ui-source-freeze.json','commands':commands,'sequenceVerified':True,'processIdentities':len(identities),'allAbsent':True,'signals':[],'ownedOutputFiles':len(files),'ownedOutputBytes':sum(x['bytes'] for x in files),'limits':'Full15s timing target missed; preserve build warnings. UI component acceptance only. GenuineRED10failed/8controls; initial lint callback braces corrected without oracle change. Browser layout and actual disk persistence separate; no earnedcampaign/balance/performance/coverage acceptance.'}
(r/'ui-final-gates.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='commands'}));print(json.dumps([{'command':x['command'][:6],'seconds':x['seconds'],'tests':x.get('tests'),'files':x.get('files')} for x in commands]))
