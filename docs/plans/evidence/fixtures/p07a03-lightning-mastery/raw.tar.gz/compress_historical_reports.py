from pathlib import Path
import gzip,hashlib,json,datetime,stat
r=Path(__file__).resolve().parent;out=r/'historical-report-compression.json';assert not out.exists()
# Exact completed prior reports; every prior reader released. Current final UI reports stay live.
names=['unit-stage-a-report.json','unit-compat-report.json','unit-runtime-report.json','unit-runtime-final-report.json','unit-runtime-v2-report.json','engine-stage-a-report.json','engine-compat-report.json','engine-runtime-report.json','engine-runtime-final-report.json','engine-runtime-v2-report.json','unit-ui-report.json']
rows=[]
for n in names:
 p=r/n;assert p.resolve()==p and stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();z=r/(n+'.gz');assert not z.exists();packed=gzip.compress(b,mtime=0);z.write_bytes(packed);assert gzip.decompress(z.read_bytes())==b
 rows.append({'original':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'compressed':z.name,'compressedBytes':len(packed),'compressedSHA256':hashlib.sha256(packed).hexdigest(),'exactRoundtripVerified':True})
# All durable compressed records verified before unlinking exact original copies.
for row in rows:
 p=r/row['original'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];p.unlink();assert not p.exists()
out.write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'lossless completed historical Vitest reports only; all prior consumers released; source/failures/assertions preserved byte-for-byte in gzip','records':rows,'removedOriginalBytes':sum(x['bytes'] for x in rows),'retainedCompressedBytes':sum(x['compressedBytes'] for x in rows),'failures':[]},indent=2)+'\n')
print({'reports':len(rows),'originalBytes':sum(x['bytes'] for x in rows),'retainedBytes':sum(x['compressedBytes'] for x in rows)})
