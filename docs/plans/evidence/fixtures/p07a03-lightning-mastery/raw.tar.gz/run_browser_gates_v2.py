from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
for name,args in [('types-browser-v2',['npm','run','typecheck']),('lint-browser-v2',['npm','run','lint']),('browser-lightning-v2',['python3',str(r/'run_browser_v2.py')])]:
 result=subprocess.run([sys.executable,str(r/'bounded_runner.py'),name,*args])
 if result.returncode:sys.exit(result.returncode)
