const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = __dirname;
const baseURL = 'http://127.0.0.1:4463';
const ids = ['holy-freeze','conviction'];
const names = {
 en: ['Holy Freeze','Conviction'],
 'zh-CN': ['神圣冰冻','信念']
};
const allIds = ['might','holy-fire','conviction','meditation','thorns','blessed-aim','concentration','holy-freeze','holy-shock','sanctuary','fanaticism','prayer','resist-fire','defiance','resist-cold','cleansing','resist-lightning','vigor','redemption','salvation'];
const summary = {cases:[], geometry:[], failures:[]};
let serial = 0;
async function exportSave(page, label) {
 const pending = page.waitForEvent('download');
 await page.getByTestId('export-save-button').click();
 const dl = await pending, target = path.join(root, `${label}-${++serial}.json`);
 await dl.saveAs(target);
 return JSON.parse(await fs.readFile(target, 'utf8'));
}
async function nav(page, route) {
 await page.locator(`a[href="/${route}"]`).first().click();
 await expect(page.getByTestId(`${route}-screen`)).toBeVisible();
}
function domains(save) {return Object.fromEntries(['player','inventory','map','mercs','formation'].map(k=>[k,save[k]]));}
async function continuePair(page, context, locale, label) {
 await nav(page,'settings');
 await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();
 await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');
 const before=await exportSave(page,label+'-before');
 assert.equal(before.version,22);
 await page.close(); page=await context.newPage();
 await page.goto(baseURL,{waitUntil:'networkidle'});
 await expect(page.getByTestId('home-continue')).toBeEnabled();
 await page.getByTestId('home-continue').click();
 await expect(page.getByTestId('town-screen')).toBeVisible();
 await nav(page,'settings');
 const after=await exportSave(page,label+'-after');
 assert.deepEqual(domains(after),domains(before));
 await nav(page,'skills');
 return {page,selection:after.player.selectedAuraId};
}
async function geometry(page,label) {
 const original=page.viewportSize();
 for (const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]) {
  await page.setViewportSize({width,height});
  const sizes=await page.locator('input[name="selected-player-aura"]').evaluateAll(inputs=>inputs.map(input=>{
    const r=input.closest('label').getBoundingClientRect();return {id:input.value,width:r.width,height:r.height};
  }));
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
  assert.ok(overflow<=0,`${label} overflow ${overflow}`);
  assert.equal(sizes.length,13);
  for(const size of sizes) assert.ok(size.width>=44&&size.height>=44,JSON.stringify(size));
  summary.geometry.push({label,width,height,overflow,sizes});
 }
 await page.setViewportSize(original);
}
(async()=>{
 const browser=await chromium.launch({headless:true});
 try {
 for(const [locale,width,slug] of [['en',1280,'conviction'],['zh-CN',360,'holy-freeze']]) {
  const context=await browser.newContext({viewport:{width,height:width===360?640:800},locale});
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  try {
   await page.goto(baseURL,{waitUntil:'networkidle'});
   await page.getByTestId('home-new-game').click();
   await page.getByTestId('class-paladin').click();
   await page.getByTestId('character-name-input').fill('AuraVisual');
   await page.getByTestId('character-start-btn').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();
   await nav(page,'settings');
   await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
   const files=await fs.readdir(root);
   const file=files.find(name=>name.startsWith(`${locale}-${width}-${slug}-before-`)&&name.endsWith('.json'));
   assert.ok(file);
   const fixture=await fs.readFile(path.join(root,file),'utf8');
   await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   const dialog=page.getByRole('dialog');
   await dialog.getByRole('textbox').fill(fixture);
   await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   await expect(dialog).toHaveCount(0);
   await nav(page,'skills');
   await page.getByTestId('skill-node-skills-paladin-'+slug).click();
   await page.mouse.move(1,1);
   const detail=page.getByTestId('skill-detail-panel');
   await detail.scrollIntoViewIfNeeded();
   await expect(detail).toContainText(locale==='en'?'all six enemy resistances by 25 percentage points':'攻击速度降低50%');
   await detail.screenshot({path:path.join(root,`corrected-visual-${locale}-${width}-${slug}.png`)});
   assert.deepEqual(errors,[]);
   console.log('Corrected visual '+locale+' '+slug+' PASS');
  } finally {await context.close();}
 }
 } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
