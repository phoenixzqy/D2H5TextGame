from pathlib import Path
import gzip,hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=set()
for name in ['src','tests','scripts']:
 paths.update(p for p in Path(name).rglob('*') if p.is_file() and not p.is_symlink())
paths.update(p for p in Path('.').iterdir() if p.is_file() and p.suffix in ['.json','.ts','.mjs','.js'])
sources={str(p):sha(p.read_bytes()) for p in sorted(paths)}
build={str(p.relative_to(root/'build')):sha(p.read_bytes()) for p in sorted((root/'build').rglob('*')) if p.is_file()}
genuine=sha(gzip.decompress(Path('docs/plans/evidence/fixtures/earned-ancients401/retained-final.json.gz').read_bytes()))
assert genuine=='c4a543af9db6b6b926ece07417b82c80c39615a53cbb03e2a358074f019a7577'
r={'sources':sources,'build':build,'genuine':genuine,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],text=True)}
(root/(sys.argv[1]+'.json')).write_text(json.dumps(r,indent=2))
print(json.dumps({'sourceFiles':len(sources),'buildFiles':len(build),'genuine':genuine,'head':r['head']}))
