import {createServer}from'/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import{readFile,writeFile}from'node:fs/promises';import{gunzipSync,gzipSync}from'node:zlib';import{createHash}from'node:crypto';import assert from'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2',root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/ancients396',policy=JSON.parse(await readFile(root+'/policy.json','utf8')),raw=await readFile(policy.input),save=JSON.parse(gunzipSync(raw));assert.equal(createHash('sha256').update(gunzipSync(raw)).digest('hex'),policy.inputRawSHA256);assert.equal(save.map.challengeOrdinals.normal,policy.firstOrdinal);
const nativeNow=Date.now;Date.now=()=>save.timestamp;const server=await createServer({root:repo,configFile:false,cacheDir:root+'/vite-cache',server:{middlewareMode:true,hmr:false,ws:false},resolve:{alias:{'@':repo+'/src'}}});
const report={kind:'diagnostic only; no genuine action or save promotion',policy,rows:[],seeds:[]};
try{const load=p=>server.ssrLoadModule(p),{restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts'),{useMapStore}=await load('/src/stores/mapStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{loadQuests}=await load('/src/data/loaders/quests.ts'),{hashSeed}=await load('/src/engine/rng.ts'),{__resetRollItemSeqForTests}=await load('/src/engine/loot/rollItem.ts');

const baseline=JSON.parse(await readFile(root+'/ancients-screen.json','utf8')),row=baseline.rows.find(r=>r.waves.length===7);assert(row);
restoreEarnedSave(save,save.timestamp);const q=loadQuests().find(q=>q.id===policy.quest);useMapStore.getState().updateQuestProgress(q.id,{status:'inProgress',objectives:Object.fromEntries(q.objectives.map(o=>[o.id,false]))});
const handle=startEarnedRun({act:5,subAreaId:policy.area,mode:'manual',runSeed:row.seed}),waves=[];
for(let n=0;n<handle.totalWaves;n++){const w=playEarnedWave(handle,n);waves.push(w);if(w.advanceResult!=='next-wave')break;}
await writeFile(root+'/baseline-boss-trace.diagnostic-only.json.gz',gzipSync(JSON.stringify({seed:row.seed,waves})),{flag:'wx'});
const last=waves.at(-1),events=last.opening.recordedEvents;console.log(JSON.stringify({seed:row.seed,openingKeys:Object.keys(last.opening),outcomeKeys:Object.keys(last.played.outcome),eventSample:events.slice(0,15),heroEvents:events.filter(e=>e.sourceId===save.player.id||e.actorId===save.player.id).slice(0,20)},null,2));
useCombatStore.getState().endCombat();
}finally{await server.close();Date.now=nativeNow;}
