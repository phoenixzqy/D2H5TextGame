from pathlib import Path
import json,hashlib,tarfile,shutil,gzip
raw=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
summary=json.loads((raw/'summary.json').read_text());cleanup=json.loads((raw/'cleanup.json').read_text());assert summary['status']=='pass' and cleanup['allConsumersTerminal'] and not cleanup['remaining'] and not cleanup['failures']
target=repo/'docs/plans/evidence/fixtures/earned-act5-arreat-farm396';target.mkdir();files={}
for p in sorted(raw.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink();rel=str(p.relative_to(raw));data=p.read_bytes();files[rel]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
archive=target/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
 for rel in files:tf.add(raw/rel,arcname=rel,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(m.name for m in tf.getmembers())==set(files)
 for member in tf.getmembers():
  assert member.isfile();data=tf.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==files[member.name]['sha256'] and len(data)==files[member.name]['bytes']
shutil.copyfile(raw/'summary.json',target/'summary.json');shutil.copyfile(raw/'earned-arreat396-through400/final.json.gz',target/'retained-final.json.gz');assert hashlib.sha256(gzip.decompress((target/'retained-final.json.gz').read_bytes())).hexdigest()==summary['finalRawSHA256']
manifest={'kind':'six failed Ancients qualifications and bounded earned Arreat farm from396, including all original tooling failures; diagnostic saves never resume','owner':'root','rawRoot':str(raw),'retention':'root retains exact raw directory through campaign/full-v1 consumers, then removes it','files':files,'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'finalRawSHA256':summary['finalRawSHA256'],'cleanup':cleanup};(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'archivedFiles':len(files),'archiveBytes':archive.stat().st_size,'finalRawSHA256':summary['finalRawSHA256']}))
