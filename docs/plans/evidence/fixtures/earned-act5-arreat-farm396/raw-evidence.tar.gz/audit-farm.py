from pathlib import Path
import gzip,json,hashlib
r=Path(__file__).resolve().parent
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
j=lambda p:json.loads(Path(p).read_text())
z=lambda p:json.load(gzip.open(p))
def own(s):
 a=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[i for eq in s['mercs']['mercEquipment'].values() for i in eq.values()];a=[i for i in a if i is not None];m={i['id']:i for i in a};assert len(m)==len(a);return m
def xp(s):return s['player']['experience']+sum(int(100*l**2.5)for l in range(1,s['player']['level']))
policy=j(r/'farm-policy.json');start=z(policy['input']);report=j(r/'earned-arreat396-through400/report.json');final=z(r/'earned-arreat396-through400/final.json.gz');ancestors=own(start);current=own(final)
assert report['status']=='observed' and not report['errors'] and not report['console'] and not report.get('cleanupErrors') and report['retries']==0
assert hashlib.sha256(gzip.decompress(Path(policy['input']).read_bytes())).hexdigest()==policy['inputRawSHA256']
assert 1<=len(report['launches'])<=5 and report['launches']==[{'ordinal':396+i,'alias':'arreat-plateau'}for i in range(len(report['launches']))]
assert final['map']['challengeOrdinals']=={'normal':396+len(report['launches']),'nightmare':0}
for id,item in ancestors.items():assert current[id]==item,id
for k in ['coreStats','skillLevels','comboOrder','respecsRemaining']:assert final['player'][k]==start['player'][k]
dlevels=final['player']['level']-start['player']['level'];assert final['player']['level']<=33;assert final['player']['statPoints']==start['player']['statPoints']+5*dlevels;assert final['player']['skillPoints']==start['player']['skillPoints']+dlevels
for k in ['equipped','materialActionOrdinal','questItems','questServices']:assert final['inventory'][k]==start['inventory'][k]
for k in ['questProgress','questReceipts','questTitles','questDifficulties','selectedTitle','selectedDifficulty']:assert final['map'][k]==start['map'][k]
assert final['mercs']['mercEquipment']==start['mercs']['mercEquipment'];assert final['endgame']==start['endgame'];assert final['formation']==start['formation'];assert final['player']['derivedStats']['magicResist']==40
pairs=[];saved=0
for i,label in enumerate(report['states']):
 state=z(r/'earned-arreat396-through400'/(label+'.json.gz'))
 if 'player' in state:
  saved+=1;items=own(state)
  for id,item in ancestors.items():assert items[id]==item,(label,id)
 if label.endswith('-saved'):
  other=report['states'][i+1];assert other.endswith('-continued');assert state==z(r/'earned-arreat396-through400'/(other+'.json.gz'));pairs.append([label,other])
wins=0;nonwins=0;rewardXP=0;rewardItems=0
for area in report['areas']:
 ordinal=area['ordinal'];assert area['waves'];assert area['alias']=='arreat-plateau'
 for w in area['waves']:
  n=w['wave'];before=z(r/f'earned-arreat396-through400/{ordinal}-w{n}-initial.json.gz');after=z(r/f'earned-arreat396-through400/{ordinal}-w{n}-terminal.json.gz');assert set(before['enemyIds'])<=set(after['enemyIds']);assert after['skipDisabled'] is True
  if w['outcome']=='victory':
   assert after['liveEnemies']==0 and after['defeat']is None and after['log'][-1]=='Victory! All enemies are defeated.';assert next(c for c in after['cards']if c['id']=='unit-card-'+start['player']['id'])['dead']is None;wins+=1;rewardXP+=w['delta']['xp'];rewardItems+=len(w['delta']['newItems'])
  else:
   nonwins+=1;assert area is report['areas'][-1]and w is area['waves'][-1]and w['delta']=={'xp':0,'newItems':[]}
 if area['outcome']=='victory':assert len(area['waves'])==6 and all(w['outcome']=='victory'for w in area['waves'])
assert nonwins<=1;assert xp(final)-xp(start)==report['totalXP']==rewardXP;assert len(current)-len(ancestors)==rewardItems
if final['player']['level']==33:assert report['stopReason']=='target-level33'
elif not nonwins:assert len(report['launches'])==5 and report['stopReason']=='five-new-attempt-cap'
freeze=j(r/'source-freeze.json');assert all((repo/p).is_file()and hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
diagnostics={}
for key,file in [('baseline','ancients-screen.json'),('weapon','gear-screen.json'),('Dexterity','dex-v2-screen.json'),('IceBlast','cold-v2-screen.json'),('FrozenOrb','orb-screen.json'),('manaCritGear','mana-gear-screen.json'),('ArreatFarm','farm-screen.json')]:
 v=j(r/file);assert v['status']=='complete'and len(v['rows'])==32;diagnostics[key]={k:v[k]for k in ['wins','secondHalfWins','qualified']}
assert all(v['wins']==0 for k,v in diagnostics.items()if k!='ArreatFarm');assert diagnostics['ArreatFarm']['qualified']
summary={'status':'pass','kind':'six unqualified Ancients alternatives retained; bounded genuine Arreat farming from396','diagnostics':diagnostics,'diagnosticRuns':224,'genuineLaunches':report['launches'],'victoryWaves':wins,'nonwinWaves':nonwins,'heroXP':rewardXP,'newGear':rewardItems,'ownedBefore':len(ancestors),'ownedFinal':len(current),'ancestralFullPayloadsExact':True,'nativeSavedSnapshots':saved,'saveContinuePairs':pairs,'finalLevel':final['player']['level'],'finalXP':final['player']['experience'],'finalStatPoints':final['player']['statPoints'],'finalSkillPoints':final['player']['skillPoints'],'finalNextNormal':final['map']['challengeOrdinals']['normal'],'finalRawSHA256':hashlib.sha256(gzip.decompress((r/'earned-arreat396-through400/final.json.gz').read_bytes())).hexdigest(),'sourceFiles':len(freeze),'sourceDrift':[],'stopReason':report.get('stopReason',report['outcome']),'limitations':'no Ancients/native Rite or C2/full-v1 acceptance; no diagnostic save promotion; clock transport is not player pacing'}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
