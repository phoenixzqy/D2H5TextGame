import os,json
from pathlib import Path
r=Path(__file__).resolve().parent
args=['node','node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','4447','--strictPort','--outDir',str(r/'dist-v2')]
(r/'preview-process.json').write_text(json.dumps({'pid':os.getpid(),'command':' '.join(args),'port':4447},indent=2)+'\n')
os.execvp('node',args)
