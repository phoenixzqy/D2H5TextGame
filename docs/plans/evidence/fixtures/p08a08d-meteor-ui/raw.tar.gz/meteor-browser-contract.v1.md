# Meteor production browser contract

Separate2path increment after source acceptance, tests/pwa/meteor.{config,spec}.ts.
Clean production preview only, no bridge/devserver/state injection. Two locales,
native fresh sorceress then explicit imported L24/FireBolt1/FireBall1/FireWall1,
2points and FireBall combo. Imported eligibility/stats are scaffolding, not earned.
Date fixed only (native timers). Preview Meteor unlearned truthful rank1 prose,
absence from all9combo options, no changes to whole player from detail inspection.
Enter native Moor wave, immediately pause before hero first action. Capture rendered
log, card text and every progressbar current/max (finite browser evidence of
existing recording). For learning0→1 and upgrade1→2 use focused Allocate+Enter,
check current/next literal damage, MP50/CD4/orderedBurn+Melt, entire player resources
and combo unchanged except exact skills/points; return combat each time and assert
same rendered snapshot and paused state. Full hidden recording/event identity is
unit evidence only. Flee explicitly before editing combo; ordinary slot changes
may intentionally replay and are not asserted frozen. Meteor option then exists;
keyboard select Meteor slot2, remove and re-add, ensure bothslots durable. No aura
selection claim. NineCSSsizes, detail screenshot/prose14px, heading/node/allocate
44px/hit-grid/no overflow, zh actual Noto glyph evidence via read-only CDP. Save→
Saved→close→newPage→Continue under same Date, entire SaveCurrent equality inclmeta,
reopen details and active slots. Console warning/error arrays empty. No native
touch/allbrowser/fullaccessibility/mercenary/cast/balance/campaign acceptance.
No download retained after JSON read; all attachments outside repo in exact RAW.
