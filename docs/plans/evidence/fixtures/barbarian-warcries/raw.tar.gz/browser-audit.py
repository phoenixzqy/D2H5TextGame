from pathlib import Path
import json,copy
root=Path(__file__).resolve().parent
report=json.loads((root/'browser-report.json').read_text())
assert len(report['cases'])==4 and all(c['pass'] and not c['errors'] for c in report['cases'])
def one(pattern):
 paths=list(root.glob(pattern));assert len(paths)==1,(pattern,paths)
 return json.loads(paths[0].read_text())
count=0
for case in report['cases']:
 label=case['label'];imported=one(label+'-imported-*.json')
 assert imported['player']['class']=='barbarian' and imported['player']['level']==24
 assert imported['player']['skillPoints']==5 and imported['player']['skillLevels']=={}
 for slug,levels,points in [
  ('shout',{'barbarian.howl':1,'barbarian.shout':2},2),
  ('battle-orders',{'barbarian.howl':1,'barbarian.shout':2,'barbarian.battle_orders':2},0)]:
  before=one(label+'-'+slug+'-before-*.json');after=one(label+'-'+slug+'-after-*.json')
  assert before['version']==after['version']==22
  for key in ['player','inventory','map','mercs','formation']: assert before[key]==after[key],(label,slug,key)
  expected=copy.deepcopy(imported['player']);expected['skillLevels']=levels;expected['skillPoints']=points
  assert before['player']==expected,(label,slug,'unexpected player mutation')
  for key in ['inventory','map','mercs','formation']: assert before[key]==imported[key],(label,slug,key,'changed')
  count+=1
assert count==8
assert len(report['geometry'])==40
out={'cases':4,'exactContinuePairs':count,'exactDomains':['player','inventory','map','mercs','formation'],
 'exactExpectedAllocations':True,'saveVersion':22,'geometrySamples':len(report['geometry']),
 'scope':'Synthetic L24 import followed by native learning; not earned campaign/class viability or full accessibility acceptance'}
(root/'browser-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
