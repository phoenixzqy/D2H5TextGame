from pathlib import Path
import json,sys,time
root=Path(__file__).resolve().parent
label=sys.argv[1]
p=json.loads((root/(label+'.process.json')).read_text())
lines=(root/(label+'.log')).read_text().splitlines()
failed=[line for line in lines if line.startswith(' ❯ |') or line.startswith(' FAIL ') or 'AssertionError:' in line]
print(json.dumps({'label':label,'elapsedSeconds':round(time.time()-p['started'],1),'terminal':(root/(label+'.result.json')).exists(),'passedFileMarkers':sum('✓ |' in line for line in lines),'failedMarkers':failed[-12:],'recentOutput':lines[-3:]},ensure_ascii=False))
