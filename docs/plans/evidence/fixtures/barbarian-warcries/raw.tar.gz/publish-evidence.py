from pathlib import Path
import csv,collections,hashlib,json,subprocess
root=Path(__file__).resolve().parent
full=json.loads((root/'full-final.result.json').read_text());assert full['exit']==0
before=json.loads((root/'before-full-final.json').read_text());after=json.loads((root/'after-full-final.json').read_text());assert before==after
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
proof=json.loads((root/'source-commit-integrity.json').read_text());assert proof['head']==head and proof['exactMatch']
manifest=json.loads(Path('docs/plans/evidence/fixtures/barbarian-warcries/manifest.json').read_text())
full_log=(root/'full-final.log').read_text()
assert '12505 passed' in full_log and '537 passed' in full_log and '2 skipped' in full_log
for label in ['engine-final-corrected','types-final-corrected','lint-terminal-retry','corpus-final','build-final','bridge-final','browser-final','browser-audit-complete']:
 assert json.loads((root/(label+'.result.json')).read_text())['exit']==0,label
p=Path('docs/plans/skill-inventory.csv')
with p.open(newline='') as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
ids=[r['data_id'] for r in rows];changed=[]
for row in rows:
 if row['runtime_id'] in ['barbarian.shout','barbarian.battle_orders']:
  assert row['behavior_verification']=='unverified'
  row.update(adapter_route='buff-metadata+fresh-player-warcry-composition',risk_flags='earned-class-build-balance-open',behavior_verification='bounded-functional;independent-acceptance-open',contract_evidence='docs/plans/evidence/d05-barbarian-warcries.md');changed.append(row['runtime_id'])
assert len(changed)==2 and len(rows)==213 and ids==[r['data_id'] for r in rows]
with p.open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(rows)
counts=collections.Counter(r['behavior_verification'] for r in rows)
assert counts=={'unverified':154,'bounded-functional;independent-acceptance-open':54,'bounded-functional;earned-balance-open':3,'bounded-engine-functional;independent-acceptance-open':1,'review-needed':1},counts
p=Path('production/bugs/BUG-184-barbarian-warcry-passives.md');s=p.read_text().replace('Status: reproduced; implementation in progress','Status: fixed locally in `'+head+'`; independent acceptance/earned balance open')
s+='\nRegression: src/stores/barbarian-warcries-composition.test.ts,\nsrc/stores/barbarian-warcries-native.test.ts,\nsrc/engine/skills/barbarian-warcries.test.ts and\nsrc/features/skills/SkillsScreen.barbarian-warcries.test.tsx.\nCurrent verification: docs/plans/evidence/d05-barbarian-warcries.md.\n';p.write_text(s)
text=f'''# D05 — Automatic personal Barbarian Shout and Battle Orders

Runtime/UI commit: `{head}`. Controlling [D05 contract](../decisions/D05-barbarian-warcries-v1.md).
BUG184 fixed locally; independent design/QA and earned-build balance remain open.

## Delivered behavior

Shout automatically adds the authored3% ordinary Defense per allocated rank,
unlock6/Howl prerequisite/cap20. Orders adds4% maximum Life and1% ordinary
Energy-based MP recovery per rank, unlock24/Shout prerequisite/cap20. The old
fixed50%/party/timed/max-mana descriptions are explicitly reconciled. Hero only;
no cast, combo, timer, selection, passive action, RNG, cost or saved-field change.

Copied/frozen schema-owned definitions accept only exact allocation aliases,
MAX once/cap; the fresh hero boundary enforces class/level eligibility. Native
learning owns prerequisites. Same-stat bonuses add over one fresh equipment/quest
baseline: life*(1+Stamina+Orders), defense*(1+IronSkin+Shout). Orders boosts normal
Energy recovery before existing item recovery. Maximum MP is unchanged. Current
HP/MP remain absolute and clamp on removal; fresh encounter full-pool policy stays.
Learning/reset applies next wave. Explicit replay retains original resources,
carries/seed and pays no duplicate income. Save remains22.

## Verification

| Check | Result |
| --- | --- |
| Focused new/adjacent engine, composition, native, bilingual UI |79 tests/seven files pass |
| Full authored corpus loader/integrity |322 tests/two files pass |
| Engine suite after final test typing/lint correction |6296 tests/223 files pass |
| Standard full regression |12505 tests/537 files pass; two existing skips |
| Strict typecheck/global lint/engine purity |Pass |
| Production build, explicit VITE_E2E=false |Pass; existing bundle/PWA warnings remain |
| Production test-bridge scan |Four chunks/five forbidden patterns absent |
| Production en/zh desktop/mobile + separate attachment audit |Four cases/eight exact five-domain Continue pairs pass |

The full run completed normally in{full['seconds']}seconds. All{len(after['sources'])}
source/test/config hashes,{len(after['build'])} build hashes, HEAD/Git status and
claimed-Rite genuine save digest are exactly equal before/after. All committed
source blobs separately match validated hashes and working files at the runtime
commit. Existing test-time/bundle/PWA budgets and intermittent BUG180 remain open;
BUG180 did not recur here. No validate:data script exists; actual corpus validation
uses the repository loader/integrity suites, without an alternate weaker validator.

## Proof scope

Actual seeded rank1/20 battles verify landed physical mitigation, additional
surviving HP, useful ordinary paid healing into new capacity and increased MP
recovery. Tests cover exact aliases/cap/invalid ranks, independent unlocks,
foreign classes, strict closed payloads, copied/frozen alternate tuning, fresh
equipment composition/removal/clamping, real Phoenix recovery ordering and merc
nonrecipients. No new automatic cast or status marker is needed.

Four native store cases use constructed L30 gear/finisher fixtures. Public
learning changes next wave only, preserving carried pools and exact recovery
carry; free pure-composition reset and original-input replay conserve income,
clamp decreases and remain deterministic. Validated v22 serialization/import
preserves allocations and recomposes without persistent derived bonuses. This
proves composition reset, not the paid town respec service.

Browser cases import an explicitly synthetic L24/five-point fixture, then learn
Howl/Shout/Orders and rank both passives through public controls. Both locales
show actual rank1/next2 values, ordinary recovery versus maximum MP, self-only,
unlock/cap and next-wave semantics. Eight Save-close-new-page-Continue pairs
compare complete player/inventory/map/mercs/formation domains. A separate raw-save
auditor verifies exact expected allocation/point changes and unchanged other
fields. Forty geometry samples across360x640/412x915/640x360/1280x800/1920x1080
show no horizontal overflow and Allocate>=44x44. No page errors captured. All eight
screenshots inspected individually. Existing fixed header/navigation partly
occludes mobile headings/Allocate/lower rows, and icon/font fallbacks remain;
whole-screen accessibility/safe-area acceptance is not established.

## Original failures retained

Initial RED16 failures included mistaken fixtures: full-unit equality included
retained allocations, wrong BattleResult field, flat damage floor and a duplicate
variable introduced while correcting them. Corrected causal RED10 failures/six
controls precedes production edits. First production schema omitted nested object
types required by strict Ajv; collection failed in focused/native/engine runs.
Explicit types/property declarations fix the schema without relaxing validation.
Corrected core/native passed47 cases while four UI cases still failed, before
actual description/alias wiring. All79 focused cases then passed, including added
healing/item/merc and exact recovery-label checks.

Initial final typecheck exposed one excess-property literal in a merc fixture;
lint exposed two void assertion callbacks. Only fixtures/callback braces changed.
A later lint wrapper terminated143 without a child receipt; its recorded child
PID and all ESLint consumers in this worktree were confirmed absent before an
unchanged-source normal retry passed. The cause of termination is unknown. An
attachment audit was mistakenly started before the fourth live browser case
finished; its original incomplete-report failure remains, followed by the complete
four-case audit. No gameplay/number/timeout/worker/discovery/gate weakening or new
skips were introduced. Preview exit-15 is deliberate exact-owned-PID cleanup after
all browser consumers finished, separately recorded.

## Retention and remaining scope

[Manifest](fixtures/barbarian-warcries/manifest.json) retains{manifest['rawFiles']} raw
files/{manifest['terminalProcessRecords']} terminal process records, byte-verified
in raw.tar.gz. [Cleanup receipt](fixtures/barbarian-warcries/cleanup.json) records
exact task-owned disposal/preview closure; shared caches and older campaign
evidence are preserved.

Only these two skills gain bounded-functional dispositions. All213 IDs/order
remain:154 unverified,57 bounded-functional, one bounded-engine-functional (Ice
Arrow), one review-needed (Cold Mastery). These58 bounded records have different
proof scopes. Golem Mastery's known stale row is not credited by this batch.

Genuine Ancients401/Rite remains L33/XP149261/23682gear/nextNormal402,
decompressed SHA256`{after['genuine']}`.
No genuine campaign actions or remote publication. Baal/C2-C4/fullG0-G7, all213
skills, seven classes/two builds, economy/pacing/endgame/offline/PWA/accessibility/
performance and independent acceptance remain unfinished. The umbrella goal,
branch and worktree claim stay active.
'''
Path('docs/plans/evidence/d05-barbarian-warcries.md').write_text(text)
p=Path('docs/plans/execution-ledger.md');p.write_text(p.read_text()+f'''\n\n## D05 — Automatic personal Barbarian warcries / BUG184

Runtime{head[:7]} applies authored Shout defense and Orders life/ordinary Energy
recovery at fresh hero composition. Like bonuses add over fresh equipment/quest
stats; Orders precedes item recovery, with no max-MP, timer, action, refill or save
change. Both locales show actual current/next values and automatic self-only rules.
[Evidence](evidence/d05-barbarian-warcries.md): focused79/7, engine6296/223,
corpus322/2, full12505/537/two existing skips; types/lint/build/bridge pass.
Production browser4/4, eight separately audited exact five-domain Continue pairs,
40 geometry samples; eight screenshots inspected with existing mobile occlusion
and icon/font fallback limits retained. Full-run1253 source/760 build hashes,
HEAD/status and genuine save digest remain exact. All original fixture/schema/
type/lint/premature-auditor failures and interrupted lint observation retained.
{manifest['rawFiles']} raw files/{manifest['terminalProcessRecords']} terminal records archived/byte-verified;
exact task cleanup receipt accompanies evidence. No new skip or gate weakening.
Only two new bounded-functional rows:213 IDs/order unchanged,154 unverified/
57 bounded-functional/one engine-only/one review-needed. Genuine claimed Rite
save remainsL33/XP149261/23682gear/next402; no campaign replay or remote action.
C2-C4/fullG0-G7, earned Baal/all-class builds/economy/pacing/endgame/PWA/performance
and independent acceptance remain open. Existing umbrella goal/worktree active.
''')
print(json.dumps({'runtimeCommit':head,'inventory':dict(counts),'rawFiles':manifest['rawFiles']}))
