from pathlib import Path
import hashlib, json, subprocess, sys

root = Path(__file__).resolve().parent
expected = json.loads((root / 'after-full-final.json').read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
paths = list(expected['sources'])
request = ''.join(f'{head}:{path}\n' for path in paths).encode()
blobs = subprocess.check_output(['git', 'cat-file', '--batch'], input=request)
offset = 0
for path in paths:
    end = blobs.index(b'\n', offset)
    header = blobs[offset:end].split()
    assert len(header) == 3 and header[1] == b'blob', (path, header)
    size = int(header[2])
    start = end + 1
    data = blobs[start:start + size]
    assert len(data) == size and blobs[start + size:start + size + 1] == b'\n', path
    digest = hashlib.sha256(data).hexdigest()
    assert digest == expected['sources'][path], (path, 'committed source differs')
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, (path, 'working source differs')
    offset = start + size + 1
assert offset == len(blobs)
result = {'head': head, 'validatedSourceBlobs': len(paths), 'exactMatch': True,
          'validatedSnapshot': 'after-full-final.json'}
label = sys.argv[1] if len(sys.argv) > 1 else 'source-commit-integrity'
(root / f'{label}.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
