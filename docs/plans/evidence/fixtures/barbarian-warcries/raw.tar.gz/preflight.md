# Barbarian Shout/Battle Orders preflight

Previous turn: progress; Concentration delivered and source/evidence committed/cleaned. Current98c3d81clean, own umbrella human claim revalidated in_use. Root sole writer, no subagents; original read-only, no reset/switch/release, remote publication or genuine campaign actions. Exact scratch is owner.json disposableRoot; build-final and browser outputs belong to this task. Copied browser tools still require full adaptation before use. Planned port4471.

Security check: pass. Scope is local deterministic JSON/strict validation/fresh combat/UI/tests, no dependency/network/credential/permission/save-version change.

Plan review: ready after recording numeric/recipient/timing conflicts in the controlling D05 contract before implementation. Preserve authored unlocks/prerequisites/caps/coefficients and automatic self-only trigger; compose once from fresh equipment/quest baseline. Same-kind Stamina/Orders life percentages and Iron Skin/Shout defense percentages add before one multiplication. Orders scales normal effective-Energy recovery before existing item recovery composition, without max-MP change. Include actual damage/healing/recovery, eligibility/alias/cap/frozen tuning, native learning/next wave/original replay/reset/no income/refill/save and bilingual current/next proof. No new party aura, timed buff or saved field. Independent design/QA/earned balance remain open.

Children root-owned sequential: contract+causal RED; strict definitions/schema+fresh native consumer; native/UI GREEN; production browser/full regression/fingerprint/source commit; evidence/inventory/cleanup/docs commit. No competing writers.

Continuation audit: the immediately preceding user-status turn was no progress
for the implementation goal. Current HEAD/clean state and exact registry owner
were revalidated, then contract/causal regressions and native implementation
advanced authoritative state. No genuine blocker or approval hold exists.
