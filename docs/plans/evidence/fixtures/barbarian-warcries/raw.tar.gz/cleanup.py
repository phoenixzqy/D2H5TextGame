from pathlib import Path
import json,hashlib,socket
root=Path(__file__).resolve().parent
out=Path('docs/plans/evidence/fixtures/barbarian-warcries')
manifest=json.loads((out/'manifest.json').read_text())
assert manifest['scratchRoot']==str(root) and manifest['byteVerified']
assert hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest()==manifest['archiveSha256']
for e in manifest['files']:
 f=root/e['path'];assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256'],e['path']
# Build output is task-owned; all final build hashes must still match before disposal.
expected=json.loads((root/'after-full-final.json').read_text())['build']
actual={str(f.relative_to(root/'build-final')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'build-final').rglob('*') if f.is_file()}
assert actual==expected
sock=socket.socket();sock.settimeout(.3)
assert sock.connect_ex(('127.0.0.1',4471))!=0,'preview port remains open'
sock.close()
paths=sorted(root.rglob('*'),key=lambda f:len(f.parts),reverse=True)
assert not any(f.is_symlink() for f in paths)
files=[f for f in paths if f.is_file()]
report={'scratchRoot':str(root),'removedFiles':[str(f) for f in files],'removedDirectories':[],'remaining':[],'failures':[],'previewPort':4471,'previewClosed':True}
for f in files:
 assert f.resolve().is_relative_to(root.resolve());f.unlink()
for d in [f for f in paths if f.is_dir()]:
 d.rmdir();report['removedDirectories'].append(str(d))
root.rmdir()
assert not root.exists()
report['scratchAbsent']=True
(out/'cleanup.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'removedFiles':len(files),'scratchAbsent':True,'previewClosed':True,'remaining':[],'failures':[]}))
