# Root self-review (not independent approval)

Correctness: narrow JSON coefficients; exact aliases/MAX/cap; class/unlock guard;
like bonuses add over fresh stats; recovery before canonical item composition.
Native next-wave/original-input replay/reset and v22 import retain pools/carries.
Actual damage, healing capacity, MP recovery and item/merc negative cases pass.
UI uses shared definitions and rank aliases, both current/next values in zh/en.
Readability/architecture: one narrow pure module, one hero boundary, existing
shared strict validator; no engine DOM/React, action/timer/RNG/persistence changes.
Security: strict closed schema, no dependencies, network, credentials or permissions.
Performance: module-load copied definitions/one shared validator; two constant-size
allocation checks per composition. No new per-action loops or compilation.
Diff hygiene: preserved old schema bytes and appended one condition; JSON-semantic
identity before/after formatting verified. No unrelated source edits.
Pending: final immutable inputs regression, build/browser and screenshot review.
Independent design/QA and earned class/build balance remain open.

Final verification: full12505/537/two existing skips, engine6296/223, types/lint/build/corpus/browser and source/build/Git/genuine fingerprints PASS. Eight final screenshots inspected; mobile occlusion and icons/font fallback limits retained. No independent approval or earned-build claim.
