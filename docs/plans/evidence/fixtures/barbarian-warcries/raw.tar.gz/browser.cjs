const { chromium, expect } = require('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/@playwright/test');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = __dirname, baseURL = 'http://127.0.0.1:4471';
const summary = {cases:[], geometry:[], failures:[]};
let serial = 0;
async function exportSave(page,label) {
 const pending=page.waitForEvent('download'); await page.getByTestId('export-save-button').click();
 const dl=await pending,target=path.join(root,`${label}-${++serial}.json`);await dl.saveAs(target);
 return JSON.parse(await fs.readFile(target,'utf8'));
}
async function nav(page,route) {
 await page.locator(`a[href="/${route}"]`).first().click();await expect(page.getByTestId(`${route}-screen`)).toBeVisible();
}
function domains(save) {return Object.fromEntries(['player','inventory','map','mercs','formation'].map(k=>[k,save[k]]));}
async function continuePair(page,context,locale,label) {
 await nav(page,'settings');await page.getByRole('button',{name:locale==='en'?'Save':'保存',exact:true}).click();
 await expect(page.getByRole('status')).toContainText(locale==='en'?'Saved':'已保存');
 const before=await exportSave(page,label+'-before');assert.equal(before.version,22);
 await page.close();page=await context.newPage();await page.goto(baseURL,{waitUntil:'networkidle'});
 await expect(page.getByTestId('home-continue')).toBeEnabled();await page.getByTestId('home-continue').click();
 await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');
 const after=await exportSave(page,label+'-after');assert.deepEqual(domains(after),domains(before));
 await nav(page,'skills');return {page};
}
function section(detail,title) {return detail.getByRole('heading',{name:title,exact:true}).locator('xpath=ancestor::section[1]');}
async function geometry(page,label) {
 const original=page.viewportSize();
 for(const [width,height] of [[360,640],[412,915],[640,360],[1280,800],[1920,1080]]) {
  await page.setViewportSize({width,height});
  const detail=page.getByTestId('skill-detail-panel'),button=detail.getByRole('button',{name:/^(Allocate|分配)$/});
  const box=await button.boundingBox();const overflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
  assert.ok(overflow<=0,`${label}: overflow ${overflow}`);assert.ok(box&&box.width>=44&&box.height>=44,JSON.stringify(box));
  summary.geometry.push({label,width,height,overflow,button:box});
 }
 await page.setViewportSize(original);
}
(async()=>{
 const browser=await chromium.launch({headless:true,downloadsPath:path.join(root,'downloads')});
 try {
 for(const locale of ['en','zh-CN']) for(const viewport of [{width:1280,height:800},{width:360,height:640}]) {
  const label=`${locale}-${viewport.width}`,context=await browser.newContext({viewport,locale,acceptDownloads:true});
  const errors=[];context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
  await context.tracing.start({screenshots:true,snapshots:true,sources:false});let page=await context.newPage();
  const result={label,pairs:[],errors};
  try {
   await page.goto(baseURL,{waitUntil:'networkidle'});assert.equal(await page.evaluate(()=>typeof window.__GAME__),'undefined');
   await page.getByTestId('home-new-game').click();await page.getByTestId('class-barbarian').click();
   await page.getByTestId('character-name-input').fill('WarcryCheck');await page.getByTestId('character-start-btn').click();
   await expect(page.getByTestId('town-screen')).toBeVisible();await nav(page,'settings');
   await page.getByRole('button',{name:locale==='en'?'English':'简体中文',exact:true}).click();
   const fresh=await exportSave(page,label+'-fresh');assert.equal(fresh.player.level,1);
   // Explicitly synthetic eligible fixture, never genuine campaign progress.
   const constructed={...fresh,player:{...fresh.player,level:24,skillPoints:5,skillLevels:{},comboOrder:[]}};
   await fs.writeFile(path.join(root,label+'-constructed-input.json'),JSON.stringify(constructed,null,2));
   await page.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();
   const dialog=page.getByRole('dialog');await dialog.getByRole('textbox').fill(JSON.stringify(constructed));
   await dialog.getByRole('button',{name:locale==='en'?'Import Save':'导入存档',exact:true}).click();await expect(dialog).toHaveCount(0);
   const imported=await exportSave(page,label+'-imported');assert.equal(imported.player.level,24);assert.equal(imported.player.skillPoints,5);
   await nav(page,'skills');
   await page.getByTestId('skill-node-skills-barbarian-howl').click();
   await page.getByTestId('skill-detail-panel').getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
   for(const [slug,bonus] of [['shout',3],['battle-orders',4]]) {
    await page.getByTestId('skill-node-skills-barbarian-'+slug).click();let detail=page.getByTestId('skill-detail-panel');
    await detail.getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
    for(const text of (locale==='en'?['Automatically','Barbarian only','maximum 20 ranks','next wave']:['自动生效','仅野蛮人','最高20级','下一波'])) await expect(detail).toContainText(text);
    await expect(section(detail,locale==='en'?'Current':'当前')).toContainText(bonus+'%');
    await expect(section(detail,locale==='en'?'Next Level':'下一级')).toContainText((bonus*2)+'%');
    if(slug==='battle-orders') {
     await expect(detail).toContainText(locale==='en'?'Maximum mana is unchanged':'不增加最大法力');
     await expect(section(detail,locale==='en'?'Current':'当前')).toContainText('1%');
     await expect(section(detail,locale==='en'?'Next Level':'下一级')).toContainText('2%');
    }
    await expect(detail).not.toContainText('{{');await geometry(page,label+'-'+slug);
    await detail.scrollIntoViewIfNeeded();await page.mouse.move(1,1);
    await page.screenshot({path:path.join(root,label+'-'+slug+'-rank1.png')});
    await detail.getByRole('button',{name:locale==='en'?'Allocate':'分配',exact:true}).click();
    await expect(section(detail,locale==='en'?'Current':'当前')).toContainText((bonus*2)+'%');
    const pair=await continuePair(page,context,locale,label+'-'+slug);page=pair.page;
    await page.getByTestId('skill-node-skills-barbarian-'+slug).click();
    await expect(section(page.getByTestId('skill-detail-panel'),locale==='en'?'Current':'当前')).toContainText((bonus*2)+'%');
    result.pairs.push({skill:slug,rank:2});
   }
   assert.deepEqual(errors,[]);result.pass=true;await context.tracing.stop();console.log(label+' PASS: 2 exact Continue pairs');
  }catch(error){result.pass=false;result.error=String(error.stack||error);summary.failures.push(label);
   await page.screenshot({path:path.join(root,label+'-failed.png'),fullPage:true}).catch(()=>{});
   await context.tracing.stop({path:path.join(root,label+'-failed-trace.zip')});throw error;
  }finally{summary.cases.push(result);await fs.writeFile(path.join(root,'browser-report.json'),JSON.stringify(summary,null,2));await context.close();}
 }
 }finally{await browser.close();}
 assert.equal(summary.cases.length,4);assert.deepEqual(summary.failures,[]);console.log('All browser cases passed.');
})().catch(error=>{console.error(error);process.exitCode=1;});
