All eight final screenshot files inspected individually: en/zh-CN,1280x800/360x640,
Shout/Orders rank1. Desktop descriptions, current/next and prerequisites readable.
Mobile descriptions/rank values present and wrap without horizontal overflow;
existing fixed header/nav partially occlude top headings/Allocate and some lower
rows at the captured scroll. Existing icon/font fallback squares remain. Forty
geometry samples verify no horizontal overflow and Allocate>=44x44 only.
This is not full accessibility/safe-area or whole-screen mobile acceptance.
