from pathlib import Path
import gzip,hashlib,json,tarfile,socket
TASK=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop')
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
ROOT=TASK/'ring-slot160'
sha=lambda b:hashlib.sha256(b).hexdigest()
f=json.loads((ROOT/'freeze.json').read_text());assert all(sha((REPO/p).read_bytes())==h for p,h in f['source'].items())
full=(ROOT/'full.log').read_text();assert '451 passed (451)' in full and '11670 passed | 2 skipped' in full
assert sha(gzip.decompress((REPO/'docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz').read_bytes()))=='9deb0079f5288e7242c4c0e93211aca08d33b9321babc6eac4cb4efc80521b5e'
for port in [4435,4436]:
 s=socket.socket();assert s.connect_ex(('127.0.0.1',port))!=0;s.close()
for name in ['dexterity-preparation369','ring-slot160']:assert not (TASK/name/'dist').exists()
a=json.loads((ROOT/'audit.json').read_text());assert a['cases']==4 and a['exactDurablePairs']==12
ownership=json.loads((TASK/'artifact-ownership.json').read_text());assert ownership['ringSlot160']['fullExit']==0
final={'sourceCommit':'59f2590','sourceFiles':len(f['source']),'sourceDrift':[],'actualSaveUnchanged':True,'actualNextNormal':369,'fullSummary':[l.strip() for l in full.splitlines() if any(t in l for t in ['Test Files','Tests  ','Duration  '])],'browserAudit':a,'remainingDisposable':[],'cleanupFailures':[],'retention':'root retains raw diagnostic evidence through campaign/full-v1 consumers; removes it after consumers finish; source/history/versioned evidence retained'}
(ROOT/'final-check.json').write_text(json.dumps(final,indent=2)+'\n')
files=[]
for name in ['dexterity-preparation369','owned-damage369','ring-slot160']:
 for p in sorted((TASK/name).rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():files.append(p)
entries=[{'path':str(p.relative_to(TASK)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
dest=REPO/'docs/plans/evidence/fixtures/ring-slot-and-stat-preparation';dest.mkdir()
archive=dest/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(TASK)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 actual=[]
 for m in tar.getmembers():
  assert m.isfile();b=tar.extractfile(m).read();actual.append({'path':m.name,'bytes':len(b),'sha256':sha(b)})
assert actual==entries
manifest={'sourceCommit':'59f2590','archive':'raw.tar.gz','archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive.read_bytes()),'fileCount':len(entries),'files':entries,'actualCampaign':'unchanged genuine next369; no diagnostic state promoted','retention':final['retention']}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
