import gzip,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
sha=lambda b:hashlib.sha256(b).hexdigest()
original_path=REPO/'docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz'
assert sha(gzip.decompress(original_path.read_bytes()))=='9deb0079f5288e7242c4c0e93211aca08d33b9321babc6eac4cb4efc80521b5e'
original=load(original_path)
def owned(s):
 rows=[*s['inventory']['backpack'],*s['inventory']['stash'],*s['inventory']['equipped'].values(),*(i for g in s['mercs']['mercEquipment'].values() for i in g.values())]
 rows=[i for i in rows if i];d={i['id']:i for i in rows};assert len(d)==len(rows);return d
old=owned(original)
fixture=json.loads((ROOT/'fixture-v2/fixture.json').read_text())
allowed={fixture['candidate'],fixture['originalLeft'],fixture['originalRight']}
r=json.loads((ROOT/'browser/report.json').read_text());assert r['errors']==[]
assert {x['name'] for x in r['cases']}=={'en-360','en-1280','zh-CN-360','zh-CN-1280'}
exports=0;pairs=0
for c in r['cases']:
 assert c['status']=='passed' and c['errors']==[] and c['console']==[]
 assert c['pairs']==['right','left-empty','right-again']
 assert len(c['exports'])==7
 for label in c['exports']:
  s=load(ROOT/'browser'/c['name']/(label+'.json.gz'));now=owned(s);assert now.keys()==old.keys()
  for id,i in old.items():
   if id not in allowed:assert now[id]==i,(c['name'],label,id)
   else:
    before={k:v for k,v in i.items() if k!='equipped'};after={k:v for k,v in now[id].items() if k!='equipped'};assert before==after
  for key in ['map','mercs','endgame','formation']:assert s[key]==original[key]
  for key in ['experience','coreStats','skillLevels','comboOrder','respecsRemaining','statPoints','skillPoints']:assert s['player'][key]==original['player'][key]
  exports+=1
 for stage in c['pairs']:
  expected=load(ROOT/'fixture-v2'/(c['locale']+'-'+stage+'.json.gz'))
  saved=load(ROOT/'browser'/c['name']/(stage+'-saved.json.gz'));continued=load(ROOT/'browser'/c['name']/(stage+'-continued.json.gz'));assert saved==continued==expected
  pairs+=1
f=json.loads((ROOT/'freeze.json').read_text());assert all(sha((REPO/p).read_bytes())==h for p,h in f['source'].items());assert all(sha((ROOT/'dist'/p).read_bytes())==h for p,h in f['build'].items())
summary={'cases':len(r['cases']),'exports':exports,'exactDurablePairs':pairs,'uniqueAncestralGear':len(old),'actualNextNormal':369,'actualStateChanged':False,'sourceFiles':len(f['source']),'buildFiles':len(f['build']),'sourceDrift':[],'buildDrift':[],'scope':'constructed diagnostic ownership rearrangement and UI equipment transactions; no genuine campaign/reset/transfer consumed'}
(ROOT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
