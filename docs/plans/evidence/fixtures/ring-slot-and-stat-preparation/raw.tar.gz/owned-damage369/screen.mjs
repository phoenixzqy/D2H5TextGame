import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/owned-damage369';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const input=repo+'/docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,369);
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedTarget}=await load('/tests/sim/production/earned-playback.ts');
 const {useInventoryStore}=await load('/src/stores/inventoryStore.ts');
 const {useMercStore}=await load('/src/stores/mercStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {loadItemBases}=await load('/src/data/loaders/loot.ts');
 const {checkEligibility,slotMatches}=await load('/src/features/inventory/compareEquip.ts');
 const {isTwoHanded}=await load('/src/engine/inventory/equipValidator.ts');
 const {prepareEquippedPlayerStats}=await load('/src/engine/progression/equipped-stats.ts');
 const {deriveEquippedMercStats}=await load('/src/engine/progression/merc-equipment-stats.ts');
 const {mitigateDamage}=await load('/src/engine/combat/damage.ts');
 const {hashSeed}=await load('/src/engine/rng.ts');
 const bases=loadItemBases(),merc=save.mercs.ownedMercs.find(m=>m.id===save.mercs.fieldedMercId);
 assert(merc);
 const heroDerive=prepareEquippedPlayerStats(save.player,save.player.level,save.map.questProgress,save.inventory.questItems,save.map.questReceipts);
 const initial={hero:heroDerive(save.inventory.equipped),merc:deriveEquippedMercStats(merc,save.mercs.mercEquipment[merc.id])};
 const equipment={hero:{...save.inventory.equipped},merc:{...save.mercs.mercEquipment[merc.id]}};
 const derive=(who,gear)=>who==='hero'?heroDerive(gear):deriveEquippedMercStats(merc,gear);
 const score=(who,gear)=>{
  const s=derive(who,gear),base=initial[who];
  if(s.lifeMax<(who==='hero'?500:330)||s.manaMax<base.manaMax*.85||s.attackSpeed<base.attackSpeed||s.defense<base.defense*.7||s.resistances.physical<0)return -Infinity;
  if(s.resistances.lightning<(who==='hero'?50:35)||s.resistances.cold<(who==='hero'?60:45)||s.resistances.fire<(who==='hero'?40:25))return -Infinity;
  return (1+s.critChance*(s.critDamage-1))*(who==='merc'?s.attack:1)*s.attackSpeed/base.attackSpeed;
 };
 const slots=['weapon','head','chest','gloves','boots','belt','amulet','offhand','ring-left','ring-right'];
 for(let pass=0;pass<2;pass++)for(const who of ['hero','merc'])for(const slot of slots){
  const person=who==='hero'?save.player:merc;
  const occupied=new Set([...Object.entries(equipment[who]).filter(([key])=>key!==slot).map(([,i])=>i?.id),...Object.values(equipment[who==='hero'?'merc':'hero']).map(i=>i?.id)]);
  let best=equipment[who],value=score(who,best);
  for(const item of save.inventory.backpack){
   if(isTwoHanded(bases.get(item.baseId))||occupied.has(item.id)||!slotMatches(bases.get(item.baseId)?.slot,slot)||!checkEligibility(item,person,bases).eligible)continue;
   const next={...equipment[who],[slot]:item},candidate=score(who,next);
   if(candidate>value+1e-12){best=next;value=candidate;}
  }
  equipment[who]=best;
 }
 const changes=[];
 for(const who of ['hero','merc'])for(const slot of slots){const old=(who==='hero'?save.inventory.equipped:save.mercs.mercEquipment[merc.id])[slot],item=equipment[who][slot];if(item?.id!==old?.id)changes.push({who,slot,from:old?.id??null,to:item.id});}
 const apply=()=>{restoreEarnedSave(save,0);for(const c of changes){const item=useInventoryStore.getState().backpack.find(i=>i.id===c.to);assert(item);assert.deepEqual(c.who==='hero'?useInventoryStore.getState().equipItem(item):useMercStore.getState().equipOnMerc(merc.id,c.slot,item),{ok:true});}};
 apply();
 const report={kind:'isolated owned-backpack offensive heuristic and32 fixed independent full-area seeds; no actual preparation or attempt consumed, no projected save promoted',inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),heuristic:'two fixed coordinate passes,20 legal one-handed slots; maximize expected offensive damage; hero500/Rogue330life,85%mana,original speed,70%defense,physical resistance>=0; hero50lightning60cold40fire/Rogue35lightning45cold25fire',initial,proposed:{hero:derive('hero',equipment.hero),merc:derive('merc',equipment.merc)},changes,seeds:JSON.parse(await readFile('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/dexterity-preparation369/screen.json','utf8')).seeds,rows:[]};
 for(const adapted of [true])for(const area of ['travincal','durance-of-hate'])for(const seed of report.seeds){
  if(adapted)apply();else restoreEarnedSave(save,0);
  const h=startEarnedRun({act:3,subAreaId:'areas/act3-'+area,mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,369);const result=playEarnedTarget(h);
  report.rows.push({adapted,area,seed,outcome:result.terminalAdvance,waves:result.waves.map(w=>({wave:w.index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life})),players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life}))}))});
  useCombatStore.getState().endCombat();process.stdout.write(JSON.stringify({adapted,area,seed,outcome:result.terminalAdvance})+'\n');
 }
 report.summary=['travincal','durance-of-hate'].map(area=>({area,n:report.seeds.length,wins:report.rows.filter(r=>r.area===area&&r.outcome==='victory').length}));
 assert.deepEqual(await readFile(input),raw);await writeFile(root+'/screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify({summary:report.summary,changes,proposed:report.proposed})+'\n');
}finally{await server.close();}
