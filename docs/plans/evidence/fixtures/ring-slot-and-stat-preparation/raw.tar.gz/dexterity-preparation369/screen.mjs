import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/dexterity-preparation369';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const input=repo+'/docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz',raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,369);assert.deepEqual(save.player.coreStats,{strength:10,dexterity:25,vitality:132,energy:63});
const server=await createServer({root:repo,configFile:false,server:{middlewareMode:true,hmr:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p),{restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts'),{startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts'),{useCombatStore}=await load('/src/stores/combatStore.ts'),{prepareTownRespec,executeTownRespec}=await load('/src/stores/respecActions.ts'),{hashSeed}=await load('/src/engine/rng.ts');
 const seeds=Array.from({length:32},(_,i)=>hashSeed('Earned369-StatPreparation-v1|'+i));
 const report={kind:'isolated paired diagnostic, no actual reset/attempt or promoted save',input,inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),policy:JSON.parse(await readFile(root+'/policy.json','utf8')),seeds,rows:[]};
 for(const moved of [0,40,80,120])for(const area of ['travincal','durance-of-hate'])for(const [index,seed]of seeds.entries()){
  restoreEarnedSave(save,0);const player=()=>usePlayerStore.getState().player;
  if(moved){const prepared=prepareTownRespec('npc/ormus','stat');assert.equal(prepared.kind,'ok');assert.equal(prepared.cost,0);assert.equal(executeTownRespec(prepared.request),'ok');assert.equal(usePlayerStore.getState().allocateStatPoints({strength:0,dexterity:moved,vitality:122-moved,energy:28},player()),'ok');assert.deepEqual(player().coreStats,{strength:10,dexterity:25+moved,vitality:132-moved,energy:63});assert.equal(player().statPoints,0);assert.deepEqual(player().respecsRemaining,{stat:2,skill:0});}
  assert.deepEqual(player().skillLevels,save.player.skillLevels);assert.deepEqual(player().comboOrder,save.player.comboOrder);
  const handle=startEarnedRun({act:3,subAreaId:'areas/act3-'+area,mode:'manual',runSeed:seed});assert.equal(handle.challengeOrdinal,369);const waves=[];
  for(let i=0;i<handle.totalWaves;i++){const w=playEarnedWave(handle,i);waves.push({wave:i+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,openingHero:w.opening.playerTeam.filter(u=>u.kind==='hero').map(u=>({stats:u.stats,life:u.life,mana:u.mana})),remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life})),players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana}))});if(w.advanceResult!=='next-wave')break;}
  const won=waves.length===handle.totalWaves&&waves.every(w=>w.winner==='player');report.rows.push({moved,area,seed,group:index<16?'screen':'holdout',won,waves});useCombatStore.getState().endCombat();if(index===31)process.stdout.write(JSON.stringify({moved,area,wins:report.rows.filter(r=>r.moved===moved&&r.area===area&&r.won).length,n:32})+'\n');
 }
 report.summary=[0,40,80,120].flatMap(moved=>['travincal','durance-of-hate'].map(area=>({moved,area,...Object.fromEntries(['screen','holdout'].map(group=>{const rows=report.rows.filter(r=>r.moved===moved&&r.area===area&&r.group===group);return[group,{n:rows.length,wins:rows.filter(r=>r.won).length}]}))})));
 assert.deepEqual(await readFile(input),raw);await writeFile(root+'/screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});process.stdout.write(JSON.stringify(report.summary)+'\n');
}finally{await server.close();}
