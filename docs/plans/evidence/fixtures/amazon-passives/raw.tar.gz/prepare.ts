import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync, gzipSync } from 'node:zlib';
import { createMockPlayer } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/features/character/createMockPlayer';
import { deriveEquippedPlayerStats } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/progression/equipped-stats';
import { deriveStats } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/progression/stats';
import { xpRequired } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/progression/xp';
import { decodeSave } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/save/validate';
import { buildSave, toJsonSafe } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/src/engine/save/serialize';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/amazon-passives';
const source='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/earned-spider-through281/retained-final.json.gz';
const original=decodeSave(JSON.parse(gunzipSync(readFileSync(source)).toString()));
for(const level of [30,60]){
 const fresh=createMockPlayer('Constructed Amazon passive eligibility '+level,'amazon');
 const ranks=level===60?{'amazon.critical_strike':20,'amazon.penetrate':20,'amazon.dodge':20}:{};
 const player={...fresh,level,experience:0,experienceToNextLevel:xpRequired(level),
  derivedStats:deriveStats(fresh.coreStats,level),skillLevels:ranks,skillPoints:level===30?6:3,comboOrder:[]};
 const equipped=Object.fromEntries(fresh.equipment.map(item=>['weapon',item]));
 player.derivedStats=deriveEquippedPlayerStats(player,level,equipped,original.map.questProgress,original.inventory.questItems,original.map.questReceipts);
 const save=buildSave({...original,player,inventory:{...original.inventory,backpack:[],stash:[],
   equipped,currencies:{shards:0,wishstones:0}},
   mercs:{...original.mercs,ownedMercs:[],fieldedMercId:null,mercEquipment:{}},timestamp:original.timestamp});
 const json=toJsonSafe(save);decodeSave(json);
 writeFileSync(root+'/constructed-amazon-'+level+'.json.gz',gzipSync(JSON.stringify(json)));
}
console.log('Constructed only: L30 learning and L60 rank-cap import fixtures validated; no genuine save modified.');
