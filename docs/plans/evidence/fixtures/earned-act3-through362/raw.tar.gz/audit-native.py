"""Audit genuine exports and original reports without running gameplay."""
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')

def read(path):
    return json.loads(gzip.decompress(path.read_bytes()))

def raw_hash(path):
    return hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest()

def xp(save):
    p = save['player']
    return p['experience'] + sum(int(100 * level ** 2.5) for level in range(1, p['level']))

def owned(save):
    inv = save['inventory']
    items = [*inv['backpack'], *inv['stash'], *inv['equipped'].values(),
             *(item for slots in save['mercs']['mercEquipment'].values() for item in slots.values())]
    items = [item for item in items if item]
    result = {item['id']: item for item in items}
    assert len(result) == len(items), 'duplicate owned gear'
    return result

def conserved(before, after):
    old, new = owned(before), owned(after)
    for ident, item in old.items():
        assert new.get(ident) == item, f'lost/changed ancestral item {ident}'
    return [ident for ident in new if ident not in old]

def durable_pairs(directory):
    count = 0
    if (directory / 'saved.json.gz').exists():
        assert read(directory / 'saved.json.gz') == read(directory / 'continued.json.gz')
        count += 1
    for saved in directory.glob('*-saved.json.gz'):
        stem = saved.name.removesuffix('-saved.json.gz')
        if re.match(r'^\d{3}-', stem):
            stem = stem[4:]
            matches = list(directory.glob('???-' + stem + '-continued.json.gz'))
        else:
            matches = [directory / (stem + '-continued.json.gz')]
        assert len(matches) == 1 and matches[0].exists(), f'missing Continue for {saved}'
        assert read(saved) == read(matches[0]), f'Continue drift at {saved}'
        count += 1
    return count

def encounter(name, input_path, ordinal, alias):
    directory = ROOT / name
    report = json.loads((directory / 'report.json').read_text())
    before = read(input_path)
    assert report['status'] == 'observed', report.get('failure')
    assert report['errors'] == report['console'] == []
    assert report['retries'] == 0
    assert report['launches'] == [{'ordinal': ordinal, 'alias': alias}]
    assert report['inputSHA256'] == raw_hash(input_path)
    assert read(directory / '001-imported.json.gz') == before
    assert read(directory / f'prelaunch-{ordinal}.json.gz') == before
    area, = report['areas']
    current = before
    winning = 0
    for wave in area['waves']:
        n = wave['wave']
        initial = read(directory / f'{ordinal}-w{n}-initial.json.gz')
        terminal = read(directory / f'{ordinal}-w{n}-terminal.json.gz')
        assert initial['enemyIds']
        assert terminal['skipDisabled'] is True
        assert set(initial['enemyIds']) <= set(terminal['enemyIds'])
        hero, = [card for card in terminal['cards'] if card['id'] == 'unit-card-' + before['player']['id']]
        if wave['outcome'] == 'victory':
            assert terminal['log'][-1] == 'Victory! All enemies are defeated.'
            assert terminal['liveEnemies'] == 0 and hero['dead'] is None
            paths = list(directory.glob(f'???-{ordinal}-w{n}-settled.json.gz'))
            assert len(paths) == 1
            settled = read(paths[0])
            added = conserved(current, settled)
            assert xp(settled) - xp(current) == wave['delta']['xp'] > 0
            assert added == wave['delta']['newItems']
            winning += 1
        else:
            paths = list(directory.glob(f'???-{ordinal}-nonwin.json.gz'))
            assert len(paths) == 1
            settled = read(paths[0])
            assert settled['inventory'] == current['inventory']
            assert settled['mercs'] == current['mercs']
            assert xp(settled) == xp(current)
        assert settled['map']['challengeOrdinals']['normal'] == ordinal + 1
        for key in ['skillLevels', 'comboOrder', 'coreStats', 'respecsRemaining']:
            assert settled['player'][key] == before['player'][key], key
        current = settled
    final = read(directory / 'final.json.gz')
    assert current == final
    added = conserved(before, final)
    assert len(owned(before)) == report['ownedBefore']
    assert len(owned(final)) == report['ownedAfter']
    assert xp(final) - xp(before) == report['totalXP']
    assert durable_pairs(directory) == 2
    if area['outcome'] == 'victory':
        assert 'areas/act3-' + alias in final['map']['clearedSubAreas']
        assert winning == len(area['waves'])
    return {'status': 'pass', 'ordinal': ordinal, 'area': alias, 'outcome': area['outcome'],
            'victories': winning, 'heroXP': xp(final) - xp(before), 'newGear': len(added),
            'ownedBefore': len(owned(before)), 'ownedAfter': len(owned(final)),
            'exactContinuePairs': 2, 'finalRawSHA256': raw_hash(directory / 'final.json.gz')}

def preparation():
    ancestor = REPO / 'docs/plans/evidence/fixtures/earned-spider-through360/retained-final.json.gz'
    before = read(ancestor)
    stopped = read(ROOT / 'prepare-native-v2/stopped-native.json.gz')
    path = ROOT / 'prepare-native-v3/final.json.gz'
    final = read(path)
    report = json.loads((ROOT / 'prepare-native-v3/report.json').read_text())
    assert report['status'] == 'observed' and report['errors'] == report['console'] == []
    assert read(ROOT / 'prepare-native/stopped-native.json.gz') == before
    assert read(ROOT / 'prepare-native-v3/imported.json.gz') == stopped
    assert durable_pairs(ROOT / 'prepare-native-v3') == 1
    stopped['player']['comboOrder'] = final['player']['comboOrder']
    assert stopped == final, 'V3 changed more than priorities'
    expected = {f'sorceress.{skill}': rank for skill, rank in report['recipe'].items()}
    assert final['player']['skillLevels'] == expected
    assert final['player']['comboOrder'] == ['skills-sorceress-' + skill.replace('_', '-') for skill in report['order']]
    assert final['player']['statPoints'] == final['player']['skillPoints'] == 0
    assert final['player']['respecsRemaining'] == {'stat': 3, 'skill': 0}
    assert final['player']['coreStats'] == {**before['player']['coreStats'], 'vitality': before['player']['coreStats']['vitality'] + 35}
    for key in ['inventory', 'mercs', 'map', 'meta', 'endgame', 'timestamp']:
        assert final[key] == before[key], key
    for key in ['life', 'mana']:
        assert final['player']['derivedStats'][key] == before['player']['derivedStats'][key]
    assert xp(final) == xp(before)
    assert len(owned(final)) == 18019
    return {'status': 'pass', 'ownedGear': 18019, 'exactContinuePairs': 1,
            'zeroCombatEntries': True, 'preparedRawSHA256': raw_hash(path)}

def actions():
    before = read(ROOT / 'attempt361/final.json.gz')
    directory = ROOT / 'khalim-actions-v2'
    report = json.loads((directory / 'report.json').read_text())
    assert report['status'] == 'observed' and report['errors'] == report['console'] == []
    final = read(directory / 'final.json.gz')
    original = ROOT / 'khalim-actions'
    failed = json.loads((original / 'report.json').read_text())
    assert failed['status'] == 'tooling-failure' and failed['errors'] == failed['console'] == []
    assert read(original / 'imported.json.gz') == before
    recovered = read(original / 'flail-recovered.json.gz')
    assert read(original / 'stopped-native.json.gz') == recovered
    assert read(directory / 'imported.json.gz') == recovered
    assert durable_pairs(original) == 1
    assert durable_pairs(directory) == 3
    k = 'quests/act3-khalims-will'
    g = 'quests/act3-guardian'
    will = k + '#objective:obj-transmute'
    cube = 'quests/act2-horadric-staff#objective:obj-cube'
    recovered = read(ROOT / 'khalim-actions/flail-recovered.json.gz')
    assert recovered['inventory']['questItems'][k + '#objective:obj-flail'] == {'itemId': 'quest/khalims_flail', 'state': 'owned'}
    assembled = read(directory / 'assembled.json.gz')
    assert assembled['inventory']['questItems'][will] == {'itemId': 'items/khalims_will', 'state': 'owned'}
    assert xp(assembled) == xp(before)
    claimed = read(directory / 'khalim-claimed.json.gz')
    assert xp(claimed) - xp(assembled) == 8000
    assert claimed['inventory'] == assembled['inventory']
    assert claimed['map']['questProgress'][k]['rewardClaimed'] is True
    assert final['player'] == claimed['player'] and final['mercs'] == claimed['mercs']
    assert final['inventory']['questItems'][will]['state'] == 'consumed'
    assert final['inventory']['questItems'][cube] == before['inventory']['questItems'][cube]
    for part in ['heart', 'brain', 'eye', 'flail']:
        assert final['inventory']['questItems'][k + '#objective:obj-' + part]['state'] == 'consumed'
    assert final['map']['questReceipts'] == {k + '#action:council-victory': True, g + '#action:break-compelling-orb': True}
    assert final['map']['questProgress'][g]['objectives']['obj-kill-mephisto'] is False
    assert final['map']['challengeOrdinals'] == before['map']['challengeOrdinals']
    assert conserved(before, final) == []
    return {'status': 'pass', 'heroXP': 8000, 'exactContinuePairs': 4, 'originalNavigationFailurePreserved': True,
            'willConsumed': True, 'cubeRetained': True, 'guardianCredit': False,
            'finalRawSHA256': raw_hash(directory / 'final.json.gz')}

def runtime(served):
    freeze = json.loads((ROOT / 'freeze.json').read_text())
    drift = {}
    for kind, base in [('source', REPO), ('dist', ROOT / 'dist')]:
        if kind == 'dist' and not base.exists() and not served:
            continue
        drift[kind] = [name for name, digest in freeze[kind].items()
                       if hashlib.sha256((base / name).read_bytes()).hexdigest() != digest]
        assert not drift[kind], drift[kind]
    subprocess.run(['git', 'diff', '--exit-code', freeze['productionSourceCommit'], '--', 'src'], cwd=REPO, check=True, capture_output=True)
    chunks = {}
    if served:
        for name, digest in freeze['dist'].items():
            if name.startswith('assets/') and name.endswith('.js'):
                data = urllib.request.urlopen('http://127.0.0.1:4432/' + name).read()
                assert hashlib.sha256(data).hexdigest() == digest
                assert b'__GAME__' not in data and b'VITE_E2E' not in data
                chunks[name] = digest
        assert len(chunks) == 4
    return {'status': 'pass', 'sourceFiles': len(freeze['source']), 'buildFiles': len(freeze['dist']),
            'productionSourceCommit': freeze['productionSourceCommit'], 'drift': drift, 'servedChunks': chunks}

if __name__ == '__main__':
    out = {'runtime': runtime('--served' in sys.argv), 'preparation': preparation(),
           'travincal': encounter('attempt361', ROOT / 'prepare-native-v3/final.json.gz', 361, 'travincal')}
    if (ROOT / 'khalim-actions-v2/final.json.gz').exists():
        out['khalimActions'] = actions()
    if (ROOT / 'attempt362/final.json.gz').exists():
        out['mephisto'] = encounter('attempt362', ROOT / 'khalim-actions-v2/final.json.gz', 362, 'durance-of-hate')
    (ROOT / 'native-audit.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(out, indent=2))
