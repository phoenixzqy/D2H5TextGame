import fs from 'node:fs';
import ts from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/typescript/lib/typescript.js';
const source=fs.readFileSync('tests/sim/production/earned-report.ts','utf8');
const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {encodeObservation}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
for (const input of [Object.assign([1],{extra:2}),Object.assign([1],{[Symbol('array-field')]:2})]) {
 let rejected=false;try{encodeObservation(input)}catch{rejected=true}
 console.log(JSON.stringify({actualArrayRejected:rejected,rowSpreadArgument:input[0],rowSpreadArgumentEncoded:encodeObservation(input[0])}));
}
