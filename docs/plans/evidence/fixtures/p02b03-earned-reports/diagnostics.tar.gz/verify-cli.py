from pathlib import Path
import json,collections
r=Path(__file__).parent
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
ref=json.loads((r/'refusal-earned-report.json').read_text())
assert len(ref['attempts'])==2
assert all(a['status']=='action-refused' and a['refusal']=={'actionIndex':0,'reason':'no-points'} and a['target'] is None and a['acquisitionJournal']==[] for a in ref['attempts'])
assert ref['comparisons'][0]['rewardPathCoverage']=={'first':'unexercised','second':'unexercised'}
assert (r/'existing-report.json').read_bytes()==b'KEEP existing report sentinel\n'
for p in [r/'invalid-must-not-exist.json',w/'earned-output-must-not-exist.json',w/'earned-relative-must-not-exist.json',r/'repo-parent-alias'/'earned-output-must-not-exist.json']:assert not p.exists(),p
checks={}
for name,fragment in [('driver-reject-overwrite','exist'),('driver-reject-inrepo','outside'),('driver-reject-symlink-parent','outside'),('driver-reject-invalid','invalid'),('driver-reject-relative','absolute')]:
 m=json.loads((r/(name+'.meta.json')).read_text());assert m['exitCode']==1
 log=(r/(name+'.log')).read_text()+(r/(name+'-report.json')).read_text();assert fragment.lower() in log.lower(),(name,log)
 checks[name]={'exitCode':1,'seconds':m['seconds'],'outputAbsentOrSentinelPreserved':True}
d=json.loads((r/'default-repeat-differences.json').read_text());ids=[x for x in d if x['path'][-1]=='id']
assert len(d)==171 and len(ids)==169 and all(x['first'].startswith('it-') and x['second'].startswith('it-') for x in ids)
result={'refusal':{'attempts':2,'status':'action-refused','reason':'no-points','target':None,'rewardCoverage':'unexercised'},'boundaries':checks,'repeatDifferences':{'total':171,'itemIdOccurrences':169,'distinctItemPairs':len(set((x['first'],x['second']) for x in ids)),'otherFields':['repetition','wallSeconds'],'source':'src/engine/loot/rollItem.ts:17-18 module itemSeq; nine awards each repetition; allocator is deliberately not reset'},'sentinelPreserved':True}
(r/'cli-verified.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
