from pathlib import Path
import json,hashlib,tarfile,os
r=Path(__file__).parent
w=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=w/'docs/plans/evidence/fixtures/p02b03-earned-reports'
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for f in sorted(r.iterdir()):
 if f.is_symlink():continue
 assert f.is_file(),f
 records.append({'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)})
archive=out/'diagnostics.tar.gz'
with tarfile.open(archive,'w:gz',dereference=False) as tar:
 for row in records:tar.add(r/row['path'],arcname=row['path'],recursive=False)
commands=[json.loads(f.read_text()) for f in sorted(r.glob('*.meta.json'))]
packet={'task':'P02b03','inputHead':'353b69d','dependencies':['c0788c5','353b69d'],'scope':'versioned earned reports only; separately reviewed screening and P02/C0-C4/G0-G7/fullv1 remain open','sourceHashes':json.loads((r/'source-hashes.json').read_text()),'preservedAndFrozen':json.loads((r/'verified-freezes.json').read_text()),'testCounts':json.loads((r/'test-report-counts.json').read_text()),'cliVerification':json.loads((r/'cli-verified.json').read_text()),'commands':commands,'archive':{'path':'diagnostics.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive),'records':records,'excludedSymlinks':[{'path':'repo-parent-alias','target':os.readlink(r/'repo-parent-alias'),'reason':'test alias to worktree; never follow/archive target'}]},'buildChunks':json.loads((r/'build-chunk-hashes.json').read_text()),'cleanup':{'owner':'root','state':'pending final packet review/release; result recorded in closing ledger','paths':[str(r),str(w/'dist'),str(w/'node_modules/.vite')],'symlink':'unlink exact repo-parent-alias before deleting owned regular files; never follow','installedTools':'preserved','overallWorktree':'retained for active fullv1'},'limitations':['Missing-moduleREDs execute0assertions; dynamicdriverRED1failedtest beforeassertions','Initial codec26pass2setupfail; approved wrapping then28pass4genuinefail','First comparator67+32codec99passes did not prove projection isolation; corrected separationRED68pass8genuinefail','Synthetic sensitivity/mocks are not gameplay evidence','Default both completed execution with DenW2defeat; no clear/campaign/browser/coverage/screening acceptance','All169IDdifferences are item IDs in this sample; global allocator deliberately not reset','Related16.646s>5s and full54.821s>15s unchanged budgets; U/T/L concurrent','Existing buildwarnings retained; no game/data/config/dependency/lockfile changes','No push/PR/merge/deployment']}
(out/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'records':len(records),'commands':len(commands),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'packetSha256':sha(out/'packet.json')},indent=2))
