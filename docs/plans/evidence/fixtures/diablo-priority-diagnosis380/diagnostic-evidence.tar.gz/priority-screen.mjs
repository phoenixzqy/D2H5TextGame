import {createServer} from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/node_modules/vite/dist/node/index.js';
import {readFile,writeFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const repo='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2';
const root='/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/diablo-diagnosis380';
const input=repo+'/docs/plans/evidence/fixtures/earned-tyrael-and-river-through379/retained-final.json.gz';
const raw=await readFile(input),save=JSON.parse(gunzipSync(raw));
assert.equal(save.map.challengeOrdinals.normal,380);
const server=await createServer({root:repo,configFile:false,cacheDir:root+'/vite-cache',server:{middlewareMode:true,hmr:false,ws:false},resolve:{alias:{'@':repo+'/src'}}});
try {
 const load=p=>server.ssrLoadModule(p);
 const {restoreEarnedSave}=await load('/tests/sim/production/earned-state.ts');
 const {startEarnedRun,playEarnedWave}=await load('/tests/sim/production/earned-playback.ts');
 const {usePlayerStore}=await load('/src/stores/playerStore.ts');
 const {useCombatStore}=await load('/src/stores/combatStore.ts');
 const {hashSeed}=await load('/src/engine/rng.ts');
 const policies=[{id:'retained-static-orb',order:save.player.comboOrder},{id:'orb-static',order:[...save.player.comboOrder].reverse()},{id:'orb-only',order:['skills-sorceress-frozen-orb']}];
 const report={kind:'diagnostic priority-only comparison; no genuine launch, no promoted save or balance acceptance',inputRawSHA256:createHash('sha256').update(gunzipSync(raw)).digest('hex'),nextNormal:380,policies,seeds:Array.from({length:16},(_,i)=>hashSeed('diablo380-priority-only-v1:'+i)),rows:[],summary:[]};
 await writeFile(root+'/frozen-policy.json',JSON.stringify({...report,rows:undefined,summary:undefined},null,2)+'\n',{flag:'wx'});
 for(const policy of policies){
  for(const seed of report.seeds){
   restoreEarnedSave(save,0);usePlayerStore.getState().setComboOrder(policy.order);
   assert.deepEqual(usePlayerStore.getState().player,{...save.player,comboOrder:policy.order});
   const h=startEarnedRun({act:4,subAreaId:'areas/act4-chaos-sanctuary',mode:'manual',runSeed:seed});assert.equal(h.challengeOrdinal,380);
   const waves=[];
   for(let index=0;index<h.totalWaves;index++){
    const state=useCombatStore.getState(),hero=state.playerTeam.find(u=>u.kind==='hero'||u.id.startsWith('player-'));
    const events=state.recordedEvents,actions={},damage={},mana={};
    for(const e of events){
     if(e.kind==='action'&&e.actor===hero.id)actions[e.skillId??'basic']=(actions[e.skillId??'basic']??0)+1;
     if(e.kind==='damage'&&e.source===hero.id)damage[e.damageType]=(damage[e.damageType]??0)+e.amount;
     if(e.kind==='mana'&&e.target===hero.id)mana[e.reason]=(mana[e.reason]??0)+1;
    }
    const w=playEarnedWave(h,index);
    waves.push({wave:index+1,winner:w.played.outcome.winner,ms:w.terminalSimClockMs,openingHero:hero,heroActions:actions,heroDamage:damage,manaEvents:mana,players:w.played.outcome.finalPlayerTeam.map(u=>({id:u.id,life:u.life,mana:u.mana})),remaining:w.played.outcome.finalEnemyTeam.filter(u=>u.life>0).map(u=>({id:u.id,life:u.life,stats:u.stats})),...(seed===report.seeds[0]&&index===h.totalWaves-1?{recording:events}:{})});
    if(w.advanceResult!=='next-wave')break;
   }
   report.rows.push({policy:policy.id,seed,won:waves.length===h.totalWaves&&waves.every(w=>w.winner==='player'),waves});useCombatStore.getState().endCombat();
  }
  const rows=report.rows.filter(r=>r.policy===policy.id),boss=rows.map(r=>r.waves.at(-1));
  const summary={policy:policy.id,n:rows.length,wins:rows.filter(r=>r.won).length,diabloReached:rows.filter(r=>r.waves.length===7).length,remainingBossLife:boss.map(w=>w.remaining.reduce((n,u)=>n+u.life,0))};
  report.summary.push(summary);process.stdout.write(JSON.stringify(summary)+'\n');
 }
 assert.deepEqual(await readFile(input),raw);await writeFile(root+'/priority-screen.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
}finally{await server.close();}
