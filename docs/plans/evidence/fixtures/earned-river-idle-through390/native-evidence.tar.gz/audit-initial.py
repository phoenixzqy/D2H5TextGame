from pathlib import Path
import json,gzip,hashlib,re,math
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
root=Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-static-field-27sv3iop/idle389');native=root/'native'
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
original=load(repo/'docs/plans/evidence/fixtures/earned-river-through388/retained-final.json.gz');final=load(native/'final.json.gz');report=json.loads((native/'report.json').read_text())
assert report['status']=='observed' and report['outcome']=='two-earned-idle-clears-automatic-repeat-stop-no-late-awards'
assert report['errors']==[] and report['console']==[] and report['retries']==0 and not report.get('cleanupErrors')
assert report['inputSHA256']=='5f835bccb6715367ff92cd23b6245f1784a6a537460ac591da05a18c307dcae8'
def xp(s):return s['player']['experience']+sum(math.floor(100*l**2.5)for l in range(1,s['player']['level']))
def owned(s):
 rows=s['inventory']['backpack']+s['inventory']['stash']+list(s['inventory']['equipped'].values())+[i for gear in s['mercs']['mercEquipment'].values()for i in gear.values()];rows=[i for i in rows if i is not None];d={i['id']:i for i in rows};assert len(rows)==len(d);return d
ancestor=owned(original);new=owned(final);saves={};states={}
for p in sorted(native.glob('*.json.gz')):
 s=load(p);states[p.name[:-8]]=s
 if isinstance(s,dict)and all(k in s for k in ['player','inventory','map','mercs','meta','formation']):
  saves[p.name[:-8]]=s;items=owned(s)
  for k,i in ancestor.items():assert items.get(k)==i,(p.name,k)
  for k in ['coreStats','skillLevels','comboOrder','respecsRemaining']:assert s['player'][k]==original['player'][k]
  for k in ['equipped','questItems','questServices']:assert s['inventory'][k]==original['inventory'][k]
  for k in ['mercEquipment','fieldedMercId']:assert s['mercs'][k]==original['mercs'][k]
  for k in ['formation','endgame']:assert s[k]==original[k]
  for k in ['questProgress','questReceipts','unlockedActs','selectedDifficulty']:assert s['map'][k]==original['map'][k]
  assert s['map']['challengeOrdinals']['nightmare']==0
  assert s['map']['challengeOrdinals']['normal']in [389,390,391]
  for k,n in original['inventory']['materials'].items():assert s['inventory']['materials'].get(k,0)>=n
  for k,n in original['inventory']['currencies'].items():assert s['inventory']['currencies'].get(k,0)>=n
  assert [m['id']for m in s['mercs']['ownedMercs']]==[m['id']for m in original['mercs']['ownedMercs']]
  for merc in original['mercs']['ownedMercs']:
   if merc['id']!=original['mercs']['fieldedMercId']:assert next(m for m in s['mercs']['ownedMercs']if m['id']==merc['id'])==merc
normal={re.sub(r'^\d+-','',k):s for k,s in saves.items()};pairs=[]
for k,s in normal.items():
 if k.endswith('-saved'):
  other=k[:-6]+'-continued';assert s==normal[other];pairs.append([k,other])
assert len(pairs)==2
assert [x['ordinal']for x in report['areas']]==[389,390];assert [x['ordinal']for x in report['launches']]==[389,390]
assert report['automaticRepeats']==[{'fromOrdinal':389,'toOrdinal':390,'trigger':'native timer','clickedNextRun':False}]
assert (native/'launch-389.json').is_file()and(native/'launch-390.json').is_file();assert not(native/'launch-391.json').exists()
wins=[]
for area in report['areas']:
 ordinal=area['ordinal'];assert area['outcome']=='victory' and area['alias']=='river-of-flame' and len(area['waves'])==6
 admission=normal[str(ordinal)+'-admitted'];assert admission['map']['challengeOrdinals']['normal']==ordinal+1;assert admission['meta']['idleState']['idleTarget']=='a4-river-of-flame'
 for w in area['waves']:
  wave=w['wave'];assert w['outcome']=='victory';a=states[f'{ordinal}-w{wave}-initial'];b=states[f'{ordinal}-w{wave}-terminal'];assert a['enemyIds']and all(i in b['enemyIds']for i in a['enemyIds']);assert b['liveEnemies']==0 and b['skipDisabled']is True and b['log'][-1]=='Victory! All enemies are defeated.';assert next(c for c in b['cards']if c['id']=='unit-card-'+original['player']['id'])['dead']is None;wins.append(w)
assert len(wins)==12
assert final['map']['challengeOrdinals']['normal']==391==report['finalOrdinal']
assert xp(final)-xp(original)==report['totalXP']==sum(w['delta']['xp']for w in wins)
assert len(new)-len(ancestor)==sum(len(w['delta']['newItems'])for w in wins)
assert normal['389-w6-settled']['meta']['idleState']['idleTarget']=='a4-river-of-flame'
stopped=normal['390-w6-settled'];later=normal['stopped-after120s']
for k in ['player','inventory','mercs','map','formation','endgame']:assert stopped[k]==later[k]
for s in [stopped,later,final]:assert 'idleTarget'not in s['meta']['idleState']
assert report['stopChecks']==[{'requestedWaitMs':120000,'nextNormal':391,'noRewardsOrOrdinalChange':True,'idleTargetAbsent':True}]
assert final==normal['stopped-continued']
freeze=json.loads((root/'source-freeze.json').read_text());drift=[k for k,h in freeze.items()if hashlib.sha256((repo/k).read_bytes()).hexdigest()!=h];assert not drift
build=json.loads((root/'build-hashes.json').read_text());buildDrift=[k for k,h in build.items()if hashlib.sha256((root/'dist'/k).read_bytes()).hexdigest()!=h];assert not buildDrift
scan=json.loads((root/'bridge-scan.json').read_text());assert len(scan)==7 and all(not x for row in scan.values()for x in row.values())
audit={'kind':'genuine production UI idle farming pilot; root self-audit; independent acceptance pending','runtime':report['runtime'],'inputRawSHA256':report['inputSHA256'],'finalRawSHA256':hashlib.sha256(gzip.decompress((native/'final.json.gz').read_bytes())).hexdigest(),'firstOrdinal':389,'lastOrdinal':390,'nextNormal':391,'fullClears':2,'nativeWaveVictories':len(wins),'nativeNonwins':0,'automaticRepeats':report['automaticRepeats'],'stopChecks':report['stopChecks'],'nativeSaveExports':len(saves),'saveCloseContinuePairs':len(pairs),'ancestralFullItemsPreserved':len(ancestor),'ownedItemsFinal':len(new),'newItems':len(new)-len(ancestor),'earnedHeroXP':xp(final)-xp(original),'heroLevel':final['player']['level'],'heroXP':final['player']['experience'],'statPoints':final['player']['statPoints'],'skillPoints':final['player']['skillPoints'],'sourceFiles':len(freeze),'sourceDrift':drift,'buildFiles':len(build),'buildDrift':buildDrift,'servedJS':len(json.loads((root/'served-hashes.json').read_text())),'errors':report['errors'],'warnings':report['console'],'scriptWallMs':report['executionWallMs'],'requestedClockAdvanceMs':report['requestedClockAdvanceMs'],'limits':'single genuine English mobile360x640 pilot; fixed historical Date; clock transport only, no pacing/full-idle/weak-build/background/offline/locale matrix acceptance'}
(root/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
