Security check: pass
Scope: authorized local Cleansing gameplay/data/UI changes and local test/browser evidence.
Summary: no credentials, network publication, permissions, CI bypass, dependencies or destructive requests.
Findings: none. Preserve genuine campaign save and original checkout; root sole writer.

Plan review: ready
Root cause: Cleansing has no selected projection or duration consumer; its recovery coefficient lacks an HP source.
Plan: author Cleansing-only metadata (duration multiplier 0.5; independent healing base20/5000ms), preserve lifeRegenPct1.5% and magical dodge0.5pp per rank. These new numbers are provisional local defaults; no synergy or implicit Vitality baseline.
Extend the existing shared aura projection, not a fourth scheduler. Shorten finite poison/plague and exact named Necromancer curse durations at application or first eligible wave admission. Record transient status-local one-time reduction across wave carries. Source death prevents future reductions/heals/dodge, never lengthens already shortened statuses. Preserve absent/indefinite expiry, status source/potency/stacks, refresh max-expiry, exact alias identity, DoT/death ordering and no RNG/action/mana cost. Fresh applications after expiry qualify again; spread uses recipient eligibility.
Keep Prayer-only JSON auraHealing ownership; Cleansing owns separate cleansing metadata whose independent recovery reuses only the generic healing timeline.
RED first: actual poison HP loss, curse-hit mitigation, source/dead/merc/summon guards, carry/refresh/reapplication/indefinite/CC/expiry/default and invalid tuning. Then schema before JSON, source, native/save/replay and bilingual details. Focused/engine/types/lint/build/bridge/browser; full alone with frozen hashes. Retain failures/successes and remove exact task artifacts before local commits. No earned balance or independent acceptance claim.
