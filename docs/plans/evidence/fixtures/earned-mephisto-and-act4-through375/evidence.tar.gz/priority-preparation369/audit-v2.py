import copy,gzip,hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
original=load(REPO/'docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz')
assert sha(gzip.decompress((REPO/'docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz').read_bytes()))=='9deb0079f5288e7242c4c0e93211aca08d33b9321babc6eac4cb4efc80521b5e'
freeze=json.loads((ROOT/'freeze.json').read_text())
assert all(sha((REPO/k).read_bytes())==v for k,v in freeze['source'].items())
assert all(sha((Path(freeze['distRoot'])/k).read_bytes())==v for k,v in freeze['dist'].items())
served={}
for k,v in freeze['dist'].items():
 if k.startswith('assets/') and k.endswith('.js'):
  b=urllib.request.urlopen('http://127.0.0.1:4437/'+k).read();assert sha(b)==v
  assert not any(t in b for t in [b'__GAME__',b'seedItem',b'attachTestBridge']);served[k]=v
assert len(served)==4
hybrid=json.loads((ROOT.parent/'hybrid-preparation369/screen.json').read_text())
assert len(hybrid['rows'])==96 and hybrid['selected'] is None
screen=json.loads((ROOT/'screen.json').read_text())
assert len(screen['rows'])==160 and len(set(screen['seeds']))==32
assert screen['selected']=={'id':'owned-gear-dex120-priority','gear':True,'moved':120}
for area in ['durance-of-hate','travincal']:
 rows=[r for r in screen['rows'] if r['build']==screen['selected']['id'] and r['area']==area]
 assert len(rows)==32 and sum(r['won'] for r in rows)>=26 and sum(r['won'] for r in rows if r['group']=='second-half')>=12
 for r in rows:
  assert r['won']==(len(r['waves'])==6 and all(w['winner']=='player' for w in r['waves']))
  assert all(w['winner']=='player' for w in r['waves'][:-1])

def owned(s):
 rows=[*s['inventory']['backpack'],*s['inventory']['stash'],*s['inventory']['equipped'].values(),*(i for g in s['mercs']['mercEquipment'].values() for i in g.values())]
 rows=[i for i in rows if i];d={i['id']:i for i in rows};assert len(d)==len(rows);return d

def xp(s):return s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))
def mxp(s):
 mid=s['mercs']['fieldedMercId'];m=next(m for m in s['mercs']['ownedMercs'] if m['id']==mid)
 return s['mercs']['mercProgress'][mid]['experience']+sum(int(60*l*1.3**(l-1)) for l in range(1,m['level']))

initial=owned(original);changed={c[k] for c in screen['changes'] for k in ['from','to']}
exports=[];pairs=[]
for dirname in ['native-preparation','native-priority-resume','attempt369','guardian-claim','act4-370']:
 root=ROOT/dirname
 for path in root.glob('*.json.gz'):
  s=load(path)
  if 'player' not in s:continue
  now=owned(s);exports.append(str(path.relative_to(ROOT)))
  for ident,item in initial.items():
   assert ident in now,path
   a,b=copy.deepcopy(item),copy.deepcopy(now[ident])
   if ident in changed:a.pop('equipped',None);b.pop('equipped',None)
   assert a==b,(path,ident)
  assert s['player']['skillLevels']==original['player']['skillLevels']
  assert s['mercs']['mercEquipment']==original['mercs']['mercEquipment']
  assert s['mercs']['fieldedMercId']==original['mercs']['fieldedMercId']
  assert s['map']['challengeOrdinals']['nightmare']==0
  assert s['endgame']==original['endgame']
 for saved in root.glob('*saved.json.gz'):
  suffix=saved.name.replace('saved.json.gz','continued.json.gz')
  if dirname in ['attempt369','act4-370']:
   suffix=suffix.partition('-')[2];matches=list(root.glob('*-'+suffix))
  else:matches=[root/suffix]
  assert len(matches)==1 and matches[0].exists(),(saved,matches)
  assert load(saved)==load(matches[0]);pairs.append([str(saved.relative_to(ROOT)),str(matches[0].relative_to(ROOT))])

failed=load(ROOT/'native-preparation/stopped-native.json.gz')
prepared=load(ROOT/'native-priority-resume/final.json.gz')
expected=copy.deepcopy(failed);expected['player']['comboOrder']=['skills-sorceress-static-field','skills-sorceress-frozen-orb'];assert prepared==expected
assert prepared['player']['coreStats']=={'strength':10,'dexterity':145,'vitality':12,'energy':63}
assert prepared['player']['respecsRemaining']=={'stat':2,'skill':0}
assert prepared['player']['statPoints']==prepared['player']['skillPoints']==0
assert prepared['inventory']['currencies']==original['inventory']['currencies']
assert prepared['player']['derivedStats']['life']==original['player']['derivedStats']['life']==120
assert prepared['player']['derivedStats']['mana']==original['player']['derivedStats']['mana']==102
assert prepared['map']==original['map'] and prepared['meta']==original['meta'] and prepared['mercs']==original['mercs']
expectedGear=copy.deepcopy(original['inventory']['equipped'])
for c in screen['changes']:
 expectedGear[c['slot']]={**initial[c['to']],'equipped':True}
 assert owned(prepared)[c['from']]=={**initial[c['from']],'equipped':False}
assert prepared['inventory']['equipped']==expectedGear
assert prepared['player']['equipment']==list(expectedGear.values())

combats=[]
for dirname,input_path,first_ordinal,aliases in [
 ('attempt369',ROOT/'native-priority-resume/final.json.gz',369,['durance-of-hate']),
 ('act4-370',ROOT/'guardian-claim/final.json.gz',370,['outer-steppes','plains-of-despair'])]:
 root=ROOT/dirname;report=json.loads((root/'report.json').read_text());assert report['status']=='observed',report.get('failure')
 assert report['errors']==report['console']==[] and report['retries']==0 and not report.get('cleanupErrors')
 assert 1<=len(report['launches'])<=len(aliases)
 assert report['launches']==[{'ordinal':first_ordinal+i,'alias':aliases[i]} for i in range(len(report['launches']))]
 inp=load(input_path);final=load(root/'final.json.gz');wins=[]
 for area in report['areas']:
  prior=load(root/f"prelaunch-{area['ordinal']}.json.gz")
  for w in area['waves']:
   stem=f"{area['ordinal']}-w{w['wave']}";opening=load(root/(stem+'-initial.json.gz'));end=load(root/(stem+'-terminal.json.gz'))
   assert set(opening['enemyIds']).issubset(end['enemyIds'])
   if w['outcome']=='victory':
    assert end['liveEnemies']==0 and end['log'][-1]=='Victory! All enemies are defeated.'
    match=list(root.glob('*-'+stem+'-settled.json.gz'));wins.append(w)
   else:
    assert w['delta']['xp']==0 and w['delta']['newItems']==[]
    assert end['liveEnemies']>0
    match=list(root.glob('*-'+str(area['ordinal'])+'-nonwin.json.gz'))
   assert len(match)==1;after=load(match[0]);before_items,after_items=owned(prior),owned(after)
   assert all(after_items.get(k)==v for k,v in before_items.items())
   assert xp(after)-xp(prior)==w['delta']['xp']
   assert set(after_items)-set(before_items)==set(w['delta']['newItems'])
   if w['outcome']!='victory':assert after['inventory']==prior['inventory'] and after['mercs']==prior['mercs']
   prior=after
 assert xp(final)-xp(inp)==report['totalXP']==sum(w['delta']['xp'] for w in wins)
 assert len(owned(final))-len(owned(inp))==sum(len(w['delta']['newItems']) for w in wins)
 assert final['map']['challengeOrdinals']['normal']==first_ordinal+len(report['launches'])
 combats.append({'directory':dirname,'launches':report['launches'],'outcomes':[a['outcome'] for a in report['areas']],'winningWaves':len(wins),'heroXP':report['totalXP'],'gear':len(owned(final))-len(owned(inp)),'executionWallMs':report['executionWallMs'],'requestedClockAdvanceMs':report['requestedClockAdvanceMs']})

won=load(ROOT/'attempt369/final.json.gz');claimed=load(ROOT/'guardian-claim/final.json.gz');q='quests/act3-guardian'
assert won['map']['questProgress'][q]['objectives']['obj-kill-mephisto'] is True
assert won['map']['questProgress'][q]['status']=='completed' and won['map']['questProgress'][q].get('rewardClaimed') is not True
assert claimed['map']['questProgress'][q]['rewardClaimed'] is True
assert claimed['inventory']['questItems'][q+'#reward:questItem']=={'itemId':'items/soulstone_mephisto','state':'owned'}
assert xp(claimed)-xp(won)==18000 and mxp(claimed)-mxp(won)==13500
oracle=json.loads((ROOT/'guardian-cache-oracle.json').read_text())['cache']
added=claimed['inventory']['backpack'][len(won['inventory']['backpack']):]
assert [{**i,'id':''} for i in added]==[{**i,'id':''} for i in oracle['items']]
assert claimed['inventory']['backpack'][:len(won['inventory']['backpack'])]==won['inventory']['backpack']
currencies={**won['inventory']['currencies']}
for k,n in [('rune-shard',oracle['runeShards']),('wishstone',oracle['wishstones'])]:
 if n:currencies[k]=currencies.get(k,0)+n
assert claimed['inventory']['currencies']==currencies
materials={**won['inventory']['materials']}
for k,n in oracle['materials'].items():materials[k]=materials.get(k,0)+n
assert claimed['inventory']['materials']==materials
for k in ['stash','equipped']:assert claimed['inventory'][k]==won['inventory'][k]
assert claimed['map']['challengeOrdinals']==won['map']['challengeOrdinals']
claim_report=json.loads((ROOT/'guardian-claim/report.json').read_text());assert claim_report['status']=='observed' and claim_report['errors']==claim_report['console']==[]
final=load(ROOT/'act4-370/final.json.gz')
summary={'sourceFiles':len(freeze['source']),'buildFiles':len(freeze['dist']),'servedBridgeFreeChunks':len(served),'exportsAudited':len(exports),'allAncestralPayloads':len(initial),'legallyChangedEquippedFlags':sorted(changed),'exactDurablePairs':len(pairs),'pairs':pairs,'screenProjections':len(screen['rows'])+len(hybrid['rows']),'selected':screen['selected'],'combat':combats,'guardianHeroXP':18000,'guardianMercXP':13500,'guardianCacheItems':len(added),'guardianCacheRuneShards':oracle['runeShards'],'finalLevel':final['player']['level'],'finalExperience':final['player']['experience'],'nextNormal':final['map']['challengeOrdinals']['normal'],'finalOwnedGear':len(owned(final)),'heroXPEarned':xp(final)-xp(original),'finalRawSHA256':sha(gzip.decompress((ROOT/'act4-370/final.json.gz').read_bytes())),'scope':'genuine historical campaign continuation, Mephisto victory/Guardian claimed and actual ActIV attempts; full C2-C4 and G0-G7 remain incomplete'}
(ROOT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['pairs','legallyChangedEquippedFlags']},indent=2))
