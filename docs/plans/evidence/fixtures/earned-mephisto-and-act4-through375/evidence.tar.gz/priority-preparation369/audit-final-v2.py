import gzip,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=subprocess.run([sys.executable,str(ROOT/'audit-v2.py')],capture_output=True,text=True)
assert p.returncode==0,p.stderr
base=json.loads((ROOT/'audit.json').read_text())
load=lambda p:json.loads(gzip.decompress(p.read_bytes()))
sha=lambda b:hashlib.sha256(b).hexdigest()
def owned(s):
 rows=[*s['inventory']['backpack'],*s['inventory']['stash'],*s['inventory']['equipped'].values(),*(i for g in s['mercs']['mercEquipment'].values() for i in g.values())];rows=[i for i in rows if i];d={i['id']:i for i in rows};assert len(d)==len(rows);return d
def xp(s):return s['player']['experience']+sum(int(100*l**2.5) for l in range(1,s['player']['level']))
def mxp(s):
 mid=s['mercs']['fieldedMercId'];m=next(m for m in s['mercs']['ownedMercs'] if m['id']==mid)
 return s['mercs']['mercProgress'][mid]['experience']+sum(int(60*l*1.3**(l-1)) for l in range(1,m['level']))
ancestral=load(ROOT/'guardian-claim/final.json.gz');items=owned(ancestral)
dirs=['act4-quest-start','izual372','izual-claim-warmth','city-river373','forge-seals','forge-seals-resume','diablo375']
exports=[];pairs=[]
for dirname in dirs:
 root=ROOT/dirname;report=json.loads((root/'report.json').read_text())
 if dirname=='forge-seals':assert report['status']=='tooling-failure' and 'currentSubAreaId' in report['failure']
 else:assert report['status']=='observed',report.get('failure')
 assert report['errors']==report['console']==[] and not report.get('cleanupErrors')
 for path in root.glob('*.json.gz'):
  s=load(path)
  if 'player' not in s:continue
  now=owned(s);assert all(now.get(k)==v for k,v in items.items()),path
  levels={**ancestral['player']['skillLevels']}
  after=dirname in ['city-river373','forge-seals','forge-seals-resume','diablo375'] or (dirname=='izual-claim-warmth' and (path.name.startswith('warmth3') or path.name.startswith('claimed-no-repeat') or path.name=='final.json.gz'))
  if after:levels['sorceress.warmth']=3
  assert s['player']['skillLevels']==levels,path
  assert s['player']['coreStats']==ancestral['player']['coreStats']
  assert s['player']['comboOrder']==ancestral['player']['comboOrder']
  assert s['player']['respecsRemaining']==ancestral['player']['respecsRemaining']=={'stat':2,'skill':0}
  assert s['inventory']['equipped']==ancestral['inventory']['equipped']
  assert s['mercs']['mercEquipment']==ancestral['mercs']['mercEquipment']
  assert s['mercs']['fieldedMercId']==ancestral['mercs']['fieldedMercId']
  assert s['inventory']['currencies']['wishstone']>=ancestral['inventory']['currencies']['wishstone'] # Ordinary live kill income may add Wishstones; these scripts spend none.
  assert s['endgame']==ancestral['endgame']
  exports.append(str(path.relative_to(ROOT)))
 if dirname in ['act4-quest-start']:continue # Already audited Save/Continue in native script; count below.
 for saved in root.glob('*saved.json.gz'):
  suffix=saved.name.replace('saved.json.gz','continued.json.gz')
  if dirname in ['izual372','city-river373','diablo375']:suffix=suffix.partition('-')[2];matches=list(root.glob('*-'+suffix))
  else:matches=[root/suffix]
  assert len(matches)==1 and matches[0].exists(),(saved,matches)
  assert load(saved)==load(matches[0]);pairs.append([str(saved.relative_to(ROOT)),str(matches[0].relative_to(ROOT))])
# The quest-start script uses plain saved/continued, as does its source template.
assert load(ROOT/'act4-quest-start/saved.json.gz')==load(ROOT/'act4-quest-start/continued.json.gz')
pairs.append(['act4-quest-start/saved.json.gz','act4-quest-start/continued.json.gz'])
combats=[]
for dirname,input_path,ordinal,aliases in [
 ('izual372',ROOT/'act4-quest-start/final.json.gz',372,['plains-of-despair']),
 ('city-river373',ROOT/'izual-claim-warmth/final.json.gz',373,['city-of-the-damned','river-of-flame']),
 ('diablo375',ROOT/'forge-seals-resume/final.json.gz',375,['chaos-sanctuary'])]:
 root=ROOT/dirname;r=json.loads((root/'report.json').read_text());assert r['status']=='observed' and r['retries']==0
 assert r['launches']==[{'ordinal':ordinal+i,'alias':alias} for i,alias in enumerate(aliases)]
 wins=[];nonwins=0
 for area in r['areas']:
  prior=load(root/f"prelaunch-{area['ordinal']}.json.gz")
  for w in area['waves']:
   stem=f"{area['ordinal']}-w{w['wave']}";before=load(root/(stem+'-initial.json.gz'));end=load(root/(stem+'-terminal.json.gz'));assert set(before['enemyIds']).issubset(end['enemyIds'])
   if w['outcome']=='victory':
    assert end['liveEnemies']==0 and end['log'][-1]=='Victory! All enemies are defeated.'
    matches=list(root.glob('*-'+stem+'-settled.json.gz'));wins.append(w)
   else:
    assert end['liveEnemies']>0 and end['log'][-1]=='Defeat... your team has fallen.'
    assert next(c for c in end['cards'] if c['id']=='unit-card-'+ancestral['player']['id'])['dead']=='true'
    assert w['delta']['xp']==0 and w['delta']['newItems']==[];matches=list(root.glob('*-'+str(area['ordinal'])+'-nonwin.json.gz'));nonwins+=1
   assert len(matches)==1;after=load(matches[0]);old,now=owned(prior),owned(after)
   assert all(now.get(k)==v for k,v in old.items())
   assert xp(after)-xp(prior)==w['delta']['xp'] and set(now)-set(old)==set(w['delta']['newItems'])
   if w['outcome']!='victory':assert after['inventory']==prior['inventory'] and after['mercs']==prior['mercs']
   prior=after
 final=load(root/'final.json.gz');initial=load(input_path)
 assert xp(final)-xp(initial)==r['totalXP']==sum(w['delta']['xp'] for w in wins)
 assert len(owned(final))-len(owned(initial))==sum(len(w['delta']['newItems']) for w in wins)
 assert final['map']['challengeOrdinals']['normal']==ordinal+len(aliases)
 combats.append({'directory':dirname,'launches':r['launches'],'outcomes':[a['outcome'] for a in r['areas']],'winningWaves':len(wins),'nonwins':nonwins,'heroXP':r['totalXP'],'gear':len(owned(final))-len(owned(initial)),'executionWallMs':r['executionWallMs'],'requestedClockAdvanceMs':r['requestedClockAdvanceMs']})
# The earlier untracked Izual371 win must never become retrospective quest credit.
early=load(ROOT/'act4-370/final.json.gz');tracked=load(ROOT/'act4-quest-start/final.json.gz');f='quests/act4-fallen-angel'
assert f not in early['map']['questProgress'] and tracked['map']['questProgress'][f]['objectives']['obj-kill-izual'] is False
won=load(ROOT/'izual372/final.json.gz');claimed=load(ROOT/'izual-claim-warmth/izual-claimed.json.gz');learned=load(ROOT/'izual-claim-warmth/final.json.gz')
assert won['map']['questReceipts'][f+'#action:izual-victory'] is True and claimed['map']['questProgress'][f]['rewardClaimed'] is True
assert xp(claimed)-xp(won)==9000 and mxp(claimed)-mxp(won)==6750
assert claimed['player']['skillPoints']==won['player']['skillPoints']+2
assert learned['player']['skillLevels']['sorceress.warmth']==3 and learned['player']['skillPoints']==won['player']['skillPoints']
assert learned['inventory']==claimed['inventory'] and learned['mercs']==claimed['mercs']
forge='quests/act4-hellforge';hammer=forge+'#objective:obj-kill-hephasto';stone='quests/act3-guardian#reward:questItem'
river=load(ROOT/'city-river373/final.json.gz');recovered=load(ROOT/'forge-seals/stopped-native.json.gz');consumed=load(ROOT/'forge-seals-resume/forge-consumed.json.gz');paid=load(ROOT/'forge-seals-resume/forge-claimed.json.gz');seals=load(ROOT/'forge-seals-resume/final.json.gz')
assert river['map']['questReceipts'][forge+'#action:hephasto-victory'] is True
assert recovered['inventory']['questItems'][hammer]=={'itemId':'quest/hellforge_hammer', 'state':'owned'}
assert recovered['map']['currentSubAreaId']=='areas/act4-river-of-flame'
assert xp(recovered)==xp(river) and recovered['player']==river['player']
for key in [hammer,stone]:assert consumed['inventory']['questItems'][key]['state']=='consumed'
assert consumed['map']['questReceipts'][forge+'#action:shatter-soulstone'] is True
assert consumed['player']==recovered['player'] and consumed['mercs']==recovered['mercs']
assert xp(paid)-xp(consumed)==7000 and mxp(paid)-mxp(consumed)==5250
cache=json.loads((ROOT/'hellforge-cache-oracle.json').read_text())['cache'];assert cache['materials']=={'runes/ko':1}
expected_c={**consumed['inventory']['currencies']};expected_c['gem-shard']=expected_c.get('gem-shard',0)+3
assert paid['inventory']['currencies']==expected_c
expected_m={**consumed['inventory']['materials']};expected_m['runes/ko']=expected_m.get('runes/ko',0)+1
assert paid['inventory']['materials']==expected_m and paid['inventory']['backpack']==consumed['inventory']['backpack']
t='quests/act4-terrors-end';previous=paid
for i in range(1,4):
 s=load(ROOT/f'forge-seals-resume/seal-{i}.json.gz');assert xp(s)==xp(previous) and s['inventory']==previous['inventory'] and s['mercs']==previous['mercs']
 assert all(s['map']['questProgress'][t]['objectives']['obj-seal-'+str(j)]==(j<=i) for j in range(1,4))
 assert s['map']['questProgress'][t]['objectives']['obj-kill-diablo'] is False;previous=s
final=load(ROOT/'diablo375/final.json.gz')
assert final['map']['questProgress'][t]['objectives']['obj-kill-diablo'] is False
assert final['map']['questProgress'][t].get('rewardClaimed') is not True
assert t+'#action:diablo-victory' not in final['map']['questReceipts']
assert final['player']['level']==31 and final['player']['statPoints']==5 and final['player']['skillPoints']==1
base['combat']+=combats;base['exactDurablePairs']+=len(pairs);base['pairs']+=pairs
base['exportsAudited']+=len(exports);base['finalLevel']=31;base['finalExperience']=final['player']['experience'];base['nextNormal']=376;base['finalOwnedGear']=len(owned(final));base['heroXPEarned']=sum(r['heroXP'] for r in base['combat'])+18000+9000+7000
origin=load(Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/docs/plans/evidence/fixtures/earned-act3-through368/retained-final.json.gz'))
assert xp(final)-xp(origin)==base['heroXPEarned']
assert len(owned(final))-len(owned(origin))==sum(r['gear'] for r in base['combat'])+4
base.update(finalRawSHA256=sha(gzip.decompress((ROOT/'diablo375/final.json.gz').read_bytes())),allLaunches=[v for r in base['combat'] for v in r['launches']],winningWaves=sum(r['winningWaves'] for r in base['combat']),failedWaves=1,finalStatPoints=5,finalSkillPoints=1,finalWarmth=3,sourceDrift=[],finalScope='Genuine historical Mephisto369 victory and claimedGuardian; allfiveActIVareasentered, Izual/Hellforgeclaimed, actualDiablo375defeat retained. C2-C4/fullG0-G7 incomplete.')
assert [x['ordinal'] for x in base['allLaunches']]==list(range(369,376))
(ROOT/'audit-final.json').write_text(json.dumps(base,indent=2)+'\n');print(json.dumps({k:v for k,v in base.items() if k not in ['pairs','legallyChangedEquippedFlags','combat']},indent=2))
