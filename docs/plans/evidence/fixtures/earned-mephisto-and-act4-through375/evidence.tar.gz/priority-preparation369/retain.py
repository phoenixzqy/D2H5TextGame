from pathlib import Path
import gzip,hashlib,json,tarfile
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
OUT=REPO/'docs/plans/evidence/fixtures/earned-mephisto-and-act4-through375'
OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
summary=json.loads((ROOT/'audit-final.json').read_text())
raw={}
for root in [ROOT.parent/'hybrid-preparation369',ROOT]:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();b=p.read_bytes();raw[str(p.relative_to(ROOT.parent))]={'bytes':len(b),'sha256':sha(b)}
(OUT/'raw-manifest.json').write_text(json.dumps({'retainedRoot':str(ROOT.parent),'owner':'root','retainedThrough':'campaign/full-v1 acceptance consumers; root removes raw evidence after consumers finish','files':raw},indent=2)+'\n')
selected={
 'native-preparation/stopped-native.json.gz','native-priority-resume/saved.json.gz','native-priority-resume/continued.json.gz','attempt369/final.json.gz',
 'guardian-claim/guardian-claimed-saved.json.gz','guardian-claim/guardian-claimed-continued.json.gz','act4-370/final.json.gz','act4-quest-start/final.json.gz',
 'izual372/final.json.gz','izual-claim-warmth/final.json.gz','city-river373/final.json.gz','forge-seals/stopped-native.json.gz',
 'forge-seals-resume/forge-consumed-unclaimed-saved.json.gz','forge-seals-resume/forge-consumed-unclaimed-continued.json.gz','forge-seals-resume/final.json.gz',
 'diablo375/prelaunch-375.json.gz','diablo375/375-w7-initial.json.gz','diablo375/375-w7-terminal.json.gz'
}
for p in (ROOT/'diablo375').glob('*-375-w6-settled.json.gz'):selected.add(str(p.relative_to(ROOT)))
for p in (ROOT/'diablo375').glob('*-375-nonwin-*.json.gz'):selected.add(str(p.relative_to(ROOT)))
entries={}
for key,meta in raw.items():
 rel=Path(key)
 if not key.endswith('.json.gz') or (rel.parts[0]=='priority-preparation369' and str(Path(*rel.parts[1:])) in selected):entries[key]=meta
archive=OUT/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
 for key in entries:t.add(ROOT.parent/key,arcname=key,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert set(t.getnames())==set(entries)
 for m in t:
  b=t.extractfile(m).read();assert len(b)==entries[m.name]['bytes'] and sha(b)==entries[m.name]['sha256']
final=(ROOT/'diablo375/final.json.gz').read_bytes();assert sha(gzip.decompress(final))==summary['finalRawSHA256']
(OUT/'retained-final.json.gz').write_bytes(final)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
manifest={'sourceCommit':'59f2590','runtimeHead':'39bce13','archive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive.read_bytes()),'archiveEntries':entries,'rawFiles':len(raw),'rawManifest':'raw-manifest.json','coverage':'All scripts/reports/failures/logs/screenshots plus representative stage exports; complete native stage exports remain at the exact retained raw paths in raw-manifest.json. The final genuine save is also a standalone deliverable.','finalRawSHA256':summary['finalRawSHA256'],'summarySHA256':sha((OUT/'summary.json').read_bytes()),'retainedFinalSHA256':sha(final)}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(raw),'archiveEntries':len(entries),'archiveBytes':manifest['archiveBytes'],'archiveSHA256':manifest['archiveSHA256'],'finalRawSHA256':summary['finalRawSHA256']},indent=2))
