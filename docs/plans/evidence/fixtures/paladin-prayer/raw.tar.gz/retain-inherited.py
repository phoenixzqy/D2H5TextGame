"""Retain this task's evidence, verify bytes, then remove its exact scratch tree."""
from pathlib import Path
import hashlib
import json
import socket
import tarfile

root = Path(__file__).resolve().parent
expected = Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-pulse-auras-q04u4dmx')
assert root == expected and not root.is_symlink()
draft = (root / 'evidence-draft.md').read_text()
owner = json.loads((root / 'ownership.json').read_text())
assert owner['owner'] == 'root' and owner['task'] == 'Paladin Holy Fire and Holy Shock pulses'
worktree = Path(owner['worktree'])
target = worktree / 'docs/plans/evidence/fixtures/paladin-pulse-auras'
assert not target.exists(), 'Never overwrite retained evidence'
for label in ['pulse-focused-current', 'pulse-full-current', 'pulse-engine-final', 'pulse-types-current', 'pulse-lint-current', 'pulse-build-final', 'pulse-bridge-final', 'pulse-browser-final', 'pulse-browser-audit-final']:
    assert json.loads((root / (label + '.result.json')).read_text())['exit'] == 0, label
assert json.loads((root / 'full-before.json').read_text()) == json.loads((root / 'full-after.json').read_text())
assert json.loads((root / 'final-browser/browser-domain-audit.json').read_text())['pass'] is True
processes = list(root.glob('*.process.json'))
for process in processes:
    assert process.with_name(process.name.replace('.process.json', '.result.json')).is_file(), process
connection = socket.socket()
assert connection.connect_ex(('127.0.0.1', 4464)) != 0, 'Preview must stop before retention'
connection.close()

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

owned = sorted(root.rglob('*'))
assert not any(path.is_symlink() for path in owned), 'Resolve unexpected links before cleanup'
files = [path for path in owned if path.is_file() and
         path.relative_to(root).parts[0] not in ['build', 'build-final'] and
         'downloads' not in path.relative_to(root).parts]
target.mkdir(parents=True)
records = []
retained = {}
with tarfile.open(target / 'raw.tar.gz', 'w:gz', compresslevel=6) as archive:
    for path in files:
        relative, size, sha = str(path.relative_to(root)), path.stat().st_size, digest(path)
        record = {'path': relative, 'bytes': size, 'sha256': sha}
        if sha in retained:
            record.update(retained[sha])
        elif path.suffix == '.zip' and size > 20 * 1024 * 1024:
            traces = target / 'traces'
            traces.mkdir(exist_ok=True)
            parts = []
            with path.open('rb') as stream:
                index = 0
                while chunk := stream.read(20 * 1024 * 1024):
                    index += 1
                    part = traces / f'{sha[:12]}.zip.part{index:02d}'
                    part.write_bytes(chunk)
                    parts.append(str(part.relative_to(target)))
            record.update({'artifacts': parts, 'reassemble': 'concatenate parts in listed order'})
            retained[sha] = {key: record[key] for key in ['artifacts', 'reassemble']}
        else:
            archive.add(path, arcname=relative, recursive=False)
            record.update({'artifact': 'raw.tar.gz', 'member': relative})
            retained[sha] = {key: record[key] for key in ['artifact', 'member']}
        records.append(record)

with tarfile.open(target / 'raw.tar.gz', 'r:gz') as archive:
    for record in records:
        value = hashlib.sha256()
        count = 0
        if 'artifacts' in record:
            streams = [(target / part).open('rb') for part in record['artifacts']]
        else:
            streams = [archive.extractfile(record['member'])]
        for stream in streams:
            assert stream is not None
            with stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    value.update(chunk)
                    count += len(chunk)
        assert count == record['bytes'] and value.hexdigest() == record['sha256'], record['path']

manifest = {'scratchRoot': str(root), 'rawFiles': len(records),
            'terminalProcessRecords': len(processes), 'byteVerified': True,
            'archiveSha256': digest(target / 'raw.tar.gz'), 'files': records}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

receipt = {'scratchRoot': str(root), 'removedFiles': [], 'removedDirectories': [],
           'remainingPaths': [], 'failures': []}
for path in sorted(owned, key=lambda path: len(path.parts), reverse=True):
    relative = str(path.relative_to(root))
    try:
        if path.is_file():
            path.unlink()
            receipt['removedFiles'].append(relative)
        elif path.is_dir():
            path.rmdir()
            receipt['removedDirectories'].append(relative)
    except OSError as error:
        receipt['failures'].append({'path': relative, 'error': str(error)})
try:
    root.rmdir()
except OSError as error:
    receipt['failures'].append({'path': str(root), 'error': str(error)})
receipt['scratchAbsent'] = not root.exists()
if root.exists():
    receipt['remainingPaths'] = [str(path) for path in root.rglob('*')]
connection = socket.socket()
receipt['preview4464Closed'] = connection.connect_ex(('127.0.0.1', 4464)) != 0
connection.close()
(target / 'cleanup.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'retainedFiles': len(records), 'terminalProcesses': len(processes),
                  'removedFiles': len(receipt['removedFiles']),
                  'scratchAbsent': receipt['scratchAbsent'],
                  'preview4464Closed': receipt['preview4464Closed'],
                  'failures': receipt['failures']}))
assert receipt['scratchAbsent'] and not receipt['failures'] and receipt['preview4464Closed']

full=json.loads((target/'manifest.json').read_text())
with tarfile.open(target/'raw.tar.gz') as archive:
 def original(name):
  record=next(r for r in full['files'] if r['path']==name)
  return json.loads(archive.extractfile(record['member']).read())
 before=original('full-before.json')
 result=original('pulse-full-current.result.json')
 commit=original('committed-inputs.json')
 assert commit['sources']==before['sources']
 full_log_record=next(r for r in full['files'] if r['path']=='pulse-full-current.log')
 full_log=archive.extractfile(full_log_record['member']).read().decode()
 import re
 tests=re.search(r'Tests\s+(\d+) passed',full_log)
 files_count=re.search(r'Test Files\s+(\d+) passed',full_log)
 assert tests and files_count
 full_result=f"Full current-source run: **{int(tests.group(1)):,} tests passed / {files_count.group(1)} files**, with two existing skips ({result['seconds']} seconds process time). All {len(before['sources']):,} source/test/config hashes, {len(before['build'])} build hashes, HEAD/Git state and the genuine save digest stayed exact throughout. Commit {commit['head'][:7]} has the identical validated source hashes."
retention_result=f"The manifest retains {len(records)} original files and {len(processes)} terminal process records, all byte-verified. [Fixtures](fixtures/paladin-pulse-auras/) include original failures, scripts, successful outputs, input/build hashes, save attachments and screenshots."
cleanup_result=f"Cleanup removed {len(receipt['removedFiles'])} exact task-owned files, confirms scratch-root absence and preview4464 closure, and reports no failures or remaining paths. Shared caches and older campaign evidence remain."
report=draft.replace('FULL_RESULT',full_result).replace('RETENTION_RESULT',retention_result).replace('CLEANUP_RESULT',cleanup_result)
report=report.replace('FOCUSED_RESULT','Initial focused regression: 119 tests pass across eight files. After correcting the stale store expectation, 164 tests pass across nine files.').replace('ENGINE_RESULT','Engine regression: 6,131 tests pass across 209 files.')
report=report.replace('BROWSER_RESULT','All four browser cases pass. Twelve Save → close → new-page Continue pairs compare all five complete saved domains; an independent attachment audit repeats those checks. Forty geometry samples across 360×640, 412×915, 640×360, 1280×800 and 1920×1080 show no horizontal overflow and all fifteen radio labels at least 44×44. No captured page errors or production test bridge.')
assert not any(marker in report for marker in ['FULL_RESULT','FOCUSED_RESULT','ENGINE_RESULT','RETENTION_RESULT','CLEANUP_RESULT','BROWSER_RESULT'])
(worktree/'docs/plans/evidence/d05-paladin-pulse-auras.md').write_text(report)

# Reconcile only the two newly verified skill records after all evidence is retained.
import csv,io
inventory=worktree/'docs/plans/skill-inventory.csv'
lines=inventory.read_text().splitlines(keepends=True)
header=next(csv.reader([lines[0]]))
changed=[]
for index,line in enumerate(lines[1:],1):
    values=next(csv.reader([line])); row=dict(zip(header,values))
    if row['data_id'] not in ['skills-paladin-holy-fire','skills-paladin-holy-shock']: continue
    assert row['behavior_verification']=='unverified'
    fire=row['data_id']=='skills-paladin-holy-fire'
    row['adapter_route']='exclusive-selected-living-source-fire-pulse-burn-party-fire' if fire else 'exclusive-selected-living-source-lightning-pulse-party-lightning'
    row['declared_statuses']='burn' if fire else ''
    row['risk_flags']='earned-class-build-balance-open'
    row['behavior_verification']='bounded-functional;independent-acceptance-open'
    row['contract_evidence']='docs/plans/evidence/d05-paladin-pulse-auras.md'
    output=io.StringIO();csv.writer(output,lineterminator='\n').writerow([row[key] for key in header])
    lines[index]=output.getvalue();changed.append(row['data_id'])
assert len(changed)==2
new_inventory=''.join(lines)
rows=list(csv.DictReader(io.StringIO(new_inventory)))
assert len(rows)==213 and sum(row['behavior_verification']=='unverified' for row in rows)==162
assert sum(row['behavior_verification'].startswith('bounded-functional;') for row in rows)==49
assert sum(row['behavior_verification'].startswith('bounded-engine-functional;') for row in rows)==1
assert sum(row['behavior_verification']=='review-needed' for row in rows)==1
inventory.write_text(new_inventory)

short=commit['head'][:7]
ledger=worktree/'docs/plans/execution-ledger.md'
text=ledger.read_text()
card=f"| D05 Holy Fire/Holy Shock / BUG181 | two pulse effects locally implemented/verified; six distinct auras remain | Runtime {short}; JSON-owned 1s pulses, mitigated Fire Burn, source/death/tie/deadline/cap rules and RNG-neutral damage. Focused164/9, engine6131/209, full{tests.group(1)}/{files_count.group(1)} plus two existing skips; types/lint/build/bridge PASS. Production browser4/4,12 exact five-domain Continue pairs,40 geometry samples. [Evidence](evidence/d05-paladin-pulse-auras.md); all1233 inputs and760 build hashes, HEAD/Git and genuine Rite digest stayed exact. Raw evidence byte-verified; exact task cleanup complete,4464closed.213 IDs:162unverified/49bounded-functional/one bounded-engine-functional/one review-needed. Genuine campaign remainsL33/next402; earned balance, independent acceptance, remaining six aura mechanics, Baal/C2-C4/fullG0-G7 remain open. Local only. |\n"
marker='| --- | --- | --- |\n'
assert marker in text
text=text.replace(marker,marker+card,1)
text+=f"""

## D05 — Selected Holy Fire and Holy Shock / BUG181

Implementation `{short}` adds actual automatic fire/lightning pulses to the shared
selected wave projection. JSON owns 1000ms timing and 20 base damage; first pulse
waits a full interval. Fire produces canonical finite Burn at 10% of mitigated
pulse damage per second, floored/minimum1,3000ms/five-stack cap. Existing source
increases, combos, mitigation and exact-once death consequences remain shared.
Source periodic death prevents a tied pulse; pulse precedes surviving actions,
includes60000ms and never fabricates action-cap catch-up. No hit/crit/proc RNG,
mana/cast/action slot or save-version change. Both locales explain actual effects.

[Evidence](evidence/d05-paladin-pulse-auras.md): focused164/9, engine6131/209,
full{tests.group(1)}/{files_count.group(1)} plus two existing skips; final types/lint/build/bridge PASS.
All1233 source/test/config hashes,760 build hashes, HEAD/Git and the genuine
claimed Rite digest stayed exact through the full run. Browser4/4 and independent
attachment audit prove12 exact five-domain Continue pairs;40 geometry samples
check all15 radio labels. Original RED, stale support/radio assertions, lint and
auditor failures remain retained. Raw originals/process records are byte-verified;
exact task cleanup confirms scratch absence,4464closed and no remaining paths
or failures. Shared caches and older retained campaign evidence remain.

Only these two skill rows gain bounded-functional dispositions:213 IDs remain,
162unverified/49bounded-functional/one bounded-engine-functional/one review-needed.
The50 bounded records have different proof scopes. BUG181 remains open for
Sanctuary, Cleansing, Redemption, Prayer, Vigor and Concentration. Holy Shock's
base/timing are provisional local design defaults; earned balance and independent
acceptance remain open. GenuineL33/XP149261/23682gear/nextNormal402 is unchanged;
no campaign action or diagnostic-save promotion. Baal/C2-C4/fullG0-G7 and complete
privatev1 remain incomplete. Local only; umbrella goal/branch/worktree stay active.
"""
ledger.write_text(text)

bug=worktree/'production/bugs/BUG-181-paladin-aura-family-selection.md'
text=bug.read_text().replace('Status: Open; eight stat auras plus Holy Freeze/Conviction locally verified, eight distinct aura mechanics outstanding','Status: Open; fourteen selected auras locally verified in bounded scope, six distinct aura mechanics outstanding')
text=text.replace('Remaining eight: Holy Fire, Holy Shock, Sanctuary, Cleansing, Redemption, Prayer,','Remaining after that checkpoint: Holy Fire, Holy Shock, Sanctuary, Cleansing, Redemption, Prayer,')
text+=f"""

Third batch `{short}` adds actual selected Holy Fire and Holy Shock pulses and
canonical mitigated Fire Burn, with explicit JSON timing/base/Burn ownership,
source/death/tie/deadline/cap guards and no damage/proc RNG. Native allocation,
original-input replay, bilingual UI and savev22 selection pass. Full{tests.group(1)}/{files_count.group(1)}
plus two existing skips, engine6131/209, types/lint/build/bridge PASS; production
browser4/4,12 exact five-domain Continue pairs and40 geometry samples pass.
[Evidence and original failures](../../docs/plans/evidence/d05-paladin-pulse-auras.md).
Remaining six: Sanctuary, Cleansing, Redemption, Prayer, Vigor and Concentration.
Earned balance and independent whole-family acceptance remain open. Genuine
campaign save/next402 is unchanged; no actual campaign action occurred.
"""
bug.write_text(text)
print('Reconciled exactly two skill rows, current ledger card and open BUG181')

contract=worktree/'docs/plans/decisions/D05-paladin-aura-family-v1.md'
text=contract.read_text()
text=text.replace('Holy Fire/Shock require actual damage pulses; Sanctuary requires undead damage', 'Holy Fire/Shock now follow the pulse contract above and have [bounded local verification](../evidence/d05-paladin-pulse-auras.md). Sanctuary requires undead damage')
text=text.replace('data explicitly before implementation. Holy Freeze/Conviction follow the resolved', 'data explicitly before implementing their remaining mechanics. Holy Freeze/Conviction follow the resolved')
text=text.replace('and older descriptions disagree for these eight:', 'and older descriptions disagree for the remaining six:')
contract.write_text(text)
