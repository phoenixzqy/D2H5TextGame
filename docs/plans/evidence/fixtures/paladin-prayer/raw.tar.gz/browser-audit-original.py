from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
report=json.loads((root/'browser-report.json').read_text())
assert len(report['cases'])==4 and all(c['pass'] and not c['errors'] for c in report['cases'])
assert len(report['geometry'])==20 and not report['failures']
pairs=[]
for before in sorted(root.glob('*-before-*.json')):
 label,serial=before.stem.rsplit('-before-',1)
 after=root/(label+'-after-'+str(int(serial)+1)+'.json')
 a,b=json.loads(before.read_text()),json.loads(after.read_text())
 assert a['version']==b['version']==22
 keys=['player','inventory','map','mercs','formation']
 assert {k:a[k] for k in keys}=={k:b[k] for k in keys}
 selected=None if label.endswith('-none') else 'paladin.prayer'
 assert a['player'].get('selectedAuraId')==selected
 assert a['player']['skillLevels']=={'paladin.prayer':1}
 assert a['player']['skillPoints']==0 and a['player']['level']==1
 fresh=json.loads(next(root.glob(label.split('-prayer')[0].split('-none')[0]+'-fresh-*.json')).read_text())
 assert a['player']['derivedStats']==fresh['player']['derivedStats']
 assert a['inventory']==fresh['inventory'] and a['map']==fresh['map']
 for bad in ['statAura','auraHealing','nextAuraPulseAtMs']:
  assert bad not in json.dumps(a)
 pairs.append({'before':before.name,'after':after.name,'selection':selected,'domains':keys,
  'domainSha256':hashlib.sha256(json.dumps({k:a[k] for k in keys},sort_keys=True).encode()).hexdigest()})
assert len(pairs)==8
out={'pass':True,'pairs':pairs,'geometrySamples':len(report['geometry'])}
(root/'browser-domain-audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'pass':True,'exactFiveDomainContinuePairs':len(pairs),'geometrySamples':20}))
