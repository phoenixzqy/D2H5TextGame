Security check: pass
Scope: owner-authorized docs/plans D05 Prayer implementation; existing BUG-181 and selected-aura contracts.
Summary: deterministic local gameplay change; no credentials, network, permission, CI bypass, remote publication or diagnostic campaign promotion required.
Findings: none actionable.
Recommended next step: strict JSON and direct-engine metadata validation; preserve original earned save and existing worktree claim.

Plan review: ready
Prayer currently has authored lifeRegenPct but no HP consumer; selected-aura whitelist and pulse timeline provide the integration boundary. Add exact Prayer-only healing metadata to schema before JSON, copy/freeze into the existing shared projection, and settle actual HP healing on the existing wave-local timeline through the normal heal commit. Explicit local defaults: base20/5000ms and floor(base*(1+rank bonus)), not baseline Vitality regeneration or inferred turn timing. Test causal missing behavior first, then source/recipient authority, periodic death/ties/deadline/cap, alternate/invalid tuning, RNG/input immutability, public native allocation/replay/next-wave and bilingual persistence/layout. Existing savev22 already permits Prayer; do not add saved potency or bump schema. Full suite runs alone after inputs freeze; retain original failures and exact task cleanup. Independent/earned balance and whole-v1 acceptance stay open.
