from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
report=json.loads((root/'browser-report.json').read_text())
assert len(report['cases'])==4 and all(c['pass'] and not c['errors'] for c in report['cases'])
assert len(report['geometry'])==40 and not report['failures']
pairs=[]
for before in sorted(root.glob('*-before-*.json')):
 label,serial=before.stem.rsplit('-before-',1)
 after=root/(label+'-after-'+str(int(serial)+1)+'.json')
 a,b=json.loads(before.read_text()),json.loads(after.read_text())
 assert a['version']==b['version']==22
 keys=['player','inventory','map','mercs','formation']
 assert {k:a[k] for k in keys}=={k:b[k] for k in keys}
 selected=None if label.endswith('-none') else 'paladin.'+('holy-fire' if 'holy-fire' in label else 'holy-shock')
 assert a['player'].get('selectedAuraId')==selected
 for slug in ['holy_fire','holy_shock']:
  expected=0 if selected=='paladin.holy-fire' and slug=='holy_shock' else 1
  assert a['player']['skillLevels'].get('paladin.'+slug,0)==expected
 assert a['player']['skillPoints']==(1 if selected=='paladin.holy-fire' else 0)
 for bad in ['statAura','auraPulse','nextAuraPulseAtMs']:
  assert bad not in json.dumps(a)
 pairs.append({'before':before.name,'after':after.name,'selection':selected,'domains':keys,
  'domainSha256':hashlib.sha256(json.dumps({k:a[k] for k in keys},sort_keys=True).encode()).hexdigest()})
assert len(pairs)==12
out={'pass':True,'pairs':pairs,'geometrySamples':len(report['geometry'])}
(root/'browser-domain-audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'pass':True,'exactFiveDomainContinuePairs':len(pairs),'geometrySamples':40}))
