from pathlib import Path
import hashlib,json,tarfile,socket
root=Path(__file__).resolve().parent
assert root==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-paladin-prayer-6aqmrvh6') and not root.is_symlink()
owner=json.loads((root/'owner.json').read_text())
assert owner['task']=='D05 selected Paladin Prayer healing' and owner['root']==str(root)
assert owner['baseline']=='99b2363c01182746312de97c23ba405b06e6f21e'
wt=Path(owner['worktree']); target=wt/'docs/plans/evidence/fixtures/paladin-prayer'
assert wt==Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
assert not target.exists(), 'Never overwrite retained evidence'
for label in ['engine-current','types-current','lint-final','build-final','bridge-final','browser-final','browser-audit-final','full-current']:
 assert json.loads((root/(label+'.result.json')).read_text())['exit']==0,label
before=json.loads((root/'full-before.json').read_text());after=json.loads((root/'full-after.json').read_text())
assert before==after
assert json.loads((root/'committed-inputs.json').read_text())['sources']==before['sources']
assert json.loads((root/'source-commit-audit.json').read_text())['pass'] is True
assert json.loads((root/'final-browser/browser-domain-audit.json').read_text())['pass'] is True
processes=sorted(root.glob('*.process.json'))
for p in processes: assert p.with_name(p.name.replace('.process.json','.result.json')).is_file(),p
sock=socket.socket();assert sock.connect_ex(('127.0.0.1',4465))!=0;sock.close()
paths=sorted(root.rglob('*'));assert not any(p.is_symlink() for p in paths)
files=[p for p in paths if p.is_file() and p.relative_to(root).parts[0]!='build-final']
sha=lambda data:hashlib.sha256(data).hexdigest()
target.mkdir(parents=True);records=[];dedup={}
with tarfile.open(target/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for p in files:
  relative=str(p.relative_to(root));data=p.read_bytes();digest=sha(data)
  member=dedup.get(digest,relative)
  if digest not in dedup:archive.add(p,arcname=member,recursive=False);dedup[digest]=member
  records.append({'path':relative,'bytes':len(data),'sha256':digest,'artifact':'raw.tar.gz','member':member})
with tarfile.open(target/'raw.tar.gz') as archive:
 for r in records:
  data=archive.extractfile(r['member']).read();assert len(data)==r['bytes'] and sha(data)==r['sha256'],r['path']
manifest={'scratchRoot':str(root),'rawFiles':len(records),'terminalProcessRecords':len(processes),'byteVerified':True,
 'archiveSha256':sha((target/'raw.tar.gz').read_bytes()),'files':records}
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'retainedFiles':len(records),'terminalProcessRecords':len(processes),'byteVerified':True,'target':str(target)}))
