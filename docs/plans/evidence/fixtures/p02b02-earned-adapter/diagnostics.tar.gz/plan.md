# P02b02 — Isolated fresh earned acquisition execution

Revised for independent final plan approval; original preserved as plan-original.md. Dependency: accepted P02b01 parser/fingerprint
and P02b00 source-feasibility, feature c7df807.
Full private v1 remains active; C0–C4/G0–G7 are unaccepted. Root alone writes/runs
tests in already-claimed human worktree2; reviewers read only and preserve others.
No production src changes, native browser pilot,40-prep screening or tuning here.

## Scope and API

At most five harness/document source files: new earned-adapter.ts,
earned-adapter.test.ts, earned-state.ts and earned-playback.ts under
tests/sim/production/, plus append README. Small private helpers stay local;
the two helper modules separate complete observations/isolation from bounded
production playback, avoiding a monolithic action runner. Evidence/ledger later.
Preserve existing fixture/adapter/provenance/measure and package/config/scripts,
and the accepted earned-fixture parser/tests byte-for-byte.

One public synchronous runEarnedRecipeOnce(input:unknown,
{targetSeed:number,repetition:1|2}) returns one evidence-bearing attempt.
Parse against current production catalogs (actual flattened hire roster), require
targetSeed be a declared uint32 seed, reject invalid repetition. It executes once
only. P02b03 owns versioned provenance/report shape, repetitions/comparisons/CLI.
Reuse collectSourceState/assertSourceStable for before/after source+data identity;
do not pass fixturev2 to v1 buildRunProvenance or fabricate a provenance object.
Driver-before-dynamic-gameplay-import provenance remains P02b03 responsibility.

Expected action refusals and acquisition W1 loss/draw return status with partial
evidence and stop at the first failure; no later action or target run executes.
Malformed input, active caller run, structural invariants, source drift or cleanup
failure throw. Preserve original exception alongside cleanup failures using
AggregateError; returned refusals preserve every already-applied production step.

## Acceptance1 — isolation and observations

Reject an active production run before any mutation. Snapshot data plus original
methods for player,inventory,map,merc,formation,combat and meta stores; pity and
Date.now. Freeze Date.now to fixture clock before resetting meta; reset all seven
stores and pity, then create actual production Sorceress via createMockPlayer and
playerStore.setPlayer. No persistence subscribers are installed: dedicated Node
sim-contracts realm only, direct store imports, no store barrel/persistence init.
Never stop caller subscriptions; no public getter proves they are inactive.

On every success/refusal/error, finally abort only the task run and attempt every
store/pity/Date restoration even if one fails; verify source stability after
restoration. Date is restored even when store cleanup fails. Never reset the
process-global item allocator, production challenge counter or unknown processes.

Observations clone complete nonfunction domain state for player,inventory,merc,
map,meta and formation. Combat evidence separately retains opening teams, full
timed recording, raw outcome/final teams, presentation, cursor/completion,
terminal logical clock, advance result and raw/actual reward/progression values.
Capture creation; before/after every action; explicit checkpoints; before/after
each award; installed W2 before flee; after flee; pretarget and target terminal.
Persistent player resources are not combat carry. Presentation logs retain raw
random log IDs and are not claimed deterministic in P02b03.

## Acceptance2 — ordinary actions and bounded production playback

Execute ordered closed recipe commands through current production boundaries:
- Hire: actual enclosing roster act.unlockReqLevel (not merc.reqLevel), then
  hireMerc; retain returned result. L1 can legitimately hire L3 InnerSight.
- Skill: allocateSkillPoint once per requested point; record each result and
  observed rank/points. If pointN refuses, preserve earlier allocations and stop.
- Combo: current Sorceress template, active+learned rank+required level checked
  via alias-aware production helpers before permissive setComboOrder. Do not
  silently drop unavailable entries or reorder.
- Stats: allocateStatPoints(deltas,currentPlayer), require 'ok'; no refill/set.
- Gear: selector.defense means current computeStats(item).defense (displayed
  defense). Select only original items acquired during this attempt and still
  in backpack, matching exact base/rarity/slot/defense. Keep a separate acquisition
  journal ordered by awarded wave then raw item position; first-acquired never
  means current backpack order. Call equipItem/equipOnMerc, retain original ID,
  observed equipment/stats and production result; no synthetic fallback.
- Quest: reproduce UI available/prerequisite predicate and actual catalog false
  objectives via updateQuestProgress. No completion, reward or claim injection.
- Checkpoint: full cloned observed state only; never input hydration.

For one farm action, use Blood Moor manual with production-clock seed OMITTED,
explicit ordinals0..count−1, pity0; record actual returned handles/seeds/ordinals.
For each attempted W1, play its complete recorded events using production cursor
API and call advanceWaveOrFinish exactly once after terminal playback. Observe
actual W1 award once, independent of claimed win flags. On loss/draw return and
stop honestly; no retry, extra preparation, forced outcome or repair.

On W1 win, advance synchronously installs/precomputes W2. Retain abandoned W2
opening/carry/outcome evidence, then native flee sequence abortSubAreaRun,
setIdleTarget(undefined), reset pity,endCombat. Never play/finalize/award W2;
its precomputed outcome is not an attempted-wave failure. Fresh next preparation
composes from persistent stores as production does; no manual refill/carry write.

After all actions succeed, set canonical target map location and start ordinary
manual Den with declared targetSeed and recipe ordinal,pity0. Play/advance all
expected waves normally using native living-team/resource/status carry; observe
raw cooldown fields, documenting that effective scheduler timers reset for each
battle. Do not assert or implement effective cooldown continuity. Stop first
actual loss/draw. Retain all raw teams/events/rewards/actual deltas, terminal result and
source identity. Separate logical duration, summed UI hints and measured wall
runtime. No fixed victory, event-count-only assertion or global replay claim.

## Acceptance3 — frozen RED and small actual self-tests

Before implementation, independently review test source+genuine missing-module
RED. Preserve original assertions/failed attempts; independently review any
oracle amendment. Tests use fresh earned defaults and no acquisition state
injection. Sentinel caller state/mocks are permitted only to prove isolation or
error cleanup, clearly separated from earned gameplay claims.

Freeze one tiny1-preparation recipe at clock1792497600000,targetseed1:
hire InnerSight; allocate FireBolt1; set Fire combo; farm1 ordinal0; checkpoint
earned-after-one; allocate5Vitality; acceptDen; checkpointready. Source predicts
W1 win but test must observe it and fail honestly if false. No more farming or
build/seed fallback to make this pass. No promise of target Den win.

Independent copied-source conditional oracles from design/technical:
- acquisition productionclock seed2330410254; W1 seed349193407,8trashL2:
  6Fallen/2Quill,HP242..418,armor12/10,MR1. Installed W2 seed3062484588:
  9championL3,5Fallen/2Shaman/2Zombie,appendedFireBall.
- If W1 genuinely wins with hero alive: hero+160XP→L2 XP60/next565,
  +5stat/+1skill; InnerSight+120XP→L3 XP120/304.
- Persistent hero before spending HP120/128 MP102/106 ATK24 armor23 MR0;
  after5Vitality HP120/138 MP102/106 (no healing). Preserve raw combat carry
  separately; do not assert it equals persistent player resources.
- Quest inProgress,obj-clear-den/obj-return false,no reward claimed; flee leaves
  no active run,pity0,idle target absent,no area clear; retain only actual W1 award.
No source-derived loot count. Compare observed raw rewards with inventory/currency
and XP/merc deltas; no synthetic zero-loot success or oracle relaxation.

Tests: tiny complete actual run and first-loss/draw target termination; W1 once-only
award and W2 unplayed/unawarded; compare living prior outcome to every actually
installed next opening using production stat-refresh/status-clock-rebase rules.
Acquisition W2 carry is conditional on actual W1 win. Den positive multiwave
carry is conditional on actual progression; if tiny Den ends at W1, explicitly
report target carry unexercised and assert terminal/no later play or award.
Earned Den multiwave acceptance needs a later separately frozen recipe; native
carry source/tests are supporting evidence only. No extra farms/seeds/forced wins; caller seven-store/Date/pity full
restoration on success/refusal/thrown production action; rejection of caller active
run without aborting it; invalid seed/repetition/input no mutation; meta sentinel
cannot multiply acquisition XP; partial skill refusal; duplicate hire; real locked
roster act; learned/level combo refusal; stat overspend; missing earned gear;
duplicate quest acceptance; checkpoint independence. Test actual earned equipment
selection only if source-backed tiny loot contains a candidate; otherwise defer
positive equip to a separately reviewed recipe and prove deterministic pure
selection with clearly synthetic helper fixtures, never call it earned evidence.
No multi-seed screen or measurement distribution. Use spies only for bounded
structural/cleanup/source-drift errors, not to manufacture combat/award success.

Validation: focused then related, full U/T/L; no engine edits so E unnecessary,
no browser flow so browser acceptance not claimed. Guarded production B only
after tests/fingerprint consumers finish. Budgets unchanged, retain exact argv,
exit/time/assertions and overruns. Independent source/outcome review; compact
evidence and feature commit then exact RAW/dist/.vite cleanup after releases,
separate closing ledger. Keep overall worktree claimed and proceed P02b03.

Security assessment: local untrusted recipe validated first, no shell execution,
network,new permissions/dependencies,persistence/import/hydration. Actions only
invoke existing bounded production methods inside disposable dedicated Node realm.
Refusals fail closed with honest partial evidence; no policy/CI/hook bypass.
