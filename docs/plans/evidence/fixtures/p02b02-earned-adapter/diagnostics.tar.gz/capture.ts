import { writeFileSync } from 'node:fs';
import { runEarnedRecipeOnce } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/tests/sim/production/earned-adapter';
import type { EarnedFixture, EarnedAction } from '/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2/tests/sim/production/earned-fixture';
const FIRE = 'skills-sorceress-fire-bolt';
const MERC = 'mercs/act1-rogue-inner-sight';
const DEN = 'areas/act1-den-of-evil';
const QUEST = 'quests/act1-den-of-evil';
const CLOCK = 1792497600000;
const farm: EarnedAction = { kind: 'farm-first-waves',
  subAreaId: 'areas/act1-blood-moor', count: 1, firstChallengeOrdinal: 0 };
const tiny: EarnedFixture = {
  fixtureVersion: 2, id: 'earned-adapter-tiny',
  origin: { kind: 'new-character', classId: 'sorceress', name: 'Tiny Earned',
    policy: 'production-creation-defaults' },
  clockEpochMs: CLOCK, seeds: [1], acquisitionSeedPolicy: 'production-clock',
  actions: [
    { kind: 'hire-merc', mercId: MERC },
    { kind: 'allocate-skill', skillId: FIRE, points: 1 },
    { kind: 'set-combo', skillIds: [FIRE] }, farm,
    { kind: 'checkpoint', id: 'earned-after-one' },
    { kind: 'allocate-stats', deltas: { strength: 0, dexterity: 0, vitality: 5, energy: 0 } },
    { kind: 'accept-quest', questId: QUEST },
    { kind: 'checkpoint', id: 'ready' }
  ],
  scenario: { act: 1, subAreaId: DEN, mode: 'manual', challengeOrdinal: 1,
    idleEliteMisses: 0 }, mercPolicy: 'recipe-actions', summonPolicy: 'production-default'
};
const options = { targetSeed: 1, repetition: 1 as const };
const attempt=runEarnedRecipeOnce(tiny,options);
writeFileSync('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-root-earned-adapter-jghowem4/tiny-observed.json',JSON.stringify(attempt,(_key,value)=>value instanceof Map?{mapEntries:[...value]}:value,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:attempt.status,acquisition:attempt.actions.flatMap(a=>a.farms).map(f=>({seed:f.handle.runSeed,winner:f.waves[0]?.opening.outcome?.winner,xp:f.waves[0]?.actualDelta.xp,itemCount:f.waves[0]?.rawRewardDelta.items.length,abandoned:f.abandoned?.opening.currentWave})),target:attempt.target?.waves.map(w=>({index:w.index,winner:w.opening.outcome?.winner,advance:w.advanceResult,xp:w.actualDelta.xp})),carry:attempt.target?.carryCoverage,timings:attempt.timings}));
