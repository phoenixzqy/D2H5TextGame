import sys,subprocess,time,json
from pathlib import Path
root=Path(__file__).resolve().parent;name=sys.argv[1];command=sys.argv[2:];started=time.time()
with (root/(name+'.log')).open('w') as out:
 p=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,cwd='/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
 (root/(name+'.process.json')).write_text(json.dumps({'pid':p.pid,'command':command,'started':started}))
 code=p.wait()
result={'name':name,'pid':p.pid,'command':command,'exit':code,'seconds':round(time.time()-started,2)}
(root/(name+'.result.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result));print('\n'.join((root/(name+'.log')).read_text().splitlines()[-16:]));sys.exit(code)
