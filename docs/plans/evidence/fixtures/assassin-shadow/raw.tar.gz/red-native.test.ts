import { beforeEach, expect, it } from 'vitest';
import { createMockPlayer } from '@/features/character/createMockPlayer';
import { playerToCombatUnit } from './combatHelpers';
import { useInventoryStore } from './inventoryStore';
import { usePlayerStore } from './playerStore';
import { runBattleRecorded } from '@/engine/combat/combat';
import type { CombatUnit } from '@/engine/combat/types';

beforeEach(() => { useInventoryStore.getState().reset(); usePlayerStore.getState().reset(); });
const learned = { 'assassin.burst_of_speed': 1, 'assassin.fade': 1, 'assassin.venom': 1 };
function owner(skillLevels: Record<string, number> = {}) {
  return { ...createMockPlayer('Constructed shadow fixture', 'assassin'), level: 30, comboOrder: [], skillLevels };
}
it('applies learned Fade resistance points and magical dodge from fresh player composition', () => {
  const plain = playerToCombatUnit(owner()), actual = playerToCombatUnit(owner(learned));
  for (const type of ['physical', 'fire', 'cold', 'lightning', 'poison', 'arcane'] as const) {
    expect.soft(actual.stats.resistances[type]).toBe(plain.stats.resistances[type] + 2);
  }
  expect.soft(actual.stats.magicDodge).toBeCloseTo(plain.stats.magicDodge + .005, 12);
});
it('applies authored Venom poison increase without adding passive casts or resource refill', () => {
  const plain = playerToCombatUnit(owner()), actual = playerToCombatUnit(owner(learned));
  expect(actual.increasedDamagePct?.poison).toBeCloseTo(.03, 12);
  expect(actual.skillOrder).toEqual(plain.skillOrder);
  expect([actual.life, actual.mana]).toEqual([plain.life, plain.mana]);
});
it('produces actual poison from eligible basic hits instead of a marker-only passive', () => {
  const native = playerToCombatUnit(owner(learned));
  const hero: CombatUnit = { ...native, life: 10000, mana: 10000,
    stats: { ...native.stats, attack: 100, defense: 0, lifeMax: 10000, attackSpeed: 100, critChance: 0 } };
  const enemy: CombatUnit = { ...hero, id: 'poison-target', side: 'enemy', kind: 'monster', skillOrder: [],
    stats: { ...hero.stats, defense: 0, physDodge: 0, magicDodge: 0,
      resistances: { physical: 0, fire: 0, cold: 0, lightning: 0, arcane: 0, poison: 0 } },
    statuses: [{ id: 'stun', sourceId: 'fixture', remaining: -1, stacks: 1 }] };
  const snapshot = { seed: 7, playerTeam: [hero], enemyTeam: [enemy], maxRounds: 2,
    assassinVenom: { sourceHeroId: hero.id, rank: 1 } };
  const result = runBattleRecorded(snapshot);
  expect(result.events.some(e => e.kind === 'status' && e.statusId === 'poison' && e.target === enemy.id)).toBe(true);
});
