from pathlib import Path
import json,hashlib,tarfile,socket
root=Path(__file__).resolve().parent
assert root==Path('/home/felixzhao/.zai/profiles/anonymous/zai-temp/d2h5-assassin-shadow-y5kxjfgb') and not root.is_symlink()
repo=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
fixture=repo/'docs/plans/evidence/fixtures/assassin-shadow'
assert not fixture.exists(); fixture.mkdir()
verification=json.loads((root/'full-verification.json').read_text())
assert verification['exit']==0 and not verification['drift'] and verification['headUnchanged'] and verification['statusUnchanged']
processes=[]
for p in sorted(root.glob('*.process.json')):
 name=p.name.removesuffix('.process.json')
 result=root/('full-verification.json' if name=='full-npm' else name+'.result.json')
 assert result.exists(),p
 processes.append({'process':p.name,'result':result.name,**json.loads(result.read_text())})
assert not (root/'dist').exists() and socket.socket().connect_ex(('127.0.0.1',4459))!=0
files=[]
for p in sorted(root.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file(): files.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
archive=fixture/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for row in files: tar.add(root/row['path'],arcname=row['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers(); assert len(members)==len(files)
 for member,row in zip(members,files,strict=True):
  stream=tar.extractfile(member);assert stream is not None
  payload=stream.read();assert member.name==row['path'] and len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
r={'baseline':'2a1dc008fd1bb1b6381a07ee7777d7fd9eb8490f','scratch':str(root),
 'files':files,'fileCount':len(files),'terminalProcessRecords':processes,'archive':archive.name,
 'archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'allMembersByteVerified':True,'fullVerification':verification,'port4459Closed':True}
(fixture/'manifest.json').write_text(json.dumps(r,indent=2));print(json.dumps({'files':len(files),'processes':len(processes),'archiveBytes':r['archiveBytes']}))
