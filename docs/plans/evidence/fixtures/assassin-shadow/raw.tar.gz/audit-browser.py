from pathlib import Path
import json,base64,hashlib,socket
root=Path(__file__).resolve().parent;report=json.loads((root/'browser-report.json').read_text())
assert report['stats']['expected']==8 and all(report['stats'][k]==0 for k in ['skipped','unexpected','flaky'])
out=root/'browser-attachments';out.mkdir(exist_ok=False)
results=[];files=[]
def walk(suites):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for test in spec.get('tests',[]):
    assert test['status']=='expected' and len(test['results'])==1
    result=test['results'][0];assert result['status']=='passed' and result.get('retry',0)==0 and not result.get('errors')
    prefix=test['projectName']+'-'+spec['title'].split()[0]+'-'+spec['title'].split()[-1]
    for a in result.get('attachments',[]):
     payload=base64.b64decode(a['body']);extension='.png' if a['contentType']=='image/png' else '.json'
     p=out/(prefix+'-'+a['name']+extension);p.write_bytes(payload)
     files.append({'path':str(p.relative_to(root)),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
     if a['name']=='exact-Continue':
      d=json.loads(payload);assert d['errors']==[]
      fields=['player','inventory','map','mercs','formation']
      for field in fields: assert d['saved'][field]==d['loaded'][field],(prefix,field)
      results.append({'case':prefix,'exactFields':fields,'errors':d['errors']})
  walk(suite.get('suites',[]))
walk(report['suites']);assert len(files)==24 and len(results)==8
r={'cases':results,'attachments':files,'port4459Closed':socket.socket().connect_ex(('127.0.0.1',4459))!=0}
assert r['port4459Closed'];(root/'browser-audit.json').write_text(json.dumps(r,indent=2));print(json.dumps({'exactPairs':len(results),'attachments':len(files),'portClosed':r['port4459Closed']}))
