import subprocess,json,hashlib,time,sys
from pathlib import Path
root=Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
out=Path(__file__).resolve().parent

def state():
    paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=root).decode().split('\0')
    files={}
    for name in sorted(set(paths)):
        if not name: continue
        p=Path(name)
        if p.parts[0] in ['src','tests','scripts','.github'] or (len(p.parts)==1 and p.suffix in ['.ts','.json','.cjs','.js']):
            f=root/p
            if f.is_file(): files[name]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size}
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
      'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True),'files':files}
a=state();(out/'full-before.json').write_text(json.dumps(a,indent=2))
command=['npm','test','--','--reporter=dot'];start=time.time();p=subprocess.Popen(command,cwd=root)
(out/'full-npm.process.json').write_text(json.dumps({'pid':p.pid,'command':command,'started':start}))
code=p.wait();b=state();(out/'full-after.json').write_text(json.dumps(b,indent=2))
drift=[k for k in sorted(set(a['files'])|set(b['files'])) if a['files'].get(k)!=b['files'].get(k)]
result={'exit':code,'pid':p.pid,'seconds':round(time.time()-start,2),'files':len(a['files']),
'drift':drift,'headUnchanged':a['head']==b['head'],'statusUnchanged':a['status']==b['status']}
(out/'full-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result));
sys.exit(code if code else int(bool(drift or not result['headUnchanged'] or not result['statusUnchanged'])))
