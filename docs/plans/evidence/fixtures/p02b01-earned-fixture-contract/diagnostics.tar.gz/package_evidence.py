from pathlib import Path
import collections, gzip, hashlib, io, json, tarfile

raw = Path(__file__).parent
wt = Path('/home/felixzhao/.zai/profiles/anonymous/worktrees/D2H5TextGame-human-worktree-2')
dest = wt / 'docs/plans/evidence/fixtures/p02b01-earned-fixture-contract'
dest.mkdir(parents=True, exist_ok=True)
archive = dest / 'diagnostics.tar.gz'
entries = []
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for path in sorted(raw.iterdir()):
                if not path.is_file() or path.is_symlink():
                    raise RuntimeError(f'Unexpected artifact: {path}')
                data = path.read_bytes()
                info = tarfile.TarInfo(path.name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
                entries.append({'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})

commands = {}
for path in sorted(raw.glob('*.meta.json')):
    commands[path.name.removesuffix('.meta.json')] = json.loads(path.read_text())
reports = {}
for name in commands:
    path = raw / (name + '.json')
    if not path.exists():
        continue
    report = json.loads(path.read_text())
    if 'testResults' not in report:
        continue
    counts = collections.Counter(a['status'] for suite in report['testResults'] for a in suite['assertionResults'])
    reports[name] = {
        'success': report['success'], 'actualAssertions': dict(counts),
        'failedSuites': report['numFailedTestSuites'], 'todo': report['numTodoTests'],
        'aggregateTotal': report['numTotalTests'], 'aggregatePassed': report['numPassedTests']
    }
packet = {
    'task': 'P02b00/P02b01', 'status': 'final-evidence-review-pending',
    'inputHead': '1c55248935d1ae4b94c7359fe44581950f9279fa',
    'scope': 'Post-MR source feasibility; additive fresh-earned v2 parser and fingerprint only',
    'notAcceptance': ['acquisition execution', 'Den win', 'native browser pilot', 'screening', 'pacing', 'balance', 'campaign', 'C0-C4', 'G0-G7', 'full v1'],
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': entries},
    'sources': json.loads((raw/'final-source-identity.json').read_text()),
    'v1Baseline': json.loads((raw/'v1-baseline.json').read_text()),
    'commands': commands, 'reports': reports,
    'reviews': {name: json.loads((raw/(name+'.json')).read_text()) for name in ['plan-review', 'red-review', 'typeguard-amendment', 'source-review']},
    'disclosures': [
        'All missing-module RED runs execute only 35 old v1 assertions; no new assertion failures are claimed.',
        'Parser-stage filtered run has 148 actual passed and 14 intentionally skipped assertions; Vitest aggregate incorrectly reports all 162 passed. Final focused and full runs have zero skipped assertions.',
        'Initial noUncheckedIndexedAccess failure is preserved; independent approval covers only two test-presence guards plus parser optional access. Every original assertion and nested mutation is retained.',
        'Related 6.880s exceeds unchanged 5s budget; final full 49.832s exceeds unchanged 15s budget. Initial full 45.803s also exceeded it. Final U/T/L were concurrent and no performance-budget acceptance is claimed.',
        'Guarded production build passes; existing large-chunk and oversized manifest precache warnings remain. No browser evidence required or claimed for this parser-only slice.',
        'Producer and QA released all source/fingerprint consumers before guarded build; no test/build process remains.',
        'No src/config/package/v1 implementation edit, acquisition action execution, allocator reset, persistence hook, dependency, push, PR, merge or deployment.'
    ],
    'cleanup': {'state':'pending reviewer release', 'owner':'root', 'paths':[str(raw),str(wt/'dist'),str(wt/'node_modules/.vite')], 'preserve':['installed node_modules','source/history','durable packet/archive','overall claimed worktree']}
}
(dest/'packet.json').write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'archiveEntries':len(entries),'archiveBytes':archive.stat().st_size,'archiveSha256':packet['archive']['sha256'],'packetSha256':hashlib.sha256((dest/'packet.json').read_bytes()).hexdigest()}))
