# P02b01 — Fresh earned acquisition recipe contract

Draft for independent design/producer/QA plan review. Full v1 remains active.
P06d accepted0d21276; closing ledger1c55248. New capability, no existing runtime defect claim.
Root is the sole repository writer/test runner in claimed human worktree2.
Reviewers are read-only and must not revert others' work. No native pilot or screening under this child.

Security check: local strict parsing and hashing of untrusted JSON recipes only; no shell execution, imports/hydration of supplied state, persistence, network, credentials, new dependency or permissions. Reject closed-object extra fields to prevent stats/reward/state injection. All IDs must reference current production catalogs, not resolver fallbacks.

Architecture decision: additive fresh-earned fixturev2 starts at production creation and later replays explicit earned actions. Preserve strict FreshFixturev1/parser/hash/adapter/CLI behavior byte-for-byte. Historical P04a04c save checkpoints are comparison evidence only; no new hydration/legacy migration/import/allocator API. Producer P02-V2-ARCHITECTURE READY and game/technical source review support this route.

Own at most four source/document files: new tests/sim/production/earned-fixture.ts, new earned-fixture.test.ts, existing README.md (append v2 contract), and source-only feasibility evidence p02b00-post-mr-den-feasibility.md. Durable evidence/ledger later. Do not change src/**, existing fixture.ts, adapter.ts, provenance.ts, measure.test.ts, package/config/scripts. Input parser and fingerprint are complete useful capability; execution/reporting follow separately.

Acceptance1: Parse a bounded fresh Sorceress ActI Den recipe with explicit ordered actions and current production references, without imports, stores or mutations. Required strict top-level fields:
- fixtureVersion2; canonical slug id; origin{kind:new-character,classId:sorceress,name1..40,policy:production-creation-defaults}; finite safe clockEpochMs>=0;
- seeds1..8 distinct uint32, used for target Den runSeed; acquisitionSeedPolicy:production-clock (acquisition runSeed omitted under frozen Date, actual handle values recorded later);
- actions array1..32; scenario{act1,subAreaId:areas/act1-den-of-evil,mode:manual,challengeOrdinal:1..40,idleEliteMisses0}; mercPolicy:recipe-actions; summonPolicy:production-default.
Exactly one farm-first-waves action; scenario ordinal must equal its count. Explicit acquisition ordinals0..count-1; no hidden counter, implicit extra farming or target advancement. Counts1..40 permit a tiny adapter self-test and the separately reviewed40-prep recipe. Schema validation never claims the recipe can afford or win anything.

Closed action union (counts bound work, not injected totals):
- hire-merc{mercId}: production roster ID; future adapter validates actual UI level/roster eligibility and fields via hireMerc.
- allocate-skill{skillId,points:1..20}: canonical current Sorceress skill ID; actual available points/prereqs/rank checks left to production action.
- set-combo{skillIds:0..9 unique}: current active Sorceress skill IDs; future adapter also checks learned/rank/level before permissive store action.
- farm-first-waves{subAreaId:areas/act1-blood-moor,count:1..40,firstChallengeOrdinal:0}: exact bounded W1 settlement/W2 abort semantics below.
- allocate-stats{deltas:{strength,dexterity,vitality,energy}:integers0..25,positive sum<=25}: production transactional allocation, no stat set/refill.
- equip-earned{owner:hero|merc,mercId only for merc,slot:gloves|boots,selector:{baseId,rarity:normal,defense:nonnegativeinteger<=1000,selection:first-acquired}}: current base IDs, current compatible base slot; only original earned backpack items are selectable. Stable acquisition-order tie-break, no historical IDs or synthetic item payload. Merc owner requires referenced roster ID; canonical slot compatibility, actual ownership checked by later adapter.
- accept-quest{questId:quests/act1-den-of-evil}: current quest ID; later adapter uses available quest's actual false objectives through same production map action as UI, no arbitrary objectives/flags.
- checkpoint{id:canonical slug}: unique checkpoint names, full observed state output only; no input snapshot.
References passed explicitly from real production class/area/skill/merc/base/quest datasets. Reject missing/mismatched catalogs and foreign/unknown IDs; current catalog class/area relationships must agree. Return independent structuredClone, no coercion/defaults/removal of extra keys.

Acceptance2: fingerprintEarnedFixture hashes full validated fixture via existing canonicalJson/fingerprintEntries with fixture.json path, preserving array order and key-order independence. Action order, point allocation, gear selector, count, clock, seed, target and policy changes affect hash. It accepts typed EarnedFixture only, with no source/provenance fabrication. v1 sources/tests and hashes remain unchanged.

Acceptance3: Real-catalog contract tests cover valid full legal40-prep candidate and tiny1-prep form, independent cloning and no input mutation, all action forms, missing/extra fields at each nesting/variant, unknown/foreign/cross-act references, numeric bounds/coercion/duplicate/oversized seeds, action count bounds, missing/multiple farm action, ordinal mismatch, duplicate checkpoint, invalid gear owner/slot/base, invalid deltas and fingerprints. Independently review tests and genuine missing-module RED before implementing parser. Controls keep v1 rejecting v2/state overrides. Preserve original RED sources/results and approved amendments, if any.

Validation: focused sim-contract tests then related tests, full unit +typecheck+lint before handoff. No engine edit so E not required for this child. No browser screen/runtime output change so no browser acceptance claim; use guarded production build only if reviewer/repository requires it for this source-only harness slice. Existing budgets unchanged; retain exact argv/exit/times and any overrun. Do not run builds concurrently with fingerprint consumers. Compact evidence and feature/evidence commit, exact task-owned .vite/RAW cleanup after review release, separate ledger commit. Worktree stays claimed for fullv1.

Future card sequencing (NOT implemented/executed here):
P02b02 acquisition adapter +tests: reset/snapshot/restore all seven relevant stores including meta (readIdleBonus affects XP), Date and pity; source identity guard before/after, no production persistence subscribers. No global item allocator reset. Validate actual UI hire/combo/quest eligibility (hire uses loadMercHireRoster act.unlockReqLevel, not merc def.reqLevel; L1 hero may hire L3 InnerSight); execute production actions, stop on refusal/missing gear or attempted W1 loss/draw; no repair/fallback/extra prep. W1 playback+one advance synchronously installs W2; observe W1 award, then native flee abort/resetIdlePity/setIdleTarget(undefined)/endCombat. Preserve abandoned W2 opening without awarding/playing it or treating its computed outcome as attempted loss. Den uses ordinary carry/advances and stops first loss/draw. Preserve full raw events, hero/merc/equipment/map/resource/point checkpoints, actual awards and selected original IDs.
P02b03 report/driver: versioned current-head earned provenance, separate raw battle/reward/checkpoint equality and narrowly declared semantic top-level item-ID normalization; preserve raw IDs, expose differences honestly. Two repetitions/seed, no unconditional fullRawReplayEqual claim; logical/wall/UI hint times separated.
P02b04 tiny screening: separately freeze exactly one legal candidate, acquisition actions/clock/seed/gear oracle and limits after source feasibility reviewed. At most a tiny seed set, no native browser pilot/1000seed/campaign/balance/pacing acceptance. Results may fail honestly.
